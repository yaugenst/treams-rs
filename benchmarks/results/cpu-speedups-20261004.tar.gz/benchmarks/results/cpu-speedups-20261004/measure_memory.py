# /// script
# requires-python = ">=3.12"
# dependencies = ["numpy>=2.1,<3"]
# ///
"""Repeat isolated memory measurements without serializing timed outputs."""

import json
import statistics
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "scripts"))
import compare_builds as compare

folder = Path(__file__).resolve().parent
previous = json.loads((folder / "final-4threads.json").read_text())
names = list(previous["calls"]) + [
    "prepared-dipole-cluster-map-n32-l1-p4096-forward",
    "prepared-dipole-cluster-map-n32-l1-p4096-field-gradient",
]
trees = {"baseline": folder / "baseline", "candidate": folder / "stage6"}
result = {
    "recorded_at": datetime.now(UTC).isoformat(),
    "method": "Linux VmHWM in a fresh exec per tree, call and repeat; setup before growth measurement. Absolute peak includes imports and setup. No large output serialization in parent.",
    "supersedes": "Only memory_mib and memory_peak_mib in final-4threads.json: those inherited the driver ru_maxrss and are invalid. Its timings and numerical agreement remain valid.",
    "threads": 4,
    "cpu_affinity": compare.cpu_affinity(),
    "benchmark_sha256": compare.file_sha256(compare.__file__),
    "script_sha256": compare.file_sha256(__file__),
    "builds": {label: compare.provenance(tree) for label, tree in trees.items()},
    "calls": {},
}
for name in names:
    measurements = {label: [] for label in trees}
    for repeat in range(3):
        labels = list(trees) if repeat % 2 == 0 else list(reversed(trees))
        for label in labels:
            measurements[label].append(compare.measure_memory(trees[label], name, 4))
    result["calls"][name] = {
        label: {
            "samples": samples,
            "median_growth_mib": statistics.median(s["growth_mib"] for s in samples),
            "median_peak_mib": statistics.median(s["peak_mib"] for s in samples),
        }
        for label, samples in measurements.items()
    }
    print(name, result["calls"][name], flush=True)
(folder / "stage6-memory.json").write_text(json.dumps(result, indent=2) + "\n")
