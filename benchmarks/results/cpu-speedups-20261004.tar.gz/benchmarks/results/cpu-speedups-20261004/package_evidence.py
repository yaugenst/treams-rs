# /// script
# requires-python = ">=3.12"
# dependencies = []
# ///
"""Package the frozen pre-scheduling CPU evidence without rerunning measurements."""

import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

root = Path.cwd()
source = root / "benchmarks/results/local/cpu-speedups-20261004"
summary = json.loads((source / "summary.json").read_text())
identity = json.loads((source / "source-final.json").read_text())
prefix = "benchmarks/results/cpu-speedups-20261004"
public_path = root / f"{prefix}.tar.gz"
private_path = source / "publication-original.tar.gz"


def sha(data):
    return hashlib.sha256(data).hexdigest()


names = set(summary["evidence_sha256"]) | {
    "summary.json", "stage6-final.patch", "compare_builds-final.py",
    "final-4threads.json", "stage6-broad-4threads.json",
    "blas-idle-contention-diagnostic.json", "strong-cluster-crossover.log",
    "cluster-convergence.json", "mie-cutoff.json", "periodic-cutoff.json",
    "radial-qualification/summary.json", "radial-qualification/qualify.py",
    "build-stage6-final.log", "measure_memory.py", "strong_cluster_crossover.py",
    "summarize.py", "package_evidence.py",
}
original = {name: (source / name).read_bytes() for name in sorted(names)}
for name, expected in summary["evidence_sha256"].items():
    assert sha(original[name]) == expected, name
assert sha(original["stage6-final.patch"]) == identity["patch_sha256"]
assert sha(original["compare_builds-final.py"]) == identity["benchmark_harness"]["sha256"]
original["_harness.py"] = subprocess.check_output(
    ["git", "show", f"{identity['base_commit']}:scripts/_harness.py"], cwd=root
)
assert original["_harness.py"] == (root / "scripts/_harness.py").read_bytes()
test_name = "tests/scripts/test_memory_measurement.py"
test_bytes = (root / test_name).read_bytes()
assert sha(test_bytes) == identity["modified_files_sha256"][test_name]
original["test_memory_measurement.py"] = test_bytes

private_hosts = {
    document["host"]
    for name, data in original.items()
    if name.endswith(".json")
    and isinstance(document := json.loads(data), dict)
    and isinstance(document.get("host"), str)
}


def sanitize(text):
    text = text.replace(str(root), "<repository>")
    for host in private_hosts:
        text = text.replace(host, "<benchmark-host>")
    return text


distributed = {name: sanitize(data.decode()).encode() for name, data in original.items()}
numeric_count = 0


def check_json(before, after):
    global numeric_count
    assert type(before) is type(after)
    if isinstance(before, dict):
        assert before.keys() == after.keys()
        for key in before:
            check_json(before[key], after[key])
    elif isinstance(before, list):
        assert len(before) == len(after)
        for first, second in zip(before, after, strict=True):
            check_json(first, second)
    elif isinstance(before, str):
        assert sanitize(before) == after
    elif isinstance(before, float):
        assert before.hex() == after.hex()
        numeric_count += 1
    else:
        assert before == after
        numeric_count += 1


for name, data in original.items():
    if name.endswith(".json"):
        check_json(json.loads(data), json.loads(distributed[name]))
    assert str(root).encode() not in distributed[name]
    assert all(host.encode() not in distributed[name] for host in private_hosts)

readme = """# Frozen CPU comparison, 2026-10-04

This archive records the CPU changes before the later small-product scheduling
work. No measurement was rerun for publication. See the tracked qualification
record benchmarks/cpu-speedups-20261004.json and docs/performance/cpu-speedups.md.

Primary results: final-isolated-4threads.json (36 targeted cases),
final-isolated-broad-4threads.json (92 broader cases), and stage6-memory.json.
Thread screens, null controls and separately named rechecks retain every outcome.
summary.json is the original analysis, including all four memory-gate failures.

Superseded exploratory evidence is retained, not counted as final qualification:
final-4threads.json has invalid inherited-ru_maxrss memory; stage6-broad-4threads.json
used competing persistent workers. blas-idle-contention-diagnostic.json records
the same-build diagnosis under concurrent CI on disjoint cores, not a final
performance measurement. The strong-cluster failure log stays next to its
tighter-residual diagnostic; production tolerances were not changed.

source-final.json records the uncommitted measured source. stage6-final.patch
applies to 8bbcb87aaeaccd9293fc8c09eecb8727c37c4970. The untracked memory test is
provided separately as test_memory_measurement.py. Restore compare_builds-final.py
to scripts/compare_builds.py and _harness.py to scripts/_harness.py when replaying
the measured source. Other scripts are as-run snapshots; their original local
directory assumptions are retained. Rebuild package trees separately; native
binaries and virtual environments are intentionally absent.

manifest.json records original and distributed digests for every payload.
As-run fingerprints in original result/summary/source records are unchanged;
after privacy redaction use manifest.json's sanitized_sha256 for distributed
bytes. Redactions affect only the incidental repository path and private host
label. Tar owner/group, timestamps and gzip metadata are neutral. JSON numbers,
booleans, nulls, timing samples, outcomes and all other strings are preserved.
""".encode()
manifest = {
    "schema_version": 1,
    "scope": "Pre-scheduling CPU evidence; privacy-only distribution copies",
    "measurements_rerun": False,
    "base_commit": identity["base_commit"],
    "as_run_patch_sha256": identity["patch_sha256"],
    "as_run_native_sha256": identity["native_sha256"],
    "json_non_string_primitives_verified": numeric_count,
    "files": {
        name: {
            "sha256": sha(original[name]),
            "sanitized_sha256": sha(distributed[name]),
            "bytes": len(distributed[name]),
        }
        for name in sorted(original)
    },
}
for payload in (original, distributed):
    payload["README.md"] = readme
    payload["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()


def archive(payload):
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as tar:
            for name, data in sorted(payload.items()):
                info = tarfile.TarInfo(f"{prefix}/{name}")
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
    return stream.getvalue()


private_bytes, public_bytes = archive(original), archive(distributed)
private_path.write_bytes(private_bytes)
public_path.write_bytes(public_bytes)
with tarfile.open(fileobj=io.BytesIO(public_bytes), mode="r:gz") as tar:
    assert len(tar.getmembers()) == len(distributed)
    for member in tar:
        name = member.name.removeprefix(prefix + "/")
        assert member.uid == member.gid == member.mtime == 0
        assert member.uname == member.gname == ""
        assert tar.extractfile(member).read() == distributed[name]

compact_results = {
    name: {
        key: value for key, value in result.items() if key != "memory"
    } | {
        "peak_rss_mib": {
            label: measurement["median_peak_mib"]
            for label, measurement in result["memory"].items()
        }
    }
    for name, result in summary["selected_results"].items()
}
qualification = {
    "schema_version": 1,
    "kind": "Historical pre-scheduling CPU performance qualification",
    "recorded_at": summary["recorded_at"],
    "scope": summary["scope"],
    "source": {
        "baseline_tag": identity["release_tag"],
        "baseline_commit": identity["base_commit"],
        "baseline_sources_match_release": identity["baseline_numerical_and_python_sources_match_release"],
        "candidate": "Uncommitted stage6-final.patch on the baseline; predates scheduling changes",
        "patch_sha256": identity["patch_sha256"],
        "native_sha256": identity["native_sha256"],
        "benchmark_sha256": identity["benchmark_harness"]["sha256"],
        "full_identity": f"{prefix}/source-final.json",
    },
    "environment": {key: identity[key] for key in ("cpu", "platform", "python", "numpy", "rustc", "profile", "precision")},
    "measurement": summary["measurement"],
    "selected_results": compact_results,
    "performance_gates": summary["performance_gates"],
    "memory_gate": {
        "passed": False,
        "limit": "Candidate call growth <= 1.05 * baseline growth when baseline growth >= 16 MiB",
        "failures": {
            name: {
                label: {key: value for key, value in entry.items() if key != "samples"}
                for label, entry in entries.items()
            }
            for name, entries in summary["memory_tradeoff"]["failures"].items()
        },
        "explanation": summary["memory_tradeoff"]["explanation"],
        "scratch_bounds": summary["memory_tradeoff"]["scratch_bounds"],
    },
    "validation": summary["validation"],
    "additional_evidence": summary["additional_evidence"],
    "evidence_corrections": summary["evidence_corrections"],
    "limitations": summary["limitations"] + ["Predates later small-matrix-product scheduling; no timing attributed to that later implementation."],
    "evidence_archive": {
        "path": str(public_path.relative_to(root)),
        "sha256": sha(public_bytes),
        "bytes": len(public_bytes),
        "files": len(distributed),
        "manifest": f"{prefix}/manifest.json",
        "extract_from_repository_root": f"tar -xzf {public_path.relative_to(root)}",
        "privacy_provenance": "benchmarks/privacy-provenance.json",
    },
}
(root / "benchmarks/cpu-speedups-20261004.json").write_text(json.dumps(qualification, indent=2) + "\n")
privacy_path = root / "benchmarks/privacy-provenance.json"
privacy = json.loads(privacy_path.read_text())
artifact_path = str(public_path.relative_to(root))
assert all(item["path"] != artifact_path for item in privacy["artifacts"])
privacy["artifacts"].append({
    "path": artifact_path,
    "original_archive": str(private_path.relative_to(root)),
    "original_sha256": sha(private_bytes),
    "sanitized_sha256": sha(public_bytes),
    "operation": "Publish compact selected pre-scheduling CPU evidence; original distribution revision above does not apply to this new archive.",
    "source_base_commit": identity["base_commit"],
    "source_patch_sha256": identity["patch_sha256"],
    "measurements_rerun": False,
    "verification": {
        "json_non_string_primitives_checked": numeric_count,
        "payload_files": len(manifest["files"]),
        "archive_members": len(distributed),
        "all_other_strings_unchanged": True,
        "as_run_fingerprints_preserved": True,
        "archive_members_read_back_byte_identical": True,
        "neutral_archive_metadata": True,
        "removed": ["Incidental repository absolute path", "Private benchmark host label"],
    },
})
privacy_path.write_text(json.dumps(privacy, indent=2) + "\n")
print(json.dumps(qualification["evidence_archive"], indent=2))
print(f"Verified {numeric_count} non-string JSON primitives; originals unchanged.")
