# /// script
# requires-python = ">=3.13"
# dependencies = ["mpmath==1.3.0"]
# ///
"""Qualify a real-positive Hankel recurrence against independent 90-digit jets.

Run with `uv run --script qualify.py > summary.json`. This is accuracy evidence,
not a timing benchmark. No package code is imported or modified.
"""

import hashlib
import json
import math
from pathlib import Path
import random

import mpmath as mp


mp.mp.dps = 90
SEED = 721680
COEFFICIENTS = [
    [
        mp.mpf(math.factorial(degree + k))
        / math.factorial(k)
        / math.factorial(degree - k)
        / (2**k)
        * mp.j**k
        for k in range(degree + 1)
    ]
    for degree in range(66)
]


def polynomial_reference(x, degree):
    """Explicit finite Hankel polynomial; derivatives differentiate monomials."""
    z = mp.mpf(x)
    prefactor = (-mp.j) ** (degree + 1) * mp.exp(mp.j * z)
    powers = [z ** (-k - 1) for k in range(degree + 3)]
    coefficients = COEFFICIENTS[degree]
    return [
        prefactor * mp.fsum(coefficients[k] * powers[k] for k in range(degree + 1)),
        prefactor
        * mp.fsum(
            coefficients[k] * (mp.j * powers[k] - (k + 1) * powers[k + 1])
            for k in range(degree + 1)
        ),
        prefactor
        * mp.fsum(
            coefficients[k]
            * (
                -powers[k]
                - 2 * mp.j * (k + 1) * powers[k + 1]
                + (k + 1) * (k + 2) * powers[k + 2]
            )
            for k in range(degree + 1)
        ),
    ]


def cylindrical_reference(x, degree):
    """Independent cylindrical Hankel and arbitrary precision differentiation."""
    z = mp.mpf(x)

    def value(q):
        return mp.sqrt(mp.pi / (2 * q)) * mp.hankel1(mp.mpf(degree) + mp.mpf(".5"), q)

    return [value(z), mp.diff(value, z, 1), mp.diff(value, z, 2)]


def candidate(x):
    inverse = 1 / x
    previous = complex(math.cos(x) * inverse, math.sin(x) * inverse)
    current = complex(math.sin(x) * inverse, -math.cos(x) * inverse)
    values = [current]
    for degree in range(65):
        following = ((2 * degree + 1) * inverse) * current - previous
        values.append(following)
        previous, current = current, following
    for degree in range(65):
        value = values[degree]
        first = degree * (value / x) - values[degree + 1]
        second = -2 * (first / x) + degree * (degree + 1) * ((value / x) / x) - value
        yield value, first, second


rng = random.Random(SEED)
log_lower, log_upper = math.log(0.5), math.log(10000.0)
arguments = sorted(
    set(
        [math.exp(log_lower + i / 179 * (log_upper - log_lower)) for i in range(180)]
        + [0.5, math.nextafter(0.5, 1), 1, math.pi, 10000.0, math.nextafter(10000.0, 0)]
        + [
            max(0.5, degree * factor)
            for degree in range(1, 65)
            for factor in (0.5, 0.9, 1, 1.1, 2)
        ]
        + [degree + 0.5 for degree in range(65)]
        + [math.exp(rng.uniform(log_lower, log_upper)) for _ in range(500)]
    )
)
# Clamp the geometric grid's final exp(log(10000)) roundoff to the stated domain.
arguments = sorted(set(min(x, 10000.0) for x in arguments))
worst_jet_scaled = [{"error": 0.0} for _ in range(3)]
worst_component_relative = [{"error": 0.0} for _ in range(3)]
nonfinite = 0
maximum_magnitude = 0.0
for x in arguments:
    for degree, actual in enumerate(candidate(x)):
        expected = polynomial_reference(x, degree)
        size = sum(abs(v) for v in expected)
        for derivative, (a, e) in enumerate(zip(actual, expected)):
            nonfinite += not math.isfinite(abs(a))
            maximum_magnitude = max(maximum_magnitude, abs(a))
            for denominator, worst in (
                (size, worst_jet_scaled),
                (abs(e), worst_component_relative),
            ):
                error = float(abs(a - e) / denominator)
                if error > worst[derivative]["error"]:
                    worst[derivative] = {
                        "error": error,
                        "argument": x,
                        "degree": degree,
                    }

reference_rows = []
crosscheck_max = 0.0
for x, degree in [
    (0.5, 0),
    (0.5, 64),
    (64.0, 64),
    (56.7, 57),
    (10000.0, 0),
    (10000.0, 64),
]:
    direct = cylindrical_reference(x, degree)
    polynomial = polynomial_reference(x, degree)
    size = sum(abs(v) for v in direct)
    crosscheck_max = max(
        crosscheck_max,
        float(max(abs(a - b) / size for a, b in zip(direct, polynomial))),
    )
    reference_rows.append(
        {
            "argument": x,
            "degree": degree,
            "jets_real_imag": [[float(mp.re(v)), float(mp.im(v))] for v in direct],
        }
    )

# A separate SciPy AMOS diagnostic identified why a proposed regular/outgoing
# Wronskian test failed: the existing regular derivative was the inaccurate term.
# Recorded SciPy values are observations, not recomputed by this dependency-light
# script. Their errors and the current candidate's flux are recomputed below.
diagnostic_x, diagnostic_degree = 856.495946507376, 40
diagnostic_z = mp.mpf(diagnostic_x)


def diagnostic_regular(z):
    return mp.sqrt(mp.pi / (2 * z)) * mp.besselj(mp.mpf("40.5"), z)


regular_value = diagnostic_regular(diagnostic_z)
regular_first = mp.diff(diagnostic_regular, diagnostic_z)
observed_amos_value = 0.00023355205611227597
observed_amos_first = -0.0011436096691956822
diagnostic_value, diagnostic_first, _ = list(candidate(diagnostic_x))[diagnostic_degree]
diagnostic_flux = (diagnostic_value.conjugate() * diagnostic_first).imag
expected_flux = 1 / diagnostic_x**2
amos_diagnostic = {
    "provenance": "Separate SciPy half-integer jv AMOS diagnostic; recorded doubles checked here against 90-digit mpmath",
    "observed_scipy_version": "1.16.3",
    "argument": diagnostic_x,
    "degree": diagnostic_degree,
    "observed_amos_value": observed_amos_value,
    "observed_amos_first": observed_amos_first,
    "value_relative_error": float(
        abs(observed_amos_value - regular_value) / abs(regular_value)
    ),
    "first_relative_error": float(
        abs(observed_amos_first - regular_first) / abs(regular_first)
    ),
    "current_candidate_outgoing_flux": diagnostic_flux,
    "expected_outgoing_flux": expected_flux,
    "current_candidate_flux_relative_error": abs(diagnostic_flux - expected_flux)
    / expected_flux,
    "resolution": "Test the well-conditioned outgoing flux above the turning point; retain the regular/outgoing Wronskian below it, at the original 1e-13 tolerance.",
}

print(
    json.dumps(
        {
            "purpose": "accuracy qualification, not timing",
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "mpmath_version": mp.__version__,
            "reference_precision_decimal_digits": mp.mp.dps,
            "reference": "explicit finite spherical Hankel polynomial and differentiated monomials; cylindrical Hankel plus mp.diff cross-check",
            "random_seed": SEED,
            "random_argument_count": 500,
            "argument_count": len(arguments),
            "argument_range": [0.5, 10000.0],
            "degree_range": [0, 64],
            "jet_component_count": len(arguments) * 65 * 3,
            "jet_error_normalization": "abs(candidate-reference) / sum(abs(value), abs(first), abs(second))",
            "required_jet_scaled_tolerance": 1e-13,
            "worst_jet_scaled": worst_jet_scaled,
            "worst_complex_component_relative": worst_component_relative,
            "nonfinite_count": nonfinite,
            "maximum_candidate_magnitude": maximum_magnitude,
            "reference_crosscheck_max_jet_scaled": crosscheck_max,
            "reference_rows": reference_rows,
            "amos_regular_derivative_diagnostic": amos_diagnostic,
            "limitations": [
                "Empirical coverage is not a global proof of floating-point rounding bounds.",
                "Python prototypes the Rust formulas and inverse multiplications; it is not bitwise Rust proof (sin/cos and complex-division implementations may differ).",
                "Complex relative accuracy does not guarantee tiny regular J real components when irregular Y dominates.",
                "The implementation domain should remain real positive arguments and bounded degrees; complex, negative, and higher-order cases were not qualified.",
            ],
        },
        indent=2,
    )
)
