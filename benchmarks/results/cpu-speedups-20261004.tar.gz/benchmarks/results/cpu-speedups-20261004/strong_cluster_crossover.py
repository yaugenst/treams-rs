# /// script
# requires-python = ">=3.12"
# dependencies = ["numpy>=2.1,<3"]
# ///
"""Untuned, single-host crossover diagnostic for the exact strong CPU case.

Time complete fresh solves and solves with a retained operator/factor. Input
geometry and incident-wave construction are outside the timings. Numerical
agreement is checked before timing. This does not time physical pullbacks or
measure peak memory; it establishes the forward selected-LU crossover only.
Use --rtol to tighten the iterative residual without changing the fixed
componentwise agreement gate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import sys
import time


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", required=True, type=Path, help="Directory containing built treams_rs/")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--repeats", type=int, choices=(3, 4, 5), default=5)
    parser.add_argument("--rtol", type=float, default=1e-10)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_suffix(".json"))
    args = parser.parse_args()
    if args.threads < 1:
        parser.error("--threads must be positive")
    package = args.package.resolve()
    for name in ("TREAMS_RS_NUM_THREADS", "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ[name] = str(args.threads)
    sys.path.insert(0, str(package))
    import numpy as np
    import treams_rs as tr
    from treams_rs import _native
    from treams_rs.iterative import SphereCluster

    native = Path(_native.__file__).resolve()
    if not native.is_relative_to(package):
        raise RuntimeError(f"Wrong native library: {native}")
    if _native.build_profile() != "release":
        raise RuntimeError("The diagnostic requires a release extension")
    tr.set_num_threads(args.threads)

    n, lmax, columns, k0 = 32, 3, 8, 1.7
    side = math.ceil(n ** (1 / 3))
    positions = np.column_stack(np.unravel_index(np.arange(n), (side, side, side))) * 1.3
    positions += np.random.default_rng(617).uniform(-0.06, 0.06, positions.shape)
    radii = np.linspace(0.45, 0.52, n)
    epsilon = np.full(n, 8.0 + 0.1j)
    basis = tr.SphericalBasis.default(lmax, n, positions=positions)
    incident = np.column_stack([
        tr.plane_wave([0.13 + 0.07 * p, -0.11 + 0.03 * p, 1.0], p % 2, k0=k0).expand(basis)
        for p in range(columns)
    ])
    options = dict(rtol=args.rtol, atol=0.0, restart=30, max_iterations=300)
    names = ("matrix_free", "selected_lu")

    def prepare(name):
        if name == "matrix_free":
            return SphereCluster(lmax, k0, radii, epsilon, positions)
        return tr.diff.sphere_cluster_factor(lmax, k0, radii, epsilon, positions)

    def solve(name, prepared):
        return prepared.solve(incident, **options) if name == "matrix_free" else prepared.solve(incident)

    # Keep the setup object alive until after the timer stops, so destruction is
    # outside both methods' fresh timing, as it is outside their reuse timing.
    def fresh(name):
        prepared = prepare(name)
        return prepared, solve(name, prepared)

    retained = {name: prepare(name) for name in names}
    numerical = {name: solve(name, retained[name]) for name in names}
    iterative = numerical["matrix_free"]
    dense = np.asarray(numerical["selected_lu"])
    difference = iterative.coefficients - dense
    comparison = {
        "relative_l2_error": float(np.linalg.norm(difference) / np.linalg.norm(dense)),
        "max_absolute_error": float(np.max(np.abs(difference))),
        "agreement_rtol": 2e-9,
        "agreement_atol": 1e-12,
        "agrees": bool(np.allclose(iterative.coefficients, dense, rtol=2e-9, atol=1e-12)),
    }
    convergence = [dict(iterations=int(c.iterations), residual_norm=float(c.residual_norm),
                        rhs_norm=float(c.rhs_norm), relative_residual=float(c.residual_norm / c.rhs_norm))
                   for c in iterative.convergence]
    if not comparison["agrees"]:
        raise RuntimeError(f"Solvers disagree before timing: {comparison}")

    # Warm fresh construction as well as the retained-factor solves above.
    for name in names:
        warm = fresh(name)
        del warm
    timings = {name: {"fresh_seconds": [], "reuse_seconds": []} for name in names}
    for repeat in range(args.repeats):
        order = names if repeat % 2 == 0 else names[::-1]
        for phase in ("fresh", "reuse"):
            for name in order:
                start = time.perf_counter()
                answer = fresh(name) if phase == "fresh" else solve(name, retained[name])
                elapsed = time.perf_counter() - start
                timings[name][f"{phase}_seconds"].append(elapsed)
                del answer
    for measurement in timings.values():
        for phase in ("fresh", "reuse"):
            measurement[f"{phase}_median_seconds"] = statistics.median(measurement[f"{phase}_seconds"])
    speedup = {
        phase: timings["matrix_free"][f"{phase}_median_seconds"] / timings["selected_lu"][f"{phase}_median_seconds"]
        for phase in ("fresh", "reuse")
    }
    result = {
        "package": str(package), "native_file": str(native),
        "native_sha256": hashlib.sha256(native.read_bytes()).hexdigest(),
        "diagnostic_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python": sys.version, "numpy": np.__version__, "threads": tr.get_num_threads(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)), "repeats": args.repeats,
        "geometry": dict(particles=n, lmax=lmax, columns=columns, k0=k0,
                         radius_range=[0.45, 0.52], epsilon=[8.0, 0.1], grid_side=side,
                         spacing=1.3, jitter_seed=617, jitter_interval=[-0.06, 0.06]),
        "positions_sha256": hashlib.sha256(positions.tobytes()).hexdigest(),
        "incident_sha256": hashlib.sha256(incident.tobytes()).hexdigest(),
        "options": options, "comparison": comparison, "forward_convergence": convergence,
        "timings": timings, "selected_lu_speedup_over_matrix_free": speedup,
        "timing_scope": "Same process, alternating backend order each repeat, warmed. Fresh includes native setup and requested-column solve. Reuse retains the operator or LU. Common geometry/incident construction and result destruction excluded. No gradient or peak-memory measurements.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"comparison": comparison, "timings": timings,
                      "selected_lu_speedup_over_matrix_free": speedup,
                      "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
