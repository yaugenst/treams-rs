# /// script
# requires-python = ">=3.12"
# dependencies = []
# ///
"""Consolidate final CPU evidence without changing any raw result."""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

folder = Path(__file__).resolve().parent


def read(name):
    return json.loads((folder / name).read_text())


def gate(name):
    result = read(name)
    return {
        "file": name,
        "cases": len(result["calls"]),
        "passed": sum(c["passed"] for c in result["calls"].values()),
        "failed": [n for n, c in result["calls"].items() if not c["passed"]],
        "numerical_failures": [n for n, c in result["calls"].items() if not c["agrees"]],
        "maximum_relative_difference": max(c["relative_difference"] for c in result["calls"].values()),
    }


primary = read("final-isolated-4threads.json")
memory = read("stage6-memory.json")
source = read("source-final.json")
files = [
    "source-final.json", "final-isolated-4threads.json",
    "final-isolated-broad-4threads.json", "stage6-memory.json",
    "final-broad-outlier-recheck.json", "null-broad-outliers.json",
    "final-stack-32threads-recheck.json", "null-stack-32threads.json",
    "small-stack-native-thread-budget.json",
    "null-isolated-4threads.json", "ci-stage6-final.log",
    "strong-cluster-crossover-1e12.json",
    "illumination-stage6-n512-p8.json", "illumination-stage6-n1024-p8.json",
    *[f"final-isolated-{n}threads.json" for n in (1, 16, 32)],
]
selected = [
    "iterative-n512-l1-p1-forward",
    "iterative-n512-l1-p8-forward",
    "iterative-n512-l1-p8-gradient",
    "iterative-n32-l3-p8-forward",
    "prepared-dipole-cluster-map-n32-l1-p4096-forward",
    "prepared-dipole-cluster-map-n32-l1-p4096-field-gradient",
    "mie-nearfield-l12-p4096-forward",
    "mie-nearfield-l12-p4096-gradient",
    "periodic-array-n4-l6-size1-forward",
    "periodic-array-n4-l6-size1-gradient",
    "slab-internal-h1024-forward",
    "slab-internal-h1024-gradient",
]
results = {}
for name in selected:
    call = primary["calls"][name]
    results[name] = {
        "baseline_seconds": call["baseline_seconds"],
        "candidate_seconds": call["candidate_seconds"],
        "paired_median_speedup": 1 / call["ratio"],
        "speedup_range": [1 / call["ratio_range"][1], 1 / call["ratio_range"][0]],
        "relative_difference": call["relative_difference"],
        "memory": memory["calls"][name],
    }
memory_failures = {
    name: item for name, item in memory["calls"].items()
    if item["baseline"]["median_growth_mib"] >= 16
    and item["candidate"]["median_growth_mib"] > 1.05 * item["baseline"]["median_growth_mib"]
}
for name in files:
    if name.startswith("final-isolated") and name.endswith(".json"):
        result = read(name)
        assert result["candidate"]["native_sha256"] == source["native_sha256"]
        assert result["benchmark_sha256"] == source["benchmark_harness"]["sha256"]
summary = {
    "recorded_at": datetime.now(UTC).isoformat(),
    "status": "CPU implementation and local validation complete; no publication",
    "source": "source-final.json",
    "scope": "CPU only; matched complex128/f64, tolerances and inputs against rebuilt v0.1.0 numerical/Python sources on Ryzen 9 9950X Linux",
    "measurement": {
        "primary_threads": 4, "primary_cpu_affinity": [8, 9, 10, 11],
        "primary_rounds": 7, "samples_per_round": 3,
        "minimum_sample_seconds": 0.06,
        "worker_policy": "Fresh sequential processes per tree/call, ABBA ordering; no competing idle BLAS worker and no modified BLAS policy",
        "gradient_scope": "Gradient timings include their forward calculation and analytic pullbacks. Cluster incident construction is outside timing; field maps use prepared scattering coefficients; slab internal fields use prepared slab matrices.",
    },
    "selected_results": results,
    "performance_gates": {
        "targeted": gate("final-isolated-4threads.json"),
        "broader": gate("final-isolated-broad-4threads.json"),
        "broader_outlier_rechecks": gate("final-broad-outlier-recheck.json"),
        "same_build_outlier_controls": gate("null-broad-outliers.json"),
        "broader_adjudication": "Four short-run timing failures remain in the original 92-case report. Identical-build controls passed with longer batches; all four baseline/candidate rechecks then passed at seven rounds, five samples and minimum 0.15 seconds per sample. The small 64-mode stack still has about 60 microseconds overhead (paired median +6.1 percent), within the unchanged 10 percent submillisecond limit. Do not describe this as proof of zero regressions.",
        "thread_counts": {str(n): gate(f"final-isolated-{n}threads.json") for n in (1, 16, 32)},
        "thread32_outlier_control": gate("null-stack-32threads.json"),
        "thread32_outlier_recheck": gate("final-stack-32threads-recheck.json"),
        "thread32_adjudication": "All 16 targeted optimization cases pass. The extra 64-mode stack timing fails in the short screen; both its same-build control and longer baseline/candidate recheck pass at seven rounds, five samples, minimum 0.3 seconds. The longer paired ratio is 1.036. Original failure is preserved.",
    },
    "memory_tradeoff": {
        "decision": "Retain significant speedups with bounded temporary storage; report memory gate failures explicitly",
        "threshold_unchanged": True, "maximum_growth_ratio": 1.05,
        "gate_status": "failed", "failures": memory_failures,
        "explanation": "Eight independent Krylov spaces add roughly 5 MiB of call growth in the measured 512-dipole case. Periodic l6 gradients add 4.7-6.3 MiB growth and 2-4 MiB total peak. Parallel gathered cotangents explain up to 4.22 MiB extra for 16 blocks, plus bounded per-group Ewald caches; this is source-based attribution, not an allocation profile.",
        "scratch_bounds": "At most eight simultaneous Krylov spaces. Periodic gathers normally at most 32 MiB per batch, except one oversized block. Real Ewald cache at most 1024 points per active group; reciprocal cache at most floor(1024/(l+2)) points. These are scratch bounds, not total RSS bounds.",
    },
    "validation": source["validation"],
    "additional_evidence": {
        "native_dense_comparison": "512-dipole eight-column forward and physical pullbacks agree with native full-T reference to at most 3.06e-12 at iterative rtol=1e-10",
        "convergence_and_cutoffs": ["cluster-convergence.json", "mie-cutoff.json", "periodic-cutoff.json"],
        "hankel": "Rust reference, identity and gradient tests plus six 90-digit goldens; separate matching-formula Python qualification covers 184,860 components with maximum jet-scaled error 7.23e-15. The Python sweep is not a bitwise Rust qualification.",
        "small_strong_cluster": "At tightened rtol=1e-12 (unchanged agreement gate), selected dense LU is about 5x faster fresh and 71x faster reused than matrix-free for N=32, lmax=3, eight columns. At default rtol=1e-10 a strict componentwise diagnostic gate failed on small coefficients; failure and original script preserved. Production tolerances were not changed.",
    },
    "evidence_corrections": [
        "final-4threads.json memory entries inherit the driver ru_maxrss and are invalid; stage6-memory.json supersedes those entries using Linux VmHWM.",
        "Earlier persistent-worker timings are retained as exploratory evidence. Same-build control proved idle BLAS contention; final-isolated reports use corrected worker isolation and measured-duration calibration. Earlier failures remain in their original files.",
    ],
    "limitations": [
        "Performance measured on one Linux Ryzen host; no macOS or Windows performance validation.",
        "Full historical 1,300-case benchmark grid not replayed.",
        "Existing two ignored Rust tests and 22 skipped Python dtype/alias cases remain.",
        "The 1,024-particle diagnostic skips dense/upstream comparisons above their existing size limits; no same-size independent dense accuracy claim.",
        "Additional 16 field-contract seeds were run before stage6 on the unchanged high-order field path; final full CI and stage6-specific field checks cover the final tree.",
    ],
    "next_cpu_opportunity": {
        "topic": "Bound worker counts for small dense products",
        "evidence": "small-stack-native-thread-budget.json",
        "native_budget_median_seconds": read("small-stack-native-thread-budget.json")["median_seconds"],
        "interpretation": "The same prepared 64-mode stack/power call takes about 19.5 ms at 32 native threads and 0.70 ms at four, with BLAS held at one and identical output bits. Its 14 small dense products exceed the current work threshold and receive the full native budget, while LU is already limited. This is an existing thread-configuration opportunity; automatic matrix-product scheduling was not changed in this implementation.",
    },
    "git": {"committed": False, "pushed": False, "pr_state_or_comments_changed": False},
    "evidence_sha256": {name: hashlib.sha256((folder / name).read_bytes()).hexdigest() for name in files},
}
(folder / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary["performance_gates"], indent=2))
