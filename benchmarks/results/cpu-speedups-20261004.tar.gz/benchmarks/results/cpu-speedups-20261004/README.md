# Frozen CPU comparison, 2026-10-04

This archive records the CPU changes before the later small-product scheduling
work. No measurement was rerun for publication. See the tracked qualification
record benchmarks/cpu-speedups-20261004.json and docs/performance/cpu-speedups.md.

Primary results: final-isolated-4threads.json (36 targeted cases),
final-isolated-broad-4threads.json (92 broader cases), and stage6-memory.json.
Thread screens, null controls and separately named rechecks retain every outcome.
summary.json is the original analysis, including all four memory-gate failures.

Superseded exploratory evidence is retained, not counted as final qualification:
final-4threads.json has invalid inherited-ru_maxrss memory; stage6-broad-4threads.json
used competing persistent workers. blas-idle-contention-diagnostic.json records
the same-build diagnosis under concurrent CI on disjoint cores, not a final
performance measurement. The strong-cluster failure log stays next to its
tighter-residual diagnostic; production tolerances were not changed.

source-final.json records the uncommitted measured source. stage6-final.patch
applies to 8bbcb87aaeaccd9293fc8c09eecb8727c37c4970. The untracked memory test is
provided separately as test_memory_measurement.py. Restore compare_builds-final.py
to scripts/compare_builds.py and _harness.py to scripts/_harness.py when replaying
the measured source. Other scripts are as-run snapshots; their original local
directory assumptions are retained. Rebuild package trees separately; native
binaries and virtual environments are intentionally absent.

manifest.json records original and distributed digests for every payload.
As-run fingerprints in original result/summary/source records are unchanged;
after privacy redaction use manifest.json's sanitized_sha256 for distributed
bytes. Redactions affect only the incidental repository path and private host
label. Tar owner/group, timestamps and gzip metadata are neutral. JSON numbers,
booleans, nulls, timing samples, outcomes and all other strings are preserved.
