# Single-layer antireflection coating design

## Physical setup

A single lossless dielectric coating layer sits on top of a semi-infinite
substrate, with vacuum on the negative-z (incident) side and the substrate
extending on the positive-z side with no intervening vacuum gap. A plane wave
is normally incident from -z. The task is to choose the coating thickness
that minimizes the reflected power fraction at the design wavelength.

## Units and conventions

- Lengths (`wavelength`, `thickness`, `bounds`) are in micrometers.
- `epsilon` and `substrate_epsilon` are relative permittivities (dimensionless);
  `mu = 1` and `chirality = 0` throughout (non-magnetic, achiral, lossless media).
- The vacuum wavenumber is `k0 = 2*pi/wavelength`.
- `treams_rs.PlaneWavePorts.default([0, 0])` builds the normal-incidence
  (kx=ky=0) plane-wave port basis with both polarization channels.
- `treams_rs.slab` / `treams_rs.advect.slab` build the coating as one
  homogeneous layer between named exterior media (`negative_medium=1.0` for
  vacuum, `positive_medium=substrate_epsilon` for the substrate); this
  directly encodes "no vacuum gap after the coating."
- `SMatrix.power([0, 1], side="negative")` gives the power balance for
  positive-helicity incidence from the negative (vacuum) side; `reflection`
  is the reported power reflection coefficient R.

## Numerical method

Reflection R(thickness) and its exact derivative dR/dthickness are obtained
from `treams_rs.advect`, which wraps the native Rust scattering computation
with a reverse-mode (autodiff) pullback (`advect.value_and_grad`). No
closed-form quarter-wave formula, and no finite-difference derivative, is
used to compute R or its gradient or to take optimization steps.

Optimization is projected gradient descent with Armijo-style backtracking
line search: at each step the trial thickness `thickness - step * gradient`
is clipped to `bounds`, and the step size is halved until the reflection
strictly decreases (or the projected point stops changing, indicating a
bound is active). The loop stops when `reflection < 1e-7` or no further
decrease is possible within `bounds`. `loss_history` records the reflection
value evaluated at each accepted iterate, starting from `initial_thickness`.

## Correctness checks

- The analytic (autodiff) gradient was cross-checked against a central
  finite difference (`h = 1e-6`) at several thicknesses; they agree to
  ~9 significant digits, confirming the pullback is correct without using
  finite differences to drive the optimizer.
- For the example config (`epsilon = 2.25`, `substrate_epsilon = 5.0625`),
  the classic quarter-wave index-matching condition
  `epsilon_coating = sqrt(substrate_epsilon)` happens to hold
  (`sqrt(5.0625) = 2.25`), so a near-zero-reflection thickness exists inside
  `bounds`; the optimizer reaches `reflection < 1e-7` there without that
  formula ever being evaluated in the code.
- When the coating/substrate indices are not quarter-wave matched, or when
  the optimal thickness falls outside `bounds`, the optimizer instead
  converges to the true constrained minimum (verified by comparison against
  a bound-respecting scan), rather than forcing an unphysical `<1e-7` result.

## Example result (`results.json`)

For the given example config, the optimizer starts at
`initial_thickness = 0.05` um with `initial_reflection ≈ 0.0959` and
converges to `thickness ≈ 0.1167` um with `reflection ≈ 6.6e-8` and a small
final gradient magnitude (`≈ 2.9e-3`), well inside `bounds = [0.025, 0.21]`.
