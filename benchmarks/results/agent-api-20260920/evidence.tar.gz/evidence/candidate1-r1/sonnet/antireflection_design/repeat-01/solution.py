"""Gradient-based single-layer antireflection coating design using treams-rs (advect adapter)."""
import json
import math
import sys

import advect as ad
import treams_rs as t
import treams_rs.advect as tr


def _reflection_and_grad(basis, k0, epsilon, substrate_epsilon, thickness):
    def objective(d):
        sm = tr.slab(
            basis=basis,
            k0=k0,
            thickness=d,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        pb = sm.power([0, 1], side="negative")
        return pb.reflection

    value, grad = ad.value_and_grad(objective)(thickness)
    return float(value), float(grad)


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    thickness = float(config["initial_thickness"])
    lo, hi = (float(config["bounds"][0]), float(config["bounds"][1]))

    k0 = 2 * math.pi / wavelength
    basis = t.PlaneWavePorts.default([0, 0])

    thickness = min(max(thickness, lo), hi)

    initial_reflection, grad = _reflection_and_grad(
        basis, k0, epsilon, substrate_epsilon, thickness
    )

    loss_history = [initial_reflection]
    reflection = initial_reflection
    step = 0.01 * (hi - lo)
    max_iters = 500
    tol = 1e-7

    for _ in range(max_iters):
        if reflection < tol:
            break
        reflection, grad = _reflection_and_grad(
            basis, k0, epsilon, substrate_epsilon, thickness
        )
        loss_history.append(reflection)
        if reflection < tol:
            break

        # Backtracking line search on the projected gradient step.
        trial_step = step
        accepted = False
        for _ in range(60):
            candidate = min(max(thickness - trial_step * grad, lo), hi)
            candidate_reflection, _ = _reflection_and_grad(
                basis, k0, epsilon, substrate_epsilon, candidate
            )
            if candidate_reflection < reflection or candidate == thickness:
                accepted = True
                break
            trial_step *= 0.5
        if not accepted or candidate == thickness:
            break
        thickness = candidate
        reflection = candidate_reflection
        step = trial_step * 1.5

    reflection, grad = _reflection_and_grad(
        basis, k0, epsilon, substrate_epsilon, thickness
    )
    loss_history.append(reflection)

    return {
        "thickness": thickness,
        "reflection": reflection,
        "initial_reflection": initial_reflection,
        "gradient": grad,
        "loss_history": loss_history,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
