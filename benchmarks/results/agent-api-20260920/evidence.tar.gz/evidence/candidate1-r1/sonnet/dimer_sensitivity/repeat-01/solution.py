import json
import sys

import numpy as np
import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _build_objective(radius, epsilon, wavelength, lmax, point):
    k0 = 2 * np.pi / wavelength
    material = tr.Material(epsilon=complex(epsilon[0], epsilon[1]))
    point_arr = np.asarray([point], dtype=float)

    def objective(separation):
        sphere = tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
        half = separation / 2
        zero = anp.asarray(0.0)
        positions = anp.stack([
            anp.stack([-half, zero, zero]),
            anp.stack([half, zero, zero]),
        ])
        cluster = tr.Cluster([sphere, sphere], positions=positions)
        incident = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
        scattered = cluster.scatter(incident)
        e_total = incident.efield(point_arr) + scattered.efield(point_arr)
        return anp.sum(anp.abs(e_total) ** 2)

    return objective


def run(config):
    radius = config["radius"]
    epsilon = config["epsilon"]
    separation = config["separation"]
    wavelength = config["wavelength"]
    lmax = config["lmax"]
    point = config["point"]

    objective = _build_objective(radius, epsilon, wavelength, lmax, point)
    value, gradient = ad.value_and_grad(objective)(np.asarray(float(separation)))

    return {
        "value": float(value),
        "gradient": float(gradient),
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
