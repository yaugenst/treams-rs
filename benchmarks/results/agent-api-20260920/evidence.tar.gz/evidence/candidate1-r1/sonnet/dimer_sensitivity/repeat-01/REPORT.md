# Dimer field-intensity sensitivity to separation

## Physical setup

Two identical homogeneous, non-magnetic, achiral spheres in vacuum are placed
on the x-axis at `(-separation/2, 0, 0)` and `(+separation/2, 0, 0)`, and
illuminated by a plane wave of positive helicity travelling along `+z`
(direction `[0, 0, 1]`, unit amplitude). Multiple scattering between the two
spheres is fully included by solving the coupled cluster T-matrix problem
(`treams_rs.advect.Cluster.scatter`), which internally assembles both
particles' single-sphere T-matrices, couples them through the vacuum
translation operators, and solves `(I - T C) X = T` for the requested
illumination.

At the fixed observation `point`, the reported quantities are

- `value = sum(|E_total|**2)`, where `E_total = E_incident + E_scattered`
  is the complex electric field vector (3 components) at `point`, and the
  sum runs over the three Cartesian components. This is a common local
  "field intensity" proxy — it is *not* normalized by the incident field
  and is not a Poynting flux/cross section; it is dimensionless because
  fields are normalized to a unit-amplitude incident plane wave.
- `gradient = d(value)/d(separation)`, obtained from the analytic reverse-mode
  derivative of the whole pipeline (sphere T-matrices → cluster coupling →
  scattered field → total field → intensity) with respect to the two sphere
  positions, which both move symmetrically as `separation` changes. Only
  `separation` is treated as the differentiated variable; `point`,
  `wavelength`, `radii`, `material`, and `lmax` are held fixed.

## Units and conventions

- Lengths (`radius`, `separation`, `point` coordinates, wavelength) are in
  micrometers, and consistently so — `k0 = 2*pi/wavelength` is in inverse
  micrometers.
- `epsilon` is `[real, imaginary]`, combined as a complex relative
  permittivity `epsilon[0] + 1j*epsilon[1]`, with `mu = 1` and `kappa = 0`
  (non-magnetic, achiral), exterior medium is vacuum (`medium=1`).
- Polarization convention is `helicity` (treams_rs default), and the
  illumination uses `"positive_helicity"`.
- All numerical scattering (single-sphere Mie T-matrices, cluster
  coupling/solve, and field evaluation) is performed by `treams-rs`
  (`treams_rs.advect.sphere_tmatrix`, `treams_rs.advect.Cluster`,
  `treams_rs.advect.plane_wave`); no scattering physics is reimplemented.

## Analytic derivatives

The gradient is produced by `advect.value_and_grad` applied to an objective
function built entirely from `treams_rs.advect` primitives (which carry
native Rust reverse-mode pullbacks through the sphere T-matrix, cluster
assembly/solve, and field evaluation). The two sphere positions are
constructed from `separation` using traced `advect.numpy` array operations
(`-separation/2`, `+separation/2`) so that the reverse pass correctly
accumulates the dependence of *both* sphere positions on `separation`. No
finite differences are used to produce the returned `gradient`.

## Checks performed

The analytic gradient was validated against central finite differences
(step `1e-6` in `separation`) for the example configuration and two
additional configurations with different radius, epsilon, wavelength, lmax
and point:

| separation | value | analytic gradient | finite-difference gradient |
|---|---|---|---|
| 0.3  | 1.185550635 | -0.403725421 | -0.403725421 |
| 0.5  | 1.225514899 | -0.382884873 | -0.382884873 |
| 0.15 | 1.074004981 | -0.138175019 | -0.138175019 |

Agreement is at the level of the finite-difference truncation/round-off
error (better than 1e-7 relative), confirming the analytic derivative is
correct.

## Interface

`run(config)` accepts a dict with keys `radius`, `epsilon` (`[re, im]`),
`separation`, `wavelength`, `lmax`, `point` (`[x, y, z]`), and returns
`{"value": float, "gradient": float}`. The CLI (`python solution.py`) reads
one such config as JSON from stdin and writes the result dict as JSON to
stdout.
