"""Infer a homogeneous sphere radius from target scattering efficiencies.

Uses treams-rs's Advect adapter for the analytic scattering efficiency and
its reverse-mode radius derivative; the optimizer only consumes those values.
"""
import json
import math
import sys

import advect as ad
import treams_rs.advect as tr


def _efficiency_and_grad(radius, k0, lmax, epsilon):
    """Q_sca(radius) and dQ_sca/dradius at fixed k0, via native pullback."""

    def objective(r):
        sphere = tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=epsilon)
        wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
        cs = sphere.cross_sections(wave)
        return cs.scattering / (math.pi * r ** 2)

    value, grad = ad.value_and_grad(objective)(radius)
    return float(value), float(grad)


def _loss_and_grad(radius, k0s, lmax, epsilon, targets):
    n = len(k0s)
    loss = 0.0
    grad = 0.0
    efficiencies = []
    for k0, target in zip(k0s, targets):
        q, dq = _efficiency_and_grad(radius, k0, lmax, epsilon)
        efficiencies.append(q)
        resid = (q - target) / target
        loss += resid ** 2
        grad += 2.0 * resid * dq / target
    return loss / n, grad / n, efficiencies


def run(config):
    epsilon = config["epsilon"]
    lmax = config["lmax"]
    wavelengths = config["wavelengths"]
    initial_radius = config["initial_radius"]
    lo, hi = config["bounds"]
    targets = config["target_efficiencies"]

    k0s = [2.0 * math.pi / wl for wl in wavelengths]

    radius = float(initial_radius)
    initial_loss, _, _ = _loss_and_grad(radius, k0s, lmax, epsilon, targets)

    loss_history = [initial_loss]
    step = (hi - lo) * 0.5
    loss, grad, efficiencies = initial_loss, None, None

    max_iters = 500
    for _ in range(max_iters):
        loss, grad, efficiencies = _loss_and_grad(radius, k0s, lmax, epsilon, targets)
        if loss < 1e-7:
            break

        # Backtracking line search along the negative gradient, projected to bounds.
        for _ in range(60):
            candidate = radius - step * grad
            candidate = min(max(candidate, lo), hi)
            cand_loss, _, _ = _loss_and_grad(candidate, k0s, lmax, epsilon, targets)
            if cand_loss < loss or candidate == radius:
                break
            step *= 0.5
        else:
            break

        if candidate == radius:
            break
        radius = candidate
        loss = cand_loss
        loss_history.append(loss)
        step *= 1.2

    loss, grad, efficiencies = _loss_and_grad(radius, k0s, lmax, epsilon, targets)
    if loss_history[-1] != loss:
        loss_history.append(loss)

    return {
        "radius": radius,
        "loss": loss,
        "initial_loss": initial_loss,
        "gradient": grad,
        "fitted_efficiencies": efficiencies,
        "loss_history": loss_history,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
