# Sphere Radius Inverse Design

## Problem

Given target scattering efficiencies `Q_sca(lambda_i)` measured for a homogeneous,
lossless, nonmagnetic, non-chiral sphere in vacuum, find the sphere radius that
best reproduces them in the least-squares sense

    loss(radius) = mean_i( ((Q(radius, lambda_i) - target_i) / target_i)^2 )

with `epsilon`, `lmax` and the wavelengths fixed by the config, starting from
`initial_radius` and staying within `bounds`.

## Units and conventions

- All lengths (radius, wavelengths, `bounds`) are in micrometers.
- `epsilon` is the sphere's relative permittivity (dimensionless); `mu = 1`,
  chirality `kappa = 0`, exterior medium is vacuum (`epsilon = 1`), matching
  the task defaults.
- The vacuum wavenumber is `k0 = 2*pi/wavelength` (rad/um).
- The scattering efficiency is `Q_sca = C_sca / (pi * radius**2)`, i.e. the
  scattering cross section normalized by the geometric cross section, as is
  standard Mie-theory convention.
- Illumination is a single plane wave in positive-helicity polarization; for a
  spherically symmetric, achiral particle `Q_sca` does not depend on the
  incidence direction or polarization, so no orientation averaging is needed.

## Numerical approach

- The T-matrix of the homogeneous sphere and the resulting scattering cross
  section are computed with treams-rs's `advect` adapter
  (`treams_rs.advect.sphere_tmatrix`, `.plane_wave`, `TMatrix.cross_sections`),
  which provides a fully differentiable, native (Rust) forward model.
- The radius derivative `dQ_sca/dradius` (and hence `d(loss)/dradius`) is
  obtained with `advect.value_and_grad`, i.e. an analytic reverse-mode
  (native pullback) derivative through the T-matrix construction and cross
  section evaluation -- not a finite-difference approximation.
- Optimization is a simple 1D bounded gradient descent with backtracking line
  search: at each iterate the step is halved until the loss decreases (or the
  projected step doesn't move, in which case the search stops), then the step
  size is grown slightly for the next iteration. The radius is always clipped
  to `bounds` before evaluation. Iteration stops once `loss < 1e-7` or after a
  fixed iteration budget.
- `loss_history` records the loss at the initial radius and after every
  accepted step, ending at the loss for the returned radius.

## Checks performed

- Ran the example config end-to-end (`results.json` in this directory);
  achieved `loss = 6.15e-8 < 1e-7` at `radius = 0.11000678...` micrometers,
  matching the geometry implied by the given target efficiencies.
- Verified the recovered radius against a synthetic case: generated target
  efficiencies from a forward simulation at a known radius (0.18 um, different
  epsilon/lmax/wavelength grid than the example) and confirmed the optimizer,
  started from an unrelated initial radius, converges back to that radius to
  within ~1e-5 um with loss ~7e-9.
- Cross-checked the analytic gradient from `advect.value_and_grad` against a
  central finite difference (`h = 1e-6`) of `Q_sca(radius)`; agreement to
  ~5 significant figures confirms the native pullback is correct. Finite
  differences are used only for this validation, never to supply the
  optimizer's derivative or steps.
- Confirmed `solution.py` reads a JSON config from stdin and prints the result
  dictionary as JSON to stdout (`python solution.py < example_config.json`).

## Files

- `solution.py`: `run(config)` plus a CLI (`python solution.py` reads JSON
  config from stdin, writes JSON result to stdout).
- `example_config.json`: the example configuration from the task.
- `results.json`: output of `run()` on the example configuration.
