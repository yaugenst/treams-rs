import json
import sys
import math

import treams_rs as t


def _material(entry):
    re, im = entry
    return t.Material(complex(re, im))


def run(config):
    radii = config["radii"]
    epsilon_layers = config["epsilon_layers"]
    epsilon_medium = config["epsilon_medium"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    layer_materials = [_material(e) for e in epsilon_layers]
    if isinstance(epsilon_medium, (list, tuple)):
        medium_material = _material(epsilon_medium)
    else:
        medium_material = t.Material(complex(epsilon_medium))
    materials = layer_materials + [medium_material]

    scattering = []
    extinction = []
    absorption = []
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        tm = t.TMatrix.sphere(lmax, k0, radii, materials)
        cs = tm.average_cross_sections
        scattering.append(cs.scattering)
        extinction.append(cs.extinction)
        absorption.append(cs.absorption)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
