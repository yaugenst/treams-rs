# Core-Shell Sphere Scattering Report

## Task
Compute rotationally averaged scattering, extinction and absorption cross
sections for a concentric core-shell sphere embedded in a homogeneous
dielectric exterior, as a function of wavelength, using `treams-rs`.

## Units and conventions
- All lengths (radii, wavelengths) are in micrometers.
- `epsilon_layers` gives one `[real, imag]` relative permittivity per layer,
  ordered inside-out (innermost core first, outermost shell last),
  matching the strictly increasing `radii` list of outer layer boundaries.
- `epsilon_medium` is the (real or `[real, imag]`) relative permittivity of
  the exterior background; `mu = 1` and chirality `kappa = 0` throughout,
  as no magnetic or chiral parameters are specified in the config.
- The vacuum angular wavenumber `k0 = 2*pi/wavelength` is computed per
  wavelength and passed to `treams_rs.TMatrix.sphere`, together with the
  layer radii and one `Material` per layer plus the exterior medium
  (ordered center-to-outside, exterior last), following the documented
  `TMatrix.sphere(lmax, k0, radii, materials)` signature. The exterior is
  *not* appended as an extra finite radius — it is only the trailing
  material entry, as required by the API.
- Cross sections are read from `TMatrix.average_cross_sections`, which
  returns rotationally- and polarization-averaged `scattering`,
  `extinction`, and `absorption` (the latter as a derived property,
  `extinction - scattering`) in squared length units (µm²), consistent
  with the µm length convention used for radii and wavelengths.

## Checks performed
- **Energy balance**: `extinction == scattering + absorption` holds to
  machine precision for every wavelength in the example config.
- **lmax convergence**: cross sections are essentially converged
  (agreement to ~10 significant figures) between `lmax=6` and `lmax=8`,
  and already close at `lmax=4`, confirming the requested `lmax=4` is a
  reasonable truncation for these sub-wavelength radii.
- **Passivity sanity check**: for a lossless homogeneous sphere
  (`epsilon` purely real), the resulting absorption cross section is
  numerically zero (~1e-17, i.e. floating-point noise), as expected from
  reciprocity/energy conservation for a non-absorbing scatterer.

## Implementation notes
`solution.py` exposes `run(config)`, which builds one `treams_rs.Material`
per layer (from the `[real, imag]` pairs) plus the exterior `Material`,
constructs a `TMatrix.sphere(...)` per wavelength, and reads off
`average_cross_sections`. No finite differences or reimplementation of the
Mie/multilayer scattering physics are used — all numerics are delegated to
`treams-rs`. The CLI entry point reads a JSON config dict from stdin and
writes the resulting dict as JSON to stdout.

## Example results
See `results.json`, generated from the example config in the task
(`radii=[0.07,0.12]`, `epsilon_layers=[[2.25,0.03],[4,0.06]]`,
`epsilon_medium=1.7689`, `wavelengths=[0.58,0.7,0.82]`, `lmax=4`):

```json
{
  "scattering":  [0.03431592329021956, 0.018912460310459123, 0.012135679701039646],
  "extinction":  [0.03752383432335123, 0.02117015737980841, 0.013901066200918064],
  "absorption":  [0.003207911033131665, 0.002257697069349286, 0.0017653864998784172]
}
```
