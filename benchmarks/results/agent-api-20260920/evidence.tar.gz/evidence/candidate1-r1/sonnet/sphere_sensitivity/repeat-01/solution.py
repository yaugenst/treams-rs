"""Scattering efficiency and its gradient for a lossy sphere under +z, positive-helicity incidence.

Computes Q = scattering_cross_section / (pi * radius**2) using treams-rs, and the
gradient of Q with respect to (radius, epsilon_real) at fixed epsilon_imag,
wavelength and lmax, using analytic derivatives via the treams_rs.advect adapter.
"""

import json
import math
import sys

import advect
import treams_rs.advect as tra


def _scattering_efficiency(radius, epsilon_real, epsilon_imag, k0, lmax):
    material = tra.Material(epsilon_real + 1j * epsilon_imag, 1.0, 0.0)
    tmatrix = tra.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
    incident = tra.plane_wave(
        direction=(0.0, 0.0, 1.0), polarization="positive_helicity", k0=k0
    )
    cross_sections = tmatrix.cross_sections(incident)
    return cross_sections.scattering / (math.pi * radius**2)


def run(config):
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    k0 = 2.0 * math.pi / wavelength

    def objective(r, eps_r):
        return _scattering_efficiency(r, eps_r, epsilon_imag, k0, lmax)

    value, (dq_dr, dq_deps) = advect.value_and_grad(objective, argnums=(0, 1))(
        radius, epsilon_real
    )

    # Finite-difference cross-check (not used as the reported derivative).
    h_r = max(abs(radius), 1.0) * 1e-6
    h_eps = max(abs(epsilon_real), 1.0) * 1e-6
    dq_dr_fd = (
        objective(radius + h_r, epsilon_real) - objective(radius - h_r, epsilon_real)
    ) / (2 * h_r)
    dq_deps_fd = (
        objective(radius, epsilon_real + h_eps) - objective(radius, epsilon_real - h_eps)
    ) / (2 * h_eps)

    return {
        "Q": float(value),
        "gradient": [float(dq_dr), float(dq_deps)],
        "gradient_fd_check": [float(dq_dr_fd), float(dq_deps_fd)],
        "k0": k0,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
