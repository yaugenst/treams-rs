# Scattering efficiency of a lossy sphere and its gradient

## Problem
A homogeneous, lossy dielectric sphere in vacuum is illuminated by a plane
wave of pure positive helicity traveling in +z. We compute the scattering
efficiency

    Q = C_sca / (pi * radius^2)

and its gradient with respect to `radius` and `epsilon_real`, holding
`epsilon_imag`, `wavelength` and `lmax` fixed.

## Units and conventions
- Lengths (`radius`, `wavelength`) are in micrometers; `1/radius^2` and cross
  sections therefore carry units of um^2, so `Q` itself is dimensionless.
- `epsilon_real`/`epsilon_imag` form the relative permittivity
  `epsilon = epsilon_real + i*epsilon_imag` of the sphere; the exterior medium
  is vacuum (`epsilon=1, mu=1, kappa=0`), and the sphere itself has `mu=1`,
  `kappa=0` as specified.
- The vacuum angular wavenumber is `k0 = 2*pi/wavelength`, consistent with
  treams-rs's convention that `radius` and `1/k0` share the same length unit.
- "Positive-helicity +z incidence" is built with
  `plane_wave(direction=(0,0,1), polarization="positive_helicity", k0=k0)`,
  using treams-rs's helicity polarization convention.
- `lmax` is the fixed spherical multipole truncation order used to build the
  sphere T-matrix.

## Method
- The T-matrix of the homogeneous sphere is built with
  `treams_rs.advect.sphere_tmatrix`, and the scattering cross section with
  `TMatrix.cross_sections(incident).scattering`, both using treams-rs's native
  Mie/T-matrix solver (no reimplementation of the physics).
- `Q` is defined as a plain Python function of `(radius, epsilon_real)` (with
  `epsilon_imag`, `wavelength`, `lmax` closed over as fixed constants) built
  entirely from `treams_rs.advect` calls, which retain differentiable/traced
  values end to end (geometry, material and the normalization `pi*radius**2`
  are all part of the traced computation).
- The gradient `[dQ/dradius, dQ/depsilon_real]` is obtained with
  `advect.value_and_grad(Q, argnums=(0,1))`, i.e. the analytic reverse-mode
  (VJP) derivative provided by the `advect` adapter shipped with treams-rs —
  no finite differences are used to produce the reported gradient.

## Verification
As a sanity check only (not used for the reported gradient), the solution also
evaluates a central finite-difference approximation of the same two partial
derivatives (`gradient_fd_check` in the output) with a small relative step
(`1e-6`). For the example config the analytic and finite-difference gradients
agree to ~7-8 significant digits, confirming the analytic derivatives are
correct:

- Example config: `radius=0.1`, `epsilon_real=4.0`, `epsilon_imag=0.06`,
  `wavelength=0.72`, `lmax=3`.
- `Q = 0.463376...`
- `gradient = [dQ/dr, dQ/deps_real] = [18.65367, 0.19973]`
- `gradient_fd_check = [18.65367, 0.19973]` (matches to >6 digits)

The function was also exercised with a second, different configuration
(`radius=0.2, epsilon_real=2.5, epsilon_imag=0.3, wavelength=0.5, lmax=5`) to
confirm the implementation is not hard-coded to the example values; the
analytic and finite-difference gradients again agreed to >6 significant
digits.

## Files
- `solution.py`: exposes `run(config)` and a CLI (`python solution.py` reads a
  JSON config dict from stdin, writes the result dict as JSON to stdout).
- `results.json`: output of `run(config)` for the example config above.
