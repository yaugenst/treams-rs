"""Dimer scattering: total electric field and cross sections via treams-rs."""
import sys
import json

import numpy as np
import treams_rs as t


def run(config):
    radii = config["radii"]
    epsilon = config["epsilon"]
    separation = config["separation"]
    wavelength = config["wavelength"]
    lmax = config["lmax"]
    points = np.asarray(config["points"], dtype=float)

    k0 = 2 * np.pi / wavelength

    tmatrices = []
    for r, (eps_re, eps_im) in zip(radii, epsilon):
        eps = complex(eps_re, eps_im)
        tmatrices.append(t.TMatrix.sphere(lmax, k0, r, [eps, 1]))

    positions = [[-separation / 2, 0.0, 0.0], [separation / 2, 0.0, 0.0]]
    cluster = t.Cluster(tmatrices, positions=positions)
    solved = cluster.solve()

    incident = t.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
    )

    scattered_wave = solved.scatter(incident)

    field_scattered = scattered_wave.efield(points)
    field_incident = incident.efield(points)
    field_total = field_incident + field_scattered

    xs = solved.cross_sections(incident)

    points_valid = solved.valid_points(points, radii).tolist()

    return {
        "total_field_real": field_total.real.tolist(),
        "total_field_imag": field_total.imag.tolist(),
        "scattering_cross_section": float(xs.scattering),
        "extinction_cross_section": float(xs.extinction),
        "absorption_cross_section": float(xs.absorption),
        "points_outside_spheres": points_valid,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
