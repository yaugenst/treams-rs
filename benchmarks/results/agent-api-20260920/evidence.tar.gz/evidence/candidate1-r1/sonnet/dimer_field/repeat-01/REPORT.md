# Dimer scattering: total electric field and cross sections

## Method

Two homogeneous, isotropic, non-magnetic (`mu=1`), achiral (`kappa=0`) spheres
are placed on the x-axis at `x = -separation/2` and `x = +separation/2`
(`y = z = 0`), embedded in vacuum. Each sphere's T-matrix is built with
`treams_rs.TMatrix.sphere(lmax, k0, radius, [epsilon, 1])`, where the last
entry (`1`) is the vacuum exterior. The two T-matrices are assembled into a
`treams_rs.Cluster` at their Cartesian positions and `Cluster.solve()`
computes the fully coupled response, i.e. all orders of multiple scattering
between the two particles at the fixed `lmax` (no interaction truncation
beyond the multipole cutoff already implied by `lmax`).

The incident field is a plane wave propagating along `+z` with positive
helicity (`treams_rs.plane_wave(direction=[0,0,1], polarization=
"positive_helicity", k0=k0)`) and unit incident-field amplitude (the
package's default plane-wave normalization). `solved.scatter(incident)`
returns the outgoing multipole wave including multi-particle interaction;
its `.efield(points)` gives the scattered Cartesian field, and
`incident.efield(points)` gives the incident field, both using the package's
native field kernels (no manual multipole summation is implemented here).
The total field returned is `incident + scattered`, evaluated at each
requested point.

Cross sections are obtained from `solved.cross_sections(incident)`, which
returns named scattering and extinction cross sections for the whole
(multi-origin) coupled cluster under the given illumination; absorption is
`extinction - scattering` (the `.absorption` property), using the default
flux normalization (`flux=0.5`) consistent with the unit-amplitude plane
wave.

## Units and conventions

- Lengths (radii, separation, wavelength, points) are in micrometers.
- `epsilon` entries are `[real, imag]` relative permittivities; `mu=1`,
  chirality `kappa=0` for the particles, exterior medium is vacuum
  (`epsilon=1, mu=1, kappa=0`).
- Vacuum angular wavenumber: `k0 = 2*pi/wavelength` (inverse micrometers).
- Cross sections are in squared length units (µm²).
- Polarization convention: helicity basis; illumination is positive
  helicity along `+z`.
- Field values are complex; `total_field_real`/`total_field_imag` are the
  real/imaginary parts of the Cartesian `(Ex, Ey, Ez)` total field at each
  point, shape `(n_points, 3)`.

## Checks performed

- **Non-absorbing sanity check**: for real-valued epsilon (zero imaginary
  part) at a larger separation, `scattering_cross_section` equals
  `extinction_cross_section` to numerical precision and
  `absorption_cross_section` is numerically zero, as required by energy
  conservation for a lossless scatterer.
- **`points_outside_spheres`**: the solution also reports, via
  `TMatrix.valid_points`, whether each requested evaluation point lies
  strictly outside both spheres' circumscribing surfaces; the multipole
  expansion used for the scattered field is only formally valid there. For
  the example configuration both points are valid (`true`).
- Cross-section and field values change smoothly and non-trivially when
  `wavelength`, `radii`, `separation`, or `epsilon` are varied, confirming
  the implementation is not hard-coded to the example.

## Example result

See `results.json`, computed by running `solution.py` on the example config
from the prompt (`radii=[0.08,0.11]`, `epsilon=[[4,0.02],[6,0.08]]`,
`separation=0.32`, `wavelength=0.72`, `lmax=3`, two evaluation points).
