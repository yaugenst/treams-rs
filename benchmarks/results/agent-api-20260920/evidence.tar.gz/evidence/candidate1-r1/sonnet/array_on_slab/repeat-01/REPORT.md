# Square sphere array on a dielectric slab (vacuum gap) — treams-rs

## Physical setup

Along +z the network is: **dielectric slab** → **vacuum gap** → **square
periodic array of identical spheres**, all embedded in vacuum on both
exterior sides. Illumination is a unit-amplitude, positive-helicity plane
wave incident from the −z side, propagating along +z. Since the requested
wavelengths all exceed the lattice period, only the zeroth (specular)
diffraction order is retained, for both helicity channels, at Bloch vector
`kpar = [0, 0]`.

## Units and conventions

- Lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) are in
  micrometers; `k0 = 2*pi/wavelength` is in inverse micrometers, matching
  `treams_rs`'s convention that a consistent length unit is used throughout
  (radius, lattice pitch, distances and 1/k0 all share it).
- `sphere_epsilon` and `slab_epsilon` are real relative permittivities
  (`mu = 1`, no chirality); both media are treated as lossless.
- Polarization/mode convention is helicity (`treams_rs` default), with
  ports ordered `(negative_helicity, positive_helicity)`; the incident
  vector `[0, 1]` therefore selects unit-amplitude positive helicity.
- `PowerBalance.absorption` is defined as the fraction of incident power not
  carried away by the transmitted or reflected zeroth-order beams; it is
  clipped at zero to remove floating-point noise (real permittivities imply
  no material loss channel, so physically it should equal exactly zero).

## Numerical method (treams-rs)

For each wavelength:

1. Build a single sphere T-matrix with `treams_rs.sphere_tmatrix` at the
   fixed `lmax`.
2. Solve the full periodic interaction of the square array with
   `treams_rs.solve_periodic` on a `Lattice.cubic(period)` cell at
   `kpar = [0, 0]` (native Ewald-summed lattice sums; no manual
   reimplementation of the lattice interaction).
3. Convert the solved periodic response to a scattering matrix in the
   zeroth-order, both-helicity plane-wave basis
   (`PlaneWavePorts.default([0, 0])`) via `PeriodicResponse.to_smatrix`.
4. Build the slab layer (`treams_rs.slab`) and the vacuum-gap propagation
   layer (`treams_rs.propagation`) in the same plane-wave basis.
5. Cascade the three layers, negative-to-positive z, with
   `treams_rs.stack([slab, gap, sphere_array])`.
6. Read off transmission/reflection/absorption fractions with
   `network.power([0, 1], side="negative")` for incidence from the slab
   side along +z with positive helicity.

All scattering numerics (sphere Mie coefficients, lattice sums, Fresnel-like
slab/interface matrices, and S-matrix cascading) are performed by
`treams_rs`; no cross sections or lattice sums are recomputed by hand.

## Checks performed

- **Energy conservation**: for the example config and all additional test
  configs (real, lossless `sphere_epsilon`/`slab_epsilon`), the computed
  absorption is zero to floating-point precision and `transmission +
  reflection = 1`, as expected with no loss channel present.
- **`lmax` convergence**: increasing `lmax` from 1 to 4 for the example
  config converges the transmission values to ~6 significant digits
  (e.g. at λ=0.65 μm: 0.88811 → 0.88733 → 0.887338 → 0.887338), confirming
  `lmax = 2` is already close to converged for these parameters and that the
  periodic solve is numerically stable.
- **Wavelength ordering**: `run()` sorts output by wavelength regardless of
  the input order, verified by permuting the example wavelength list.
- **Edge cases**: `gap = 0` and a trivial "no slab" configuration
  (`slab_thickness = 0`, `slab_epsilon = 1`) both run without error and give
  physically sensible results (transmission near unity when the slab is
  removed, since only the bare sphere array remains).

## Example result (results.json)

For the example configuration
(`radius=0.06, sphere_epsilon=9.0, period=0.4, gap=0.12,
slab_thickness=0.09, slab_epsilon=2.25, lmax=2`):

| wavelength (μm) | transmission | reflection | absorption |
|---|---|---|---|
| 0.65 | 0.88733 | 0.11267 | 0.0 |
| 0.74 | 0.90207 | 0.09793 | 0.0 |
| 0.83 | 0.91191 | 0.08809 | 0.0 |

## Files

- `solution.py`: exposes `run(config)` and a CLI (`stdin` JSON in,
  `stdout` JSON out).
- `results.json`: saved output for the example config above.
