"""Square periodic sphere array above a dielectric slab, separated by a vacuum gap.

Network order along +z: slab -> vacuum gap -> sphere array.
Illumination: from the -z side, propagating along +z, positive helicity.
Only the zeroth diffraction order (both helicities) is kept, at Bloch
vector kpar = [0, 0], since wavelengths exceed the lattice period.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def run(config):
    radius = config["radius"]
    sphere_epsilon = config["sphere_epsilon"]
    period = config["period"]
    gap = config["gap"]
    slab_thickness = config["slab_thickness"]
    slab_epsilon = config["slab_epsilon"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    lattice = tr.Lattice.cubic(period)
    basis = tr.PlaneWavePorts.default([0, 0])

    order = sorted(range(len(wavelengths)), key=lambda i: wavelengths[i])
    sorted_wavelengths = [wavelengths[i] for i in order]

    transmission = []
    reflection = []
    absorption = []
    for wavelength in sorted_wavelengths:
        k0 = 2 * np.pi / wavelength

        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon
        )
        periodic = tr.solve_periodic(sphere, lattice=lattice, kpar=[0, 0])
        sphere_smat = periodic.to_smatrix(basis)

        slab_smat = tr.slab(
            basis=basis,
            k0=k0,
            thickness=slab_thickness,
            material=slab_epsilon,
        )
        gap_smat = tr.propagation(distance=gap, basis=basis, k0=k0)

        network = tr.stack([slab_smat, gap_smat, sphere_smat])

        # Ports are ordered (negative helicity, positive helicity); [0, 1]
        # selects unit-amplitude positive-helicity incidence from -z.
        power = network.power([0, 1], side="negative")

        t_val = float(power.transmission)
        r_val = float(power.reflection)
        a_val = float(power.absorption)
        # Power fractions cannot be physically negative; clip numerical noise.
        t_val = max(0.0, t_val)
        r_val = max(0.0, r_val)
        a_val = max(0.0, a_val)

        transmission.append(t_val)
        reflection.append(r_val)
        absorption.append(a_val)

    return {
        "wavelengths": sorted_wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
