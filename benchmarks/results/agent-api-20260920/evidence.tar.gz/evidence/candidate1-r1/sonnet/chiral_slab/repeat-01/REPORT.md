# Chiral slab transmission/reflection/absorption

## Physical setup

A uniform, reciprocal, isotropic chiral slab of finite `thickness` occupies a
region normal to `z`, with vacuum on both sides. A plane wave is incident
along `+z` (normal incidence) from the vacuum region on the negative-`z`
side. The slab material is `Material(epsilon, mu=1, kappa)`, where:

- `epsilon = epsilon_re + i*epsilon_im` is the relative permittivity
  (dimensionless, SI-like convention with `exp(-i*omega*t)` implicit in
  treams-rs; positive `epsilon_im` corresponds to a lossy/absorbing medium).
- `kappa` is the (real, in this task) Pasteur/Tellegen chirality parameter
  used directly by treams-rs's `Material`. It couples the eigen-polarizations
  of the medium to left/right circular (helicity) states rather than linear
  polarizations.
- `mu` defaults to 1 (non-magnetic) when not given in the config.

All lengths (`thickness`, `wavelengths`) are in micrometers. The vacuum
wavenumber is `k0 = 2*pi/wavelength` (inverse micrometers), matching the
length unit used for `thickness`.

## Method

The calculation uses `treams_rs.slab(...)`, which builds the full,
non-reimplemented multiple-scattering solution (`SMatrices`) for a single
homogeneous chiral layer between two vacuum half-spaces, evaluated in the
helicity polarization basis (`polarization="helicity"`, the default). The
plane-wave port basis is built with
`treams_rs.PlaneWavePorts.default([0.0, 0.0])`, i.e. purely normal incidence
(`kx = ky = 0`) with both helicity channels included.

For each wavelength:

1. `k0 = 2*pi/wavelength` is computed.
2. `treams_rs.slab(basis=..., k0=k0, thickness=thickness, material=Material(epsilon, mu, kappa))`
   returns the layer's `SMatrices` object (vacuum on both sides by default).
3. `smat.power([0, 1], side="negative")` illuminates the slab from the
   negative-`z` (i.e. incidence along `+z`) side with a pure positive-helicity
   plane wave, returning a `PowerBalance(transmission, reflection)` with an
   `.absorption` property (`1 - T - R`), all normalized to the incident power
   (power fractions, not amplitude coefficients).
4. `smat.power([1, 0], side="negative")` does the same for pure negative
   helicity.

No custom scattering physics is implemented; treams-rs's native S-matrix
solver and power-balance bookkeeping are used directly.

## Output convention

`run(config)` returns a dict with keys `transmission`, `reflection`,
`absorption`, each a list of shape `(len(wavelengths), 2)`. For each
wavelength the two entries are ordered `[positive_helicity, negative_helicity]`,
matching the task specification. All values are power fractions in `[0, 1]`.

## Checks performed

- **Energy conservation**: for every wavelength and helicity,
  `transmission + reflection + absorption == 1` to floating-point precision
  (verified numerically on the example config; residuals were exactly `0.0`
  after rounding).
- **kappa = 0 consistency**: setting `kappa = 0` makes the positive- and
  negative-helicity results numerically identical, as expected for an
  achiral medium.
- **Real-kappa symmetry**: for the example config (`kappa` real, `epsilon`
  complex), the positive- and negative-helicity transmission/reflection/
  absorption fractions come out numerically equal to ~1e-12. This is
  physically correct: a real chirality parameter only shifts the *real* part
  of the helicity-dependent refractive index (`n_pm = sqrt(eps*mu) +/- kappa`
  for real `kappa`), producing optical activity (rotation) but no circular
  dichroism, since the imaginary part (and thus absorption/extinction) of
  `n_+` and `n_-` remains the same. Circular dichroism would appear only for
  complex `kappa`, which is not exercised by the example but is supported by
  the same code path since `kappa` is passed through as a complex number.

## Example result

For the example config (`thickness=0.16`, `epsilon=[2.25, 0.06]`,
`kappa=0.08`, `wavelengths=[0.55, 0.65, 0.8]`), the computed power fractions
are saved in `results.json`. At `wavelength=0.55` um: transmission ~0.905,
reflection ~0.024, absorption ~0.071 for both helicities (matching to the
displayed precision).
