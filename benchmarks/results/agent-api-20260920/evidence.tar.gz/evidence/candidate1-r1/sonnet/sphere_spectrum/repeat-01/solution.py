import json
import math
import sys

import treams_rs as t


def run(config):
    radius = config["radius"]
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    scattering = []
    extinction = []
    absorption = []
    efficiency = []

    geometric = math.pi * radius**2

    for wl in wavelengths:
        k0 = 2 * math.pi / wl
        tmat = t.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)
        pw = t.plane_wave(direction=[0, 0, 1], polarization="positive_helicity", k0=k0)
        cs = tmat.cross_sections(pw)
        scattering.append(cs.scattering)
        extinction.append(cs.extinction)
        absorption.append(cs.absorption)
        efficiency.append(cs.scattering / geometric)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
