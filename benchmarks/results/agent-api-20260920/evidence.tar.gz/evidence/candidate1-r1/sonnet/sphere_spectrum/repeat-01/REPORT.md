# Homogeneous Dielectric Sphere Spectrum

## Method
`solution.py` computes the Mie-type scattering spectrum of a homogeneous,
isotropic, non-magnetic, non-chiral dielectric sphere illuminated by a
plane wave propagating along +z with positive helicity. All numerics are
done by `treams-rs`:

1. For each wavelength, `k0 = 2*pi/wavelength` (vacuum angular wavenumber).
2. `treams_rs.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)`
   builds the sphere's T-matrix. `material=epsilon` sets relative
   permittivity as a complex number `epsilon_re + i*epsilon_im`; `mu=1`
   and `kappa=0` (non-chiral) by default, and the exterior medium is
   vacuum by default, matching the problem statement.
3. `treams_rs.plane_wave(direction=[0,0,1], polarization="positive_helicity", k0=k0)`
   defines the incident wave: propagation along +z, positive helicity
   (i.e. purely right-circularly-polarized in the helicity basis used by
   `treams-rs`), in vacuum.
4. `tmat.cross_sections(pw)` returns a `CrossSections` object with
   `.scattering`, `.extinction`, and `.absorption` (the last derived from
   power balance: absorption = extinction - scattering).

## Units and conventions
- Lengths (`radius`, `wavelengths`) are in micrometers; cross sections are
  therefore returned in square micrometers (areas).
- `epsilon = [real, imag]` is the relative permittivity, not a refractive
  index; it is converted internally to `complex(real, imag)`.
- Scattering efficiency `Q_sca = scattering / (pi * radius**2)`, the
  cross section normalized by the sphere's geometric cross-sectional
  area — dimensionless.
- The multipole cutoff `lmax` is passed directly to `sphere_tmatrix`.

## Output
`run(config)` returns a dict with keys `scattering`, `extinction`,
`absorption`, `efficiency`, each a list in the same order as the input
`wavelengths`. The CLI (`python solution.py`) reads a JSON config from
stdin and writes the JSON result dict to stdout.

## Checks performed
- **Power balance**: for each wavelength, `extinction ≈ scattering +
  absorption` (verified numerically to floating-point precision for the
  example config).
- **Lossless limit**: setting `epsilon` to a purely real value (no
  imaginary part) with a second test config
  (`radius=0.2, epsilon=[4,0], wavelengths=[0.6,1.0], lmax=6`) yields
  `absorption ≈ 0` (residual ~1e-15, numerical noise) and
  `extinction ≈ scattering`, as expected for a non-absorbing dielectric.
- **Non-hard-coded behavior**: the function was exercised with a config
  different from the example (different radius, epsilon, wavelengths,
  lmax) and produced physically distinct, self-consistent results,
  confirming no example-specific hard-coding.

## Example results
Computed for the example config (`radius=0.1`, `epsilon=[12,0.05]`,
`wavelengths=[0.45,0.55,0.65,0.75]`, `lmax=4`); saved in `results.json`.
A resonance-like peak in scattering efficiency (~5.2) appears near
0.55 um, consistent with a Mie resonance for a moderate-index sphere of
this size relative to the wavelength.
