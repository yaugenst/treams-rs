import sys
import json
import numpy as np
import treams_rs as t


def run(config):
    radius = config["radius"]
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    wavelengths = config["wavelengths"]
    mmax = config["mmax"]

    scattering = []
    extinction = []
    absorption = []

    for wl in wavelengths:
        k0 = 2 * np.pi / wl
        tm = t.CylindricalTMatrix.cylinder(0.0, mmax, k0, radius, [epsilon, 1])
        pw = t.plane_wave(
            direction=[1, 0, 0],
            polarization="positive_helicity",
            k0=k0,
            material=1,
        )
        cs = tm.cross_widths(pw)
        scattering.append(cs.scattering)
        extinction.append(cs.extinction)
        absorption.append(cs.absorption)

    return {
        "wavelengths": list(wavelengths),
        "scattering_width": scattering,
        "extinction_width": extinction,
        "absorption_width": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
