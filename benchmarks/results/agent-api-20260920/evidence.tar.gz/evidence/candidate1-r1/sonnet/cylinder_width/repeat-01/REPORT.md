# Scattering by an infinite homogeneous cylinder

## Physical setup

A homogeneous, infinite dielectric cylinder of radius `radius` (µm) is centered
on the z axis in vacuum. The cylinder material has relative permittivity
`epsilon = eps_re + i*eps_im` (dimensionless, complex; `eps_im >= 0` for a
passive/absorbing medium), relative permeability `mu = 1`, and chirality
`kappa = 0` (achiral). The illumination is a plane wave propagating along `+x`
(perpendicular to the cylinder axis, so the axial wavenumber `kz = 0`), with
purely positive helicity polarization. The vacuum wavenumber at each requested
wavelength is `k0 = 2*pi/wavelength`.

## Method

For every wavelength:

1. Build the cylindrical T-matrix of the homogeneous cylinder with
   `treams_rs.CylindricalTMatrix.cylinder(kzs=0.0, mmax, k0, radius,
   [material_interior, material_exterior])`, using the requested azimuthal
   cutoff `mmax` (orders `-mmax..mmax`) and the default helicity polarization
   basis. Exterior material is vacuum (`epsilon=1, mu=1, kappa=0`).
2. Build the incident field with `treams_rs.plane_wave(direction=[1,0,0],
   polarization="positive_helicity", k0=k0, material=1)`.
3. Call `tmatrix.cross_widths(incident)` which solves the scattering problem
   with treams-rs's native numerics and returns named `scattering`,
   `extinction` cross widths, with `absorption` available as
   `extinction - scattering`.

No sphere-area normalization is used; for a 2D (per-unit-length) cylinder
scattering problem the natural cross section is a *width* (units of length,
µm here), not an area, and `cross_widths` returns exactly that.

## Units and conventions

- Lengths (`radius`, `wavelengths`, and the returned cross widths) are in
  micrometers (µm).
- `epsilon` is `[real, imag]`, relative (dimensionless) permittivity of the
  cylinder; the exterior medium is vacuum (`epsilon=1`).
- `mu = 1` and `kappa = 0` (achiral) throughout, as not overridden by the
  config.
- Illumination is purely positive helicity (a Beltrami/circularly-polarized
  eigenmode of the free-space Maxwell curl operator), propagating along `+x`,
  with `kz = 0` (fields uniform along z, so a genuinely 2D/infinite-cylinder
  problem).
- `mmax` is the azimuthal (cylindrical-harmonic) order cutoff: azimuthal
  orders `m = -mmax, ..., mmax` are retained in the T-matrix.

## Checks performed

- **Energy balance**: `extinction >= scattering >= 0` and
  `absorption = extinction - scattering >= 0` for the lossy example
  (`epsilon = [5, 0.1]`), confirmed directly by the returned numbers.
- **Lossless limit**: setting `epsilon = [5, 0.0]` (no imaginary part) yields
  `absorption ~ 0` (residual `~1e-16`, i.e. numerical zero), and
  `scattering == extinction` to machine precision, as required by unitarity
  for a non-absorbing scatterer.
- **mmax convergence**: doubling `mmax` from 4 to 8 for the example
  wavelength `0.5` µm changes the scattering/extinction/absorption widths
  only in the 7th significant digit, confirming `mmax=4` is already converged
  for this small (`radius=0.08` µm) cylinder at optical wavelengths.

## Files

- `solution.py`: exposes `run(config)` and a CLI (`stdin` JSON config ->
  `stdout` JSON result).
- `results.json`: output of `run()` for the example config in the task
  description.
