"""Inverse radius design for a homogeneous dielectric sphere."""

import json
import math
import sys

import advect
import advect.numpy as anp
import numpy as np
import treams_rs.advect as tr


def _efficiency(radius, wavelength, epsilon, lmax):
    """Scattering efficiency, retaining ``radius`` as an Advect value."""
    k0 = 2.0 * math.pi / wavelength
    sphere = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=epsilon, medium=1.0
    )
    wave = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0)
    scattering_area = sphere.cross_sections(wave).scattering
    return scattering_area / (math.pi * radius * radius)


def _make_objective(config):
    wavelengths = tuple(float(x) for x in config["wavelengths"])
    targets = anp.asarray(config["target_efficiencies"])
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])

    def objective(radius):
        efficiencies = anp.stack(
            [_efficiency(radius, wavelength, epsilon, lmax) for wavelength in wavelengths]
        )
        relative_errors = (efficiencies - targets) / targets
        return anp.mean(relative_errors * relative_errors)

    return objective


def _optimize(objective, initial, lower, upper):
    """Bounded one-dimensional gradient descent with analytic gradients.

    The line search only accepts steps in the native pullback direction.  Its
    initial trust radius is deliberately conservative for strongly resonant
    scattering curves.
    """
    value_and_grad = advect.value_and_grad(objective)
    radius = min(max(float(initial), lower), upper)
    value, gradient = value_and_grad(radius)
    value = float(value)
    gradient = float(gradient)
    history = [value]
    span = upper - lower
    step = 0.125 * span

    for _ in range(300):
        if value < 1.0e-20 or abs(gradient) < 1.0e-10:
            break
        direction = -1.0 if gradient > 0.0 else 1.0
        accepted = False
        trial_step = step
        for _ in range(35):
            trial = min(max(radius + direction * trial_step, lower), upper)
            if trial == radius:
                trial_step *= 0.5
                continue
            trial_value, trial_gradient = value_and_grad(trial)
            trial_value = float(trial_value)
            if trial_value < value:
                radius, value, gradient = trial, trial_value, float(trial_gradient)
                history.append(value)
                step = min(span, trial_step * 1.35)
                accepted = True
                break
            trial_step *= 0.5
        if not accepted:
            # A failed line search means that the gradient direction is below
            # the requested precision (or a bound is active).
            break

    return radius, value, gradient, history


def run(config):
    objective = _make_objective(config)
    lower, upper = (float(x) for x in config["bounds"])
    initial = float(config["initial_radius"])
    initial_loss, _ = advect.value_and_grad(objective)(min(max(initial, lower), upper))
    radius, loss, gradient, history = _optimize(
        objective, initial, lower, upper
    )

    fitted = []
    for wavelength in config["wavelengths"]:
        # This is an ordinary (untraced) numerical evaluation for serialization.
        fitted.append(
            float(_efficiency(radius, float(wavelength), float(config["epsilon"]), int(config["lmax"])))
        )

    return {
        "radius": float(radius),
        "loss": float(loss),
        "initial_loss": float(initial_loss),
        "gradient": float(gradient),
        "fitted_efficiencies": fitted,
        "loss_history": [float(x) for x in history],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
