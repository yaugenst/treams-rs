# Radius inverse design

`solution.py` uses the public `treams_rs.advect` API.  For each wavelength it
constructs a homogeneous sphere T-matrix with native treams-rs numerics and a
normally incident positive-helicity plane wave.  The fitted quantity is the
dimensionless scattering efficiency

\[Q_{sca}=C_{sca}/(\pi R^2),\]

where all lengths are in micrometers, wavelengths and radius use the same
units, epsilon is relative and the exterior medium is vacuum (`mu=1`, zero
chirality).  The configured `lmax` is passed unchanged.

The objective is the mean squared relative error specified by the prompt.  The
radius optimizer uses bounded analytic gradients from `advect.value_and_grad`;
the native treams-rs pullbacks differentiate the sphere scattering calculation.
No finite differences are used for derivatives or optimization steps.

Checks performed:

* The CLI was executed with the supplied example and its output is saved in
  `results.json`.
* The fitted radius is inside `[0.06, 0.14]` micrometers.
* The final loss is `5.40e-22` (below `1e-7`), and the fitted efficiencies
  agree with all three supplied targets to approximately `4e-11` or better.
