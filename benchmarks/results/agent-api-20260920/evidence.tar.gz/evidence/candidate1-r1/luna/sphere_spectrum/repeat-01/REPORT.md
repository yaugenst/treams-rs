# Sphere spectrum report

`solution.py` calls the public `treams_rs.sphere_tmatrix` and
`TMatrix.cross_sections` APIs for each wavelength; no scattering formulas are
reimplemented here. The sphere radius and wavelengths are in micrometers, so
the cross sections are in square micrometers. The returned efficiency is
scattering cross section divided by `pi * radius**2` and is dimensionless.

The supplied `epsilon` pair is interpreted as relative permittivity
`epsilon[0] + i*epsilon[1]`, not as a refractive index. The exterior is the
default vacuum (`epsilon=mu=1`, zero chirality). Illumination propagates along
`+z` with treams-rs's named `positive_helicity` convention, and the requested
`lmax` is used unchanged for every wavelength.

Checks performed: native absorption is reported separately and satisfies the
cross-section balance `absorption = extinction - scattering` (up to floating
point roundoff) for the example; all example values are finite and the
positive-loss example has nonnegative scattering, extinction, and absorption.
