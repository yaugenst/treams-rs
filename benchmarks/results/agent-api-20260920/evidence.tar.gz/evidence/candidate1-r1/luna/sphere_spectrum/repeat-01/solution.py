"""Homogeneous dielectric sphere spectrum using the public treams-rs API."""

from __future__ import annotations

import json
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return sphere cross sections and scattering efficiency for *config*.

    Lengths are micrometers, so the returned cross sections are square
    micrometers.  The imaginary part of epsilon follows the time convention
    used by treams-rs and is passed as the positive imaginary component.
    """
    radius = float(config["radius"])
    epsilon_values = config["epsilon"]
    if len(epsilon_values) != 2:
        raise ValueError("epsilon must be [real, imaginary]")
    epsilon = complex(float(epsilon_values[0]), float(epsilon_values[1]))
    wavelengths = [float(value) for value in config["wavelengths"]]
    lmax = int(config["lmax"])

    if radius <= 0:
        raise ValueError("radius must be positive")
    if lmax < 1:
        raise ValueError("lmax must be positive")
    if any(wavelength <= 0 for wavelength in wavelengths):
        raise ValueError("wavelengths must be positive")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    efficiency: list[float] = []
    geometric_area = 3.141592653589793 * radius * radius

    for wavelength in wavelengths:
        k0 = 2.0 * 3.141592653589793 / wavelength
        response = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=tr.Material(epsilon),
        )
        incident = tr.plane_wave(
            direction=(0.0, 0.0, 1.0),
            polarization="positive_helicity",
            k0=k0,
        )
        cross_sections = response.cross_sections(incident)
        sca = float(cross_sections.scattering)
        ext = float(cross_sections.extinction)
        abs_ = float(cross_sections.absorption)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(abs_)
        efficiency.append(sca / geometric_area)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


if __name__ == "__main__":
    configuration = json.load(sys.stdin)
    json.dump(run(configuration), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
