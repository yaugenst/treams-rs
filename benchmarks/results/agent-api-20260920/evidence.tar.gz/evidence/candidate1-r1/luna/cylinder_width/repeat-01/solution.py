"""Cylinder scattering widths using the public treams-rs API."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return scattering, extinction, and absorption widths for each wavelength."""
    radius = float(config["radius"])
    eps = config["epsilon"]
    epsilon = complex(float(eps[0]), float(eps[1]))
    wavelengths = [float(x) for x in config["wavelengths"]]
    mmax = int(config["mmax"])

    if radius <= 0:
        raise ValueError("radius must be positive")
    if mmax < 0:
        raise ValueError("mmax must be nonnegative")
    if len(eps) != 2:
        raise ValueError("epsilon must be [real, imag]")
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        tmatrix = treams_rs.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=treams_rs.Material(epsilon),
        )
        # Cylindrical helicity channels are [negative, positive].
        incident = treams_rs.PlaneWave(
            [k0, 0.0, 0.0], [0.0, 1.0], k0=k0, poltype="helicity"
        )
        widths = tmatrix.cross_widths(incident)
        scattering.append(float(widths.scattering))
        extinction.append(float(widths.extinction))
        absorption.append(float(widths.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
