# Infinite-cylinder scattering widths

`solution.py` uses the public `treams_rs.cylinder_tmatrix` and
`TMatrixC.cross_widths` APIs. For each wavelength, `k0 = 2π/λ`; the cylinder
has radius and wavelength in micrometers, so all returned widths are in
micrometers. The relative material is `epsilon[0] + i*epsilon[1]`, with
`mu=1`, `kappa=0`, and vacuum exterior.

The incident wave has `kvec=(k0,0,0)`, `kz=0`, and unit positive-helicity
amplitude (`pol=[0,1]` in treams-rs's negative/positive helicity ordering).
No sphere-area normalization is used. The returned absorption width is the
library's extinction-minus-scattering result.

Checks performed: the CLI was run on the supplied example and the output was
saved in `results.json`; the three lists preserve input wavelength order, and
the library-reported widths satisfy the expected nonnegative scattering and
absorption values for that lossy example.
