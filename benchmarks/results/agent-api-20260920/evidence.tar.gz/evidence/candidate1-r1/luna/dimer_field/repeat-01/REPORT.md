# Dimer scattering report

`solution.py` uses the public `treams_rs` API. Each sphere is built with
`sphere_tmatrix` at the requested `lmax`; `Cluster.solve()` supplies the full
coupled response, including all inter-sphere multiple scattering.

Lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers and the cross sections are in square micrometers. Relative
permittivities are formed from each `[real, imag]` pair. The spheres use
`mu=1` and zero chirality, while the exterior is the default vacuum.

The incident wave travels along +z with treams-rs's positive-helicity
normalization. The reported field is the package's incident `efield` plus the
scattered `efield`, evaluated at each requested point. Scattering, extinction,
and absorption are obtained from the solved response; the absorption value is
the package's extinction-minus-scattering balance.

Checks performed: the example was executed through the CLI and saved to
`results.json`; the returned field has one 3-vector per input point, all
values are JSON numbers, and the reported cross sections satisfy absorption
equal to extinction minus scattering to floating-point precision.
