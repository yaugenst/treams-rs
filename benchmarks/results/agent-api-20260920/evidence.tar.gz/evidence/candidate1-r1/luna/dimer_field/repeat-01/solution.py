"""Coupled two-sphere scattering using the public treams-rs API."""

import json
import sys

import numpy as np
import treams_rs


def _complex_epsilon(value):
    """Convert the requested [real, imag] representation to a complex scalar."""
    return complex(float(value[0]), float(value[1]))


def run(config):
    """Evaluate the total electric field and cross sections for the dimer."""
    radii = [float(x) for x in config["radii"]]
    epsilons = [_complex_epsilon(x) for x in config["epsilon"]]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float)

    k0 = 2.0 * np.pi / wavelength
    particles = [
        treams_rs.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=treams_rs.Material(epsilon),
        )
        for radius, epsilon in zip(radii, epsilons)
    ]
    positions = np.asarray(
        [[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]],
        dtype=float,
    )
    cluster = treams_rs.Cluster(particles, positions=positions)
    response = cluster.solve()

    incident = treams_rs.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
    )
    scattered = response.scatter(incident)
    total_field = incident.efield(points) + scattered.efield(points)
    cross_sections = response.cross_sections(incident)

    return {
        "total_field_real": total_field.real.tolist(),
        "total_field_imag": total_field.imag.tolist(),
        "scattering": float(cross_sections.scattering),
        "extinction": float(cross_sections.extinction),
        "absorption": float(cross_sections.absorption),
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")
