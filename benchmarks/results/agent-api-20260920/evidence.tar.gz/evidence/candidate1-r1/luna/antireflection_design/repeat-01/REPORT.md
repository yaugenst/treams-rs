# Coating optimization report

The example was evaluated by `solution.py` and the output is in `results.json`.
All lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. Epsilon is relative and dimensionless; the exterior on the
negative-z side is vacuum (`epsilon=1`, `mu=1`, chirality `0`), and the
positive-z substrate uses the supplied epsilon. The layer order is vacuum,
coating, substrate, with no gap.

The normal-incidence treams-rs plane-wave basis uses the positive-helicity
channel `[0, 1]` for incidence from the negative side. `reflection` is the
reflected power fraction. The objective is evaluated with
`treams_rs.advect.slab` and its native Advect pullback supplies `dR/dthickness`.
Thickness updates use bounded Armijo backtracking gradient descent.

Checks for the supplied example:

- Initial reflected power: `0.09594027275235116`.
- Final thickness: `0.11666732799978849` micrometers, within `[0.025, 0.21]`.
- Final reflected power: `1.3764620425777628e-11` (below `1e-7`).
- Final analytic gradient: `4.162688959938478e-05` per micrometer.
- The loss history decreases monotonically through the accepted steps.
