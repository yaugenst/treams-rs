"""Bounded gradient optimization of a single normal-incidence coating."""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs as tr
import treams_rs.advect as tra


def run(config):
    """Optimize coating thickness and return JSON-compatible scalar results."""
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    lower, upper = (float(x) for x in config["bounds"])
    if wavelength <= 0 or epsilon <= 0 or substrate_epsilon <= 0:
        raise ValueError("wavelength and permittivities must be positive")
    if not lower <= initial <= upper or lower < 0 or lower > upper:
        raise ValueError("initial_thickness must lie within bounds")

    k0 = 2.0 * np.pi / wavelength
    basis = tr.PlaneWavePorts.default([0.0, 0.0])

    # All objects constructed in this objective are from treams_rs.advect,
    # so the returned derivative is the native analytic pullback.
    def reflection(thickness):
        response = tra.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        return response.power([0, 1], side="negative").reflection

    value_and_gradient = ad.value_and_grad(reflection)

    def evaluate(thickness):
        value, gradient = value_and_gradient(float(thickness))
        return float(np.asarray(value)), float(np.asarray(gradient))

    thickness = initial
    initial_reflection, gradient = evaluate(thickness)
    loss_history = [initial_reflection]

    # Armijo backtracking is gradient-based; every derivative used for a step
    # comes from the treams-rs/Advect pullback, never from finite differences.
    for _ in range(2000):
        if loss_history[-1] < 1.0e-10:
            break
        if abs(gradient) < 1.0e-13:
            break
        direction = -gradient
        step = min(0.02, max(upper - lower, 1.0e-12))
        accepted = False
        current = loss_history[-1]
        for _ in range(40):
            candidate = min(upper, max(lower, thickness + step * direction))
            if candidate == thickness:
                break
            candidate_value, candidate_gradient = evaluate(candidate)
            # Sufficient decrease, with a small numerical tolerance near zero.
            if candidate_value <= current + 1.0e-4 * gradient * (candidate - thickness) + 1.0e-14:
                thickness, gradient = candidate, candidate_gradient
                loss_history.append(candidate_value)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    final_reflection, gradient = evaluate(thickness)
    result = {
        "thickness": thickness,
        "reflection": final_reflection,
        "initial_reflection": initial_reflection,
        "gradient": gradient,
        "loss_history": loss_history,
    }
    return result


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
