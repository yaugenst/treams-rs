"""Dimer electric-field intensity and analytic separation sensitivity."""

import json
import sys

import advect
import advect.numpy as anp
import treams_rs.advect as tr


def _objective(separation, *, radius, epsilon, wavelength, lmax, point):
    """Evaluate the fixed-point intensity for a traced separation."""
    k0 = 2.0 * 3.141592653589793 / wavelength
    sphere = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=epsilon,
        medium=1.0,
        polarization="helicity",
    )

    # Both origins depend on separation, so the derivative includes their
    # motion as well as the separation-dependent mutual translation.
    positions = anp.asarray(
        [[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]]
    )
    cluster = tr.Cluster([sphere, sphere], positions=positions)
    incident = tr.PlaneWave([0.0, 0.0, 1.0], 1, k0=k0, medium=1.0)
    scattered = cluster.scatter(incident)
    total = incident.efield(point) + scattered.efield(point)
    return anp.sum(anp.real(total * anp.conj(total)))


def run(config):
    """Return ``value`` and analytic ``dvalue/dseparation`` for *config*."""
    radius = float(config["radius"])
    epsilon_parts = config["epsilon"]
    if len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = anp.asarray(config["point"])

    objective = lambda s: _objective(
        s,
        radius=radius,
        epsilon=epsilon,
        wavelength=wavelength,
        lmax=lmax,
        point=point,
    )
    value, gradient = advect.value_and_grad(objective)(separation)
    return {"value": float(value), "gradient": float(gradient)}


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
