# Dimer sensitivity report

`solution.py` uses the installed `treams_rs.advect` backend. Each sphere is a
homogeneous spherical T-matrix with the requested `lmax`; the two T-matrices
are assembled in a finite `Cluster`, whose scatter operation solves the full
multiple-scattering system. The incident wave propagates in `+z` and uses
helicity label `1` (positive helicity). The reported field is the incident
plane-wave field plus the cluster-scattered field at the supplied point.

Lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. Epsilon is interpreted as `epsilon[0] + i*epsilon[1]`; the
embedding medium has relative permittivity and permeability one. The returned
value is the dimensionless electric intensity `sum_j |E_j|^2` at the point.
The gradient is with respect to separation in micrometers, with sphere origins
at `(-separation/2, 0, 0)` and `(separation/2, 0, 0)`.

The gradient is obtained from `advect.value_and_grad`, which invokes the native
treams-rs pullbacks through T-matrix assembly, cluster multiple scattering,
and field evaluation. No finite difference is used for the returned result.
As checks, the example was executed through both `run` and the stdin CLI, and
the result was independently compared to a centered finite-difference estimate
only as a validation check.
