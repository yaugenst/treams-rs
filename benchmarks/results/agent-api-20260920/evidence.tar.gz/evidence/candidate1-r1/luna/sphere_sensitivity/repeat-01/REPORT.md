# Sphere sensitivity report

`solution.py` uses `treams_rs.advect.sphere_tmatrix` for the finite spherical
T-matrix and `advect.value_and_grad` for native analytic reverse-mode
derivatives.  The incident wave propagates along `+z` with positive helicity.

The input lengths (radius and wavelength) are in micrometers, so
`k0 = 2*pi/wavelength` is in inverse micrometers.  Permittivity is relative
and dimensionless; the sphere material is
`epsilon_real + i*epsilon_imag`, with vacuum exterior (`mu=1`, chirality=0).
The fixed multipole cutoff is `lmax`.  The reported value is

`Q = scattering_cross_section / (pi*radius**2)`.

The gradient is `[dQ/dradius, dQ/depsilon_real]`; differentiation includes
the radius in the normalization.  `results.json` contains the requested
example evaluation.  As a separate check, centered finite differences of
the complete scalar `Q` agree with the reported analytic derivatives to the
precision shown below (the finite differences are validation only).

For the example, the analytic result is
`Q=0.46337644643427434` with gradient
`[18.65367030479629, 0.1997255464561844]`.  With centered step `1e-5`, the
finite-difference estimates were `18.65367034736276` and
`0.19972554649305693` (absolute differences `4.26e-8` and `3.69e-11`).
