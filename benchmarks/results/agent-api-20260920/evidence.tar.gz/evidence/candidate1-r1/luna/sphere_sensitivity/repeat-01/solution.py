"""Lossy-sphere scattering efficiency and analytic sensitivities."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import treams_rs.advect as tr


def _efficiency(radius: Any, epsilon_real: Any, *, epsilon_imag: float,
                wavelength: float, lmax: int) -> Any:
    """Return Q while retaining Advect tracers in radius and epsilon_real."""
    k0 = 2.0 * math.pi / wavelength
    particle = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=epsilon_real + 1j * epsilon_imag,
    )
    incident = tr.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=k0
    )
    scattering = particle.cross_sections(incident).scattering
    return scattering / (ad.numpy.pi * radius * radius)


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Calculate scattering efficiency and its analytic gradient.

    Lengths are in micrometers.  The returned gradient is ordered as
    ``[dQ/dradius, dQ/depsilon_real]``.
    """
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    def objective(r: Any, er: Any) -> Any:
        return _efficiency(
            r,
            er,
            epsilon_imag=epsilon_imag,
            wavelength=wavelength,
            lmax=lmax,
        )

    value, gradient = ad.value_and_grad(objective, argnums=(0, 1))(
        radius, epsilon_real
    )
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
