# Coated sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` solver. The
input radii are interpreted as increasing outer boundaries, and each complex
permittivity pair is assigned inside-out to one finite layer. The exterior is
passed separately as `medium`; it is not added to the finite-layer list.

Lengths are in micrometres, so each wavelength uses the vacuum angular
wavenumber `k0 = 2*pi/lambda` in inverse micrometres. Permittivities are
relative and represented as `real + i*imag`; permeability is the treams-rs
default of one and chirality is zero. The returned cross sections are in
square micrometres.

For each wavelength, `average_cross_sections` supplies the rotationally
averaged scattering and extinction areas. Absorption is checked and reported
as `extinction - scattering`. The example was executed through the CLI, and
its output is stored in `results.json`.
