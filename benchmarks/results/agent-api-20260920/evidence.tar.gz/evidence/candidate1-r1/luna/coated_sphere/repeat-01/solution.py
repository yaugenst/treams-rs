"""Concentric coated-sphere cross sections using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs


def _complex_permittivity(value: Any) -> complex:
    """Convert either a scalar or a [real, imaginary] pair to complex."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ValueError("a permittivity pair must have [real, imag] entries")
        return complex(float(value[0]), float(value[1]))
    return complex(float(value), 0.0)


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return rotationally averaged sphere cross sections for each wavelength."""
    radii = [float(x) for x in config["radii"]]
    layers = config["epsilon_layers"]
    if len(radii) != len(layers) or not radii:
        raise ValueError("radii and epsilon_layers must be nonempty and have equal length")
    if any(r <= 0 for r in radii) or any(a >= b for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be positive and strictly increasing")

    materials = [_complex_permittivity(eps) for eps in layers]
    medium = _complex_permittivity(config.get("epsilon_medium", 1.0))
    lmax = int(config["lmax"])
    if lmax < 1:
        raise ValueError("lmax must be positive")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength_value in config["wavelengths"]:
        wavelength = float(wavelength_value)
        if not math.isfinite(wavelength) or wavelength <= 0:
            raise ValueError("wavelengths must be positive finite values")
        response = treams_rs.multilayer_sphere_tmatrix(
            k0=2.0 * math.pi / wavelength,
            lmax=lmax,
            radii=radii,
            materials=materials,
            medium=medium,
        )
        averaged = response.average_cross_sections
        sca = float(averaged.scattering)
        ext = float(averaged.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(ext - sca)
    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
