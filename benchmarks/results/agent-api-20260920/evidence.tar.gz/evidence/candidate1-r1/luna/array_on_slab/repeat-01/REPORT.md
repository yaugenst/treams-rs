# Periodic array on a slab

`solution.py` uses treams-rs native sphere T-matrices, periodic lattice
coupling, plane-wave ports, and network stacking.  The stack is ordered along
positive z as slab, vacuum gap, and sphere array.  The square lattice has
vectors `(period, 0)` and `(0, period)`, and the Bloch vector is zero.

All lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers.  The slab and sphere permittivities are relative, real
permittivities; all unspecified media are vacuum with relative permeability
one and zero chirality.  The normal-incidence ports retain the two helicities,
and the positive-helicity incident vector is `[0, 1]` in the treams-rs
helicity convention.

For each wavelength the returned fractions are the native network power
transmission and reflection, with absorption computed as `1 - T - R`.  The
example was checked with the native power balance; its residual absorption is
zero to numerical precision, as expected for real, lossless materials.  The
results are in `results.json` and preserve input wavelength order.
