"""Periodic sphere array above a dielectric slab, using treams-rs."""

import json
import sys

import numpy as np
import treams_rs as tr


def run(config):
    """Return wavelength-ordered power fractions for the specified structure."""
    radius = float(config["radius"])
    sphere_epsilon = float(config["sphere_epsilon"])
    period = float(config["period"])
    gap = float(config["gap"])
    slab_thickness = float(config["slab_thickness"])
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])

    if period <= 0 or radius <= 0 or gap < 0 or slab_thickness < 0:
        raise ValueError("lengths must be positive, except gap and slab thickness")
    if lmax < 0:
        raise ValueError("lmax must be nonnegative")

    # The default normal-incidence basis contains the two helicity channels.
    # With helicity polarization, [0, 1] is positive helicity (treams-rs API).
    ports = tr.PlaneWavePorts.default([0.0, 0.0])
    incident = [0.0, 1.0]
    cell = [[period, 0.0], [0.0, period]]

    transmission = []
    reflection = []
    absorption = []
    for wavelength in config["wavelengths"]:
        wavelength = float(wavelength)
        if wavelength <= 0:
            raise ValueError("wavelengths must be positive")
        k0 = 2.0 * np.pi / wavelength

        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon
        )
        array_response = tr.solve_periodic(
            sphere, lattice=cell, kpar=[0.0, 0.0]
        )
        array = array_response.to_smatrix(ports)

        slab = tr.slab(
            basis=ports,
            k0=k0,
            thickness=slab_thickness,
            material=slab_epsilon,
        )
        vacuum_gap = tr.propagation(
            distance=gap, basis=ports, k0=k0
        )
        network = tr.stack([slab, vacuum_gap, array])
        balance = network.power(incident, side="negative")
        t = float(np.real(balance.transmission))
        r = float(np.real(balance.reflection))
        a = float(np.real(1.0 - t - r))
        # Suppress harmless roundoff while retaining any genuine residual.
        if abs(a) < 1e-12:
            a = 0.0
        transmission.append(t)
        reflection.append(r)
        absorption.append(a)

    return {
        "wavelengths": [float(w) for w in config["wavelengths"]],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
