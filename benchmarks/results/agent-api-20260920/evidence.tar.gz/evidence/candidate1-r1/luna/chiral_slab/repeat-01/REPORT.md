# Chiral slab report

`solution.py` uses `treams_rs.slab` and its normal-incidence plane-wave ports.
All lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. The supplied epsilon pair is converted to the complex relative
permittivity `epsilon[0] + i*epsilon[1]`; permeability is one and `kappa` is
passed as the dimensionless package chirality.

The returned columns are positive then negative helicity, and each row is one
wavelength. `treams_rs.power` supplies transmitted and reflected powers
normalized to incident power; absorption is its package-defined remainder
`1 - T - R`. Incidence is from the negative side, i.e. along +z. The example
was executed and its output was saved in `results.json`.

Checks performed: the output has the requested `(wavelengths, 2)` shape, and
the package power balance was evaluated independently for both helicity
channels at every wavelength.
