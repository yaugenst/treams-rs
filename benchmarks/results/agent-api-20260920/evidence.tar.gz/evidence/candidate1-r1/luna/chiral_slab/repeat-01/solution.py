"""Normal-incidence scattering from a reciprocal chiral slab."""

from __future__ import annotations

import json
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[list[float]]]:
    """Return T, R and A for positive and negative helicity at each wavelength."""
    thickness = float(config["thickness"])
    epsilon = config["epsilon"]
    if not isinstance(epsilon, (list, tuple)) or len(epsilon) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon_value = complex(float(epsilon[0]), float(epsilon[1]))
    kappa = complex(float(config.get("kappa", 0.0)))
    wavelengths = [float(value) for value in config["wavelengths"]]

    # The component basis is ordered (positive, negative) by treams-rs.
    ports = tr.PlaneWavePorts.default([0.0, 0.0])
    material = tr.Material(epsilon_value, 1.0, kappa)
    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    for wavelength in wavelengths:
        network = tr.slab(
            basis=ports,
            k0=2.0 * 3.141592653589793 / wavelength,
            thickness=thickness,
            material=material,
            polarization="helicity",
        )
        row_t: list[float] = []
        row_r: list[float] = []
        row_a: list[float] = []
        for incident in ([0.0, 1.0], [1.0, 0.0]):
            balance = network.power(incident, side="negative")
            row_t.append(float(balance.transmission))
            row_r.append(float(balance.reflection))
            row_a.append(float(balance.absorption))
        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
