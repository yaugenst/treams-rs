"""Two-sphere (dimer) scattering with treams-rs.

Geometry: spheres at x = -separation/2 and +separation/2 (y = z = 0), radii and
permittivities given in that order.  Illumination is a plane wave travelling
along +z with positive helicity, in vacuum.  All multiple scattering between the
spheres is retained at the fixed multipole cutoff ``lmax``.

Lengths are in micrometers, permittivities are relative and dimensionless
(``[real, imag]`` pairs), mu = 1 and kappa = 0 everywhere, exterior is vacuum.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as tr


def _material(eps):
    """Build a Material from an ``[real, imag]`` pair (or a plain scalar)."""
    if isinstance(eps, (list, tuple)):
        value = complex(eps[0], eps[1])
    else:
        value = complex(eps)
    return tr.Material(value)


def run(config):
    radii = [float(r) for r in config["radii"]]
    epsilon = list(config["epsilon"])
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float).reshape(-1, 3)

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um

    positions = np.array(
        [[-0.5 * separation, 0.0, 0.0], [0.5 * separation, 0.0, 0.0]], dtype=float
    )

    # Individual Mie T-matrices in the helicity basis (exterior: vacuum).
    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=r,
            material=_material(e),
            medium=1,
            polarization="helicity",
        )
        for r, e in zip(radii, epsilon)
    ]

    # Coupled cluster response: solve() includes all multiple scattering orders.
    cluster = tr.Cluster(particles, positions=positions)
    solved = cluster.solve()

    # Incident plane wave: +z propagation, positive helicity, unit amplitude
    # (package incident normalization, |E_inc| = 1).
    incident = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        material=1,
    )

    scattered = solved.scatter(incident)

    e_inc = np.asarray(incident.efield(points), dtype=complex).reshape(-1, 3)
    e_sca = np.asarray(scattered.efield(points), dtype=complex).reshape(-1, 3)
    e_tot = e_inc + e_sca

    cs = solved.cross_sections(incident)

    inside = ~np.asarray(solved.valid_points(points, radii), dtype=bool).reshape(-1)

    return {
        "total_field_real": e_tot.real.tolist(),
        "total_field_imag": e_tot.imag.tolist(),
        "scattering_cross_section": float(cs.scattering),
        "extinction_cross_section": float(cs.extinction),
        "absorption_cross_section": float(cs.absorption),
        "wavelength": wavelength,
        "k0": float(k0),
        "positions": positions.tolist(),
        "lmax": lmax,
        "points_inside_circumscribing_spheres": inside.tolist(),
        "units": {
            "length": "um",
            "cross_section": "um^2",
            "field": "dimensionless (unit-amplitude incident plane wave)",
        },
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
