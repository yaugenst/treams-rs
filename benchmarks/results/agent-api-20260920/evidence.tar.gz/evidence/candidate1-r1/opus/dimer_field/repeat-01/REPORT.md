# Dimer scattering and total near field (treams-rs)

`solution.py` exposes `run(config)` and a CLI (`python solution.py < config.json`)
that reads one config dict from stdin and prints the result dict as JSON.

## Model

Two homogeneous spheres in vacuum at `x = ∓separation/2`, `y = z = 0`, with
`radii[0]/epsilon[0]` at the negative-x site and `radii[1]/epsilon[1]` at the
positive-x site.

* Mie T-matrices: `treams_rs.sphere_tmatrix(k0, lmax, radius, material, medium=1,
  polarization="helicity")`, with `k0 = 2π/wavelength`.
* Multiple scattering: `Cluster(particles, positions=...).solve()` returns the
  fully coupled finite response (all scattering orders, no Born truncation) in a
  local two-origin spherical basis at the fixed `lmax`.
* Illumination: `plane_wave(direction=[0,0,1], polarization="positive_helicity",
  k0=k0, material=1)` — unit-amplitude plane wave along +z, package incident
  normalization (`|E_inc| = 1`, `E_inc(0) = (-1,-i,0)/√2`).
* Total field: `incident.efield(points) + solved.scatter(incident).efield(points)`,
  evaluated with the package's own kernels.
* Cross sections: `solved.cross_sections(incident)` (default `flux=0.5`, which is
  the matching normalization for the unit-amplitude plane wave above).

No numerics are reimplemented; every scattering quantity comes from treams-rs.
The task requests no sensitivity/optimization output, so no derivatives are used
in the returned results.

## Units and conventions

* Lengths (radii, separation, wavelength, point coordinates, positions) in µm;
  `k0` in 1/µm.
* `epsilon` entries are `[real, imag]` relative permittivities; `mu = 1`,
  `kappa = 0`, exterior vacuum (`Material(1)`).
* Cross sections in µm²; fields are dimensionless amplitudes relative to the
  unit incident plane wave, in Cartesian components (Ex, Ey, Ez).
* Time convention is the package's `exp(-iωt)` (outgoing waves ∝ `h_l^{(1)}`),
  so the complex amplitude is `E(r) = (real + i·imag)`.
* `total_field_real` / `total_field_imag` are `len(points) × 3` nested lists in
  the input point order.

## Output keys

`total_field_real`, `total_field_imag`, `scattering_cross_section`,
`extinction_cross_section`, `absorption_cross_section`, plus diagnostics
`wavelength`, `k0`, `positions`, `lmax`, `units`, and
`points_inside_circumscribing_spheres` (from `TMatrix.valid_points`; the
multipole expansion is only valid at points outside the circumscribing spheres —
all example points are outside).

## Example result (`results.json`)

Config: radii (0.08, 0.11) µm, ε = (4+0.02i, 6+0.08i), separation 0.32 µm,
λ = 0.72 µm, lmax 3.

* σ_sca = 0.05648477 µm², σ_ext = 0.05910237 µm², σ_abs = 0.00261760 µm²
* E_tot(0,0,0.3) = (0.80919−0.26914i, 0.23513+0.82034i, 0.03110+0.07267i)
* E_tot(0.35,0.2,0.1) = (−0.22645−0.60503i, 0.52804−0.43737i, −0.02124−0.12125i)

## Checks performed (`checks.py`)

1. Energy balance: `ext − sca − abs = 0` exactly, `abs > 0`, `sca ≤ ext`.
2. Multipole convergence: going from lmax 3 → 6 changes σ_sca/σ_ext by ~1e-6
   relative and the fields by ≤3e-5 in absolute amplitude; lmax 3 as requested
   is well converged (lmax is still taken from the config, not forced).
3. Coupling limit: at separation 400 µm the coupled cluster reproduces the sum
   of the two isolated Mie cross sections to ~8e-5 relative, confirming correct
   positions/assembly; at 0.32 µm the coupled values differ from that sum by
   ~2%, i.e. multiple scattering is genuinely included.
4. Maxwell residuals of the returned total field by central finite differences
   (validation only): |∇·E| ≲ 1e-4 and the relative Helmholtz residual
   |∇²E + k0²E| / (k0²|E|) ≲ 3e-5, limited by the finite-difference step.
5. Achiral-dimer symmetry: negative-helicity illumination yields identical cross
   sections, as it must for non-chiral spheres.
