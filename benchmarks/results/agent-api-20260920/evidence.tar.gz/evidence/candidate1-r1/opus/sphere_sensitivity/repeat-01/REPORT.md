# Lossy sphere: scattering efficiency and analytic sensitivities

## Task

For a homogeneous, lossy sphere in vacuum illuminated by a positive-helicity
plane wave propagating along +z, compute

    Q = sigma_scat / (pi * radius**2)

and the gradient `[dQ/dradius, dQ/depsilon_real]`, holding `epsilon_imag`,
`wavelength` and `lmax` fixed.

## Files

- `solution.py` — `run(config)` plus a CLI (`python solution.py < config.json`)
  that reads one config dict from stdin and prints the result dict as JSON.
- `results.json` — output for the example config.
- `verify_gradient.py` — independent finite-difference validation (checks only;
  the reported derivatives come from treams-rs' analytic pullbacks).

## Units and conventions

- Lengths (`radius`, `wavelength`) are in micrometers; cross sections in µm².
- `k0 = 2*pi/wavelength` is the vacuum angular wavenumber (rad/µm). It is held
  fixed while `radius` and `epsilon_real` vary.
- Permittivity is relative and dimensionless, `epsilon = epsilon_real + 1j*epsilon_imag`
  with the `exp(-i omega t)` convention used by treams, so `epsilon_imag > 0`
  is loss (the returned absorption cross section is positive, confirming this).
- `mu = 1`, `kappa = 0`, exterior medium is vacuum (`medium=1`).
- Incidence: `plane_wave([0, 0, 1], "positive_helicity", k0=k0)`, i.e. the
  helicity polarization basis, which is the natural basis for `sphere_tmatrix`.
- `lmax` is the fixed multipole cutoff (static, not differentiated).
- `Q` is dimensionless; the gradient components carry units 1/µm and
  dimensionless, respectively.

## Method

`treams_rs.advect.sphere_tmatrix` builds the Mie T-matrix and
`response.cross_sections(wave).scattering` gives sigma_scat. The whole
objective, **including the geometric normalization `pi*radius**2`**, is
evaluated inside a single traced function, so `radius` enters both through the
Mie coefficients and through the denominator. `advect.value_and_grad` returns
the value and the reverse-mode gradient using treams-rs' native analytic
pullbacks — no finite differences are used to produce the answer. A fresh
traced call is made per evaluation, as required by the adapter (each reverse
pass consumes its residual once).

## Example result

Config `{radius: 0.1, epsilon_real: 4.0, epsilon_imag: 0.06, wavelength: 0.72, lmax: 3}`:

- `Q = 0.4633764464342743`
- `dQ/dradius = 18.65367030479629` µm⁻¹
- `dQ/depsilon_real = 0.1997255464561844`
- sigma_scat = 0.0145574004 µm², sigma_ext = 0.0156358052 µm²,
  sigma_abs = 0.0010784048 µm², size parameter `k0*r = 0.8727`.

## Checks

1. **Gradient vs. central finite differences** (`verify_gradient.py`, step 1e-6)
   for three different configs, including different `lmax`, radius, loss and
   wavelength: relative agreement 1e-12 … 3e-9 on both components.
2. **Energy balance**: `sigma_ext = sigma_sca + sigma_abs` holds, and
   `sigma_abs > 0` for `epsilon_imag > 0` (loss, correct sign convention).
3. **Symmetry**: for a sphere the scattering cross section is independent of
   incidence direction and helicity; `positive_helicity` along +z,
   `negative_helicity` along +z, `positive_helicity` along +x and the
   rotational/polarization average `xs_sca_avg` all agree to ~1e-17, as
   expected for an isotropic, achiral scatterer.
4. **Size-parameter sanity**: with `k0*r < 1` and moderate index, `Q < 1` and
   the response is dominated by the lowest multipoles; results are converged
   well before `lmax = 3` for the example.
