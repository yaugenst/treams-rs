"""Scattering efficiency of a lossy sphere and its analytic sensitivities.

Q = sigma_scat / (pi * radius**2) for a homogeneous sphere illuminated by a
positive-helicity plane wave travelling along +z, together with the gradient
[dQ/dradius, dQ/depsilon_real] obtained from treams-rs' analytic pullbacks
through the Advect adapter.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs.advect as tr


def _efficiency(params, eps_imag, k0, lmax):
    """Q(radius, epsilon_real); works on plain floats and on traced values."""
    radius, eps_real = params[0], params[1]
    sphere = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=tr.Material(eps_real + 1j * eps_imag),
        medium=1,
    )
    wave = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    # The geometric cross section is differentiated along with sigma_scat.
    return sphere.cross_sections(wave).scattering / (np.pi * radius**2)


def run(config):
    radius = float(config["radius"])
    eps_real = float(config["epsilon_real"])
    eps_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    k0 = 2.0 * np.pi / wavelength

    def objective(params):
        return _efficiency(params, eps_imag, k0, lmax)

    value, gradient = ad.value_and_grad(objective)(np.array([radius, eps_real]))

    sphere = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=tr.Material(eps_real + 1j * eps_imag),
        medium=1,
    )
    xs = sphere.cross_sections(
        tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    )

    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
        "scattering_cross_section": float(xs.scattering),
        "extinction_cross_section": float(xs.extinction),
        "absorption_cross_section": float(xs.absorption),
        "geometric_cross_section": float(np.pi * radius**2),
        "k0": float(k0),
        "size_parameter": float(k0 * radius),
        "gradient_parameters": ["radius", "epsilon_real"],
        "units": {
            "length": "micrometer",
            "cross_section": "micrometer**2",
            "value": "dimensionless",
            "gradient": ["1/micrometer", "dimensionless"],
        },
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
