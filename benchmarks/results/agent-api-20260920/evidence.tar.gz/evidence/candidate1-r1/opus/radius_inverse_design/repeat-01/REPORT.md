# Sphere radius inverse design from scattering efficiencies

## Problem
Given target scattering efficiencies measured at several vacuum wavelengths, recover the
radius of a homogeneous, lossless sphere of fixed permittivity in vacuum, by minimising

    L(r) = mean_i ( (Q_i(r) - Q_i^target) / Q_i^target )^2

over `r` within `bounds`, starting from `initial_radius`.

## Forward model (treams-rs)
For each wavelength `wl`:

* `k0 = 2*pi/wl` (rad/um),
* `treams_rs.advect.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=epsilon)` gives the
  analytic Mie T-matrix of the sphere in the default vacuum exterior (`medium=1`),
  helicity polarization basis,
* `tm.cross_sections(plane_wave([0,0,1], 0, k0=k0)).scattering` is the scattering cross
  section `sigma_sca` in um^2 for a unit-amplitude plane wave along +z,
* the efficiency is `Q_sca = sigma_sca / (pi r^2)` (dimensionless).

For a sphere the response is rotationally invariant and degenerate in polarization, so the
choice of incidence direction and polarization index does not affect `Q_sca`
(checked against `tm.average_cross_sections`, which agrees to machine precision).

## Units and conventions
* All lengths (radius, wavelengths, bounds) are in micrometers; `k0` in rad/um.
* `epsilon` is the relative permittivity, real and positive (lossless); `mu = 1`,
  `kappa = 0`, exterior is vacuum. Absorption is therefore zero and
  `extinction == scattering` (verified).
* `lmax` is the fixed multipole cutoff used as supplied; it is not increased internally.
* `Q` is the scattering *efficiency*: cross section divided by the geometric cross section
  `pi r^2`. Note the geometric factor also depends on `r`, and is included in the
  differentiated expression.
* The loss is the mean of squared *relative* residuals, so it is dimensionless;
  `gradient = dL/dr` has units of 1/um.

## Derivatives
Gradients are analytic, obtained by reverse-mode automatic differentiation through the
treams-rs Advect adapter: `treams_rs.advect` builds the T-matrix and cross sections from
traced parameters, and `treams_rs.advect.ad.value_and_grad` supplies `L(r)` and `dL/dr` in
one pass. No finite differences enter the optimisation or the reported gradient.

Validation (finite differences used **only** as a check, central differences, h = 1e-6 um):

| r (um) | analytic dL/dr | central FD | rel. diff |
|---|---|---|---|
| 0.070 | -15.951215469 | -15.951215469 | 2.4e-11 |
| 0.095 | -20.803642549 | -20.803642534 | 6.9e-10 |
| 0.130 | 136.720286692 | 136.720286518 | 1.3e-09 |

## Optimiser
Projected gradient descent on `[lo, hi]` with Armijo backtracking line search and
Barzilai–Borwein step-length guesses, started at `initial_radius` (clipped into bounds).
The first trial step is scaled to move ~10% of the bound interval, which makes the method
insensitive to the magnitude of `dL/dr`. Iterates are clipped to the bounds at every step,
so the returned radius always satisfies the constraints. If the descent from
`initial_radius` were to stall above the 1e-7 tolerance (a local minimum of the oscillatory
Mie response), a safeguard restarts from the best points of a 33-point scan of the bounds;
it was not triggered for the example config.

## Example result (`results.json`)
Config: `epsilon = 4.0`, `lmax = 3`, `wavelengths = [0.58, 0.69, 0.81] um`,
`initial_radius = 0.075 um`, `bounds = [0.06, 0.14] um`.

* `radius = 0.1099999999 um`
* `initial_loss = 6.2153e-01`, `loss = 1.98e-17` (well below the 1e-7 requirement)
* final `gradient = -3.25e-07` 1/um (stationary to numerical precision)
* `fitted_efficiencies = [1.56279817, 0.80192154, 0.42538712]`, matching the targets to
  ~5e-9 relative
* 6 accepted line-search steps (`loss_history` has 7 entries, starting at `initial_loss`).

## Checks performed
* Analytic vs. finite-difference gradients agree to ~1e-9 relative (table above).
* Energy consistency: `extinction == scattering` and `absorption == 0` for the lossless
  sphere.
* Round-trip identifiability: targets synthesised from known radii
  (0.061, 0.07, 0.09, 0.11, 0.125, 0.139 um) were recovered to better than 1e-6 um from
  four different starting radii each (24/24 cases, all with final loss < 1e-7), including
  starts at both bounds.
* A different material/cutoff (`epsilon = 9`, `lmax = 5`) also recovers its true radius
  (loss ~3e-23), confirming nothing is specialised to the example values.

## Usage
```
python solution.py < config.json      # prints the result dictionary as JSON
```
or `from solution import run; run(config)`.

Returned keys: `radius`, `loss`, `initial_loss`, `gradient`, `fitted_efficiencies`,
`loss_history`, plus the echoed `target_efficiencies`, `wavelengths`, `bounds`, and the
diagnostics `converged` and `n_iterations`.
