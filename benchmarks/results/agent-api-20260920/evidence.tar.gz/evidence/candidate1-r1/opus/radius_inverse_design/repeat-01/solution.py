"""Infer a lossless sphere radius from target scattering efficiencies.

The forward model is treams-rs' analytic Mie (``sphere_tmatrix``) response of a
homogeneous sphere in vacuum.  Radius gradients come from the Advect adapter
shipped with treams-rs (``treams_rs.advect`` + ``treams_rs.advect.ad``), i.e.
they are analytic pullbacks, never finite differences.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs.advect as tra
from treams_rs.advect import ad


def _efficiencies(radius, wavelengths, epsilon, lmax):
    """Scattering efficiencies Q_sca = sigma_sca / (pi r^2) at each wavelength.

    ``radius`` may be an Advect tracer; everything below is traced.
    """
    out = []
    geom = np.pi * radius * radius
    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl
        tm = tra.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)
        pw = tra.plane_wave([0.0, 0.0, 1.0], 0, k0=k0)
        out.append(tm.cross_sections(pw).scattering / geom)
    return out


def _loss(radius, wavelengths, epsilon, lmax, targets):
    qs = _efficiencies(radius, wavelengths, epsilon, lmax)
    acc = 0.0
    for q, tgt in zip(qs, targets):
        rel = (q - tgt) / tgt
        acc = acc + rel * rel
    return acc / len(targets)


def _descend(r0, value_and_grad, lo, hi):
    """Projected gradient descent with Armijo backtracking and BB steps."""
    r = r0
    loss, grad = value_and_grad(r)
    history = [loss]

    # Scale the first trial step so it moves a sensible fraction of the bound
    # interval even though d(loss)/dr carries units of 1/length.
    step = 0.1 * (hi - lo) / max(abs(grad), 1e-300)

    for _ in range(500):
        if loss < 1e-14 or grad == 0.0:
            break
        accepted = False
        trial = step
        for _ls in range(60):
            r_new = min(max(r - trial * grad, lo), hi)
            if r_new == r:
                break
            loss_new, grad_new = value_and_grad(r_new)
            # Armijo condition on the actually taken (projected) step.
            if loss_new <= loss - 1e-4 * grad * (r - r_new):
                dr, dg = r_new - r, grad_new - grad
                r, loss, grad = r_new, loss_new, grad_new
                history.append(loss)
                # Barzilai-Borwein guess for the next step length.
                step = abs(dr / dg) if dg != 0.0 else trial
                step = min(max(step, 1e-12), (hi - lo) / max(abs(grad), 1e-300))
                accepted = True
                break
            trial *= 0.5
        if not accepted:
            break
        if abs(history[-2] - history[-1]) < 1e-18 * max(1.0, history[-1]):
            break
    return r, loss, grad, history


def run(config):
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    targets = [float(t) for t in config["target_efficiencies"]]
    lo, hi = (float(b) for b in config["bounds"])
    r0 = float(np.clip(float(config["initial_radius"]), lo, hi))

    if len(wavelengths) != len(targets):
        raise ValueError("wavelengths and target_efficiencies must have equal length")

    def objective(r):
        return _loss(r, wavelengths, epsilon, lmax, targets)

    vg = ad.value_and_grad(objective)

    def value_and_grad(r):
        v, g = vg(float(r))
        return float(v), float(g)

    r, loss, grad, history = _descend(r0, value_and_grad, lo, hi)
    initial_loss = history[0]

    # Safeguard: if the descent from `initial_radius` stalled in a local
    # minimum, restart from the best point of a coarse scan of the bounds.
    if loss >= 1e-7:
        grid = np.linspace(lo, hi, 33)
        vals = [(objective(float(g)), float(g)) for g in grid]
        vals.sort()
        for _, g in vals[:4]:
            r2, loss2, grad2, hist2 = _descend(g, value_and_grad, lo, hi)
            history.extend(hist2[1:])
            if loss2 < loss:
                r, loss, grad = r2, loss2, grad2
            if loss < 1e-12:
                break

    fitted = [float(q) for q in _efficiencies(r, wavelengths, epsilon, lmax)]

    return {
        "radius": float(r),
        "loss": float(loss),
        "initial_loss": float(initial_loss),
        "gradient": float(grad),
        "fitted_efficiencies": fitted,
        "loss_history": [float(h) for h in history],
        "target_efficiencies": targets,
        "wavelengths": wavelengths,
        "bounds": [lo, hi],
        "converged": bool(loss < 1e-7),
        "n_iterations": len(history) - 1,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
