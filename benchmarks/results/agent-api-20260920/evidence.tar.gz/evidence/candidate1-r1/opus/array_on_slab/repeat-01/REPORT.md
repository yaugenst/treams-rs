# Sphere array above a dielectric slab

## What is computed

For each wavelength, the zeroth-order power fractions (transmission, reflection,
absorption) of the stack

```
vacuum | slab | vacuum gap | sphere array | vacuum
```

ordered along **+z**, illuminated from the **negative-z** side, propagating along
+z, with **positive helicity**.

## Units and conventions

- All lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) are in
  micrometers; only the ratio to the wavelength matters. `k0 = 2*pi/wavelength`
  is the vacuum angular wavenumber, so `1/k0` shares the length unit.
- `sphere_epsilon`, `slab_epsilon` are real relative permittivities; `mu = 1`,
  `kappa = 0`, and all exterior media are vacuum.
- Polarization convention is **helicity** throughout (the treams-rs default).
  The incident field is defined physically via
  `plane_wave(direction=[0,0,1], polarization="positive_helicity", k0=k0)`, so the
  incidence side (negative) and the channel amplitudes are inferred from the wave
  rather than hard-coded as a raw amplitude vector.
- Plane-wave ports: `PlaneWavePorts.default([[0, 0]])` — the single zeroth
  diffraction order at Bloch vector `kpar = [0, 0]`, with both polarization
  channels. Since every wavelength exceeds the period, all higher orders are
  evanescent, so the propagating-channel truncation is exact for the far field.
- Reference planes: the slab S-matrix is referenced to its two surfaces; the
  array S-matrix (from `PeriodicResponse.to_smatrix`) is referenced to the
  sphere-center plane. The `propagation(distance=gap)` layer inserted between
  them therefore places `gap` between the **slab top surface** and the
  **sphere-center plane**, as specified.
- Outputs are ordered by ascending wavelength (`wavelengths` is sorted and echoed
  back), and power fractions are normalized to the incident flux, so
  `T + R + A = 1`.

## Method (treams-rs)

1. `sphere_tmatrix(k0, lmax, radius, material)` — Mie T-matrix of one sphere in
   vacuum at the fixed multipole cutoff `lmax`.
2. `solve_periodic(tmat, lattice=Lattice(period*I2, "xy"), kpar=[0,0])` — the
   **full** Bloch-periodic interaction of the square array is solved once via the
   Ewald lattice sums (eta chosen natively); this is not a single-scattering
   approximation.
3. `PeriodicResponse.to_smatrix(basis)` — projection of the solved array onto the
   retained up/down diffraction ports.
4. `slab(...)` and `propagation(...)` give the slab and gap S-matrices;
   `stack([slab, gap, array])` cascades them from the negative to the positive
   side.
5. `SMatrix.power(incident_plane_wave)` returns the `PowerBalance`
   (transmission / reflection / absorption fractions).

No derivatives or optimization are requested by this task, so none are computed.

## Checks performed

- **Power balance**: `max |T + R + A - 1| = 1.1e-16` over the example wavelengths.
- **Losslessness**: both permittivities are real, so absorption must vanish;
  computed `|A| <= 8.5e-16` (pure round-off). This is reported as
  `checks.max_abs_absorption`.
- **Multipole convergence**: transmission at the example config for
  `lmax = 1, 2, 3, 4` is `0.88811 / 0.88733 / 0.88734 / 0.88734` at 0.65 um
  (similar at the other wavelengths); the requested `lmax = 2` is converged to
  ~1e-5. The reported results use the `lmax` from the config, as required.
- **Bare-slab limit**: with the array removed, treams-rs gives
  `R = 0.12599314968626693` at 0.74 um versus the analytic Fabry-Perot result
  `|r(1-e^{2i n k0 d})/(1-r^2 e^{2i n k0 d})|^2 = 0.12599314968626696`
  (r = (1-n)/(1+n), n = 1.5) — agreement to machine precision. Shrinking the
  sphere radius to 1e-6 um reproduces the same bare-slab transmission.
- **Reciprocity**: illuminating from the positive-z side gives the identical
  transmission (0.9020687269885588 vs 0.9020687269885590 at 0.74 um).
- **Mirror/helicity symmetry**: the achiral, z-mirror-symmetric-per-layer network
  gives the same transmission for negative helicity, as expected.
- `checks.zeroth_order_only` records that every wavelength exceeds the period, the
  condition under which keeping only the zeroth order is exact.

## Results for the example config

| wavelength (um) | T | R | A |
|---|---|---|---|
| 0.65 | 0.8873286362852495 | 0.1126713637147514 | -8.5e-16 |
| 0.74 | 0.9020687269885590 | 0.0979312730114408 |  2.4e-16 |
| 0.83 | 0.9119142686008943 | 0.0880857313991062 | -5.3e-16 |

Absorption is zero to round-off; the tiny negative values are retained verbatim
rather than clipped, so that `T + R + A` sums exactly to one.

## Usage

```
python solution.py < config.json > results.json
```

or `from solution import run; run(config_dict)`.
