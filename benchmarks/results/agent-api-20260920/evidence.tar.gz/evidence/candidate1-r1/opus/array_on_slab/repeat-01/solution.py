"""Square array of spheres above a dielectric slab, illuminated from below.

Network order along +z: [vacuum] slab | vacuum gap | sphere array [vacuum].
The incident wave travels along +z with positive helicity, so it enters from
the negative-z exterior of the stack.  Only the zeroth diffraction order is
retained (both polarization channels), with Bloch vector [0, 0].
"""

import json
import sys

import numpy as np
import treams_rs as treams


def _stack_for_wavelength(wavelength, cfg):
    """Build the cascaded S-matrix of slab + gap + array at one wavelength."""
    k0 = 2.0 * np.pi / wavelength

    # Zeroth-order plane-wave ports (both polarizations) at kpar = [0, 0].
    basis = treams.PlaneWavePorts.default([[0.0, 0.0]])

    # Isolated sphere, then the full periodic (Ewald-summed) interaction.
    tmat = treams.sphere_tmatrix(
        k0=k0,
        lmax=cfg["lmax"],
        radius=cfg["radius"],
        material=cfg["sphere_epsilon"],
    )
    lattice = treams.Lattice(np.eye(2) * cfg["period"], "xy")
    array = treams.solve_periodic(tmat, lattice=lattice, kpar=[0.0, 0.0])

    layers = [
        treams.slab(
            basis=basis,
            k0=k0,
            thickness=cfg["slab_thickness"],
            material=cfg["slab_epsilon"],
        ),
        treams.propagation(distance=cfg["gap"], basis=basis, k0=k0),
        array.to_smatrix(basis),
    ]
    return treams.stack(layers), k0


def run(config):
    cfg = dict(config)
    wavelengths = [float(w) for w in cfg["wavelengths"]]
    period = float(cfg["period"])

    transmission, reflection, absorption = [], [], []
    checks = {
        "max_power_balance_error": 0.0,
        "max_abs_absorption": 0.0,
        "zeroth_order_only": all(w > period for w in wavelengths),
    }

    for wavelength in sorted(wavelengths):
        net, k0 = _stack_for_wavelength(wavelength, cfg)
        incident = treams.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
        )
        balance = net.power(incident)
        t_, r_, a_ = (
            float(balance.transmission),
            float(balance.reflection),
            float(balance.absorption),
        )
        transmission.append(t_)
        reflection.append(r_)
        absorption.append(a_)
        checks["max_power_balance_error"] = max(
            checks["max_power_balance_error"], abs(t_ + r_ + a_ - 1.0)
        )
        checks["max_abs_absorption"] = max(checks["max_abs_absorption"], abs(a_))

    return {
        "wavelengths": sorted(wavelengths),
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "lmax": int(cfg["lmax"]),
        "checks": checks,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
