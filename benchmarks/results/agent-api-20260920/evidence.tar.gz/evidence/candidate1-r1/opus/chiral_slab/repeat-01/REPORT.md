# Chiral slab at normal incidence — power fractions

## What is computed

A uniform, reciprocal, isotropic chiral slab of thickness `d`, normal to z and
bounded by vacuum on both sides, is illuminated by a unit-amplitude plane wave
travelling along **+z**. For each vacuum wavelength and each circular
polarization we report the fractions of the incident power that are
transmitted, reflected and absorbed.

Implementation: `treams_rs.slab(...)` builds the layer scattering network in the
helicity basis, and `SMatrices.power(incident)` returns the
`PowerBalance(transmission, reflection, absorption)` for the given incident
plane wave. No scattering physics is re-implemented here.

## Units and conventions

- Lengths (`thickness`, `wavelengths`) in micrometers; `k0 = 2*pi/wavelength`
  in 1/micrometer.
- `epsilon` is the relative permittivity given as `[real, imag]` (a bare scalar
  is also accepted); `mu` defaults to 1, `kappa` (the treams material chirality)
  defaults to 0 and may be a scalar or `[real, imag]`. All are dimensionless.
- Time convention exp(-i omega t): a passive medium has Im(epsilon) >= 0, and
  the slab eigen-indices are `n_pm = sqrt(epsilon*mu) ± kappa`, with the branch
  chosen for non-negative imaginary part (decaying along the propagation
  direction). `treams_rs.Material.nmp` supplies them; they are echoed in the
  output as `refractive_indices` (positive helicity first, `[real, imag]`).
- Helicity: positive helicity is treams polarization label 1 (index `n_plus`),
  negative helicity label 0 (`n_minus`). The incident field is constructed
  explicitly as `plane_wave(direction=[0,0,1], polarization="positive_helicity"
  / "negative_helicity")`, so the labelling does not rely on basis ordering; the
  incident side ("negative", i.e. below the slab) is inferred from the +z
  propagation direction.
- Outputs `transmission`, `reflection`, `absorption` have shape
  `(len(wavelengths), 2)` with column 0 = positive helicity, column 1 = negative
  helicity. They are **power fractions** (|amplitude|^2 weighted by the axial
  time-averaged Poynting flux), not complex amplitude coefficients; each triple
  sums to 1.

## Example result (thickness 0.16, epsilon 2.25+0.06i, kappa 0.08)

| wavelength (um) | T (+/-) | R (+/-) | A (+/-) |
|---|---|---|---|
| 0.55 | 0.905416 / 0.905416 | 0.024049 / 0.024049 | 0.070536 / 0.070536 |
| 0.65 | 0.864572 / 0.864572 | 0.080756 / 0.080756 | 0.054673 / 0.054673 |
| 0.80 | 0.826736 / 0.826736 | 0.130154 / 0.130154 | 0.043110 / 0.043110 |

The two helicities coincide here, which is the correct physics rather than a
degeneracy of the code: for **real** kappa the two eigen-indices differ only in
their real part, the interface Fresnel coefficients depend on the impedance
sqrt(mu/epsilon) alone (identical for both helicities), and a Fabry–Perot round
trip flips helicity so its phase is `(n_+ + n_-) k0 d = 2 n k0 d` for both.
Chirality then produces only optical rotation, not circular dichroism.
Circular dichroism appears as soon as Im(kappa) != 0 — e.g. for
epsilon = 2.25+0.3i, kappa = 0.08+0.02i, d = 0.16 um, lambda = 0.55 um the code
gives T+ = 0.6269 vs T- = 0.7257 with equal reflections.

## Checks performed

- **Energy balance**: T + R + A = 1 by construction of `PowerBalance`;
  `checks.max_energy_balance_error` is 0.0 for the example.
- **Independent analytic cross-check** (`check_airy.py`, validation only): the
  Airy multiple-reflection formula for a chiral slab,
  `t = t01 t10 e^{i n_s k0 d} / (1 - r01^2 e^{i (n_s + n_-s) k0 d})` with
  helicity-flipping internal reflections, reproduces the treams transmission and
  reflection fractions to < 1e-15 for four (epsilon, kappa) combinations
  including complex kappa and negative kappa. This also confirms the
  positive/negative helicity column ordering.
- **Limits**: zero thickness gives T = 1, R = A = 0; a lossless slab
  (Im epsilon = 0, real kappa) gives A = 0 to ~1e-16 and T + R = 1.
- **Reflection degeneracy**: `checks.reflection_helicity_contrast` is ~1e-16 for
  real kappa, as expected from the impedance-only interface response.

## Files

- `solution.py` — `run(config)` plus a CLI reading one JSON config from stdin
  and printing the result dictionary as JSON to stdout.
- `results.json` — output for the example config.
- `check_airy.py` — independent validation script (not used by `run`).
