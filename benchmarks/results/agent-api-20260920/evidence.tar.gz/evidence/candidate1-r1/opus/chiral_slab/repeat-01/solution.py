"""Normal-incidence power fractions for a uniform reciprocal chiral slab.

The slab is normal to z, has thickness ``d`` (micrometers) and relative
material parameters ``(epsilon, mu, kappa)``.  It is bounded by vacuum on
both sides.  For illumination travelling along +z we report the
transmitted, reflected and absorbed fractions of the incident power for
positive and negative helicity.

Scattering is done with treams-rs (``treams_rs.slab`` -> ``SMatrices.power``).
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as treams

HELICITIES = ("positive_helicity", "negative_helicity")


def _complex(value) -> complex:
    """Accept a scalar or a ``[real, imag]`` pair."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError("complex entries take a scalar or [real, imag]")
    if isinstance(value, dict):
        return complex(float(value.get("real", 0.0)), float(value.get("imag", 0.0)))
    return complex(value)


def run(config: dict) -> dict:
    """Power fractions of a chiral slab at normal incidence along +z.

    Parameters
    ----------
    config
        ``thickness`` (micrometers), ``epsilon`` as ``[real, imag]`` (or a
        scalar), ``kappa`` (dimensionless chirality, scalar or
        ``[real, imag]``), optional ``mu`` (defaults to 1) and
        ``wavelengths``, a list of vacuum wavelengths in micrometers.

    Returns
    -------
    dict
        ``transmission``, ``reflection`` and ``absorption``, each a list of
        shape ``(len(wavelengths), 2)`` ordered positive then negative
        helicity, plus the echoed inputs and consistency checks.
    """
    thickness = float(config["thickness"])
    if thickness < 0:
        raise ValueError("thickness must be non-negative")
    epsilon = _complex(config["epsilon"])
    mu = _complex(config.get("mu", 1.0))
    kappa = _complex(config.get("kappa", 0.0))
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]
    if not wavelengths or any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")

    material = treams.Material(epsilon, mu, kappa)
    # Normal incidence: a single transverse wavevector (kx, ky) = (0, 0),
    # which the default port basis expands into both helicity channels.
    basis = treams.PlaneWavePorts.default([0.0, 0.0])

    transmission, reflection, absorption, indices = [], [], [], []
    for wavelength in wavelengths:
        k0 = 2 * np.pi / wavelength  # vacuum angular wavenumber, 1/micrometer
        smat = treams.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1,  # vacuum below the slab (incidence side)
            positive_medium=1,  # vacuum above the slab
            polarization="helicity",
        )
        t_row, r_row, a_row = [], [], []
        for helicity in HELICITIES:
            # Unit-amplitude plane wave running along +z, so the incident
            # side ("negative") is inferred from its propagation direction.
            incident = treams.plane_wave(
                direction=[0.0, 0.0, 1.0],
                polarization=helicity,
                k0=k0,
                material=1,
            )
            balance = smat.power(incident)
            t_row.append(float(balance.transmission))
            r_row.append(float(balance.reflection))
            a_row.append(float(balance.absorption))
        transmission.append(t_row)
        reflection.append(r_row)
        absorption.append(a_row)
        # n_plus/n_minus for the two helicities: sqrt(eps*mu) +/- kappa.
        n_minus, n_plus = material.nmp
        indices.append([[n_plus.real, n_plus.imag], [n_minus.real, n_minus.imag]])

    tot = np.array(transmission) + np.array(reflection) + np.array(absorption)
    return {
        "wavelengths": wavelengths,
        "helicity_order": ["positive", "negative"],
        "thickness": thickness,
        "epsilon": [epsilon.real, epsilon.imag],
        "mu": [mu.real, mu.imag],
        "kappa": [kappa.real, kappa.imag],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "refractive_indices": indices,
        "checks": {
            "max_energy_balance_error": float(np.max(np.abs(tot - 1.0))),
            "min_absorption": float(np.min(absorption)),
            "min_transmission": float(np.min(transmission)),
            "min_reflection": float(np.min(reflection)),
            "reflection_helicity_contrast": float(
                np.max(np.abs(np.diff(np.array(reflection), axis=1)))
            ),
        },
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
