"""Scattering spectrum of a homogeneous dielectric sphere (treams-rs)."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as treams


def _material(epsilon: Any) -> treams.Material:
    """Build a Material from ``[real, imag]`` (or a scalar) relative permittivity."""
    if isinstance(epsilon, (list, tuple)):
        eps = complex(float(epsilon[0]), float(epsilon[1]) if len(epsilon) > 1 else 0.0)
    else:
        eps = complex(epsilon)
    return treams.Material(eps)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    material = _material(config["epsilon"])

    geometric = math.pi * radius**2
    out = {"scattering": [], "extinction": [], "absorption": [], "efficiency": []}
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        tm = treams.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=material, polarization="helicity"
        )
        illumination = treams.plane_wave(
            direction=[0, 0, 1], polarization="positive_helicity", k0=k0
        )
        xs = tm.cross_sections(illumination)
        out["scattering"].append(float(xs.scattering.real))
        out["extinction"].append(float(xs.extinction.real))
        out["absorption"].append(float(xs.absorption.real))
        out["efficiency"].append(float(xs.scattering.real) / geometric)
    return out


def main() -> None:
    print(json.dumps(run(json.load(sys.stdin))))


if __name__ == "__main__":
    main()
