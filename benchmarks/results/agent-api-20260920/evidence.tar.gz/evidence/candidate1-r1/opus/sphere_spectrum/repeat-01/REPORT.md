# Homogeneous dielectric sphere spectrum

## What is computed
For each vacuum wavelength the sphere's T-matrix is built with
`treams_rs.sphere_tmatrix(k0, lmax, radius, material)` and illuminated by a
`treams_rs.plane_wave` travelling along **+z** with **positive helicity**.
`TMatrix.cross_sections(illumination)` returns the named scattering,
extinction and absorption cross sections, which are reported directly.

## Units and conventions
- Lengths in micrometers; `k0 = 2*pi / wavelength` (rad/µm), so `radius` and
  `1/k0` share the same unit.
- `epsilon = [real, imag]` is the **relative permittivity** (not a refractive
  index), passed as `Material(complex(re, im))`; `mu = 1`, `kappa = 0`, and the
  exterior medium is vacuum (treams-rs default).
- Time convention is treams' `exp(-i omega t)`, so a positive `Im(epsilon)`
  means loss and gives positive absorption.
- `scattering`, `extinction`, `absorption` are **areas** in µm² (squared length
  units of the input). `efficiency = scattering / (pi * radius**2)` is
  dimensionless (the scattering efficiency Qsca).
- The T-matrix is built in the helicity basis; `polarization="positive_helicity"`
  selects the left/right-circular illumination channel.
- Outputs are lists in the same order as the input `wavelengths`.

## Interface
- `run(config)` -> dict with keys `scattering`, `extinction`, `absorption`,
  `efficiency` (lists of floats).
- CLI: reads one JSON config on stdin, prints the result dict as JSON on stdout
  (`echo '{...}' | python solution.py`).

## Checks performed
- **Independent Mie reference.** An analytic Mie series (Bessel functions by
  downward/upward recurrence, no treams involved) reproduces all four
  scattering and extinction cross sections of the example to ~1e-15 relative
  agreement.
- **Energy balance.** `extinction - scattering = absorption > 0` at every
  wavelength, as returned by treams.
- **Lossless limit.** With `epsilon = [12, 0]` absorption is 0 to machine
  precision (-2.2e-16).
- **Helicity symmetry.** Negative-helicity illumination of the achiral sphere
  gives identical cross sections (agreement to 1e-16), as required by mirror
  symmetry.
- **Cutoff convergence.** At 0.55 µm, Csca changes by 1e-6 relative from
  lmax = 2 to 4 and by 1e-12 from 4 to 8, so lmax = 4 is converged for the
  example size parameter.

## Example result (`results.json`)
radius = 0.1 µm, epsilon = 12 + 0.05i, lmax = 4:

| λ (µm) | Csca (µm²) | Cext (µm²) | Cabs (µm²) | Qsca |
|---|---|---|---|---|
| 0.45 | 0.02714576 | 0.02916215 | 0.00201639 | 0.864076 |
| 0.55 | 0.16247547 | 0.16511567 | 0.00264020 | 5.171755 |
| 0.65 | 0.13980537 | 0.14188985 | 0.00208448 | 4.450143 |
| 0.75 | 0.17933685 | 0.18667668 | 0.00733982 | 5.708469 |

No derivatives or optimization are requested by this task, so no sensitivity
machinery is used.
