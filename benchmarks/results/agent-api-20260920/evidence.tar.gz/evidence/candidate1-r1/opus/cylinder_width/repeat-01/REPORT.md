# Scattering cross widths of a homogeneous infinite cylinder

## Problem and method

A homogeneous, infinitely long circular cylinder of radius `radius` and relative
permittivity `epsilon = [real, imag]` lies along the z axis in vacuum. It is
illuminated by a positive-helicity plane wave propagating along **+x**, i.e. at
normal incidence, so the axial wavenumber is `kz = 0`.

`solution.py` builds the cylindrical T-matrix with
`treams_rs.cylinder_tmatrix(k0=..., kz=0.0, mmax=..., radius=..., material=...,
medium=1, polarization="helicity")` and the illumination with
`treams_rs.plane_wave(direction=[1,0,0], polarization="positive_helicity", k0=...)`.
The widths come from `TMatrixC.cross_widths(illu)`, which returns
`scattering`, `extinction` and the derived `absorption = extinction - scattering`.
No analytic Mie-type series is reimplemented; all numerics are treams-rs.

## Units and conventions

- All lengths are in micrometers. Wavelengths are vacuum wavelengths, converted
  to the vacuum angular wavenumber `k0 = 2*pi/lambda` (rad/µm).
- The returned quantities are **cross widths**: cross section per unit cylinder
  length, so they have units of length (µm). No sphere-area (`pi*r^2`)
  normalization or any other dimensionless efficiency is applied.
- `epsilon`, `mu` and the chirality parameter are relative/dimensionless. With
  the `exp(-i omega t)` convention used by treams, a **positive** imaginary part
  of `epsilon` is lossy; the example `[5, 0.1]` therefore yields positive
  absorption. Defaults `mu = 1`, `chirality = 0`, exterior vacuum are used (they
  can be overridden through optional `mu`/`chirality` keys).
- `mmax` is the azimuthal cutoff: the basis contains orders `m = -mmax..mmax`
  (and both helicity channels) at the single value `kz = 0`.
- Output lists are wavelength-ordered, matching the input `wavelengths` order.

## Output keys

`wavelengths`, `scattering_cross_width`, `extinction_cross_width`,
`absorption_cross_width` (lists, µm), plus `units`, `convention` and
`diagnostics`.

## Checks performed

1. **Azimuthal convergence.** Each wavelength is recomputed with `mmax + 4`;
   the relative change is reported in `diagnostics`. For the example config it
   is below `4e-9` (scattering below `3e-13`), so `mmax = 4` is converged here.
2. **Optical theorem / power balance.** `extinction - scattering - absorption`
   is exactly 0 to machine precision (absorption is defined as the difference,
   so this confirms consistency of the reported triple rather than the physics).
   Physically, absorption is positive for `Im(epsilon) > 0`.
3. **Lossless limit.** With `epsilon = [5, 0]` the absorption width is
   `-1.1e-16` µm, i.e. zero to round-off.
4. **Vacuum limit.** With `epsilon = [1, 0]` all widths vanish (`~5e-33` µm).
5. **Symmetry.** For this achiral, rotationally symmetric scatterer the widths
   are identical for negative-helicity illumination and for incidence along +y,
   agreeing to ~1e-16 relative.

## Example result (radius 0.08 µm, epsilon 5 + 0.1i, mmax 4)

| lambda (µm) | sigma_sca (µm) | sigma_ext (µm) | sigma_abs (µm) |
|---|---|---|---|
| 0.50 | 0.5330353956 | 0.5611064991 | 0.0280711035 |
| 0.65 | 0.2585917234 | 0.2695397227 | 0.0109479993 |
| 0.80 | 0.2407417379 | 0.2488644544 | 0.0081227166 |

Saved in `results.json`.

## Usage

```
echo '{"radius":0.08,"epsilon":[5,0.1],"wavelengths":[0.5,0.65,0.8],"mmax":4}' \
  | python solution.py
```

No derivatives or optimization are requested by this task, so no pullbacks or
finite differences are used.
