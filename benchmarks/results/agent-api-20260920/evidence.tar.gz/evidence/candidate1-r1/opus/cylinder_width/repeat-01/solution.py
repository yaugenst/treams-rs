"""Scattering by a homogeneous infinite circular cylinder (axis along z).

Normal incidence (kz = 0), positive-helicity plane wave travelling along +x.
Cross widths are returned in length units (micrometers), one entry per
wavelength, in the order the wavelengths were supplied.

Numerics are provided entirely by ``treams_rs`` (cylindrical T-matrix).
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as tr


def _material(epsilon, mu=1.0, kappa=0.0) -> tr.Material:
    """Build a treams material from a [real, imag] permittivity pair."""
    if isinstance(epsilon, (list, tuple)):
        eps = complex(float(epsilon[0]), float(epsilon[1]))
    else:
        eps = complex(epsilon)
    return tr.Material(eps, complex(mu), complex(kappa))


def _widths(k0: float, radius: float, mmax: int, material: tr.Material):
    """Scattering / extinction / absorption widths for one vacuum wavenumber."""
    tm = tr.cylinder_tmatrix(
        k0=k0,
        kz=0.0,
        mmax=mmax,
        radius=radius,
        material=material,
        medium=1,
        polarization="helicity",
    )
    illu = tr.plane_wave(
        direction=[1.0, 0.0, 0.0],
        polarization="positive_helicity",
        k0=k0,
        material=1,
    )
    cw = tm.cross_widths(illu)
    return float(cw.scattering), float(cw.extinction), float(cw.absorption)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    mmax = int(config["mmax"])
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]
    material = _material(
        config["epsilon"], config.get("mu", 1.0), config.get("chirality", 0.0)
    )

    sca, ext, abso, diag = [], [], [], []
    for lam in wavelengths:
        k0 = 2.0 * np.pi / lam
        s, e, a = _widths(k0, radius, mmax, material)
        sca.append(s)
        ext.append(e)
        abso.append(a)
        # Convergence probe: same quantities with a larger azimuthal cutoff.
        sr, er, _ = _widths(k0, radius, mmax + 4, material)
        scale = max(abs(e), 1e-300)
        diag.append(
            {
                "wavelength": lam,
                "size_parameter": 2.0 * np.pi * radius / lam,
                "rel_change_scattering_mmax_plus_4": abs(sr - s) / scale,
                "rel_change_extinction_mmax_plus_4": abs(er - e) / scale,
                "optical_theorem_residual": (e - s - a) / scale,
            }
        )

    return {
        "wavelengths": wavelengths,
        "scattering_cross_width": sca,
        "extinction_cross_width": ext,
        "absorption_cross_width": abso,
        "units": {
            "length": "micrometer",
            "cross_widths": "micrometer (cross section per unit cylinder length)",
        },
        "convention": {
            "kz": 0.0,
            "incidence_direction": [1.0, 0.0, 0.0],
            "polarization": "positive_helicity",
            "mmax": mmax,
            "epsilon": [material.epsilon.real, material.epsilon.imag],
            "mu": [material.mu.real, material.mu.imag],
            "chirality": [material.kappa.real, material.kappa.imag],
            "exterior": "vacuum",
            "time_convention": "exp(-i omega t); Im(epsilon) > 0 is lossy",
            "normalization": "cross width (length), no sphere-area normalization",
        },
        "diagnostics": diag,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
