"""Sensitivity of the near field of a sphere dimer to the sphere separation.

Two identical spheres sit at x = -separation/2 and x = +separation/2, are
illuminated by a positive-helicity plane wave travelling along +z, and the
total (incident + multiply-scattered) electric field is evaluated at a fixed
observation point.  The objective is

    value = sum(|E_total|**2)

and its derivative with respect to ``separation`` is obtained with the
analytic reverse-mode pullbacks of treams-rs via the Advect adapter.
"""

from __future__ import annotations

import json
import math
import sys

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _objective(separation, cfg):
    """value = sum(|E_inc + E_scat|^2) at the fixed point, traced in separation."""
    k0 = 2.0 * math.pi / cfg["wavelength"]
    lmax = int(cfg["lmax"])
    radius = float(cfg["radius"])
    eps_re, eps_im = (float(v) for v in cfg["epsilon"])
    material = tr.Material(epsilon=complex(eps_re, eps_im))

    sphere = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=material, medium=1.0
    )

    half = separation / 2.0
    zero = 0.0 * half  # traced zeros keep the position array a single traced array
    positions = anp.stack(
        [
            anp.stack([-half, zero, zero]),
            anp.stack([half, zero, zero]),
        ]
    )

    cluster = tr.Cluster([sphere, sphere], positions=positions)
    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0)

    points = [[float(c) for c in cfg["point"]]]
    total = incident.efield(points) + cluster.scatter(incident).efield(points)
    return anp.sum(anp.real(total) ** 2 + anp.imag(total) ** 2)


def run(config):
    """Return the near-field intensity value and d(value)/d(separation)."""
    cfg = dict(config)
    separation = float(cfg["separation"])

    value, gradient = ad.value_and_grad(lambda s: _objective(s, cfg))(separation)

    return {
        "value": float(value),
        "gradient": float(gradient),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
