# Dimer near-field sensitivity to separation

## Problem

Two identical spheres of radius `radius` and permittivity `epsilon = [re, im]`
sit in vacuum at `x = -separation/2` and `x = +separation/2` (y = z = 0). A
plane wave of positive helicity and unit amplitude propagates along `+z`. At a
fixed observation `point` the objective is

```
value = sum(|E_incident + E_scattered|^2)
```

and the reported `gradient` is `d value / d separation`, with both sphere
centres moving symmetrically (each by ±1/2 per unit of separation) while point,
wavelength, radii, material and `lmax` stay fixed.

## Units and conventions

* Lengths (`radius`, `separation`, `wavelength`, `point`) are in micrometres;
  `k0 = 2*pi/wavelength` is in 1/µm, so the gradient has units of 1/µm.
* `epsilon` is the relative permittivity `re + 1j*im`; positive imaginary part
  is the passive/lossy convention used by treams-rs. `mu = 1`, `kappa = 0`, and
  the exterior medium is vacuum (`medium=1.0`).
* Fields are in the helicity (polarization) basis; the incident plane wave has
  unit amplitude, verified by `sum(|E_inc|^2) = 1.0` at the example point.
* `value` is dimensionless (intensity relative to the unit incident amplitude);
  the sum runs over the three Cartesian components of the complex field,
  `|E|^2 = Re(E)^2 + Im(E)^2`.

## Method

`treams_rs.advect` (the Advect adapter of treams-rs) builds the whole chain
inside a traced objective:

1. `tr.sphere_tmatrix(k0, lmax, radius, material)` — Mie T-matrix of one sphere.
2. `tr.Cluster([sphere, sphere], positions=...)` with traced positions built via
   `advect.numpy.stack` from the traced `separation`.
3. `cluster.scatter(incident)` solves the coupled system, i.e. **full multiple
   scattering** between the two spheres (not an independent-scatterer sum).
4. `incident.efield(point) + scattered.efield(point)` gives the total field.

The derivative comes from `advect.value_and_grad`, which uses the native
analytic reverse-mode pullbacks of treams-rs (T-matrix, translation/coupling,
interaction solve, field evaluation). No finite differences enter the returned
gradient.

## Checks

* Incident-only intensity at the example point is exactly 1.0, confirming the
  unit-amplitude plane-wave normalization.
* Multiple scattering is demonstrably active: coupled result 1.18555 versus
  1.19410 for the sum of two independent single spheres.
* Finite-difference validation only (central difference, h = 1e-6 µm):
  analytic −0.4037254206171 vs FD −0.4037254207, relative difference ~8e-11.
  A second configuration (radius 0.12, epsilon 6+0.5j, separation 0.45,
  wavelength 0.9, lmax 3) agrees to ~5e-10 relative.

## Example result (`results.json`)

Config: radius 0.08, epsilon [4.0, 0.04], separation 0.3, wavelength 0.72,
lmax 2, point [0.05, 0.02, 0.28].

```json
{"value": 1.1855506354526988, "gradient": -0.40372542061712435}
```

## Usage

```
python solution.py < config.json    # prints the result dictionary as JSON
```
or `from solution import run; run(config)`.
