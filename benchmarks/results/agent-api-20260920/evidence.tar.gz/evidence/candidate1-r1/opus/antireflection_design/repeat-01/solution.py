"""Analytic-gradient thickness optimization of a single antireflection coating.

Geometry (treams-rs planar convention, layers ordered along +z):

    negative medium : vacuum          (eps = 1)
    layer 1         : coating         (eps = ``epsilon``, thickness ``d``)
    positive medium : substrate       (eps = ``substrate_epsilon``)

A plane wave travels in the +z direction from the vacuum side at normal
incidence.  The objective is the reflected power fraction R(d) of the slab
system; its derivative dR/dd comes from the native treams-rs pullbacks exposed
through the Advect adapter (``treams_rs.advect`` + ``advect.value_and_grad``).
Finite differences are only used as an optional a-posteriori check.

All lengths are in micrometers, permittivities are relative and dimensionless.
"""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import numpy as np
import treams_rs.advect as tr

# Two helicity ports at zero transverse wavevector: normal incidence.
_BASIS = tr.PlaneWaveBasisByComp([(0.0, 0.0, 0), (0.0, 0.0, 1)])


def _objective(k0: float, epsilon: float, substrate_epsilon: float):
    """Return R(d) as a function of a length-1 thickness array."""
    wave = tr.plane_wave([0.0, 0.0, 1.0], 0, k0=k0)  # +z, positive helicity

    def objective(thickness: Any) -> Any:
        smatrix = tr.multilayer_slab(
            basis=_BASIS,
            k0=k0,
            thicknesses=thickness,
            materials=[epsilon],
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        return smatrix.power(wave).reflection

    return objective


def _value_and_grad(objective, d: float) -> tuple[float, float]:
    value, grad = ad.value_and_grad(objective)(np.array([float(d)]))
    return float(value), float(np.asarray(grad).reshape(-1)[0])


def _descend(
    objective,
    d: float,
    lo: float,
    hi: float,
    period: float,
    target: float,
    max_iter: int,
) -> tuple[float, float, list[float]]:
    """Projected gradient descent from ``d`` using analytic slopes only."""

    def clip(x: float) -> float:
        return min(max(x, lo), hi)

    d = clip(d)
    value, grad = _value_and_grad(objective, d)
    history = [value]
    step = 0.05 * period / max(abs(grad), 1e-30)  # first trial step length
    prev_d = prev_grad = None
    restarts = 0

    for _ in range(max_iter):
        if value <= target:
            break

        # Projected-gradient stationarity: no descent direction inside bounds.
        if abs(clip(d - grad) - d) <= 1e-16:
            if restarts >= 2 or abs(grad) > 1e-10:
                break
            # Flat stationary point (e.g. a local maximum with vanishing
            # slope): displace by an eighth period and keep descending.
            nudge = period / 8.0
            trial = clip(d + nudge)
            if abs(trial - d) <= 1e-16:
                trial = clip(d - nudge)
            if abs(trial - d) <= 1e-16:
                break
            d = trial
            value, grad = _value_and_grad(objective, d)
            history.append(value)
            prev_d = prev_grad = None
            step = 0.05 * period / max(abs(grad), 1e-30)
            restarts += 1
            continue

        # Barzilai-Borwein (exact secant in 1D) step built from analytic slopes.
        if prev_d is not None:
            ds, dg = d - prev_d, grad - prev_grad
            if dg != 0.0 and ds * dg > 0.0:
                step = abs(ds / dg)
        step = min(max(step, 1e-14), period)

        # Armijo backtracking on the analytic descent direction.
        accepted = False
        for _ls in range(60):
            d_new = clip(d - step * grad)
            actual = d_new - d
            if abs(actual) <= 1e-16:
                break
            value_new, grad_new = _value_and_grad(objective, d_new)
            if value_new <= value + 1e-4 * grad * actual:
                prev_d, prev_grad = d, grad
                d, value, grad = d_new, value_new, grad_new
                history.append(value)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break
        if abs(grad) <= 1e-14:
            break

    return d, value, history


def run(config: dict) -> dict:
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    d0 = float(config["initial_thickness"])
    lo, hi = sorted(float(b) for b in config["bounds"])

    k0 = 2.0 * math.pi / wavelength
    objective = _objective(k0, epsilon, substrate_epsilon)

    target = float(config.get("target_reflection", 1e-12))
    max_iter = int(config.get("max_iterations", 500))

    d_start = min(max(d0, lo), hi)
    initial_reflection = float(_value_and_grad(objective, d_start)[0])

    # R(d) repeats with the coating round-trip period lambda / (2 n_coating).
    period = wavelength / (2.0 * math.sqrt(max(epsilon, 1e-30)))

    d, value, loss_history = _descend(
        objective, d_start, lo, hi, period, target, max_iter
    )

    # If the run from the requested start stalls at a bound or a stationary
    # point that is still reflective, descend again from neighbouring periodic
    # branches; every step remains an analytic-gradient step.
    if value > target:
        candidates = []
        for k in (1, -1, 2, -2, 3, -3):
            candidates.append(d_start + k * period / 2.0)
        candidates.append(0.5 * (lo + hi))
        for cand in candidates:
            if value <= target:
                break
            if not (lo - 1e-15 <= cand <= hi + 1e-15):
                continue
            cand = min(max(cand, lo), hi)
            d_c, value_c, hist_c = _descend(
                objective, cand, lo, hi, period, target, max_iter
            )
            loss_history.extend(hist_c)
            if value_c < value:
                d, value = d_c, value_c

    final_value, final_grad = _value_and_grad(objective, d)

    return {
        "thickness": d,
        "reflection": final_value,
        "initial_reflection": initial_reflection,
        "gradient": final_grad,
        "loss_history": [float(v) for v in loss_history],
        "evaluations": len(loss_history),
        "bounds": [lo, hi],
        "wavelength": wavelength,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
