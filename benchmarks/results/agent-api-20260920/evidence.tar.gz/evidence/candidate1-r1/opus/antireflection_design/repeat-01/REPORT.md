# Single-layer antireflection coating: analytic-gradient thickness optimization

## Problem and geometry

A plane wave at normal incidence travels in the **+z** direction from vacuum,
crosses one lossless coating layer, and enters a semi-infinite substrate.  In
the treams-rs planar convention layers are ordered along the positive normal,
so the stack passed to `multilayer_slab` is

| region            | medium                          |
|-------------------|---------------------------------|
| `negative_medium` | vacuum, `eps = 1`               |
| interior layer 1  | coating, `eps = epsilon`, thickness `d` |
| `positive_medium` | substrate, `eps = substrate_epsilon` |

There is no vacuum gap behind the coating: the coating touches the substrate.

## Units and conventions

* Lengths (`wavelength`, `initial_thickness`, `bounds`, `thickness`) are in
  **micrometers**; `k0 = 2*pi/wavelength` is in rad/um.
* `epsilon` and `substrate_epsilon` are relative, dimensionless permittivities;
  `mu = 1` and chirality `0` everywhere (treams-rs defaults).  Both are real,
  so the system is lossless.
* Ports use the default **helicity** polarization basis at zero transverse
  wavevector (`PlaneWaveBasisByComp([(0,0,0),(0,0,1)])`), i.e. exactly normal
  incidence.  For isotropic achiral media the two helicities are degenerate
  (verified: R differs by 3e-17), so one incident helicity is used.
* `reflection` is the **reflected power fraction** R = P_refl / P_inc returned by
  `SMatrix.power(wave).reflection` (a Poynting-flux ratio, not a field
  amplitude).  It is dimensionless and in [0, 1].
* `gradient` is `dR/d(thickness)` at the returned thickness, in **1/um**.
* `loss_history` lists R at every accepted iterate (including the starting
  point) of the gradient descent, in evaluation order.

## Method

* **Physics**: `treams_rs.advect.multilayer_slab(...).power(wave).reflection`.
  No Fresnel/transfer-matrix reimplementation is used in the solution path.
* **Derivatives**: `advect.value_and_grad` over that objective, which is backed
  by the native treams-rs Rust pullbacks (`diff.layer_stack`, `diff.smatrix_tr`;
  pairing `dL = Re(sum(conj(g) dx))`).  No finite differences enter the
  objective, the gradient, or any optimization step.
* **Optimizer**: projected gradient descent on the bounded interval, with a
  Barzilai–Borwein step (in 1D this is the exact secant/quasi-Newton step built
  from two analytic slopes) safeguarded by Armijo backtracking.  A fresh
  forward/reverse pass is taken at every iterate, since native residuals are
  single-use.
* **Robustness** (no closed form is substituted anywhere): if the descent stalls
  at a bound or at a stationary point while R is still large, further descents
  are launched from neighbouring periodic branches
  `d_start + k*lambda/(4*n_coating)`, `k = ±1..±3`, and from the bounds midpoint;
  all of those steps are again analytic-gradient steps and the best result is
  kept.  All iterates are clipped to `bounds`.
* Stopping: R <= 1e-12, vanishing projected gradient, or 500 iterations.

## Example result (`results.json`)

Config: `wavelength = 0.7`, `epsilon = 2.25` (n = 1.5),
`substrate_epsilon = 5.0625` (n = 2.25), `initial_thickness = 0.05`,
`bounds = [0.025, 0.21]`.

* `initial_reflection = 9.594027e-02`
* `thickness = 0.11666665 um`
* `reflection = 5.37e-15`  (well below the 1e-7 requirement)
* `gradient = -8.22e-07 1/um`
* 6 accepted descent steps (7 entries in `loss_history`, monotonically
  decreasing).

## Checks performed

1. **Gradient vs. central finite differences** (diagnostic only, h = 1e-6 um):
   at d = 0.05, 0.09 and at the optimum the analytic gradient matches the finite
   difference to all printed digits, e.g. `-1.862590e+00` vs `-1.862590e+00`.
2. **Energy conservation**: R + T = 1.000000000000000 and absorption ~ 3e-16 at
   both the initial and the final thickness, as expected for real permittivities.
3. **Independent physics cross-check**: the single-layer Fresnel formula
   `r = (r01 + r12 e^{2 i k0 n1 d}) / (1 + r01 r12 e^{2 i k0 n1 d})` reproduces
   the treams-rs reflectance to 12+ digits (9.594027275235e-02 at d = 0.05;
   5.3734e-15 at the optimum).  This is verification only.
4. **Physical plausibility**: the recovered thickness agrees with the
   quarter-wave value `lambda/(4 n) = 0.1166667 um`, and index matching
   `n_coating = sqrt(n_substrate)` here permits R -> 0.  The optimizer found this
   by descent; the closed form is never used to produce the answer.
5. **Other configs** (not hard-coded): index-mismatched stacks converge to the
   correct nonzero floor (e.g. `eps = 2.1`, `eps_sub = 12`: R = 0.060104, equal
   to `((eps - n_s)/(eps + n_s))^2`), bound-limited cases stop on the active
   bound with a nonzero gradient, and a start placed exactly on a local maximum
   still reaches R ~ 0 via the branch restarts.

## Interface

* `run(config) -> dict` with keys `thickness`, `reflection`,
  `initial_reflection`, `gradient`, `loss_history` (plus `evaluations`,
  `bounds`, `wavelength`).
* CLI: `echo '<config json>' | python solution.py` prints the same dictionary as
  JSON on stdout.
* Optional config keys: `target_reflection` (default 1e-12),
  `max_iterations` (default 500).
