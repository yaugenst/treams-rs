"""Core-shell (multilayer) sphere cross-section spectrum via treams-rs.

Units: lengths (radii, wavelengths) in micrometers, cross sections in um^2.
Permittivities/permeabilities/chirality are relative and dimensionless.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def _complex(value):
    """Accept a scalar, a [real, imag] pair, or a complex-like string."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) != 2:
            raise ValueError(f"expected [real, imag], got {value!r}")
        return complex(float(value[0]), float(value[1]))
    return complex(value)


def _material(epsilon, mu=1, kappa=0):
    return tr.Material(_complex(epsilon), _complex(mu), _complex(kappa))


def _materials(config, n_layers):
    """One Material per layer, inside-out; mu=1 and kappa=0 unless supplied."""
    eps = config["epsilon_layers"]
    if len(eps) != n_layers:
        raise ValueError(
            f"epsilon_layers has {len(eps)} entries for {n_layers} radii"
        )
    mus = config.get("mu_layers") or [1] * n_layers
    kappas = config.get("kappa_layers") or [0] * n_layers
    if len(mus) != n_layers or len(kappas) != n_layers:
        raise ValueError("mu_layers/kappa_layers must match the number of layers")
    return [_material(e, m, k) for e, m, k in zip(eps, mus, kappas)]


def run(config):
    radii = [float(r) for r in config["radii"]]
    if len(radii) == 0:
        raise ValueError("at least one radius is required")
    if any(r <= 0 for r in radii):
        raise ValueError("radii must be positive")
    if any(b <= a for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing outer boundaries")

    materials = _materials(config, len(radii))
    # The exterior is *not* appended as a finite layer; it enters via `medium`.
    medium = _material(
        config.get("epsilon_medium", 1),
        config.get("mu_medium", 1),
        config.get("kappa_medium", 0),
    )

    wavelengths = [float(w) for w in config["wavelengths"]]
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")
    lmax = int(config.get("lmax", 4))
    if lmax < 1:
        raise ValueError("lmax must be >= 1")

    scattering, extinction, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um
        tmat = tr.multilayer_sphere_tmatrix(
            k0=k0, lmax=lmax, radii=radii, materials=materials, medium=medium
        )
        xs = tmat.average_cross_sections  # rotation/polarization averaged, um^2
        scattering.append(float(xs.scattering))
        extinction.append(float(xs.extinction))
        absorption.append(float(xs.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "units": {"wavelength": "um", "cross_section": "um^2"},
        "lmax": lmax,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
