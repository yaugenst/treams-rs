# Core-shell sphere cross-section spectrum

`solution.py` exposes `run(config)` and a CLI (`python solution.py < config.json`)
that reads one config dict from stdin and prints the result dict as JSON.

## Method

For each wavelength the vacuum angular wavenumber `k0 = 2*pi/lambda` is formed and
`treams_rs.multilayer_sphere_tmatrix(k0=..., lmax=..., radii=..., materials=...,
medium=...)` builds the T-matrix of the concentric sphere (helicity basis, default).
Rotationally and polarization-averaged cross sections come from the T-matrix property
`average_cross_sections`, i.e. treams-rs' own analytic averages — nothing is
reimplemented here.

## Conventions

- **Lengths** (`radii`, `wavelengths`) in micrometers; cross sections therefore in um^2.
- `radii` are increasing *outer* boundaries of the layers; `epsilon_layers` gives one
  `[real, imag]` relative permittivity per layer **inside-out**, so
  `len(epsilon_layers) == len(radii)`.
- The exterior (`epsilon_medium`, scalar or `[real, imag]`) is passed as `medium` and is
  **not** appended as an extra finite layer.
- `mu = 1`, `kappa = 0` everywhere unless optional keys `mu_layers`, `kappa_layers`,
  `mu_medium`, `kappa_medium` are supplied.
- Time convention is treams' `exp(-i omega t)`: a *positive* imaginary permittivity is loss.
- `lmax` is the multipole truncation (default 4).
- Output lists are in the input wavelength order; `absorption = extinction - scattering`
  as returned by `CrossSections`.

## Example result (`results.json`)

Config: radii `[0.07, 0.12]` um, eps `[2.25+0.03i, 4+0.06i]`, exterior eps `1.7689`
(n = 1.33, water), lambda `[0.58, 0.70, 0.82]` um, lmax 4.

| lambda (um) | sigma_sca (um^2) | sigma_ext (um^2) | sigma_abs (um^2) |
|---|---|---|---|
| 0.58 | 3.431592e-2 | 3.752383e-2 | 3.207911e-3 |
| 0.70 | 1.891246e-2 | 2.117016e-2 | 2.257697e-3 |
| 0.82 | 1.213568e-2 | 1.390107e-2 | 1.765386e-3 |

## Checks

- **Multipole convergence**: sigma_sca at lmax = 2, 3, 4, 6, 8 agrees to ~1e-11 relative
  from lmax = 4 onward, so the reported lmax = 4 values are converged for this size.
- **Energy balance**: `extinction - scattering - absorption = 0` exactly (absorption is
  defined as the difference); absorption is positive for the lossy example.
- **Lossless limit**: with `Im(eps) = 0` in both layers absorption is 2e-17 um^2, i.e.
  zero to round-off.
- **Homogeneous limit**: two layers with identical material reproduce the single-layer
  result and `sphere_tmatrix` for a 0.12 um sphere to ~1e-16 relative.
- Input validation rejects non-positive or non-increasing radii, non-positive
  wavelengths, `lmax < 1`, and a layer count mismatch.
