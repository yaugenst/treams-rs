"""Scattering efficiency and analytic sensitivities for a lossy sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return Q_sca and [dQ/dradius, dQ/d(epsilon_real)].

    Radius and wavelength must use the same length unit.  The imaginary part of
    epsilon, wavelength, and the discrete multipole cutoff are held fixed.
    """
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    if not (math.isfinite(radius) and radius > 0):
        raise ValueError("radius must be finite and positive")
    if not (math.isfinite(wavelength) and wavelength > 0):
        raise ValueError("wavelength must be finite and positive")
    if not (math.isfinite(epsilon_real) and math.isfinite(epsilon_imag)):
        raise ValueError("permittivity components must be finite")
    if lmax < 1 or lmax != config["lmax"]:
        raise ValueError("lmax must be a positive integer")

    # Wavelength and epsilon_imag intentionally remain ordinary constants.
    k0 = 2.0 * math.pi / wavelength

    def efficiency(parameters: Any) -> Any:
        r = parameters[0]
        epsilon = parameters[1] + 1j * epsilon_imag
        particle = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=r,
            material=epsilon,
        )
        incident = tr.plane_wave(
            [0.0, 0.0, 1.0],
            "positive_helicity",
            k0=k0,
        )
        scattering = particle.cross_sections(incident).scattering
        # Keeping this normalization inside the traced objective includes its
        # -2 * scattering / (pi * r**3) contribution to dQ/dr.
        return scattering / (anp.pi * r * r)

    parameters = anp.asarray([radius, epsilon_real])
    value, gradient = ad.value_and_grad(efficiency)(parameters)
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


def _main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("input JSON must be an object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
