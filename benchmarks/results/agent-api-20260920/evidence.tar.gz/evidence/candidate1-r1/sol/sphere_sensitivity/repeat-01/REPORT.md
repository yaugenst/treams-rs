# Lossy-sphere scattering sensitivity

For the supplied example, the scattering efficiency is
`Q_sca = 0.46337644643427434`. Its requested gradient is
`[18.65367030479629, 0.1997255464561844]`, ordered as
`[dQ/dradius, dQ/d(epsilon_real)]`.

## Units and conventions

Radius and vacuum wavelength are in micrometers, so `k0 = 2*pi/wavelength` is
in inverse micrometers. The scattering cross section is in square micrometers,
and `Q_sca = C_sca/(pi*radius^2)` is dimensionless. Consequently,
`dQ/dradius` has units of inverse micrometers, while
`dQ/d(epsilon_real)` is dimensionless per unit relative permittivity.

The sphere has relative permittivity
`epsilon_real + i*epsilon_imag`; the package convention makes a positive
imaginary part passive loss. Relative permeability is 1 and chirality is 0,
as are their defaults. The exterior is vacuum. Illumination is a
positive-helicity plane wave propagating along +z. `lmax` is the fixed
spherical multipole cutoff.

## Derivative and checks

`solution.py` evaluates the T-matrix, incident-wave cross section, and reverse
derivative through the public `treams_rs.advect` API. Both radius and real
permittivity are traced. The division by `pi*radius^2` is performed inside the
differentiated objective, so the radius derivative includes the derivative of
the geometric normalization. `epsilon_imag`, wavelength, and `lmax` remain
fixed.

As a validation only, centered finite differences gave
`[18.653670304652483, 0.19972554649028137]`. Relative discrepancies from the
reported analytic gradient were approximately `7.7e-12` and `1.7e-10`,
respectively. The unnormalized example scattering cross section was
`0.014557400399644607 um^2`.
