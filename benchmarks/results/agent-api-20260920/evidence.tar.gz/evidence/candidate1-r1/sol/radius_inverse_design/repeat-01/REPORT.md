# Sphere radius inverse design

The fitted example radius is **0.10999999999999965 µm** and the final relative
mean-square loss is **9.153882894002532e-29**.

## Units and conventions

All input wavelengths, radii, and bounds are in micrometers. For each vacuum
wavelength, the code uses the positive vacuum angular wavenumber
`k0 = 2*pi/wavelength` in µm⁻¹. The sphere has the supplied real relative
permittivity, relative permeability 1, and zero chirality. Its exterior is
vacuum. `lmax` is the fixed spherical-multipole cutoff.

The fitted observable is the dimensionless scattering efficiency

`Q_sca = C_sca / (pi * radius**2)`,

where `C_sca` is the plane-wave scattering cross section in µm² returned by
treams-rs. A +z-propagating positive-helicity plane wave is used. A homogeneous
isotropic sphere has the same efficiency for either helicity and any incidence
direction. The optimized loss is the requested mean squared relative residual,
`mean(((Q_sca - target) / target)**2)`.

## Numerical method and checks

The forward Mie T-matrix, illumination expansion, and cross section all use the
public `treams_rs.advect` API. `advect.value_and_grad` composes the native Rust
pullbacks to obtain the radius derivative. A bounded, safeguarded
Barzilai–Borwein iteration with Armijo backtracking uses that analytic gradient
for every optimization step; finite differences are not used by the solver.

For the example, the loss decreased monotonically from 0.6215290002286541 to
9.15e-29 and the final derivative was -6.83e-13 µm⁻¹. As a diagnostic, a
centered finite difference at the initial radius gave -18.5523691901 µm⁻¹,
versus the analytic -18.5523691928 µm⁻¹ (relative difference 1.42e-10).
Scattering and extinction cross sections agreed to below 2e-15 µm², as expected
for the lossless sphere. Additional generated-target checks at radii 0.085,
0.105, and 0.130 µm recovered each radius with loss below 8e-23.
