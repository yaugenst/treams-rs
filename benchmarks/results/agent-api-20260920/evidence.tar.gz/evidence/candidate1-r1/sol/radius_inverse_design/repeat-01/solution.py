"""Radius inversion for the scattering efficiency of a dielectric sphere."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import advect as ad
import advect.numpy as anp
import numpy as np
from treams_rs import advect as tr


def _inputs(config: Mapping[str, Any]) -> tuple[float, int, np.ndarray, float, float, float, np.ndarray]:
    """Validate and normalize the fixed input schema."""
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary")

    epsilon = float(config["epsilon"])
    lmax_value = config["lmax"]
    if isinstance(lmax_value, bool) or int(lmax_value) != lmax_value:
        raise ValueError("lmax must be an integer")
    lmax = int(lmax_value)
    wavelengths = np.asarray(config["wavelengths"], dtype=float)
    targets = np.asarray(config["target_efficiencies"], dtype=float)
    bounds = np.asarray(config["bounds"], dtype=float)
    initial = float(config["initial_radius"])

    if not math.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("epsilon must be finite, real, and positive")
    if lmax < 1:
        raise ValueError("lmax must be at least one")
    if wavelengths.ndim != 1 or wavelengths.size == 0:
        raise ValueError("wavelengths must be a nonempty one-dimensional sequence")
    if targets.shape != wavelengths.shape:
        raise ValueError("target_efficiencies must have the same shape as wavelengths")
    if not np.all(np.isfinite(wavelengths)) or np.any(wavelengths <= 0):
        raise ValueError("wavelengths must be finite and positive")
    if not np.all(np.isfinite(targets)) or np.any(targets <= 0):
        raise ValueError("target_efficiencies must be finite and positive")
    if bounds.shape != (2,) or not np.all(np.isfinite(bounds)):
        raise ValueError("bounds must contain two finite numbers")
    lower, upper = map(float, bounds)
    if lower <= 0 or lower >= upper:
        raise ValueError("bounds must satisfy 0 < lower < upper")
    if not math.isfinite(initial) or not lower <= initial <= upper:
        raise ValueError("initial_radius must be finite and inside bounds")
    return epsilon, lmax, wavelengths, initial, lower, upper, targets


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Fit the sphere radius using native analytic scattering pullbacks."""
    epsilon, lmax, wavelengths, radius, lower, upper, targets_np = _inputs(config)
    targets = anp.asarray(targets_np)

    def efficiencies(r: Any) -> Any:
        values = []
        for wavelength in wavelengths:
            k0 = 2.0 * math.pi / float(wavelength)
            sphere = tr.sphere_tmatrix(
                k0=k0, lmax=lmax, radius=r, material=epsilon, medium=1.0
            )
            incident = tr.plane_wave(
                [0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0
            )
            area = sphere.cross_sections(incident).scattering
            values.append(area / (math.pi * r * r))
        return anp.stack(values)

    def objective(r: Any) -> Any:
        relative_residual = (efficiencies(r) - targets) / targets
        return anp.mean(relative_residual * relative_residual)

    # Each call performs a fresh reverse pass, as required by Advect's native
    # one-use residuals. The safeguarded Barzilai--Borwein step and Armijo line
    # search use analytic gradients only.
    value_and_gradient = ad.value_and_grad(objective)
    loss, gradient = (float(x) for x in value_and_gradient(radius))
    initial_loss = loss
    history = [loss]
    previous: tuple[float, float] | None = None
    width = upper - lower

    for _ in range(200):
        if loss < 1e-15 and abs(gradient) < 1e-8:
            break

        if previous is None:
            step_scale = min(1.0, 0.25 * width / max(abs(gradient), 1e-300))
        else:
            old_radius, old_gradient = previous
            gradient_change = gradient - old_gradient
            if abs(gradient_change) > 1e-30:
                step_scale = abs((radius - old_radius) / gradient_change)
            else:
                step_scale = 0.25 * width / max(abs(gradient), 1e-300)
            # Keep one proposal local even when the secant curvature is tiny.
            step_scale = min(
                max(step_scale, 1e-14),
                0.5 * width / max(abs(gradient), 1e-300),
            )

        accepted = False
        for _ in range(50):
            candidate = min(upper, max(lower, radius - step_scale * gradient))
            if candidate == radius:
                break
            candidate_loss, candidate_gradient = (
                float(x) for x in value_and_gradient(candidate)
            )
            if candidate_loss <= loss + 1e-4 * gradient * (candidate - radius):
                accepted = True
                break
            step_scale *= 0.5

        if not accepted:
            # This includes convergence at a constrained boundary.
            break
        previous = (radius, gradient)
        radius, loss, gradient = candidate, candidate_loss, candidate_gradient
        history.append(loss)

    fitted = np.asarray(efficiencies(radius), dtype=float)
    result = {
        "radius": float(radius),
        "loss": float(loss),
        "initial_loss": float(initial_loss),
        "gradient": float(gradient),
        "fitted_efficiencies": fitted.tolist(),
        "loss_history": [float(item) for item in history],
    }
    # Guard the CLI contract against accidental non-finite JSON values.
    if not all(math.isfinite(float(x)) for x in [radius, loss, initial_loss, gradient, *fitted]):
        raise RuntimeError("non-finite result from scattering calculation")
    return result


def _main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
