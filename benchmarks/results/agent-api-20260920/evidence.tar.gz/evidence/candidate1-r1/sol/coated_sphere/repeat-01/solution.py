"""Rotationally averaged cross sections of a concentric multilayer sphere."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping, Sequence

import treams_rs as tr


def _complex_value(value: object, name: str) -> complex:
    """Convert a JSON number or a [real, imaginary] pair to a complex value."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number or a [real, imag] pair")
    if isinstance(value, (int, float)):
        result = complex(value)
    elif (
        isinstance(value, Sequence)
        and not isinstance(value, (str, bytes))
        and len(value) == 2
    ):
        try:
            result = complex(float(value[0]), float(value[1]))
        except (TypeError, ValueError) as error:
            raise ValueError(f"{name} must contain two real numbers") from error
    else:
        raise ValueError(f"{name} must be a number or a [real, imag] pair")
    if not (math.isfinite(result.real) and math.isfinite(result.imag)):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: Mapping[str, object]) -> dict[str, list[float]]:
    """Compute averaged scattering, extinction, and absorption areas.

    Input lengths are in micrometers, so the returned cross sections are in
    square micrometers. Layers and radii are ordered from the center outwards.
    """
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary")

    try:
        radii_raw = config["radii"]
        layers_raw = config["epsilon_layers"]
        medium_raw = config["epsilon_medium"]
        wavelengths_raw = config["wavelengths"]
        lmax_raw = config["lmax"]
    except KeyError as error:
        raise ValueError(f"missing required config key: {error.args[0]}") from error

    try:
        radii = [float(value) for value in radii_raw]  # type: ignore[union-attr]
        wavelengths = [float(value) for value in wavelengths_raw]  # type: ignore[union-attr]
        layers = [
            _complex_value(value, f"epsilon_layers[{index}]")
            for index, value in enumerate(layers_raw)  # type: ignore[arg-type]
        ]
    except TypeError as error:
        raise ValueError("radii, epsilon_layers, and wavelengths must be lists") from error

    if not radii:
        raise ValueError("at least one finite layer is required")
    if len(radii) != len(layers):
        raise ValueError("epsilon_layers must contain one permittivity per radius")
    if any(not math.isfinite(radius) or radius <= 0 for radius in radii):
        raise ValueError("radii must be finite and positive")
    if any(left >= right for left, right in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing")
    if not wavelengths or any(
        not math.isfinite(wavelength) or wavelength <= 0
        for wavelength in wavelengths
    ):
        raise ValueError("wavelengths must be a nonempty list of finite positive values")
    if isinstance(lmax_raw, bool) or not isinstance(lmax_raw, int) or lmax_raw < 1:
        raise ValueError("lmax must be a positive integer")

    medium = _complex_value(medium_raw, "epsilon_medium")
    if medium.imag != 0 or medium.real <= 0:
        raise ValueError(
            "epsilon_medium must be real and positive for far-field cross sections"
        )

    result = {"scattering": [], "extinction": [], "absorption": []}
    for wavelength in wavelengths:
        response = tr.multilayer_sphere_tmatrix(
            k0=math.tau / wavelength,
            lmax=lmax_raw,
            radii=radii,
            materials=layers,
            medium=medium,
        )
        cross_sections = response.average_cross_sections
        scattering = float(cross_sections.scattering)
        extinction = float(cross_sections.extinction)
        result["scattering"].append(scattering)
        result["extinction"].append(extinction)
        result["absorption"].append(extinction - scattering)

    return result


def main() -> None:
    """Read one JSON config from stdin and write one JSON result to stdout."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
