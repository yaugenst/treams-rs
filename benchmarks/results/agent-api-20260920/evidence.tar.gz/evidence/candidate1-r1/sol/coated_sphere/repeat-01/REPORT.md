# Core-shell sphere spectrum

`solution.py` constructs a `treams_rs.multilayer_sphere_tmatrix` at each input
wavelength and reads its `average_cross_sections` result. Radii and layer
permittivities are passed inside-out, while `epsilon_medium` is passed separately
as the infinite exterior (it is not appended as another finite layer).

All input lengths are micrometers. The vacuum angular wavenumber is
`k0 = 2*pi / wavelength` in inverse micrometers, and all permittivities are
relative and dimensionless. The calculation uses relative permeability 1 and
chirality 0 through the treams-rs material defaults. Positive imaginary
permittivity denotes passive loss. Returned scattering, extinction, and
absorption cross sections are in square micrometers and are rotationally and
polarization averaged. Absorption follows the convention
`C_abs = C_ext - C_sca`.

For the supplied example, every cross section is finite, extinction exceeds
scattering, and absorption is positive. As a multipole-convergence check,
repeating the computation at `lmax=5` changed the scattering cross section by
at most `7.46e-11 um^2`, the extinction cross section by `9.66e-8 um^2`, and
the derived absorption cross section by `9.65e-8 um^2` over the three
wavelengths. The actual `lmax=4` CLI output is saved in `results.json`.
