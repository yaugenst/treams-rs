"""Scattering cross widths of a homogeneous infinite cylinder."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _positive_finite(value: Any, name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a positive finite number")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a positive finite number") from exc
    if not math.isfinite(result) or result <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return result


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return cylinder scattering, extinction, and absorption widths.

    Input lengths are interpreted in micrometers. The returned lists follow the
    input wavelength order and consequently contain widths in micrometers.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _positive_finite(config["radius"], "radius")

    epsilon_parts = config["epsilon"]
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    try:
        epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    except (TypeError, ValueError) as exc:
        raise ValueError("epsilon components must be finite numbers") from exc
    if not (math.isfinite(epsilon.real) and math.isfinite(epsilon.imag)):
        raise ValueError("epsilon components must be finite numbers")

    wavelengths_raw = config["wavelengths"]
    if not isinstance(wavelengths_raw, (list, tuple)) or not wavelengths_raw:
        raise ValueError("wavelengths must be a nonempty list")
    wavelengths = [
        _positive_finite(value, f"wavelengths[{index}]")
        for index, value in enumerate(wavelengths_raw)
    ]

    mmax_raw = config["mmax"]
    if isinstance(mmax_raw, bool) or not isinstance(mmax_raw, int):
        raise ValueError("mmax must be an integer from 0 to 128")
    if not 0 <= mmax_raw <= 128:
        raise ValueError("mmax must be an integer from 0 to 128")

    result: dict[str, list[float]] = {
        "scattering": [],
        "extinction": [],
        "absorption": [],
    }
    for wavelength in wavelengths:
        k0 = 2 * math.pi / wavelength
        response = tr.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax_raw,
            radius=radius,
            material=epsilon,
        )
        incident = tr.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
        )
        widths = response.cross_widths(incident)
        result["scattering"].append(float(widths.scattering))
        result["extinction"].append(float(widths.extinction))
        result["absorption"].append(float(widths.absorption))

    return result


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
