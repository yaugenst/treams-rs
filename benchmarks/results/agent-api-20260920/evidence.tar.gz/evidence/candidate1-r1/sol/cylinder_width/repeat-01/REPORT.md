# Cylinder cross-width calculation

`solution.py` uses the public `treams_rs` API to construct the homogeneous
infinite-cylinder T-matrix separately at each requested wavelength. The vacuum
angular wavenumber is `k0 = 2*pi/wavelength`, the cylinder axis is z, and
`kz = 0`. Illumination is a plane wave propagating in +x with positive helicity.
The supplied `mmax` retains cylindrical orders from `-mmax` through `+mmax`.

All input lengths are micrometers. Relative permittivity is formed as
`epsilon[0] + 1j*epsilon[1]`; relative permeability is 1, chirality is 0, and
the exterior is vacuum. The outputs are cross widths per unit cylinder length,
so scattering, extinction, and absorption are in micrometers—not areas and not
normalized by a sphere or cylinder area. Output list entries retain the input
wavelength order.

Checks on the example include finite positive widths, positive absorption for
the passive material, and the power-balance relation
`absorption = extinction - scattering`; its residual was zero at the reported
precision. Repeating the calculation with `mmax = 5` changed the three kinds of
width by at most `2.21e-9` micrometers relative to the requested `mmax = 4`.
