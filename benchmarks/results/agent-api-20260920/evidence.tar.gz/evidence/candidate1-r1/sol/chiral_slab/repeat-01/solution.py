"""Normal-incidence power balance of a reciprocal chiral slab."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import treams_rs as treams


def _finite_number(value: Any, name: str) -> float:
    """Convert one real, finite input value to float."""
    if isinstance(value, bool):
        raise TypeError(f"{name} must be a real number")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must be a real number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: Mapping[str, Any]) -> dict[str, list[list[float]]]:
    """Return slab power fractions for positive and negative helicity.

    The outer list follows ``config["wavelengths"]``.  Each inner list is
    ordered as positive helicity, then negative helicity.
    """
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary")

    thickness = _finite_number(config["thickness"], "thickness")
    if thickness < 0:
        raise ValueError("thickness must be non-negative")

    epsilon_parts = config["epsilon"]
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _finite_number(epsilon_parts[0], "epsilon[0]"),
        _finite_number(epsilon_parts[1], "epsilon[1]"),
    )
    kappa = _finite_number(config["kappa"], "kappa")

    wavelengths_raw = config["wavelengths"]
    if not isinstance(wavelengths_raw, (list, tuple)):
        raise TypeError("wavelengths must be a list")
    wavelengths = [
        _finite_number(value, f"wavelengths[{i}]")
        for i, value in enumerate(wavelengths_raw)
    ]
    if any(value <= 0 for value in wavelengths):
        raise ValueError("wavelengths must be positive")

    basis = treams.PlaneWavePorts.default([0.0, 0.0])
    material = treams.Material(epsilon, 1.0, kappa)

    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    # For the default basis the public slab API defines [0, 1] as positive
    # helicity.  The orthogonal channel [1, 0] is negative helicity.
    incident_channels = ([0.0, 1.0], [1.0, 0.0])
    for wavelength in wavelengths:
        smatrix = treams.slab(
            basis=basis,
            k0=2.0 * math.pi / wavelength,
            thickness=thickness,
            material=material,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        balances = [
            smatrix.power(channel, side="negative")
            for channel in incident_channels
        ]
        transmission.append([float(item.transmission) for item in balances])
        reflection.append([float(item.reflection) for item in balances])
        absorption.append([float(item.absorption) for item in balances])

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main() -> None:
    """Read one JSON config from stdin and emit one JSON result."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
