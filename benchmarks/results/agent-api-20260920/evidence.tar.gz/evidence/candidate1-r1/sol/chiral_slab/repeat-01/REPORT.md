# Chiral slab calculation

`solution.py` uses the public `treams_rs` plane-wave slab API. Lengths are in
micrometers, so the vacuum wavenumber passed to the solver is
`k0 = 2 pi / wavelength` in inverse micrometers. The slab material is
`Material(epsilon_real + i epsilon_imag, 1, kappa)` and both exterior media
are vacuum.

The illumination propagates from the negative-z exterior toward +z at normal
incidence. Results are power fractions (not field amplitudes). Columns are
ordered positive helicity, negative helicity. In the default normal-incidence
helicity basis, the package documents `[0, 1]` as positive helicity; `[1, 0]`
is its orthogonal negative-helicity channel.

For each wavelength, transmission and reflection come from the package's
flux-normalized `SMatrices.power` calculation. Absorption is its power balance
`1 - transmission - reflection`. Checks on the example confirm finite values,
the requested `(3, 2)` shape, and closure
`transmission + reflection + absorption = 1` to floating-point precision.
Because the example has real kappa and the same loss in both chiral indices,
its two helicities have equal power fractions up to roundoff (their complex
transmission phases can still differ).
