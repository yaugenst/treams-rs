"""Analytic-gradient optimization of a single antireflection coating."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import numpy as np
import treams_rs as treams
import treams_rs.advect as tr_ad


def _number(config: dict[str, Any], key: str) -> float:
    """Return a finite real-valued configuration entry."""
    try:
        value = float(config[key])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"{key} must be a finite real number") from exc
    if not math.isfinite(value):
        raise ValueError(f"{key} must be a finite real number")
    return value


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Optimize coating thickness and return reflection diagnostics.

    Thickness and wavelength use the same length unit (micrometers for the
    supplied problem).  Reflection is an incident-power fraction, and its
    gradient is per unit thickness.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    wavelength = _number(config, "wavelength")
    epsilon = _number(config, "epsilon")
    substrate_epsilon = _number(config, "substrate_epsilon")
    initial = _number(config, "initial_thickness")
    if wavelength <= 0 or epsilon <= 0 or substrate_epsilon <= 0:
        raise ValueError("wavelength and both lossless permittivities must be positive")
    try:
        lower, upper = (float(x) for x in config["bounds"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("bounds must contain two finite thicknesses") from exc
    if not (math.isfinite(lower) and math.isfinite(upper) and 0 <= lower < upper):
        raise ValueError("bounds must be finite, nonnegative, and strictly increasing")
    if not lower <= initial <= upper:
        raise ValueError("initial_thickness must lie within bounds")

    # Fixed normal-incidence port geometry can safely live outside the trace.
    basis = treams.PlaneWavePorts.default([0.0, 0.0])
    k0 = 2.0 * math.pi / wavelength

    def reflected_power(thickness: Any) -> Any:
        network = tr_ad.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        # [0, 1] is unit positive-helicity incidence from the negative side.
        return network.power([0.0, 1.0], side="negative").reflection

    value_and_grad = ad.value_and_grad(reflected_power)

    def evaluate(x: float) -> tuple[float, float]:
        # A fresh call is required because each native reverse residual is consumed.
        value, derivative = value_and_grad(float(x))
        return float(np.asarray(value)), float(np.asarray(derivative))

    thickness = initial
    loss, gradient = evaluate(thickness)
    initial_reflection = loss
    history = [loss]
    span = upper - lower
    # This is a bounded projected-gradient method with Armijo backtracking and
    # a one-dimensional Barzilai--Borwein step estimate after accepted moves.
    step_scale = span / max(abs(gradient), 1e-15)

    for _ in range(200):
        if loss < 1e-14 and abs(gradient) < 1e-8 / max(span, 1e-300):
            break

        if abs(gradient) <= 1e-14 / max(span, 1e-300):
            # Escape the exceptional case of starting exactly at a stationary
            # maximum; subsequent movement remains controlled by analytic slopes.
            probes = [max(lower, thickness - 0.02 * span), min(upper, thickness + 0.02 * span)]
            trials = [(x, *evaluate(x)) for x in probes if x != thickness]
            if not trials:
                break
            candidate, candidate_loss, candidate_gradient = min(trials, key=lambda item: item[1])
            if candidate_loss >= loss:
                break
        else:
            alpha = min(max(step_scale, 1e-16 * span / abs(gradient)), span / abs(gradient))
            accepted = False
            for _ in range(60):
                candidate = min(upper, max(lower, thickness - alpha * gradient))
                displacement = candidate - thickness
                if displacement == 0.0:
                    break
                candidate_loss, candidate_gradient = evaluate(candidate)
                if candidate_loss <= loss + 1e-4 * gradient * displacement:
                    accepted = True
                    break
                alpha *= 0.5
            if not accepted:
                break

        old_thickness, old_gradient = thickness, gradient
        thickness, loss, gradient = candidate, candidate_loss, candidate_gradient
        history.append(loss)
        delta_gradient = gradient - old_gradient
        if delta_gradient != 0.0:
            step_scale = abs((thickness - old_thickness) / delta_gradient)
        else:
            step_scale *= 0.5

    # Re-evaluate at the reported point through the differentiated treams path.
    loss, gradient = evaluate(thickness)
    if loss >= 1e-7:
        raise RuntimeError(
            f"gradient optimization did not reach the required reflection: {loss:.6g}"
        )

    return {
        "thickness": float(thickness),
        "reflection": float(loss),
        "initial_reflection": float(initial_reflection),
        "gradient": float(gradient),
        "loss_history": [float(item) for item in history],
    }


def _main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
