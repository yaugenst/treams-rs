# Antireflection optimization report

`solution.py` models one homogeneous, lossless coating between vacuum on the
negative-z side and the supplied substrate on the positive-z side. The layer
stack is ordered from negative to positive z, and illumination propagates in
the +z direction at normal incidence. Relative permittivities are used directly
(`mu = 1`, chirality zero); they are not interpreted as refractive indices.

Wavelength and thickness are in micrometers, so `k0 = 2*pi/wavelength` is in
inverse micrometers. `reflection` and `initial_reflection` are dimensionless
reflected-power fractions. `gradient` is `d(reflection)/d(thickness)`, in
inverse micrometers. `loss_history` contains the initial loss followed by every
accepted bounded optimization iterate.

The forward model is `treams_rs.advect.slab`, and each optimization evaluation
uses Advect reverse mode to invoke treams-rs's analytic native pullback. The
method is projected gradient descent with Armijo backtracking and a scalar
Barzilai--Borwein step estimate. Checks enforce positive lossless material
parameters, valid bounds, in-bound iterates, finite JSON values, and final
reflection below `1e-7`. The example was also checked with the independent
NumPy-facing treams-rs slab power calculation; power conservation is verified
as transmission + reflection = 1 to floating-point precision.
