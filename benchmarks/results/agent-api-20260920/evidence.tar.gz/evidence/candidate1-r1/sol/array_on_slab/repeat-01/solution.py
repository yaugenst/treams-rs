"""Periodic sphere-array transmission above a dielectric slab."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import numpy as np
import treams_rs as tr


_SCALAR_KEYS = (
    "radius",
    "sphere_epsilon",
    "period",
    "gap",
    "slab_thickness",
    "slab_epsilon",
)


def _real(config: Mapping[str, Any], key: str) -> float:
    """Return one finite, real-valued configuration entry."""
    if key not in config or isinstance(config[key], bool):
        raise ValueError(f"{key} must be a finite real number")
    try:
        value = float(config[key])
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{key} must be a finite real number") from exc
    if not math.isfinite(value):
        raise ValueError(f"{key} must be a finite real number")
    return value


def run(config: Mapping[str, Any]) -> dict[str, list[float]]:
    """Calculate zeroth-order power fractions for all requested wavelengths.

    The layer order is slab, vacuum propagation, and periodic sphere array,
    from negative to positive z.  The two ports are the two helicities of the
    zeroth diffraction order.
    """
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary-like mapping")

    values = {key: _real(config, key) for key in _SCALAR_KEYS}
    if "lmax" not in config or isinstance(config["lmax"], bool):
        raise ValueError("lmax must be a positive integer")
    lmax = config["lmax"]
    if not isinstance(lmax, int) or lmax < 1:
        raise ValueError("lmax must be a positive integer")

    try:
        wavelengths = [float(value) for value in config["wavelengths"]]
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        raise ValueError("wavelengths must be a nonempty sequence of finite numbers") from exc
    if not wavelengths or any(not math.isfinite(wl) or wl <= 0 for wl in wavelengths):
        raise ValueError("wavelengths must be a nonempty sequence of positive finite numbers")

    if values["radius"] <= 0 or values["period"] <= 0:
        raise ValueError("radius and period must be positive")
    if values["gap"] < 0 or values["slab_thickness"] < 0:
        raise ValueError("gap and slab_thickness must be nonnegative")
    if any(wl <= values["period"] for wl in wavelengths):
        raise ValueError("each wavelength must exceed the period")

    # PlaneWavePorts.default includes both helicities at the supplied k_parallel.
    ports = tr.PlaneWavePorts.default([0.0, 0.0])
    lattice = tr.Lattice.square(values["period"])
    positive_helicity = [0.0, 1.0]

    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength

        isolated_sphere = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=values["radius"],
            material=values["sphere_epsilon"],
        )
        array = tr.solve_periodic(
            isolated_sphere,
            lattice=lattice,
            kpar=[0.0, 0.0],
        ).to_smatrix(ports)

        slab = tr.slab(
            basis=ports,
            k0=k0,
            thickness=values["slab_thickness"],
            material=values["slab_epsilon"],
        )
        vacuum_gap = tr.propagation(
            distance=values["gap"],
            basis=ports,
            k0=k0,
        )
        network = tr.stack([slab, vacuum_gap, array])
        power = network.power(positive_helicity, side="negative")

        transmission.append(float(power.transmission))
        reflection.append(float(power.reflection))
        absorption.append(float(power.absorption))

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def _main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
