# Periodic sphere array above a slab

`solution.py` builds the optical network in its physical order along positive
z: dielectric slab, vacuum propagation gap, and square periodic sphere array.
The sphere T-matrix and the full Bloch-periodic multiple-scattering solve use
`treams_rs`; the solved array is then converted to a planar S-matrix and
cascaded with the gap and slab S-matrices.

All lengths are in micrometers, so the vacuum angular wavenumber is
`k0 = 2*pi/wavelength` in inverse micrometers. Permittivities are relative and
real; all unspecified permeabilities are one and all chiralities are zero.
The slab and both exterior half-spaces use vacuum as the surrounding medium.

The Bloch vector is `(0, 0)`. The planar basis contains only the zeroth
diffraction order and both helicities, as requested. In the treams-rs helicity
port convention, amplitudes `[0, 1]` select positive helicity. Illumination is
from the negative-z side, propagating toward positive z. The configured `gap`
is the propagation distance from the slab top plane to the sphere-center plane.

The returned transmission and reflection values are outgoing power fluxes
normalized to incident power. Absorption is `1 - transmission - reflection`.
For the supplied lossless example, every wavelength satisfies
`T + R + A = 1` to floating-point precision and absorption is at roundoff
level. The CLI result is recorded in `results.json`.
