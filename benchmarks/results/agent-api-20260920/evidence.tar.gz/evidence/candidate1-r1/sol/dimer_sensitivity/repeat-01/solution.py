"""Multiple-scattering field intensity and analytic separation sensitivity."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import advect as ad
import advect.numpy as np
import treams_rs.advect as tr


_REQUIRED_KEYS = {
    "radius",
    "epsilon",
    "separation",
    "wavelength",
    "lmax",
    "point",
}


def _validated(config: Mapping[str, Any]) -> tuple[float, complex, float, float, int, list[float]]:
    """Extract and minimally validate the fixed problem parameters."""
    missing = _REQUIRED_KEYS.difference(config)
    if missing:
        raise ValueError(f"missing configuration keys: {sorted(missing)}")

    radius = float(config["radius"])
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    epsilon_parts = list(config["epsilon"])
    point = [float(x) for x in config["point"]]

    if len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    if len(point) != 3:
        raise ValueError("point must contain three Cartesian coordinates")
    if radius <= 0 or wavelength <= 0 or separation <= 0:
        raise ValueError("radius, wavelength, and separation must be positive")
    if lmax < 1 or lmax != config["lmax"]:
        raise ValueError("lmax must be a positive integer")

    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    return radius, epsilon, separation, wavelength, lmax, point


def run(config: Mapping[str, Any]) -> dict[str, float]:
    """Return total electric intensity and its analytic separation derivative."""
    radius, epsilon, separation, wavelength, lmax, point = _validated(config)
    k0 = 2.0 * math.pi / wavelength

    # Parameters other than separation are fixed for this requested derivative.
    particle = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=epsilon,
    )
    incident = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
    )
    sample_points = np.asarray([point])

    def objective(distance: float) -> Any:
        # Both centers depend on distance, so reverse mode includes both motions.
        positions = np.asarray(
            [[-0.5 * distance, 0.0, 0.0], [0.5 * distance, 0.0, 0.0]]
        )
        cluster = tr.Cluster([particle, particle], positions=positions)
        scattered = cluster.scatter(incident)  # coupled multiple-scattering solve
        total_e = scattered.efield(sample_points) + incident.efield(sample_points)
        return np.sum(np.abs(total_e) ** 2)

    value, gradient = ad.value_and_grad(objective)(separation)
    return {"value": float(value), "gradient": float(gradient)}


def main() -> None:
    """Read one JSON config from stdin and emit one JSON result to stdout."""
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise ValueError("input JSON must be a configuration object")
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
