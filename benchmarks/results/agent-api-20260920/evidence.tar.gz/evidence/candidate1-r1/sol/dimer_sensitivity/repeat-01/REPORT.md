# Dimer field sensitivity

`solution.py` uses the `treams_rs.advect` public adapter throughout the physical
calculation. Each homogeneous sphere is represented by its Mie T-matrix. A
`Cluster.scatter` call solves the coupled two-particle multiple-scattering
problem, and the outgoing field is added coherently to the incident plane-wave
field before evaluating `sum(abs(E_total)**2)`.

## Units and conventions

- All input lengths and Cartesian coordinates are in micrometers. Thus
  `k0 = 2*pi/wavelength` is in inverse micrometers.
- `epsilon = epsilon[0] + 1j*epsilon[1]` is relative permittivity. The spheres
  use relative permeability 1 and chirality 0; their exterior is vacuum.
- Sphere centers are `(-separation/2, 0, 0)` and
  `(separation/2, 0, 0)`. Consequently, the analytic pullback differentiates
  both center motions while holding the observation point and all other inputs
  fixed.
- Illumination propagates in `+z` and uses treams-rs's named
  `positive_helicity` convention with unit electric-field amplitude. The field
  uses the package's `exp(+i k.r)` spatial convention. The returned `value` is
  in squared electric-field amplitude units, and `gradient` is per micrometer.
- The multipole expansion is truncated at the supplied `lmax`; no additional
  convergence extrapolation is performed.

## Checks for the supplied example

The executed result is `value = 1.1855506354526988` and
`gradient = -0.40372542061712435 / micrometer`. The incident field alone has
`sum(abs(E_incident)**2) = 1.0000000000000004` at the requested point.

The reported gradient comes from Advect reverse mode composed with treams-rs's
native analytic pullbacks. As a check only, a centered finite difference with
step `1e-5 micrometer` gives `-0.4037254207167606 / micrometer`, a relative
difference of about `2.5e-10` from the analytic result.
