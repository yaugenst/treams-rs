# Dimer scattering calculation

`solution.py` uses the public `treams_rs` interface. It builds one homogeneous
sphere T-matrix per input radius/permittivity at the requested fixed `lmax`,
places their expansion origins at `(-separation/2, 0, 0)` and
`(+separation/2, 0, 0)`, and calls `Cluster.solve()`. The resulting coupled
T-matrix includes all repeated scattering between the two particles within the
chosen multipole truncation.

## Units and conventions

- Radius, separation, wavelength, and field-point coordinates are in micrometers.
  The vacuum wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers.
- Scattering, extinction, and absorption cross sections are therefore in square
  micrometers.
- Each material is interpreted as relative permittivity
  `epsilon_real + i*epsilon_imag`; relative permeability is 1 and chirality is
  0. The exterior is vacuum. Positive imaginary permittivity denotes passive
  loss in the package convention.
- Illumination propagates along positive z and uses the package's named
  `positive_helicity` state. No additional field-amplitude rescaling is made.
- `total_field_real` and `total_field_imag` contain Cartesian `(Ex, Ey, Ez)` in
  input-point order. The total field is the package-normalized incident plane
  wave plus the coupled outgoing field.

## Checks

The supplied example was run through the JSON CLI to produce `results.json`.
All returned field components and cross sections are finite. The passive dimer
gives positive scattering and absorption, and the reported values satisfy the
power-balance definition
`absorption = extinction - scattering` (0.0026176027019321826 square
micrometers). A separate numerical check also compares the scattered
coefficients from the fully solved cluster T-matrix with `Cluster.scatter()`,
which directly solves the same illumination problem.
