"""Multiple-scattering response of a two-sphere dimer using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import numpy as np
import treams_rs as tr


def _positive_finite(name: str, value: Any) -> float:
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")
    return value


def run(config: Mapping[str, Any]) -> dict[str, Any]:
    """Return fields and cross sections for the configured sphere dimer.

    Length inputs are interpreted in micrometers. Consequently, the returned
    cross sections are in square micrometers and the electric field follows the
    package's unit-amplitude incident-wave normalization.
    """
    radii = np.asarray(config["radii"], dtype=float)
    eps_parts = np.asarray(config["epsilon"], dtype=float)
    points = np.asarray(config["points"], dtype=float)
    if radii.shape != (2,) or not np.isfinite(radii).all() or np.any(radii <= 0):
        raise ValueError("radii must contain two finite positive values")
    if eps_parts.shape != (2, 2) or not np.isfinite(eps_parts).all():
        raise ValueError("epsilon must contain two [real, imag] pairs")
    if points.ndim != 2 or points.shape[1:] != (3,) or not np.isfinite(points).all():
        raise ValueError("points must be a finite point-by-3 array")

    separation = _positive_finite("separation", config["separation"])
    wavelength = _positive_finite("wavelength", config["wavelength"])
    lmax = int(config["lmax"])
    if isinstance(config["lmax"], bool) or lmax != config["lmax"] or lmax < 1:
        raise ValueError("lmax must be a positive integer")

    k0 = 2 * math.pi / wavelength
    permittivities = eps_parts[:, 0] + 1j * eps_parts[:, 1]
    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=float(radius),
            material=complex(epsilon),
        )
        for radius, epsilon in zip(radii, permittivities, strict=True)
    ]
    positions = np.array(
        [[-0.5 * separation, 0.0, 0.0], [0.5 * separation, 0.0, 0.0]]
    )

    incident = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
    )
    response = tr.Cluster(particles, positions=positions).solve()
    scattered = response.scatter(incident)
    total_field = incident.efield(points) + scattered.efield(points)
    cross = response.cross_sections(incident)

    return {
        "total_field_real": total_field.real.tolist(),
        "total_field_imag": total_field.imag.tolist(),
        "scattering": float(cross.scattering),
        "extinction": float(cross.extinction),
        "absorption": float(cross.absorption),
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
