# Homogeneous-sphere spectrum

`solution.py` uses the public `treams_rs.sphere_tmatrix` and
`TMatrix.cross_sections` APIs with the requested fixed multipole cutoff. For
each input wavelength it constructs a plane wave travelling along +z with the
library's explicit `positive_helicity` convention.

## Units and conventions

- Radius and vacuum wavelength are in micrometers, with vacuum angular
  wavenumber `k0 = 2*pi/wavelength` in inverse micrometers.
- `epsilon = [real, imag]` is converted directly to the sphere's complex
  relative permittivity; it is not squared as a refractive index would be.
- The sphere is nonmagnetic and achiral (`mu = 1`, chirality = 0), and the
  exterior is vacuum, all supplied by the treams-rs defaults.
- Scattering, extinction, and absorption are in square micrometers. Efficiency
  is dimensionless and equals scattering divided by `pi*radius**2`.
- Output list order is exactly the input wavelength order.

## Checks

The implementation checks that physical lengths are finite and positive,
permittivity components are finite, and `lmax` is in the library-supported
range 1--128. It rejects non-finite solver outputs. For the example run, all
cross sections are finite, absorption is positive (as expected for positive
imaginary permittivity), and at every wavelength the reported values satisfy
`extinction = scattering + absorption` to floating-point precision. The saved
efficiencies also reproduce `scattering/(pi*radius**2)`.
