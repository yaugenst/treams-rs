"""Spectrum of a homogeneous dielectric sphere computed with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _finite_real(value: Any, name: str) -> float:
    """Convert a JSON number to a finite float, rejecting booleans."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return sphere cross sections and efficiency in wavelength order.

    Length inputs are in micrometers, so the three cross sections are in
    square micrometers. ``epsilon`` is ``[real, imag]``.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    missing = {"radius", "epsilon", "wavelengths", "lmax"} - config.keys()
    if missing:
        raise KeyError(f"missing configuration key(s): {', '.join(sorted(missing))}")

    radius = _finite_real(config["radius"], "radius")
    if radius <= 0:
        raise ValueError("radius must be positive")

    epsilon_parts = config["epsilon"]
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise TypeError("epsilon must be a two-element [real, imag] sequence")
    epsilon = complex(
        _finite_real(epsilon_parts[0], "epsilon[0]"),
        _finite_real(epsilon_parts[1], "epsilon[1]"),
    )

    lmax_value = config["lmax"]
    if isinstance(lmax_value, bool) or not isinstance(lmax_value, int):
        raise TypeError("lmax must be an integer")
    if not 1 <= lmax_value <= 128:
        raise ValueError("lmax must be between 1 and 128")

    wavelength_values = config["wavelengths"]
    if not isinstance(wavelength_values, (list, tuple)):
        raise TypeError("wavelengths must be a sequence")
    wavelengths = [
        _finite_real(value, f"wavelengths[{index}]")
        for index, value in enumerate(wavelength_values)
    ]
    if any(wavelength <= 0 for wavelength in wavelengths):
        raise ValueError("all wavelengths must be positive")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    efficiency: list[float] = []
    geometric_area = math.pi * radius * radius

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        response = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax_value,
            radius=radius,
            material=epsilon,
        )
        incident = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity", k0=k0
        )
        cross = response.cross_sections(incident)

        sca = float(cross.scattering)
        ext = float(cross.extinction)
        abs_ = float(cross.absorption)
        if not all(math.isfinite(value) for value in (sca, ext, abs_)):
            raise ArithmeticError("treams-rs returned a non-finite cross section")

        scattering.append(sca)
        extinction.append(ext)
        absorption.append(abs_)
        efficiency.append(sca / geometric_area)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


def main() -> None:
    """Read one JSON configuration from stdin and write one JSON result."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
