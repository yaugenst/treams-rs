# Cylinder cross-width calculation

`solution.py` uses the public `treams_rs.cylinder_tmatrix` and
`TMatrixC.cross_widths` interfaces. For each input wavelength it sets
`k0 = 2*pi/wavelength`, `kz = 0`, the requested `mmax` and radius, and a
homogeneous material with relative permittivity `epsilon[0] + i*epsilon[1]`.
The exterior is vacuum (`epsilon = mu = 1`, zero chirality), while the cylinder
has `mu = 1` and zero chirality by the material defaults.

## Units and conventions

All lengths are in micrometres, so `k0` and `kz` are in inverse micrometres and
the returned scattering, extinction, and absorption **cross widths** are in
micrometres. They are powers per cylinder length divided by incident intensity;
there is no sphere-area or geometric-area normalization. Output entries retain
the order of `config["wavelengths"]`.

The incident wave propagates along +x and uses the explicitly named
`positive_helicity` channel. The cylindrical basis contains azimuthal orders
from `-mmax` through `+mmax` at `kz = 0`. The package's outgoing-wave and
plane-wave convention is used (plane-wave spatial phase `exp(i k.r)`).

## Checks

The saved example was produced by executing the CLI. For every wavelength,
`absorption = extinction - scattering` to floating-point precision, and all
three absorption widths are positive, as expected for `Im(epsilon) = 0.1`.
As a convergence diagnostic, recomputing with `mmax = 5` changed the largest
extinction result by about `2.20e-9` micrometres; `mmax = 6` changed that
result from the `mmax = 5` value by about `1.78e-11` micrometres. The saved
values nevertheless use the requested cutoff `mmax = 4` exactly.
