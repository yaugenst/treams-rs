"""Cross widths of a homogeneous, infinitely long circular cylinder."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import treams_rs as treams


def _positive_finite(value: Any, name: str) -> float:
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return value


def run(config: Mapping[str, Any]) -> dict[str, list[float]]:
    """Return cylinder scattering, extinction, and absorption cross widths.

    Lengths in ``config`` are interpreted in one common unit (micrometres for
    the stated problem), so the returned widths have that same unit.
    """
    if not isinstance(config, Mapping):
        raise TypeError("config must be a mapping")

    radius = _positive_finite(config["radius"], "radius")

    epsilon_parts = config["epsilon"]
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    if not (math.isfinite(epsilon.real) and math.isfinite(epsilon.imag)):
        raise ValueError("epsilon components must be finite")

    mmax_raw = config["mmax"]
    if isinstance(mmax_raw, bool) or int(mmax_raw) != mmax_raw:
        raise ValueError("mmax must be a nonnegative integer")
    mmax = int(mmax_raw)
    if mmax < 0:
        raise ValueError("mmax must be a nonnegative integer")

    wavelengths = [
        _positive_finite(value, f"wavelengths[{index}]")
        for index, value in enumerate(config["wavelengths"])
    ]

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        tmatrix = treams.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],
            mmax=mmax,
            radius=radius,
            material=epsilon,
            medium=1,
            polarization="helicity",
        )
        illumination = treams.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        widths = tmatrix.cross_widths(illumination)
        sca = float(widths.scattering)
        ext = float(widths.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(ext - sca)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


def _main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
