"""Scattering efficiency and analytic sensitivities for a lossy sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

from advect import value_and_grad
from treams_rs import advect as tr


def _efficiency(
    radius: float,
    epsilon_real: float,
    *,
    epsilon_imag: float,
    wavelength: float,
    lmax: int,
):
    """Return Q; dynamic arguments are differentiated by Advect."""
    k0 = 2.0 * math.pi / wavelength
    sphere = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=epsilon_real + 1j * epsilon_imag,
    )
    incident = tr.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=k0
    )
    scattering = sphere.cross_sections(incident).scattering
    return scattering / (math.pi * radius**2)


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Calculate scattering efficiency and [radius, epsilon-real] gradient."""
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax_raw = config["lmax"]
    lmax = int(lmax_raw)

    if not math.isfinite(radius) or radius <= 0.0:
        raise ValueError("radius must be finite and positive")
    if not math.isfinite(wavelength) or wavelength <= 0.0:
        raise ValueError("wavelength must be finite and positive")
    if not all(math.isfinite(x) for x in (epsilon_real, epsilon_imag)):
        raise ValueError("permittivity components must be finite")
    if isinstance(lmax_raw, bool) or lmax != lmax_raw or lmax < 1:
        raise ValueError("lmax must be a positive integer")

    def objective(r: float, er: float):
        return _efficiency(
            r,
            er,
            epsilon_imag=epsilon_imag,
            wavelength=wavelength,
            lmax=lmax,
        )

    # This reverse pass composes treams-rs native pullbacks through the cross
    # section and the radius-dependent geometric normalization.
    value, gradient = value_and_grad(objective, argnums=(0, 1))(
        radius, epsilon_real
    )
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
