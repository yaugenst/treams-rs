# Sphere scattering sensitivity

`solution.py` returns the dimensionless scattering efficiency

\[Q = C_{\mathrm{sca}}/(\pi r^2)\]

and the ordered gradient `[dQ/dradius, dQ/depsilon_real]`. Lengths are in
micrometers, so `dQ/dradius` has units of inverse micrometers;
`dQ/depsilon_real` is dimensionless. The vacuum wavenumber is
`k0 = 2*pi/wavelength`. Relative permeability is 1, chirality is 0, and the
embedding medium is vacuum.

The illumination propagates along +z and has positive helicity, using the
treams-rs helicity convention. The sphere permittivity is
`epsilon_real + 1j*epsilon_imag`. The requested derivatives hold
`epsilon_imag`, wavelength, and `lmax` fixed.

The value and derivatives are evaluated by the installed treams-rs Advect
adapter. Reverse-mode differentiation is applied to the complete expression,
including both the scattering cross section and the `pi*radius**2`
normalization.

For the supplied example the result is `Q = 0.46337644643427434`, with analytic
gradient `[18.65367030479629, 0.1997255464561844]`. Centered finite differences,
used only as independent checks, gave `18.653670304680237` for radius (step
`1e-6` micrometers) and `0.19972554649305693` for epsilon real (step `1e-5`).
The respective relative discrepancies were `6.22e-12` and `1.85e-10`.
