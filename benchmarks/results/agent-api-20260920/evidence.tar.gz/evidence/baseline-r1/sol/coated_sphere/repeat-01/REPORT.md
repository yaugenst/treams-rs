# Core-shell sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` API. The
radii are passed as increasing finite-layer boundaries and the corresponding
complex permittivities are passed inside-out. The exterior permittivity is
passed separately as `medium`; it is not appended to the finite layers.

## Units and conventions

Input wavelengths are vacuum wavelengths in micrometers and the vacuum angular
wavenumber is `k0 = 2*pi/wavelength`. Radii are also in micrometers. Relative
permittivities use the convention `epsilon = real + i*imag`; relative
permeability is 1 and chirality is 0. The exterior must be a positive,
nonabsorbing dielectric because far-field averaged cross sections require
propagating waves in a lossless medium.

The returned scattering, extinction, and absorption cross sections are in
square micrometers and retain the input wavelength order. They are the
rotationally and polarization averaged values supplied by
`TMatrix.average_cross_sections`. Absorption is `extinction - scattering`.

## Checks

- For the example, every cross section is finite, scattering and absorption
  are positive, and extinction equals scattering plus absorption (to floating
  point precision).
- Replacing both layers by the same material agrees with a homogeneous sphere
  of the outer radius to within `1.8e-18 um^2` across the three wavelengths.
- Repeating the example with `lmax=8` changed scattering by at most
  `2.2e-9`, extinction by `2.7e-6`, and absorption by `3.1e-5` in relative
  terms, indicating that the requested `lmax=4` is converged for this case.

`results.json` was produced by executing the CLI with the supplied example
configuration.
