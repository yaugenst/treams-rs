"""Rotationally averaged spectra of concentric dielectric spheres."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping, Sequence
from typing import Any

import treams_rs


def _permittivity(value: Any, name: str) -> complex:
    """Convert either a real scalar or a [real, imaginary] pair to complex."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number or a [real, imag] pair")
    if isinstance(value, (int, float)):
        result = complex(value)
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        if len(value) != 2:
            raise ValueError(f"{name} must contain exactly [real, imag]")
        try:
            result = complex(float(value[0]), float(value[1]))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{name} must contain two finite numbers") from exc
    else:
        raise ValueError(f"{name} must be a number or a [real, imag] pair")
    if not (math.isfinite(result.real) and math.isfinite(result.imag)):
        raise ValueError(f"{name} must be finite")
    return result


def _positive_finite_list(value: Any, name: str) -> list[float]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ValueError(f"{name} must be a nonempty list")
    try:
        result = [float(item) for item in value]
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must contain numbers") from exc
    if not result or any(not math.isfinite(item) or item <= 0 for item in result):
        raise ValueError(f"{name} must contain positive finite numbers")
    return result


def run(config: Mapping[str, Any]) -> dict[str, list[float]]:
    """Calculate averaged cross sections for the requested vacuum wavelengths.

    Input and output lengths are in micrometers, so all returned cross sections
    are in square micrometers.
    """
    if not isinstance(config, Mapping):
        raise ValueError("config must be a dictionary")

    try:
        radii = _positive_finite_list(config["radii"], "radii")
        wavelengths = _positive_finite_list(config["wavelengths"], "wavelengths")
        raw_layers = config["epsilon_layers"]
        medium = _permittivity(config["epsilon_medium"], "epsilon_medium")
        lmax_raw = config["lmax"]
    except KeyError as exc:
        raise ValueError(f"missing required config key: {exc.args[0]}") from exc

    if any(outer <= inner for inner, outer in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing outer boundaries")
    if not isinstance(raw_layers, Sequence) or isinstance(raw_layers, (str, bytes)):
        raise ValueError("epsilon_layers must be a list")
    if len(raw_layers) != len(radii):
        raise ValueError("epsilon_layers must have exactly one entry per radius")
    layers = [
        _permittivity(value, f"epsilon_layers[{index}]")
        for index, value in enumerate(raw_layers)
    ]

    if isinstance(lmax_raw, bool) or not isinstance(lmax_raw, int):
        raise ValueError("lmax must be an integer")
    if not 1 <= lmax_raw <= 128:
        raise ValueError("lmax must be between 1 and 128")
    if medium.imag != 0:
        raise ValueError("epsilon_medium must be real for far-field cross sections")
    if medium.real <= 0:
        raise ValueError("epsilon_medium must be positive for a propagating exterior")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        tmatrix = treams_rs.multilayer_sphere_tmatrix(
            k0=2 * math.pi / wavelength,
            lmax=lmax_raw,
            radii=radii,
            materials=layers,
            medium=medium,
        )
        cross_sections = tmatrix.average_cross_sections
        sca = float(cross_sections.scattering)
        ext = float(cross_sections.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(float(cross_sections.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


def _main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
