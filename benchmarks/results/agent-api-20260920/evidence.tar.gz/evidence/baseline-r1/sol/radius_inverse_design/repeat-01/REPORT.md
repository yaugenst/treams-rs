# Radius inverse-design report

All lengths are in micrometers. Consequently, the vacuum angular
wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers and the fitted
radius is in micrometers. Relative permittivity and permeability, chirality,
scattering efficiency, and the least-squares loss are dimensionless. The
reported loss gradient is `d(loss)/d(radius)`, in inverse micrometers.

The calculation uses a homogeneous, isotropic, lossless sphere with the
configured relative permittivity, `mu = 1`, and chirality zero, embedded in
vacuum. `lmax` is held fixed. For each wavelength, the public differentiable
`treams_rs.advect.sphere` operation supplies the helicity-basis T-matrix and
its native analytic pullback. The rotationally and polarization-averaged
scattering efficiency is

`Q_sca = C_sca/(pi*r^2) = 2*||T||_F^2/(k0*r)^2`.

The requested mean squared relative residual is minimized from the supplied
initial radius by a bounded, safeguarded one-dimensional quasi-Newton method.
All optimization derivatives come from Advect reverse mode and the native
treams-rs sphere pullback; finite differences are not used for optimization.

For the example, the result is `r = 0.10999999999999965 um`, with loss
`9.1445e-29` and final analytic gradient `-6.7939e-13 1/um`. Every accepted
iterate remained in `[0.06, 0.14] um`, and the loss decreased monotonically
from `0.621529`.

Checks performed:

- The final efficiencies were recomputed with the independent public
  `treams_rs.sphere_tmatrix(...).average_cross_sections` interface. They
  agree with the adapter calculation to floating-point precision; its loss
  was `8.76e-29`.
- At the initial radius, a centered finite-difference validation with step
  `1e-6 um` gave gradient `-18.5523691901 1/um`, compared with the requested
  analytic gradient `-18.5523691928 1/um` (absolute difference `2.69e-9`).
- The sphere is lossless, so native scattering and extinction cross sections
  coincide up to numerical roundoff.
