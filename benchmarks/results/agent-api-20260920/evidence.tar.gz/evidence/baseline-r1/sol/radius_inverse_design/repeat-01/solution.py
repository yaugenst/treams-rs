"""Infer a homogeneous sphere radius from scattering efficiencies."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import advect.numpy as anp
import numpy as np
from treams_rs import advect as trs


def _validated(config: dict[str, Any]) -> tuple[float, int, np.ndarray, float, float, float, np.ndarray]:
    """Validate and normalize the public input schema."""
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = np.asarray(config["wavelengths"], dtype=float)
    initial = float(config["initial_radius"])
    bounds = np.asarray(config["bounds"], dtype=float)
    targets = np.asarray(config["target_efficiencies"], dtype=float)

    if not math.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("epsilon must be finite and positive for a lossless sphere")
    if not 1 <= lmax <= 128:
        raise ValueError("lmax must be between 1 and 128")
    if wavelengths.ndim != 1 or wavelengths.size == 0 or np.any(~np.isfinite(wavelengths)) or np.any(wavelengths <= 0):
        raise ValueError("wavelengths must be a nonempty list of positive finite values")
    if targets.shape != wavelengths.shape or np.any(~np.isfinite(targets)) or np.any(targets <= 0):
        raise ValueError("target_efficiencies must match wavelengths and be positive")
    if bounds.shape != (2,) or not np.all(np.isfinite(bounds)) or not bounds[0] < bounds[1]:
        raise ValueError("bounds must contain two finite, increasing radii")
    lower, upper = map(float, bounds)
    if not lower <= initial <= upper:
        raise ValueError("initial_radius must lie within bounds")
    return epsilon, lmax, wavelengths, initial, lower, upper, targets


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Fit radius using treams-rs scattering and Advect analytic gradients."""
    epsilon, lmax, wavelengths, initial, lower, upper, targets = _validated(config)

    # The arrays include the vacuum exterior as the final material.  Only the
    # radius is traced; material and wavelength are fixed by the experiment.
    epsilons = np.asarray([epsilon, 1.0])
    mus = np.asarray([1.0, 1.0])
    kappas = np.asarray([0.0, 0.0])
    wavenumbers = 2.0 * np.pi / wavelengths

    def efficiencies(radius: Any) -> Any:
        result = []
        for k0 in wavenumbers:
            matrix = trs.sphere(
                lmax,
                float(k0),
                ad.asarray([radius]),
                epsilons,
                mus,
                kappas,
            )
            # For a sphere, rotationally/polarization-averaged C_sca is
            # 2*pi*||T||_F^2/k0^2. Divide by geometric area pi*r^2.
            norm_squared = anp.real(anp.sum(anp.conj(matrix) * matrix))
            result.append(2.0 * norm_squared / (k0 * radius) ** 2)
        return ad.asarray(result)

    def objective(radius: Any) -> Any:
        relative_residual = (efficiencies(radius) - targets) / targets
        return anp.mean(relative_residual * relative_residual)

    # Every gradient used below is a reverse-mode analytic derivative whose
    # primitive sphere pullback is supplied by treams-rs.
    value_gradient = ad.value_and_grad(objective)

    x = initial
    value_raw, gradient_raw = value_gradient(x)
    value, gradient = float(value_raw), float(gradient_raw)
    initial_loss = value
    history = [value]
    span = upper - lower
    inverse_hessian = span / max(abs(gradient), 1.0)

    for _ in range(100):
        projected_gradient = gradient
        if (x <= lower and gradient > 0.0) or (x >= upper and gradient < 0.0):
            projected_gradient = 0.0
        if abs(projected_gradient) <= 1e-11:
            break

        step = -inverse_hessian * gradient
        step = float(np.clip(step, -0.25 * span, 0.25 * span))
        candidate = float(np.clip(x + step, lower, upper))
        if candidate == x:
            break

        # Armijo backtracking keeps all iterates in the supplied interval.
        accepted = False
        for _ in range(40):
            candidate_value_raw, candidate_gradient_raw = value_gradient(candidate)
            candidate_value = float(candidate_value_raw)
            candidate_gradient = float(candidate_gradient_raw)
            displacement = candidate - x
            if candidate_value <= value + 1e-4 * gradient * displacement:
                accepted = True
                break
            candidate = float(np.clip(x + 0.5 * displacement, lower, upper))
            if candidate == x:
                break
        if not accepted:
            break

        displacement = candidate - x
        gradient_change = candidate_gradient - gradient
        if displacement * gradient_change > 1e-18:
            inverse_hessian = displacement / gradient_change
            inverse_hessian = float(np.clip(inverse_hessian, 1e-14, span * span / 1e-14))
        else:
            inverse_hessian = span / max(abs(candidate_gradient), 1.0)

        x, value, gradient = candidate, candidate_value, candidate_gradient
        history.append(value)

    fitted = np.asarray(efficiencies(x), dtype=float)
    # Re-evaluate together so the reported loss and derivative correspond
    # exactly to the reported final radius.
    value_raw, gradient_raw = value_gradient(x)
    value, gradient = float(value_raw), float(gradient_raw)
    history[-1] = value

    return {
        "radius": float(x),
        "loss": value,
        "initial_loss": initial_loss,
        "gradient": gradient,
        "fitted_efficiencies": fitted.tolist(),
        "loss_history": [float(item) for item in history],
    }


def main() -> None:
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))


if __name__ == "__main__":
    main()
