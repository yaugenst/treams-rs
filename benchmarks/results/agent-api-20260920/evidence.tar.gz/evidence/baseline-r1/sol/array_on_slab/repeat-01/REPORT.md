# Periodic sphere array above a slab

`solution.py` uses the public `treams_rs` physics API. At each wavelength it
constructs the isolated-sphere T-matrix at the requested `lmax`, solves the
full square-lattice interaction at Bloch vector `(0, 0)`, and converts that
periodic response to the zeroth diffraction-order plane-wave ports. The slab,
vacuum propagation region, and array are then cascaded in increasing-z order.

All input lengths and the inverse vacuum wavenumber use micrometers, so
`k0 = 2*pi/wavelength` is in inverse micrometers. Permittivities are relative;
all permeabilities are one and all chiralities are zero. The slab and both
exterior half-spaces are vacuum except for the stated slab material. `gap` is
the +z distance from the slab top reference plane to the sphere-center plane.

The retained port basis contains `(kx, ky) = (0, 0)` in both helicity channels.
Illumination comes from the negative-z vacuum side, propagates along +z, and is
created explicitly as positive helicity. Transmission and reflection are the
package's flux-normalized power fractions; absorption is `1 - T - R`.

Checks performed for the example include CLI/function agreement, finite JSON
values, output ordering matching the wavelength list, and lossless power
closure. Because both supplied permittivities are real, absorption is zero up
to floating-point roundoff.
