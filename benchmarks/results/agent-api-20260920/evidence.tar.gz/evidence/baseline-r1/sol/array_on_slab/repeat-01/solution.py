"""Normal-incidence power balance of a periodic sphere array above a slab."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping

import numpy as np
import treams_rs as treams


_KEYS = {
    "radius",
    "sphere_epsilon",
    "period",
    "gap",
    "slab_thickness",
    "slab_epsilon",
    "wavelengths",
    "lmax",
}


def _validated(config: Mapping) -> tuple[float, float, float, float, float, float, list[float], int]:
    """Validate and convert the fixed input schema."""
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary")
    missing = _KEYS.difference(config)
    if missing:
        raise ValueError(f"missing config keys: {', '.join(sorted(missing))}")

    names = (
        "radius",
        "sphere_epsilon",
        "period",
        "gap",
        "slab_thickness",
        "slab_epsilon",
    )
    values = []
    for name in names:
        value = float(config[name])
        if not math.isfinite(value):
            raise ValueError(f"{name} must be finite")
        values.append(value)
    radius, sphere_eps, period, gap, slab_thickness, slab_eps = values

    if radius <= 0 or period <= 0:
        raise ValueError("radius and period must be positive")
    if gap < 0 or slab_thickness < 0:
        raise ValueError("gap and slab_thickness must be nonnegative")
    if 2 * radius >= period:
        raise ValueError("spheres must not touch or overlap in the square array")
    if gap < radius:
        raise ValueError("gap must keep the sphere from intersecting the slab")

    raw_lmax = config["lmax"]
    lmax = int(raw_lmax)
    if isinstance(raw_lmax, bool) or lmax != raw_lmax or lmax < 1:
        raise ValueError("lmax must be a positive integer")

    raw_wavelengths = config["wavelengths"]
    if not isinstance(raw_wavelengths, (list, tuple)) or not raw_wavelengths:
        raise ValueError("wavelengths must be a nonempty array")
    wavelengths = [float(wavelength) for wavelength in raw_wavelengths]
    if any(not math.isfinite(wavelength) or wavelength <= period for wavelength in wavelengths):
        raise ValueError("each wavelength must be finite and greater than the period")

    return radius, sphere_eps, period, gap, slab_thickness, slab_eps, wavelengths, lmax


def run(config: Mapping) -> dict:
    """Return wavelength-ordered transmission, reflection, and absorption."""
    (
        radius,
        sphere_eps,
        period,
        gap,
        slab_thickness,
        slab_eps,
        wavelengths,
        lmax,
    ) = _validated(config)

    # Exactly the zeroth diffraction order, with both helicity channels.
    ports = treams.PlaneWavePorts.default([[0.0, 0.0]])
    lattice = treams.Lattice.square(period)
    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2 * np.pi / wavelength

        isolated_sphere = treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=sphere_eps,
            medium=1.0,
            polarization="helicity",
        )
        periodic_sphere = treams.solve_periodic(
            isolated_sphere,
            lattice=lattice,
            kpar=[0.0, 0.0],
        ).to_smatrix(ports)

        slab = treams.slab(
            basis=ports,
            k0=k0,
            thickness=slab_thickness,
            material=slab_eps,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        vacuum_gap = treams.propagation(
            distance=gap,
            basis=ports,
            k0=k0,
            medium=1.0,
            polarization="helicity",
        )
        system = treams.stack([slab, vacuum_gap, periodic_sphere])

        incident = treams.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1.0,
        )
        balance = system.power(incident, side="negative")
        transmission.append(float(balance.transmission))
        reflection.append(float(balance.reflection))
        absorption.append(float(balance.absorption))

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def _main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
