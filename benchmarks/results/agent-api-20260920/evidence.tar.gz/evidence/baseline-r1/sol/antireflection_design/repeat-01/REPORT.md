# Antireflection coating optimization

`solution.py` models vacuum, one homogeneous coating, and the positive-side
substrate as a planar layer stack. It calls the public
`treams_rs.advect.layer_stack` operation for scattering and differentiates the
reflected power with Advect's reverse-mode transform. The resulting thickness
derivative is the native Rust layer-stack pullback; finite differences are not
used by the optimizer.

Lengths (wavelength, thickness, and bounds) are in micrometers. Thus
`k0 = 2 pi / wavelength` is in inverse micrometers, and the reported `gradient`
is `dR/dd` in inverse micrometers. Permittivities are relative and dimensionless;
all media use relative permeability 1 and chirality 0. The layer order follows
the positive normal: vacuum, coating, substrate. Illumination propagates in the
positive direction from the vacuum side at normal incidence. `reflection` and
`initial_reflection` are dimensionless power fractions, not field amplitudes.

The objective sums both reflected helicity channels for one incident helicity.
For this isotropic normal-incidence problem the other incident helicity gives
the same power. Optimization is projected gradient descent with an Armijo line
search in a dimensionless bound coordinate, starting exactly at
`initial_thickness`; all accepted iterates stay within `bounds`.

Checks performed for the supplied example: the CLI output is valid JSON, every
accepted loss is non-increasing, the returned thickness is within bounds, and
the final reflected power is below `1e-7`. A centered finite-difference check is
used only as an external validation of the final analytic derivative.
