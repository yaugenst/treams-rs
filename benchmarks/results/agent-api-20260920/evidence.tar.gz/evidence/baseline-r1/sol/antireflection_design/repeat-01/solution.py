"""Gradient design of a single antireflection coating with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import numpy as np
from treams_rs import Material
from treams_rs import advect as tr_ad


def _validate(config: dict[str, Any]) -> tuple[float, float, float, float, float]:
    required = (
        "wavelength",
        "epsilon",
        "substrate_epsilon",
        "initial_thickness",
        "bounds",
    )
    missing = [key for key in required if key not in config]
    if missing:
        raise ValueError(f"missing configuration key(s): {', '.join(missing)}")

    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    bounds = config["bounds"]
    if not isinstance(bounds, (list, tuple)) or len(bounds) != 2:
        raise ValueError("bounds must contain [lower, upper]")
    lower, upper = map(float, bounds)

    values = (wavelength, epsilon, substrate_epsilon, initial, lower, upper)
    if not all(math.isfinite(value) for value in values):
        raise ValueError("all numerical inputs must be finite")
    if wavelength <= 0 or epsilon <= 0 or substrate_epsilon <= 0:
        raise ValueError("wavelength and lossless permittivities must be positive")
    if lower < 0 or not lower < upper:
        raise ValueError("bounds must satisfy 0 <= lower < upper")
    if not lower <= initial <= upper:
        raise ValueError("initial_thickness must lie within bounds")
    return wavelength, epsilon, substrate_epsilon, initial, lower, upper


def _objective(
    wavelength: float, epsilon: float, substrate_epsilon: float
):
    """Build an Advect value-and-gradient function for R(d)."""
    k0 = 2 * np.pi / wavelength
    media = (Material(1.0), Material(epsilon), Material(substrate_epsilon))
    # There are two helicity wavenumbers per medium. They coincide here because
    # all media are achiral, but retaining both is required by the native API.
    ks = np.stack([medium.ks(k0) for medium in media])
    impedances = np.asarray([medium.impedance for medium in media])
    transverse_wavevectors = np.zeros((1, 2), dtype=float)

    def reflected_power(thickness: np.ndarray):
        smatrix = tr_ad.layer_stack(
            ks,
            impedances,
            transverse_wavevectors,
            thickness,
            fixed_q=True,
        )
        # Axes are channel, outgoing direction, incoming direction, outgoing
        # polarization, incoming polarization.  Incidence is up (0) from the
        # negative side and reflection is down (1).  Sum both output helicities.
        reflected = smatrix[0, 1, 0, :, 0]
        return ad.numpy.sum(ad.numpy.real(reflected * ad.numpy.conj(reflected)))

    transformed = ad.value_and_grad(reflected_power)

    def evaluate(thickness: float) -> tuple[float, float]:
        value, gradient = transformed(np.asarray([thickness], dtype=float))
        return float(value), float(np.asarray(gradient)[0])

    return evaluate


def _minimize(
    evaluate, initial: float, lower: float, upper: float
) -> tuple[float, float, float, list[float]]:
    """Projected Armijo gradient descent in a dimensionless bound coordinate."""
    span = upper - lower
    x = (initial - lower) / span
    loss, gradient = evaluate(initial)
    history = [loss]
    best = (loss, x, gradient)

    # Scaling to x in [0, 1] makes the line-search behavior independent of the
    # micrometer scale selected in a particular input.
    for _ in range(200):
        scaled_gradient = span * gradient
        projected_gradient = scaled_gradient
        if (x <= 0 and scaled_gradient > 0) or (x >= 1 and scaled_gradient < 0):
            projected_gradient = 0.0
        if abs(projected_gradient) <= 1e-12:
            break

        step = 1.0
        accepted = False
        for _ in range(60):
            candidate_x = min(1.0, max(0.0, x - step * scaled_gradient))
            if candidate_x == x:
                step *= 0.5
                continue
            candidate_d = lower + span * candidate_x
            candidate_loss, candidate_gradient = evaluate(candidate_d)
            displacement = candidate_x - x
            # Armijo sufficient decrease, expressed using dR/dx.
            if candidate_loss <= loss + 1e-4 * scaled_gradient * displacement:
                x, loss, gradient = candidate_x, candidate_loss, candidate_gradient
                history.append(loss)
                if loss < best[0]:
                    best = (loss, x, gradient)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    loss, x, gradient = best
    thickness = lower + span * x
    # Re-evaluate so the reported loss and derivative come from one fresh native
    # forward/pullback pair at the exact returned thickness.
    loss, gradient = evaluate(thickness)
    if history[-1] != loss:
        history.append(loss)
    return thickness, loss, gradient, history


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Optimize coating thickness and return JSON-serializable scalar results."""
    wavelength, epsilon, substrate_epsilon, initial, lower, upper = _validate(config)
    evaluate = _objective(wavelength, epsilon, substrate_epsilon)
    initial_reflection, _ = evaluate(initial)
    thickness, reflection, gradient, history = _minimize(
        evaluate, initial, lower, upper
    )
    return {
        "thickness": thickness,
        "reflection": reflection,
        "initial_reflection": initial_reflection,
        "gradient": gradient,
        "loss_history": history,
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise ValueError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
