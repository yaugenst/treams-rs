# Dimer separation sensitivity

`solution.py` uses the public `treams_rs.advect` interface. It constructs the
single-sphere helicity T-matrix, translates a positive-helicity plane wave to
both particle centers, solves the coupled two-particle scattering problem, and
evaluates the outgoing electric field at the requested point. The incident
electric field is then added before computing
`sum(abs(E_total)**2)`.

## Units and conventions

- All input lengths are in micrometers, so `k0 = 2*pi/wavelength` is in
  inverse micrometers and the returned separation gradient is per micrometer.
- `epsilon` is interpreted as `epsilon[0] + 1j*epsilon[1]`. Relative
  permeability is one, chirality is zero, and the embedding medium is vacuum.
- Sphere centers are `(-separation/2, 0, 0)` and
  `(separation/2, 0, 0)`. The observation point and all other parameters are
  held fixed when differentiating.
- Illumination propagates along positive z and uses the package's named
  `positive_helicity` state. Its electric-field normalization gives
  `sum(abs(E_incident)**2) = 1`, so `value` is in squared incident-field
  amplitude units.
- Multipoles through the supplied `lmax` are retained. Multiple scattering is
  included by the cluster illumination solve, rather than by a single-scatter
  approximation.

## Derivative and checks

Advect's reverse-mode transform is applied to one scalar separation. Both
particle positions are constructed from that scalar, and the native treams-rs
pullbacks propagate through translations, the interaction solve, and field
evaluation. No finite difference contributes to the returned gradient.

For the example, the executed CLI produced:

```json
{"value": 1.1855506354526988, "gradient": -0.40372542061712435}
```

As an independent diagnostic, a centered finite difference with a separation
step of `1e-5` micrometers gave `-0.4037254207278628` per micrometer, an
absolute difference of about `1.11e-10` from the analytic result. The incident
field intensity was also checked to be one at the sample point.
