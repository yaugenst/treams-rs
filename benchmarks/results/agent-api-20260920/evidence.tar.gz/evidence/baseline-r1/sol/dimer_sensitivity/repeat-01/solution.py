"""Electric-field intensity and separation sensitivity for a sphere dimer."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import numpy as np
import treams_rs.advect as treams


def run(config: dict[str, Any]) -> dict[str, float]:
    """Return |E_total|^2 and its analytic separation derivative.

    Lengths in ``config`` are interpreted as micrometers.  The incident plane
    wave has unit electric-field intensity and positive helicity.
    """
    radius = float(config["radius"])
    eps_parts = config["epsilon"]
    epsilon = complex(float(eps_parts[0]), float(eps_parts[1]))
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=np.float64)

    if radius <= 0 or wavelength <= 0 or separation <= 0:
        raise ValueError("radius, wavelength, and separation must be positive")
    if separation <= 2 * radius:
        raise ValueError("the two spheres must not overlap")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")
    if point.shape != (3,) or not np.all(np.isfinite(point)):
        raise ValueError("point must contain three finite Cartesian coordinates")

    k0 = 2 * math.pi / wavelength
    material = treams.Material(epsilon=epsilon)
    particle = treams.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=material,
    )
    incident = treams.plane_wave(
        [0.0, 0.0, 1.0],
        "positive_helicity",
        k0=k0,
    )

    def objective(distance: Any) -> Any:
        # Build both centers from the differentiated scalar.  The zeros are
        # arrays so that stack remains in Advect's traceable NumPy namespace.
        zero = ad.numpy.asarray(0.0)
        positions = ad.numpy.stack(
            (
                ad.numpy.stack((-0.5 * distance, zero, zero)),
                ad.numpy.stack((0.5 * distance, zero, zero)),
            )
        )
        scattered = treams.Cluster(
            (particle, particle), positions=positions
        ).scatter(incident)
        electric = scattered.efield(point) + incident.efield(point)
        return ad.numpy.sum(ad.numpy.real(electric * ad.numpy.conj(electric)))

    value, gradient = ad.value_and_grad(objective)(
        np.asarray(separation, dtype=np.float64)
    )
    return {"value": float(value), "gradient": float(gradient)}


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
