"""Electromagnetic response of a two-sphere cluster using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import numpy as np
import treams_rs as treams


def _finite_positive(name: str, value: Any) -> float:
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")
    return value


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Solve the specified sphere dimer and return fields and cross sections.

    Length inputs are interpreted in micrometers.  Field points must be in the
    exterior of both spheres, where the outgoing multipole expansion applies.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radii = np.asarray(config["radii"], dtype=float)
    epsilon_parts = np.asarray(config["epsilon"], dtype=float)
    separation = _finite_positive("separation", config["separation"])
    wavelength = _finite_positive("wavelength", config["wavelength"])
    points = np.asarray(config["points"], dtype=float)
    if points.size == 0:
        points = points.reshape(0, 3)

    if radii.shape != (2,) or not np.isfinite(radii).all() or np.any(radii <= 0):
        raise ValueError("radii must contain two finite positive values")
    if (
        epsilon_parts.shape != (2, 2)
        or not np.isfinite(epsilon_parts).all()
    ):
        raise ValueError("epsilon must contain two finite [real, imag] pairs")
    if separation <= float(np.sum(radii)):
        raise ValueError("separation must exceed the sum of the sphere radii")
    if points.ndim != 2 or points.shape[1:] != (3,) or not np.isfinite(points).all():
        raise ValueError("points must be a finite point-by-3 array")
    if isinstance(config["lmax"], bool):
        raise ValueError("lmax must be a positive integer")
    lmax = int(config["lmax"])
    if lmax != config["lmax"] or lmax < 1:
        raise ValueError("lmax must be a positive integer")

    positions = np.array(
        [[-0.5 * separation, 0.0, 0.0], [0.5 * separation, 0.0, 0.0]]
    )
    distances = np.linalg.norm(points[:, None, :] - positions[None, :, :], axis=2)
    if np.any(distances <= radii[None, :]):
        raise ValueError("electric-field sample points must lie outside both spheres")

    k0 = 2.0 * np.pi / wavelength
    epsilons = epsilon_parts[:, 0] + 1j * epsilon_parts[:, 1]
    particles = [
        treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=float(radius),
            material=complex(epsilon),
            medium=1,
            polarization="helicity",
        )
        for radius, epsilon in zip(radii, epsilons, strict=True)
    ]

    incident = treams.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        medium=1,
    )
    coupled = treams.Cluster(particles, positions=positions).solve()
    scattered = coupled.scatter(incident)
    total_field = incident.efield(points) + scattered.efield(points)
    cross_sections = coupled.cross_sections(incident)

    return {
        "total_field_real": total_field.real.tolist(),
        "total_field_imag": total_field.imag.tolist(),
        "scattering": float(cross_sections.scattering),
        "extinction": float(cross_sections.extinction),
        "absorption": float(cross_sections.absorption),
    }


def _main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
