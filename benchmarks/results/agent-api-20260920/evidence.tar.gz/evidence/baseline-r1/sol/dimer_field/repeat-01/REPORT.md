# Dimer-field calculation

`solution.py` uses the public `treams_rs` physical-object API. It constructs one
homogeneous-sphere T-matrix per particle at the requested `lmax`, assembles them
at `(-separation/2, 0, 0)` and `(separation/2, 0, 0)`, and calls
`Cluster.solve()`. Thus the outgoing coefficients and all reported quantities
include the full multiple-scattering solution within that fixed multipole
truncation.

## Units and conventions

- Lengths, positions, radii, separation, and wavelength are in micrometers.
  The vacuum angular wavenumber is `k0 = 2*pi/wavelength` in inverse
  micrometers. Cross sections are consequently in square micrometers.
- Each `[real, imag]` pair is converted to relative complex permittivity.
  Relative permeability is 1, chirality is 0, and the exterior material is
  vacuum.
- Illumination is the package's named `positive_helicity` plane wave traveling
  along `+z`. No manual rescaling is applied. In this normalization its electric
  field at the origin is `(-x - i*y)/sqrt(2)` and its default incident flux for
  cross sections is 0.5.
- Fields are complex Cartesian phasors in `(Ex, Ey, Ez)` order and in the
  package's phase convention. `total_field_real` and `total_field_imag` contain
  the real and imaginary parts of the incident-plus-scattered electric field.
  Sample points are required to lie strictly outside both spheres.

## Checks

The supplied example was executed to create `results.json`. Its energy-accounting
identity closes at returned precision:

`extinction - scattering = 0.0026176027019321826 = absorption`.

Absorption is positive for the passive example. The full solved response and
the package's direct illumination-only cluster solve also agreed in their
outgoing coefficients to a maximum absolute difference of
`4.58e-16`. Output field arrays were checked to be point-by-3, and a second
non-example configuration was run to check that inputs are handled dynamically.
