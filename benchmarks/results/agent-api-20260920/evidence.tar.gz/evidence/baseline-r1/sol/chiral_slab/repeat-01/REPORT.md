# Chiral slab calculation

`solution.py` uses the public `treams_rs` plane-wave scattering API. For each
wavelength it constructs the two normal-incidence helicity ports, a homogeneous
slab S-matrix, and a named positive- or negative-helicity plane wave incident in
the +z direction from the negative-z vacuum half-space. The returned quantities
come from `SMatrix.power`, so they are flux-normalized power fractions rather
than squared amplitudes computed by the solution itself.

All lengths (slab thickness and vacuum wavelength) are in micrometers, hence
`k0 = 2*pi/wavelength` is in inverse micrometers. The input `[epsilon_real,
epsilon_imag]` defines the complex relative permittivity; relative permeability
is one. `kappa` is passed unchanged as the dimensionless reciprocal material
chirality used by treams-rs. Both exterior media are vacuum. The polarization
columns are ordered positive helicity, then negative helicity.

Checks performed on the example output:

- every output array has shape `(3, 2)` and contains finite real values;
- for every wavelength and helicity, `T + R + A` equals one to floating-point
  precision;
- all example power fractions lie between zero and one;
- the two helicities have equal powers here (to about `1e-15`). This is expected:
  real kappa changes the two propagation phases, while this material's loss and
  wave impedance are helicity-independent. The complex transmission amplitudes
  are nevertheless different.
