"""Normal-incidence power balance of a homogeneous reciprocal chiral slab."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import numpy as np
import treams_rs as treams


def _finite_real(value: Any, name: str) -> float:
    """Convert a scalar input while rejecting booleans and non-finite values."""
    if isinstance(value, bool):
        raise TypeError(f"{name} must be a real number")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must be a real number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, list[list[float]]]:
    """Return slab power fractions for positive and negative incident helicity.

    Length inputs are in micrometers.  The two entries of ``epsilon`` are its
    real and imaginary parts; ``kappa`` is the treams-rs material chirality.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    missing = {"thickness", "epsilon", "kappa", "wavelengths"} - config.keys()
    if missing:
        raise ValueError(f"missing config keys: {', '.join(sorted(missing))}")

    thickness = _finite_real(config["thickness"], "thickness")
    if thickness < 0:
        raise ValueError("thickness must be nonnegative")

    epsilon_parts = config["epsilon"]
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _finite_real(epsilon_parts[0], "epsilon[0]"),
        _finite_real(epsilon_parts[1], "epsilon[1]"),
    )
    kappa = _finite_real(config["kappa"], "kappa")

    raw_wavelengths = config["wavelengths"]
    if not isinstance(raw_wavelengths, (list, tuple)):
        raise TypeError("wavelengths must be a list")
    wavelengths = [
        _finite_real(value, f"wavelengths[{index}]")
        for index, value in enumerate(raw_wavelengths)
    ]
    if any(value <= 0 for value in wavelengths):
        raise ValueError("wavelengths must be positive")

    # At normal incidence only the two helicity channels at kx = ky = 0 occur.
    basis = treams.PlaneWavePorts.default([0.0, 0.0], alignment="xy")
    slab_material = treams.Material(epsilon, 1.0, kappa)
    helicities = ("positive_helicity", "negative_helicity")

    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        smatrix = treams.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=slab_material,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )

        row_t: list[float] = []
        row_r: list[float] = []
        row_a: list[float] = []
        for helicity in helicities:
            incident = treams.plane_wave(
                direction=[0.0, 0.0, 1.0],
                polarization=helicity,
                k0=k0,
                medium=1.0,
            )
            power = smatrix.power(incident, side="negative")
            row_t.append(float(power.transmission))
            row_r.append(float(power.reflection))
            row_a.append(float(power.absorption))

        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
