"""Cross-section spectrum of a homogeneous dielectric sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as treams


def _finite_number(value: Any, name: str) -> float:
    """Convert a JSON number to a finite float, rejecting booleans."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number")
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must be a number") from error
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Calculate cross sections for the wavelengths in ``config``.

    Lengths are in micrometers, so the returned cross sections are in square
    micrometers.  ``epsilon`` is interpreted as ``[real, imaginary]``.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _finite_number(config.get("radius"), "radius")
    if radius <= 0:
        raise ValueError("radius must be positive")

    epsilon_parts = config.get("epsilon")
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imaginary]")
    epsilon = complex(
        _finite_number(epsilon_parts[0], "epsilon[0]"),
        _finite_number(epsilon_parts[1], "epsilon[1]"),
    )

    lmax_value = config.get("lmax")
    if isinstance(lmax_value, bool) or not isinstance(lmax_value, int):
        raise ValueError("lmax must be an integer")
    if lmax_value < 1:
        raise ValueError("lmax must be at least 1")

    wavelength_values = config.get("wavelengths")
    if not isinstance(wavelength_values, (list, tuple)) or not wavelength_values:
        raise ValueError("wavelengths must be a nonempty list")
    wavelengths = [
        _finite_number(value, f"wavelengths[{index}]")
        for index, value in enumerate(wavelength_values)
    ]
    if any(value <= 0 for value in wavelengths):
        raise ValueError("all wavelengths must be positive")

    result: dict[str, list[float]] = {
        "scattering": [],
        "extinction": [],
        "absorption": [],
        "efficiency": [],
    }
    geometric_area = math.pi * radius * radius
    material = treams.Material(epsilon=epsilon)

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        tmatrix = treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax_value,
            radius=radius,
            material=material,
            medium=1,
            polarization="helicity",
        )
        incident = treams.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        cross_sections = tmatrix.cross_sections(incident)
        scattering = float(cross_sections.scattering)
        extinction = float(cross_sections.extinction)
        absorption = float(cross_sections.absorption)

        result["scattering"].append(scattering)
        result["extinction"].append(extinction)
        result["absorption"].append(absorption)
        result["efficiency"].append(scattering / geometric_area)

    return result


def main() -> None:
    config = json.load(sys.stdin)
    output = run(config)
    json.dump(output, sys.stdout, allow_nan=False, separators=(",", ":"))
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
