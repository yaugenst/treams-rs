# Homogeneous dielectric sphere spectrum

`solution.py` uses the public `treams_rs.sphere_tmatrix` implementation at the
requested `lmax`, then illuminates it with a public `plane_wave` directed along
+z and explicitly named `positive_helicity`. The relative material parameters
are epsilon = `epsilon[0] + i*epsilon[1]`, mu = 1, and chirality = 0; the
embedding medium is vacuum.

All input lengths are micrometers. The vacuum angular wavenumber is therefore
`k0 = 2*pi/wavelength` in inverse micrometers. Scattering, extinction, and
absorption are returned in square micrometers. Absorption follows the package's
convention `C_abs = C_ext - C_sca`. Efficiency is dimensionless and is
`C_sca/(pi*radius**2)`. Every output list preserves the input wavelength order.

Checks on the example:

- all outputs are finite, and positive loss gives nonnegative absorption;
- `extinction = scattering + absorption` to floating-point precision;
- the positive-helicity plane-wave cross sections agree with the package's
  rotationally and polarization-averaged sphere cross sections to about
  1e-15 relative error, as expected for an isotropic achiral sphere;
- the T-matrix has 48 channels, matching `2*lmax*(lmax+2)` for `lmax = 4`.
