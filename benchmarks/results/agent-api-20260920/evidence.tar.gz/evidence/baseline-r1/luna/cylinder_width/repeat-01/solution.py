"""Infinite-cylinder scattering widths using the public treams-rs API."""

from __future__ import annotations

import json
import sys
from typing import Any

import treams_rs as treams


def _complex_pair(value: Any, name: str) -> complex:
    if isinstance(value, (list, tuple)) and len(value) == 2:
        return complex(float(value[0]), float(value[1]))
    return complex(value)


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return cylinder scattering, extinction, and absorption widths.

    The input lengths are in micrometers.  The optional ``mu`` and
    ``chirality`` values follow the same real/imaginary pair convention as
    ``epsilon`` (and default to 1 and 0, respectively).
    """
    radius = float(config["radius"])
    mmax = int(config["mmax"])
    wavelengths = [float(value) for value in config["wavelengths"]]
    epsilon = _complex_pair(config["epsilon"], "epsilon")
    mu = _complex_pair(config.get("mu", 1), "mu")
    chirality = _complex_pair(config.get("chirality", 0), "chirality")

    if radius <= 0 or mmax < 0 or not wavelengths or any(w <= 0 for w in wavelengths):
        raise ValueError("radius, wavelengths, and mmax must be physically valid")

    material = treams.Material((epsilon, mu, chirality))
    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * 3.141592653589793 / wavelength
        cylinder = treams.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=material,
            medium=1,
            polarization="helicity",
        )
        illumination = treams.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        widths = cylinder.cross_widths(illumination)
        scattering.append(float(widths.scattering))
        extinction.append(float(widths.extinction))
        absorption.append(float(widths.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
