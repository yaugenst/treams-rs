# Infinite-cylinder widths

`solution.py` constructs a homogeneous infinite cylinder with the public
`treams_rs.cylinder_tmatrix` API and evaluates it with a +x plane wave in the
positive-helicity convention.  The supplied epsilon pair is interpreted as
`real + i imag`; all lengths are micrometers, so the returned widths are in
micrometers.  The cylinder cross-width normalization is used (not sphere-area
normalization), with `kz=0` and azimuthal orders from `-mmax` through `mmax`.

For each wavelength, scattering and extinction come directly from
`cross_widths`; absorption is the library's extinction-minus-scattering
quantity.  The example was executed through the CLI and checked for finite
values and nonnegative absorption.
