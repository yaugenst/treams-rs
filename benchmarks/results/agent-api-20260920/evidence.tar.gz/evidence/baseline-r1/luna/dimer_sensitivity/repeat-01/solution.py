"""Dimer near-field value and separation sensitivity using treams-rs."""

import json
import sys

import numpy as np
import advect as ad
import treams_rs as tr
import treams_rs.advect as tr_ad


def run(config):
    """Return the total electric-field intensity and its analytic separation derivative."""
    radius = float(config["radius"])
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(float(eps_re), float(eps_im))
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=float).reshape(1, 3)
    k0 = 2.0 * np.pi / wavelength

    # The explicit global basis matches the particle-labelled ordering used by
    # the native interacting-cluster operation.
    modes = [
        (particle, ell, m, pol)
        for particle in range(2)
        for ell in range(1, lmax + 1)
        for m in range(-ell, ell + 1)
        for pol in (1, 0)
    ]
    basis = tr.SphericalBasis(modes, positions=np.zeros((2, 3)))

    # The incident field is independent of separation; its value is included
    # explicitly because the requested observable is the total field.
    incident_wave = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
    )
    incident_field = incident_wave.efield(point)
    radii = np.asarray([radius, radius], dtype=float)
    epsilons = np.asarray([epsilon, epsilon], dtype=np.complex128)
    vectors = np.asarray([[0.0, 0.0, k0]], dtype=float)
    polarizations = np.asarray([1], dtype=np.int64)
    ks = np.asarray([k0, k0], dtype=np.complex128)

    def observable(sep):
        zero = ad.numpy.asarray(0.0)
        positions = ad.numpy.stack(
            (
                ad.numpy.stack((-sep / 2.0, zero, zero)),
                ad.numpy.stack((sep / 2.0, zero, zero)),
            )
        )

        # Both cluster assembly/interaction and all geometry translations are
        # native treams-rs operations with Advect pullbacks.
        interacting_tmatrix = tr_ad.cluster(
            lmax, k0, radii, epsilons, positions
        )
        regular_incident = tr_ad.plane_expansion(
            positions,
            vectors,
            destination=basis,
            polarizations=polarizations,
            poltype="helicity",
            fixed_vectors=True,
        )[:, 0]
        outgoing = ad.numpy.matmul(interacting_tmatrix, regular_incident)
        scattered_field = tr_ad.field(
            outgoing,
            point,
            positions,
            ks,
            basis=basis,
            poltype="helicity",
            singular=True,
        )
        total = scattered_field + ad.numpy.asarray(incident_field)
        return ad.numpy.real(ad.numpy.sum(ad.numpy.conj(total) * total))

    value, gradient = ad.value_and_grad(observable)(separation)
    return {"value": float(value), "gradient": float(gradient)}


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
