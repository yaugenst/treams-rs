# Dimer sensitivity report

`solution.py` models two identical homogeneous, nonmagnetic spheres centered at
`(-separation/2, 0, 0)` and `(separation/2, 0, 0)`. Lengths are micrometers;
the vacuum wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers.
The supplied complex relative permittivity is used as `epsilon = real + i*imag`,
with relative permeability one and chirality zero.

The incident wave travels along +z with unit positive-helicity amplitude. The
observable is the sum of the squared magnitudes of the three complex Cartesian
components of the total electric field at the specified point, including the
incident field. The native treams-rs interacting cluster includes multiple
scattering. The separation gradient includes motion of both sphere origins and
is obtained through treams-rs native pullbacks via its Advect adapter.

Checks performed: the example was executed to create `results.json`; the
analytic gradient also agreed with a centered finite-difference diagnostic
(used only as validation, not to compute the reported derivative).
