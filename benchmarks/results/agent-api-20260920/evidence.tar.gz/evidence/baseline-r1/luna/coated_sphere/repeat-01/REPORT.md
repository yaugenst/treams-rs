# Layered-sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` routine,
with one material for each finite layer and no added exterior layer. The
permittivity pairs are interpreted as `real + i imag`; relative permeability
is one and chirality is zero. The exterior permittivity is supplied separately.

For wavelength `lambda`, the free-space wavenumber passed to treams-rs is
`k0 = 2*pi/lambda`. Thus all lengths are in micrometers and the returned
cross sections are in square micrometers. The built-in
`average_cross_sections` property supplies rotationally and polarization-
averaged scattering and extinction. Absorption is checked/formed as
`extinction - scattering`.

Checks performed by the wrapper include positive, strictly increasing radii,
matching layer and radius counts, positive wavelengths, and positive `lmax`.
