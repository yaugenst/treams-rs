"""Rotationally averaged cross sections for a concentric multilayer sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs


def _complex_permittivity(value: Any) -> complex:
    """Convert a scalar or [real, imaginary] JSON value to a complex number."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ValueError("a complex permittivity pair must have length 2")
        return complex(float(value[0]), float(value[1]))
    return complex(value)


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Compute wavelength-ordered averaged scattering, extinction, and absorption.

    Lengths are in the input length unit (micrometers here), so returned
    cross sections are in that unit squared (micrometers squared here).
    """
    radii = [float(r) for r in config["radii"]]
    if not radii or any(r <= 0 for r in radii) or any(a >= b for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be positive and strictly increasing")

    layer_values = config["epsilon_layers"]
    if len(layer_values) != len(radii):
        raise ValueError("epsilon_layers must contain one entry per radius")
    materials = [treams_rs.Material(_complex_permittivity(eps)) for eps in layer_values]
    medium = treams_rs.Material(_complex_permittivity(config.get("epsilon_medium", 1)))
    wavelengths = [float(w) for w in config["wavelengths"]]
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")
    lmax = int(config["lmax"])
    if lmax < 1:
        raise ValueError("lmax must be positive")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        tmatrix = treams_rs.multilayer_sphere_tmatrix(
            k0=2 * math.pi / wavelength,
            lmax=lmax,
            radii=radii,
            materials=materials,
            medium=medium,
        )
        averaged = tmatrix.average_cross_sections
        sca = float(averaged.scattering)
        ext = float(averaged.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(ext - sca)
    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
