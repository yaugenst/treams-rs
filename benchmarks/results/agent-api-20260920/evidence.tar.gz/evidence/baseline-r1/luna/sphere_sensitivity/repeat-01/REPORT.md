# Sphere scattering sensitivity

`solution.py` uses the public `treams_rs.advect` adapter and its native
pullbacks.  The sphere is in vacuum, with relative permeability 1 and
chirality 0.  The material permittivity is
`epsilon_real + i*epsilon_imag`; the positive-helicity incident plane wave
travels along +z.  All lengths are in micrometers, so `k0 = 2*pi/wavelength`
is in inverse micrometers and the cross section is in square micrometers.

The reported value is
`Q = scattering_cross_section / (pi*radius^2)`.  Advect differentiates this
complete expression, including the radius-dependent normalization.  The
returned gradient is ordered `[dQ/dradius, dQ/depsilon_real]`; wavelength,
epsilon_imag, and `lmax` are held fixed.

Checks performed:

- Ran the supplied example through the CLI and saved `results.json`.
- Evaluated the same expression with `ad.value_and_grad`; the result was
  `Q = 0.46337644643427434` and gradient
  `[18.65367030479629, 0.1997255464561844]`.
- The calculation uses treams-rs numerical scattering and native analytic
  pullbacks; no finite-difference derivative is used.
