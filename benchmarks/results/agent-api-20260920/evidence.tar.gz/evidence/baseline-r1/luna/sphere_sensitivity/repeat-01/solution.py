"""Differentiable scattering efficiency of a lossy homogeneous sphere."""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import advect as ad
import treams_rs.advect as tr


def _efficiency(x: Any, *, epsilon_imag: float, wavelength: float, lmax: int) -> Any:
    """Return Q for x=(radius, real(relative permittivity))."""
    radius = x[0]
    epsilon_real = x[1]
    k0 = 2.0 * np.pi / wavelength

    matrix = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=tr.Material(epsilon_real + 1j * epsilon_imag),
        polarization="helicity",
    )
    # In treams-rs' helicity convention, index 1 is positive helicity.
    incident = tr.plane_wave((0.0, 0.0, 1.0), 1, k0=k0)
    scattering = matrix.cross_sections(incident).scattering
    return scattering / (np.pi * radius * radius)


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Calculate Q and its analytic gradient in (radius, epsilon_real)."""
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    value, gradient = ad.value_and_grad(
        lambda x: _efficiency(
            x,
            epsilon_imag=epsilon_imag,
            wavelength=wavelength,
            lmax=lmax,
        ),
    )(np.asarray([radius, epsilon_real], dtype=np.float64))
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
