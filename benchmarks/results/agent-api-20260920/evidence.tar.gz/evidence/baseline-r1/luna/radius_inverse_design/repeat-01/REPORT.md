# Radius inverse design

`solution.py` uses `treams_rs.advect.sphere_tmatrix` and its native
cross-section calculation.  The reported efficiency is

`Q_sca = C_sca / (pi r^2)`,

where all lengths (radius and wavelengths) are in micrometres.  Epsilon is a
relative, real permittivity; the exterior has relative permittivity and
permeability one, and chirality is zero.  The calculation uses the package's
helicity convention and one unit-amplitude plane wave; isotropy makes either
helicity equivalent.

The objective is the mean squared relative error against the supplied
measurements.  `advect.value_and_grad` differentiates the complete native
T-matrix/cross-section computation with respect to radius.  A projected,
gradient-bracketed root solve keeps the radius within the requested bounds;
every objective and gradient used by the solve comes from Advect's native
pullback.

Checks performed: the example was executed through the CLI, the resulting
JSON was saved in `results.json`, the fitted values reproduce all three target
efficiencies, and the final loss is below `1e-7`.
