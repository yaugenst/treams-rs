"""Radius inversion for a homogeneous dielectric sphere."""

import json
import sys

import advect as ad
import numpy as np
import treams_rs.advect as tr


def _efficiencies(radius, epsilon, lmax, wavelengths):
    """Scattering efficiencies, using the native T-matrix cross section."""
    values = []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        tmatrix = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon, medium=1.0
        )
        # One unit-amplitude helicity plane wave is sufficient: the sphere is
        # isotropic, so both helicities have the same scattering cross section.
        incident = tr.plane_wave([0.0, 0.0, 1.0], [1.0, 0.0], k0=k0)
        scattering = tmatrix.cross_sections(incident).scattering
        values.append(scattering / (np.pi * radius * radius))
    return values


def _fit(config):
    epsilon = config["epsilon"]
    lmax = int(config["lmax"])
    wavelengths = tuple(float(x) for x in config["wavelengths"])
    targets = np.asarray(config["target_efficiencies"], dtype=float)
    lower, upper = (float(x) for x in config["bounds"])
    start = min(upper, max(lower, float(config["initial_radius"])))

    def objective(radius):
        efficiencies = _efficiencies(radius, epsilon, lmax, wavelengths)
        residuals = [(q - target) / target for q, target in zip(efficiencies, targets)]
        return sum(x * x for x in residuals) / len(residuals)

    value_grad = ad.value_and_grad(objective)
    initial_loss = float(objective(start))
    radius = start
    loss, gradient = value_grad(radius)
    loss = float(loss)
    gradient = float(gradient)
    history = [loss]

    # Safeguarded root finding on the analytic objective gradient.  In this
    # size range the one-dimensional sphere fit is unimodal; the endpoint
    # checks also handle a constrained optimum at either bound.
    lo, hi = lower, upper
    lo_loss, lo_grad = value_grad(lo)
    hi_loss, hi_grad = value_grad(hi)
    lo_loss, lo_grad = float(lo_loss), float(lo_grad)
    hi_loss, hi_grad = float(hi_loss), float(hi_grad)
    history.extend([lo_loss, hi_loss])
    if lo_grad >= 0.0:
        radius, loss, gradient = lo, lo_loss, lo_grad
    elif hi_grad <= 0.0:
        radius, loss, gradient = hi, hi_loss, hi_grad
    else:
        for _ in range(80):
            mid = 0.5 * (lo + hi)
            mid_loss, mid_grad = value_grad(mid)
            mid_loss, mid_grad = float(mid_loss), float(mid_grad)
            history.append(mid_loss)
            radius, loss, gradient = mid, mid_loss, mid_grad
            if abs(mid_grad) < 1.0e-12 or hi - lo < 1.0e-13:
                break
            if mid_grad > 0.0:
                hi = mid
            else:
                lo = mid

    # A final native evaluation supplies the reported derivative and values.
    loss, gradient = value_grad(radius)
    fitted = _efficiencies(radius, epsilon, lmax, wavelengths)
    return {
        "radius": float(radius),
        "loss": float(loss),
        "initial_loss": float(initial_loss),
        "gradient": float(gradient),
        "fitted_efficiencies": [float(x) for x in fitted],
        "loss_history": [float(x) for x in history],
    }


def run(config):
    """Fit and return JSON-compatible sphere-radius inversion results."""
    return _fit(config)


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
