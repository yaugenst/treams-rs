# Report

`solution.py` uses micrometers for all lengths.  Thus `k0 = 2*pi/wavelength`
is in inverse micrometers; epsilon and the implicit mu=1 and chirality=0 are
relative, dimensionless quantities.

The network is ordered along +z as slab, vacuum propagation gap, and periodic
sphere array.  The exterior media are vacuum.  Illumination is the positive-
helicity plane wave travelling from the negative-z side.  The periodic solve
uses Bloch vector `[0, 0]`, a square lattice of the requested period, and the
requested spherical `lmax`.  The output port basis retains only the zeroth
diffraction order and both helicities.

The reported absorption is `1 - transmission - reflection`.  For the example,
each row conserves power to about `1e-15`; the near-zero signed absorption
values are floating-point roundoff because both materials are real and lossless.
