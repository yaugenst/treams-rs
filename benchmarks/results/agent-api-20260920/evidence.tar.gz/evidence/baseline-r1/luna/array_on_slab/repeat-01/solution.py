"""Periodic sphere array above a dielectric slab.

The numerical work is deliberately kept in treams-rs: the sphere response,
periodic lattice interaction, plane-wave conversion, and S-matrix cascade are
all native operations.
"""

import json
import math
import sys

import treams_rs as tr


def run(config):
    """Return power fractions for the requested wavelengths."""
    wavelengths = sorted(float(value) for value in config["wavelengths"])
    radius = float(config["radius"])
    sphere_epsilon = float(config["sphere_epsilon"])
    period = float(config["period"])
    gap = float(config["gap"])
    slab_thickness = float(config["slab_thickness"])
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])

    if any(value <= 0.0 for value in (radius, period, slab_thickness)):
        raise ValueError("radius, period, and slab_thickness must be positive")
    if gap < 0.0 or lmax < 1 or not wavelengths or any(w <= 0 for w in wavelengths):
        raise ValueError("invalid gap, lmax, or wavelength")

    # The retained exterior diffraction basis is the zeroth order with both
    # helicities.  The labels 1 and 0 are positive and negative helicity.
    ports = tr.PlaneWavePorts(((0.0, 0.0, 1), (0.0, 0.0, 0)))
    lattice = ((period, 0.0), (0.0, period))
    results = []

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon
        )
        periodic = tr.solve_periodic(
            sphere, lattice=lattice, kpar=(0.0, 0.0)
        )
        array = periodic.to_smatrix(ports)

        slab = tr.slab(
            basis=ports,
            k0=k0,
            thickness=slab_thickness,
            material=slab_epsilon,
        )
        vacuum_gap = tr.SMatrix.propagation(
            (0.0, 0.0, gap), basis=ports, k0=k0
        )
        network = tr.stack((slab, vacuum_gap, array))

        incident = tr.plane_wave(
            direction=(0.0, 0.0, 1.0),
            polarization="positive_helicity",
            k0=k0,
        )
        power = network.power(incident, side="negative")
        transmission = float(power.transmission)
        reflection = float(power.reflection)
        absorption = 1.0 - transmission - reflection
        results.append((wavelength, transmission, reflection, absorption))

    return {
        "wavelengths": [row[0] for row in results],
        "transmission": [row[1] for row in results],
        "reflection": [row[2] for row in results],
        "absorption": [row[3] for row in results],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
