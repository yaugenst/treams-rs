# Antireflection design report

`solution.py` models one homogeneous, lossless coating between vacuum on the
negative side and the supplied substrate on the positive side. Lengths are in
micrometers, so the vacuum wavenumber is `k0 = 2*pi/wavelength` in inverse
micrometers. Epsilon is relative permittivity; the coating and substrate use
`mu=1` and `chirality=0`. The plane normal is +z, and illumination travels
from the negative (vacuum) side toward +z.

The normal-incidence treams-rs plane-port slab is evaluated with unit incident
amplitude. Its reflected power is the loss function. Advect's native
reverse-mode pullback supplies the analytic derivative with respect to layer
thickness. A bounded Armijo gradient descent starts at the requested initial
thickness and records every accepted loss.

Checks performed: the thickness remains inside the requested bounds; the
loss history is monotonically decreasing; the final reported gradient is
recomputed by the native pullback; and the final reflection is below `1e-7`.
