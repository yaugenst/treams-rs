"""Gradient-based single-layer antireflection design using treams-rs."""

from __future__ import annotations

import json
import sys
from typing import Any

import advect as ad
import numpy as np
import treams_rs.advect as trs
from treams_rs import PlaneWavePorts


def _validate_config(
    config: dict[str, Any],
) -> tuple[float, float, float, float, tuple[float, float]]:
    required = (
        "wavelength",
        "epsilon",
        "substrate_epsilon",
        "initial_thickness",
        "bounds",
    )
    if not isinstance(config, dict) or any(key not in config for key in required):
        raise ValueError("config must contain wavelength, epsilon, substrate_epsilon, initial_thickness, bounds")
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    bounds = config["bounds"]
    if len(bounds) != 2:
        raise ValueError("bounds must contain [lower, upper]")
    lower, upper = map(float, bounds)
    if not (wavelength > 0 and epsilon > 0 and substrate_epsilon > 0):
        raise ValueError("wavelength and permittivities must be positive")
    if not (0 < lower <= initial <= upper):
        raise ValueError("initial_thickness must lie in positive bounds")
    return wavelength, epsilon, substrate_epsilon, initial, (lower, upper)


def run(config: dict[str, Any]) -> dict[str, Any]:
    wavelength, epsilon, substrate_epsilon, initial, (lower, upper) = _validate_config(config)
    k0 = 2.0 * np.pi / wavelength

    # At normal incidence the two polarization ports are equivalent.  The
    # first port is used as the unit-amplitude incident wave.
    basis = PlaneWavePorts.default([0.0, 0.0])
    incident = np.array([1.0 + 0.0j, 0.0 + 0.0j])

    def reflection(thickness: Any) -> Any:
        scattering = trs.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        return scattering.power(incident, side="negative").reflection

    # value_and_grad differentiates through the native treams-rs slab kernel;
    # the returned gradient is therefore an analytic native pullback.
    value_and_grad = ad.value_and_grad(reflection)
    x = float(initial)
    initial_value, _ = value_and_grad(np.array(x))
    initial_reflection = float(initial_value)
    loss_history = [initial_reflection]

    # Armijo backtracking gives a bounded, monotonic gradient descent.  The
    # line search evaluates the scattering loss only; all optimization
    # directions come from the analytic pullback above.
    for _ in range(1000):
        value, gradient = value_and_grad(np.array(x))
        loss = float(value)
        grad = float(gradient)
        if loss < 1.0e-10:
            break
        direction = -grad
        if abs(direction) < 1.0e-14:
            break
        step = min(upper - lower, 0.25 * (upper - lower) / abs(direction))
        accepted = False
        for _ in range(60):
            candidate = min(upper, max(lower, x + step * direction))
            candidate_loss = float(reflection(np.array(candidate)))
            displacement = abs(candidate - x)
            if candidate_loss < loss and displacement > 0.0:
                x = candidate
                loss_history.append(candidate_loss)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    final_value, final_gradient = value_and_grad(np.array(x))
    result = {
        "thickness": float(x),
        "reflection": float(final_value),
        "initial_reflection": initial_reflection,
        "gradient": float(final_gradient),
        "loss_history": [float(item) for item in loss_history],
    }
    if result["reflection"] >= 1.0e-7:
        raise RuntimeError("bounded gradient optimization did not reach reflection < 1e-7")
    return result


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
