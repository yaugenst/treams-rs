"""Two-sphere multiple-scattering calculation using treams-rs."""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as tr


def _material(epsilon: list[float]) -> complex:
    """Convert the JSON [real, imag] convention to a Python material."""
    if len(epsilon) != 2:
        raise ValueError("each epsilon must be [real, imag]")
    return complex(float(epsilon[0]), float(epsilon[1]))


def run(config: dict) -> dict:
    """Return total electric fields and cross sections for the specified dimer."""
    radii = [float(x) for x in config["radii"]]
    epsilons = [_material(x) for x in config["epsilon"]]
    if len(radii) != 2 or len(epsilons) != 2:
        raise ValueError("radii and epsilon must each contain two entries")

    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float)
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("points must be a point-by-3 array")

    k0 = 2.0 * np.pi / wavelength
    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=epsilon,
            medium=1,
            polarization="helicity",
        )
        for radius, epsilon in zip(radii, epsilons)
    ]
    cluster = tr.Cluster(
        particles,
        positions=[[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]],
    )

    # PlaneWave polarization amplitudes are ordered negative, positive helicity.
    incident = tr.PlaneWave(
        [0.0, 0.0, 1.0], [0.0, 1.0], k0=k0, material=1, poltype="helicity"
    )
    solved = cluster.solve()
    scattered = solved.scatter(incident)
    total = incident.efield(points) + scattered.efield(points)
    cross_sections = solved.cross_sections(incident)

    return {
        "total_field_real": np.asarray(total.real).tolist(),
        "total_field_imag": np.asarray(total.imag).tolist(),
        "scattering": float(cross_sections.scattering),
        "extinction": float(cross_sections.extinction),
        "absorption": float(cross_sections.absorption),
    }


if __name__ == "__main__":
    configuration = json.load(sys.stdin)
    json.dump(run(configuration), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
