# Two-sphere dimer calculation

`solution.py` uses the installed treams-rs public API.  Lengths are in micrometers,
so `k0 = 2π / wavelength` is in inverse micrometers and the reported cross
sections are in square micrometers.  Each permittivity `[real, imag]` is passed
as `real + i imag`; the exterior has relative permittivity and permeability one
and zero chirality.

The incident wave propagates along +z and uses the positive helicity channel,
with treams-rs's native incident-field normalization.  The two sphere origins
are `(-separation/2, 0, 0)` and `(separation/2, 0, 0)` in the input order.
`Cluster.solve()` includes the complete coupled multipole interaction at the
requested `lmax`.  The returned field is the native incident field plus the
solved outgoing field.  Cross sections come from the solved response's native
cross-section routine; absorption is extinction minus scattering.

Checks performed: the example was executed through the CLI and `results.json`
was written; both fields have one Cartesian triplet per input point, all output
values are finite JSON numbers, and the example gives positive scattering,
extinction, and absorption.
