# Sphere spectrum report

`solution.py` constructs a homogeneous sphere with `treams_rs.sphere_tmatrix`
at each wavelength and illuminates it with the package's positive-helicity
plane wave travelling in the `+z` direction. The requested `lmax` is passed
directly to the native treams-rs sphere calculation.

All lengths are interpreted in micrometers, so the returned scattering,
extinction, and absorption cross sections are in µm². The material is formed
as `epsilon[0] + i*epsilon[1]` (relative permittivity); the exterior medium is
vacuum with relative permittivity and permeability one. Efficiency is
scattering divided by `pi*radius**2` and is dimensionless.

Checks performed: the CLI was executed on the supplied example; every output
has four entries in the input wavelength order, and absorption is the native
cross-section balance `extinction - scattering`.
