"""Homogeneous dielectric sphere spectrum using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return sphere cross sections for the wavelengths in *config*."""
    radius = float(config["radius"])
    epsilon = config["epsilon"]
    wavelengths = config["wavelengths"]
    lmax = int(config["lmax"])

    if len(epsilon) != 2:
        raise ValueError("epsilon must be [real, imag]")
    if radius <= 0 or lmax < 1:
        raise ValueError("radius must be positive and lmax must be at least 1")

    material = complex(float(epsilon[0]), float(epsilon[1]))
    result = {"scattering": [], "extinction": [], "absorption": [], "efficiency": []}
    area = math.pi * radius * radius

    for wavelength_value in wavelengths:
        wavelength = float(wavelength_value)
        if wavelength <= 0:
            raise ValueError("wavelengths must be positive")
        k0 = 2.0 * math.pi / wavelength
        sphere = treams_rs.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=material,
            medium=1.0,
            polarization="helicity",
        )
        incident = treams_rs.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1.0,
        )
        cross_sections = sphere.cross_sections(incident)
        scattering = float(cross_sections.scattering)
        extinction = float(cross_sections.extinction)
        absorption = float(cross_sections.absorption)
        result["scattering"].append(scattering)
        result["extinction"].append(extinction)
        result["absorption"].append(absorption)
        result["efficiency"].append(scattering / area)

    return result


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
