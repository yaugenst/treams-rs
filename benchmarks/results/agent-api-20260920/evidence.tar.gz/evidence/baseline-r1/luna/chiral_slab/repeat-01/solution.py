"""Power scattering of a reciprocal chiral slab at normal incidence."""

import json
import sys

import treams_rs


def run(config):
    """Return power fractions for positive and negative incident helicity."""
    thickness = float(config["thickness"])
    eps_data = config["epsilon"]
    epsilon = complex(float(eps_data[0]), float(eps_data[1]))
    kappa = complex(float(config.get("kappa", 0.0)))

    # PlaneWavePorts labels helicity 0 as negative and 1 as positive.
    # Put the requested positive, negative order into the basis itself.
    basis = treams_rs.PlaneWavePorts([(0.0, 0.0, 1), (0.0, 0.0, 0)])
    material = treams_rs.Material(epsilon, kappa=kappa)

    transmission = []
    reflection = []
    absorption = []
    for wavelength_value in config["wavelengths"]:
        wavelength = float(wavelength_value)
        smatrix = treams_rs.slab(
            basis=basis,
            k0=2.0 * 3.141592653589793 / wavelength,
            thickness=thickness,
            material=material,
            negative_medium=1,
            positive_medium=1,
            polarization="helicity",
        )
        t_row = []
        r_row = []
        a_row = []
        for channel in range(2):
            incident = [1.0 if i == channel else 0.0 for i in range(2)]
            balance = smatrix.power(incident, side="negative")
            t = float(balance.transmission)
            r = float(balance.reflection)
            t_row.append(t)
            r_row.append(r)
            a_row.append(float(1.0 - t - r))
        transmission.append(t_row)
        reflection.append(r_row)
        absorption.append(a_row)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
