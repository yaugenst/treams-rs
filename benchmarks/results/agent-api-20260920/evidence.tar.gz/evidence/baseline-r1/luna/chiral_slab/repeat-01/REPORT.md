# Chiral slab report

`solution.py` uses the public `treams_rs.slab` and `SMatrix.power` interfaces.
Lengths are in micrometers, so each wavelength uses `k0 = 2*pi/wavelength`
in inverse micrometers. The supplied epsilon pair is interpreted as
`epsilon_real + i epsilon_imag`; `kappa` is the dimensionless treams material
chirality, with relative permeability and both exterior media set to one.

The two normal-incidence channels use treams' helicity convention (label 1 is
positive helicity and label 0 is negative helicity), reordered in the output
as positive then negative. Transmission and reflection come from the native
power balance for incidence from the negative-z side. Absorption is computed
as `1 - transmission - reflection`.

Checks performed: every returned row has two channels, and the residual
energy balance `T + R + A` is unity to floating-point precision for the
example input. `results.json` contains the actual example run.
