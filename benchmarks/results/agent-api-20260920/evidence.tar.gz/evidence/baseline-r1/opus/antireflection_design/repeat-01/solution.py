"""Analytic-gradient thickness optimization of a single-layer antireflection coating.

The stack is vacuum (negative side) | coating | substrate (positive side) and is
probed at normal incidence with a plane wave travelling along +z.  All lengths are
in micrometers, permittivities are relative.  Reflected power is obtained from the
treams-rs plane-wave S-matrix; the thickness derivative comes from the native
analytic pullbacks exposed through the Advect adapter ``treams_rs.advect``.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs as tr
from treams_rs import advect as tad

TARGET = 1e-7


def _basis(k0: float):
    """Normal-incidence plane-wave basis (kx = ky = 0, both polarizations)."""
    return tr.PlaneWaveBasis.default([[0.0, 0.0, 1.0]]).bycomp(k0)


def _reflection(thickness, *, basis, k0, epsilon, substrate_epsilon, backend):
    """Polarization-averaged reflected power fraction for +z incidence from vacuum."""
    smat = backend.slab(
        basis=basis,
        k0=k0,
        thickness=thickness,
        material=epsilon,
        negative_medium=1.0,
        positive_medium=substrate_epsilon,
        polarization="parity",
    )
    block = smat.array[1, 0]  # outgoing down / incoming up = reflection at vacuum side
    anp = ad.numpy if backend is tad else np
    return anp.real(anp.sum(block * anp.conj(block))) / 2.0


def run(config: dict) -> dict:
    wavelength = float(config["wavelength"])
    epsilon = complex(config["epsilon"])
    substrate_epsilon = complex(config["substrate_epsilon"])
    d0 = float(config["initial_thickness"])
    lo, hi = (float(b) for b in config["bounds"])

    k0 = 2.0 * np.pi / wavelength
    basis = _basis(k0)
    kwargs = dict(
        basis=basis, k0=k0, epsilon=epsilon, substrate_epsilon=substrate_epsilon
    )

    def loss_and_grad(d: float):
        """Reflected power and its analytic derivative dR/d(thickness)."""
        value, grad = ad.value_and_grad(
            lambda x: _reflection(x, backend=tad, **kwargs)
        )(float(d))
        return float(value), float(np.real(grad))

    d = min(max(d0, lo), hi)
    loss, grad = loss_and_grad(d)
    initial_reflection = loss
    history = [loss]

    # Projected gradient descent with Armijo backtracking and step growth.  The
    # search direction is the analytic gradient; finite differences are never used.
    step = 0.1 * max(hi - lo, 1e-12) / max(abs(grad), 1e-30)
    stalled = 0
    for _ in range(500):
        if loss < TARGET * 1e-3 or abs(grad) < 1e-16:
            break
        accepted = False
        for _ in range(60):
            trial = min(max(d - step * grad, lo), hi)
            actual = trial - d  # projection may shorten the step
            if abs(actual) < 1e-15 * max(abs(d), 1.0):
                break
            new_loss, new_grad = loss_and_grad(trial)
            if new_loss <= loss + 1e-4 * grad * actual:
                d, loss, grad = trial, new_loss, new_grad
                history.append(loss)
                step *= 2.0
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break
        # A reflection floor above the target (index mismatch) flattens out here.
        stalled = stalled + 1 if history[-2] - loss <= 1e-12 * history[-2] else 0
        if stalled >= 3:
            break

    return {
        "thickness": d,
        "reflection": loss,
        "initial_reflection": initial_reflection,
        "gradient": grad,
        "loss_history": history,
        "converged": bool(loss < TARGET),
        "iterations": len(history) - 1,
        "bounds": [lo, hi],
        "wavelength": wavelength,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
