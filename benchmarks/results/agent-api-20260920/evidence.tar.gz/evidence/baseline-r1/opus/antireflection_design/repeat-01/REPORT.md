# Single-layer antireflection coating: analytic-gradient thickness optimization

## Problem and geometry

Stack along the port normal (+z), from the negative to the positive side:

```
vacuum (eps = 1)  |  coating (eps = config["epsilon"], thickness d)  |  substrate (eps = config["substrate_epsilon"])
```

There is no vacuum gap after the coating. Illumination is a normally incident
plane wave travelling in +z (i.e. entering from the vacuum, `side="negative"`).

## Units and conventions

- Lengths (`wavelength`, `initial_thickness`, `bounds`, returned `thickness`) are micrometers.
- `epsilon`, `substrate_epsilon` are relative permittivities; mu = 1, chirality = 0.
  Lossless media: refractive index n = sqrt(eps).
- Vacuum wavenumber `k0 = 2*pi/wavelength` (rad/µm), as required by treams-rs.
- `reflection` is a **power fraction** (dimensionless, in [0, 1]), not an amplitude.
- `gradient` is dR/d(thickness) in units of 1/µm, evaluated analytically at the
  returned thickness.
- `loss_history[0]` is the reflection at the (bound-clipped) initial thickness and
  equals `initial_reflection`; each further entry is an accepted descent step.

## Method

- Basis: `treams_rs.PlaneWaveBasis.default([[0, 0, 1]]).bycomp(k0)` — normal incidence
  (kx = ky = 0), both polarization labels, parity (TE/TM) polarization convention.
- Physics: `treams_rs.advect.slab(...)` builds the three-medium S-matrix. Blocks are
  indexed `[outgoing, incoming]` with 0 = up (+z) and 1 = down, so block `[1, 0]` is
  the reflection matrix for vacuum-side incidence. The objective is the
  polarization-averaged reflected power
  `R(d) = (1/2) * sum_ij |S[1,0]_ij|^2`, which at normal incidence is identical for
  both polarizations and matches `SMatrix.power(..., side="negative").reflection`.
- Derivatives: `advect.value_and_grad` over the thickness argument. This routes
  through the native treams-rs pullbacks in the Advect adapter; no finite differences
  and no closed-form quarter-wave formula enter the optimization.
- Optimizer: projected gradient descent on d, with Armijo backtracking
  (c1 = 1e-4), step doubling after each accepted step, and clipping to `bounds`
  after every trial step. Stops when R < 1e-10, when the gradient vanishes, when the
  line search cannot improve (e.g. pinned at a bound), or when progress stalls at a
  nonzero reflection floor. `converged` reports whether R < 1e-7 was achieved.

## Example result (`results.json`)

Config: wavelength 0.7 µm, eps 2.25 (n = 1.5), substrate eps 5.0625 (n = 2.25),
initial thickness 0.05 µm, bounds [0.025, 0.21] µm.

| quantity | value |
| --- | --- |
| initial reflection | 9.594027e-02 |
| final thickness | 0.1166672 µm |
| final reflection | 7.68e-12 |
| final dR/dd | 3.11e-05 /µm |
| accepted steps | 9 |

Reflection drops by ~10 orders of magnitude and is well below the 1e-7 target.

## Checks performed

1. **Gradient vs. finite differences (validation only).** At d = 0.05 µm the analytic
   derivative is -1.8625903780 /µm; a central difference with h = 1e-6 µm gives
   -1.8625903778 (9 matching digits). Agreement to ~5+ digits also holds at the
   optimum for every test config.
2. **S-matrix vs. power balance.** The objective equals
   `SMatrix.power(incident, side="negative").reflection` to machine precision for both
   incident polarizations, and R + T = 1 with |absorption| < 1e-15 (lossless media).
3. **Independent analytic cross-check of the forward model.** The thin-film Airy
   formula r = (r01 + r12 e^{-2i beta}) / (1 + r01 r12 e^{-2i beta}),
   beta = 2 pi n1 d / lambda, reproduces |r|^2 = 0.09594 at d = 0.05 µm.
4. **Physical sanity of the optimum.** The recovered thickness 0.1166672 µm agrees
   with the quarter-wave value lambda / (4 n1) = 0.1166667 µm — obtained by the
   gradient search, not imposed.
5. **Generalization (not hard-coded).** Other configs were run: an index-mismatched
   stack (n = 1, 2, 3.5) correctly converges to its nonzero floor
   R = ((n0 n2 - n1^2)/(n0 n2 + n1^2))^2 = 4.4444e-03 with a vanishing gradient; a
   start past the optimum converges to R = 8.7e-11; a bounds-limited case terminates
   at the bound with a nonzero gradient and `converged = false`.

## Interface

- `run(config) -> dict` with keys `thickness`, `reflection`, `initial_reflection`,
  `gradient`, `loss_history`, plus `converged`, `iterations`, `bounds`, `wavelength`.
- CLI: `echo '<config json>' | python solution.py` prints the result dictionary as JSON.
