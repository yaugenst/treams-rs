# Homogeneous dielectric sphere spectrum (treams-rs)

## What is computed
For each wavelength, the T-matrix of a homogeneous sphere is built with
`treams_rs.sphere_tmatrix(k0=2*pi/wavelength, lmax=lmax, radius=radius,
material=Material(epsilon, mu, kappa), medium=..., polarization="helicity")`
and illuminated by `treams_rs.plane_wave(direction=[0,0,1],
polarization="positive_helicity")`. Cross sections come from
`TMatrix.cross_sections(illumination)` (fields `scattering`, `extinction`,
`absorption`). This is treams-rs' own Mie/T-matrix machinery; nothing is
reimplemented here.

## Units and conventions
- Lengths (`radius`, `wavelengths`) are micrometers, so `k0 = 2*pi/lambda`
  is in 1/um and the returned cross sections are areas in um^2.
- `epsilon = [real, imag]` is the **relative permittivity** (not a refractive
  index); it is passed directly to `treams_rs.Material`. The sign convention of
  treams (exp(-i omega t)) makes a positive imaginary part lossy, which the
  check below confirms via positive absorption.
- Defaults: `mu = 1`, `chirality = 0`, exterior is vacuum (`epsilon = 1`).
  Optional config keys `mu`, `chirality`, `epsilon_medium` override them.
- Illumination is a unit-amplitude plane wave along +z with positive helicity
  (right-handed in the helicity basis); for an achiral sphere the result is
  helicity-independent.
- `efficiency = scattering / (pi * radius**2)` — scattering efficiency Q_sca,
  dimensionless.
- All four output lists follow the input wavelength order.

## Example result (`results.json`)
radius 0.1 um, epsilon = 12 + 0.05i, lmax = 4, lambda = 0.45/0.55/0.65/0.75 um:

| lambda (um) | sigma_sca (um^2) | sigma_ext (um^2) | sigma_abs (um^2) | Q_sca |
|---|---|---|---|---|
| 0.45 | 0.0271458 | 0.0291622 | 0.0020164 | 0.8641 |
| 0.55 | 0.1624755 | 0.1651157 | 0.0026402 | 5.1718 |
| 0.65 | 0.1398054 | 0.1418899 | 0.0020845 | 4.4501 |
| 0.75 | 0.1793369 | 0.1866767 | 0.0073398 | 5.7085 |

## Checks performed
- **Independent Mie reference:** a textbook Mie series (Riccati-Bessel
  a_n/b_n coefficients, `mie_check.py`, used only for validation) reproduces
  all scattering and extinction values to ~1e-14 relative.
- **Rayleigh limit:** for radius 0.01 um, epsilon = 2, treams gives
  1.30565e-8 um^2 vs. the analytic 8/3 x^4 |(eps-1)/(eps+2)|^2 * pi r^2 =
  1.30568e-8 um^2 (0.002% agreement).
- **Multipole convergence:** results are converged at the requested lmax = 4;
  lmax = 4, 6 and 10 agree to all printed digits (lmax = 2 differs by <1e-5
  relative at 0.45 um).
- **Energy balance:** with a lossless sphere (epsilon = 12 + 0i) absorption is
  zero to 3e-16 and extinction equals scattering. With loss, absorption is
  positive and equals extinction - scattering.
- **Helicity symmetry:** negative-helicity illumination gives identical cross
  sections for the achiral sphere (agreement to 1e-16), as required.

## Usage
```
python solution.py < example_config.json > results.json
```
or `from solution import run; run(config)`.
