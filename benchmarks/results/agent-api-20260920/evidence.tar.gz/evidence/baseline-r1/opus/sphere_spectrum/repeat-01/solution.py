"""Spectrum of a homogeneous dielectric sphere illuminated by a positive-helicity
plane wave travelling along +z, computed with treams-rs.

Lengths are in micrometers, so cross sections come out in um^2.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as treams


def _material(value: Any) -> complex:
    """Turn an [real, imag] pair (or a scalar) into a relative permittivity."""
    if isinstance(value, (list, tuple)):
        real, imag = (list(value) + [0.0])[:2]
        return complex(float(real), float(imag))
    return complex(value)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    epsilon = _material(config["epsilon"])
    mu = _material(config.get("mu", 1.0))
    kappa = _material(config.get("chirality", 0.0))
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config["lmax"])

    material = treams.Material(epsilon, mu, kappa)
    medium = treams.Material(_material(config.get("epsilon_medium", 1.0)))

    scattering, extinction, absorption, efficiency = [], [], [], []
    geometric = np.pi * radius**2
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um
        tm = treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )
        illumination = treams.plane_wave(
            k0=k0,
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            material=medium,
        )
        xs = tm.cross_sections(illumination)
        scattering.append(float(xs.scattering))
        extinction.append(float(xs.extinction))
        absorption.append(float(xs.absorption))
        efficiency.append(float(xs.scattering) / geometric)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
