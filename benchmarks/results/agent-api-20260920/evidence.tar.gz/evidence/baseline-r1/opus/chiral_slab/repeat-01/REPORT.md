# Chiral slab, normal incidence: power fractions

## Problem and method

A uniform, isotropic, reciprocal chiral slab of thickness `d` is normal to z with
vacuum on both sides. A plane wave of definite helicity is incident from the
negative-z side travelling toward +z. For every wavelength we build the slab
scattering matrix with `treams_rs.slab` in the **helicity** polarization basis at
the single normal-incidence channel `(kx, ky) = (0, 0)` and evaluate
`SMatrices.power(illumination, side="negative")`, which returns the transmitted
and reflected power fractions; absorption is the named
`PowerBalance.absorption` complement. No scattering physics is reimplemented
here — treams-rs supplies all coefficients.

## Units and conventions

* All lengths are micrometers. The vacuum angular wavenumber is
  `k0 = 2*pi/wavelength` (inverse micrometers).
* `epsilon` is given as `[real, imag]`; `mu` (default 1) and `kappa` (default 0)
  are relative and dimensionless. `kappa` is the package's material chirality,
  entering through `treams_rs.Material(epsilon, mu, kappa)`. A positive
  imaginary part of `epsilon` is lossy in the package's time convention, which
  the positive absorption values confirm.
* Helicity mode indices are `n_mp = sqrt(eps*mu) -/+ kappa` (reported under
  `checks`), while the impedance `sqrt(mu/eps)` is helicity independent.
* Exterior media are vacuum on both sides (`negative_medium = positive_medium = 1`).
* Outputs are **power fractions** normalized to the incident normal flux, not
  amplitude coefficients. `transmission`, `reflection` and `absorption` each have
  shape `(len(wavelengths), 2)` with the column order
  **[positive helicity, negative helicity]**.
* Absorption values whose magnitude is below 1e-12 (round-off around a lossless
  slab) are reported as exactly 0.

## Physical remark on the example

For the example config `kappa` is real, so `n_+` and `n_-` differ only in their
real parts (1.5801 vs 1.4201, both with `Im n = 0.019998`). At normal incidence
the two helicities therefore give **identical** power fractions: the slab is
circularly birefringent (optical rotation) but not circularly dichroic. The
Fabry–Perot round trip is also helicity independent, because a forward wave of
one helicity reflects into a backward wave of the opposite helicity, so the
round-trip phase is `exp(2i k0 sqrt(eps*mu) d)` with the `kappa` terms cancelling.
Making `kappa` complex breaks this degeneracy, as checked below.

## Checks performed

* Energy balance `T + R + A = 1` holds to machine precision at every wavelength
  (`checks.max_energy_balance_residual` is 0.0 for the example).
* All fractions are non-negative (`checks.min_fraction`).
* Lossless control (`epsilon = 2.25`, `kappa = 0.3`): `A = 0` and
  `T + R = 1` to ~1e-15, with both helicities equal.
* Vacuum control (`epsilon = 1`, `kappa = 0`): `T = 1`, `R = 0`.
* Complex-chirality control (`kappa = 0.08 + 0.02i`): transmission splits to
  0.85474 / 0.98931, i.e. genuine circular dichroism, showing the helicity
  channels are resolved rather than symmetrized.

## Files

* `solution.py` — `run(config)` plus a CLI reading one JSON config from stdin and
  printing the result dictionary as JSON.
* `results.json` — output for the example config.
