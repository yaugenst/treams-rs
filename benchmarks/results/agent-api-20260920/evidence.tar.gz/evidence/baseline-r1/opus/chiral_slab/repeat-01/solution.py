"""Normal-incidence power balance of a uniform reciprocal chiral slab.

The slab is normal to z, bounded by vacuum on both sides, and illuminated from
the negative-z side by a +z propagating plane wave of definite helicity. All
scattering is done by treams-rs (``treams_rs.slab`` -> ``SMatrices.power``).

Units and conventions
---------------------
* Lengths (thickness, wavelengths) are micrometers; k0 = 2*pi/wavelength.
* epsilon = [real, imag], mu and kappa are relative/dimensionless; a positive
  imaginary part of epsilon is lossy in the package's time convention.
* Mode indices in the medium are n_pm = sqrt(eps*mu) -/+ kappa for negative /
  positive helicity; the wave impedance sqrt(mu/eps) is helicity independent.
* Outputs are power fractions (|amplitude|^2 weighted by the normal Poynting
  flux), ordered [positive helicity, negative helicity] at each wavelength.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as trs

# Order of the reported helicity channels.
HELICITIES = ("positive_helicity", "negative_helicity")

# Absorption values below this magnitude are round-off around a lossless slab.
_ZERO_TOL = 1e-12


def _complex(value) -> complex:
    """Accept a scalar or a [real, imag] pair."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        re, im = value
        return complex(float(re), float(im))
    return complex(value)


def _power_at(k0: float, thickness: float, material: trs.Material):
    """Transmission/reflection/absorption fractions for both helicities."""
    # Normal incidence: the only transverse wavevector is (kx, ky) = (0, 0).
    basis = trs.PlaneWavePorts.default([0.0, 0.0])
    smat = trs.slab(
        basis=basis,
        k0=k0,
        thickness=thickness,
        material=material,
        negative_medium=1,  # vacuum below the slab (incident side)
        positive_medium=1,  # vacuum above the slab
        polarization="helicity",
    )
    rows = []
    for pol in HELICITIES:
        illu = trs.plane_wave(
            direction=[0.0, 0.0, 1.0],  # +z incidence, from the negative side
            polarization=pol,
            k0=k0,
            material=1,
        )
        balance = smat.power(illu, side="negative")
        absorption = float(balance.absorption)
        if abs(absorption) < _ZERO_TOL:
            absorption = 0.0
        rows.append((float(balance.transmission), float(balance.reflection), absorption))
    return rows


def run(config: dict) -> dict:
    thickness = float(config["thickness"])
    epsilon = _complex(config["epsilon"])
    mu = _complex(config.get("mu", 1.0))
    kappa = _complex(config.get("kappa", 0.0))
    wavelengths = [float(w) for w in config["wavelengths"]]

    material = trs.Material(epsilon, mu, kappa)

    transmission, reflection, absorption = [], [], []
    for lam in wavelengths:
        k0 = 2.0 * np.pi / lam
        rows = _power_at(k0, thickness, material)
        transmission.append([r[0] for r in rows])
        reflection.append([r[1] for r in rows])
        absorption.append([r[2] for r in rows])

    balance_residual = [
        [abs(t + r + a - 1.0) for t, r, a in zip(trow, rrow, arow)]
        for trow, rrow, arow in zip(transmission, reflection, absorption)
    ]

    n_minus, n_plus = (complex(v) for v in material.nmp)
    return {
        "wavelengths": wavelengths,
        "helicity_order": ["positive", "negative"],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "checks": {
            "max_energy_balance_residual": max(max(row) for row in balance_residual),
            "min_fraction": min(
                min(min(t), min(r), min(a))
                for t, r, a in zip(transmission, reflection, absorption)
            ),
            "refractive_index_positive_helicity": [n_plus.real, n_plus.imag],
            "refractive_index_negative_helicity": [n_minus.real, n_minus.imag],
            "impedance": [complex(material.impedance).real, complex(material.impedance).imag],
        },
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
