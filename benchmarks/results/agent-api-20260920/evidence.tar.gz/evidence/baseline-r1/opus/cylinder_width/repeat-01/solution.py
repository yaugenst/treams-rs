"""Scattering by a homogeneous infinite cylinder (kz=0) using treams-rs.

Cross widths (length units, micrometers) for positive-helicity plane-wave
illumination propagating along +x, normally incident on a cylinder whose axis
is the z axis.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as treams


def _as_complex(epsilon: Any) -> complex:
    """Accept [real, imag], a real scalar, or a complex value."""
    if isinstance(epsilon, (list, tuple)):
        if len(epsilon) != 2:
            raise ValueError("epsilon must be given as [real, imag]")
        return complex(float(epsilon[0]), float(epsilon[1]))
    return complex(epsilon)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    epsilon = _as_complex(config["epsilon"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    mmax = int(config["mmax"])

    mu = _as_complex(config.get("mu", 1.0))
    kappa = _as_complex(config.get("chirality", 0.0))
    material = treams.Material(epsilon, mu, kappa)
    medium = treams.Material(1)

    scattering, extinction, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        tm = treams.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )
        # Unit-amplitude plane wave, +x propagation, positive helicity.
        illu = treams.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
            poltype="helicity",
        )
        xw = tm.cross_widths(illu)
        scattering.append(float(xw.scattering))
        extinction.append(float(xw.extinction))
        absorption.append(float(xw.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering_width": scattering,
        "extinction_width": extinction,
        "absorption_width": absorption,
        "units": "micrometer",
        "mmax": mmax,
        "kz": 0.0,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
