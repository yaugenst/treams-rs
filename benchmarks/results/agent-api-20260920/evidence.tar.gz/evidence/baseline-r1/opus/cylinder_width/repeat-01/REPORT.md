# Infinite-cylinder cross widths with treams-rs

## Problem
Homogeneous, infinitely long circular cylinder with its axis along **z**, embedded in
vacuum, illuminated by a plane wave travelling along **+x** (normal incidence, so the
axial wavenumber is `kz = 0`) with **positive helicity**. Reported quantities are the
scattering, extinction and absorption **cross widths** for each requested wavelength.

## Method
`treams_rs.cylinder_tmatrix(k0=..., kz=0.0, mmax=..., radius=..., material=..., medium=1,
polarization="helicity")` builds the cylindrical T-matrix of the homogeneous cylinder in the
helicity basis with azimuthal orders `m = -mmax .. mmax`. The illumination is
`treams_rs.plane_wave(direction=[1,0,0], polarization="positive_helicity", k0=k0)`, a
unit-amplitude plane wave in vacuum. `TMatrixC.cross_widths(illu)` returns the named
scattering and extinction widths (default flux normalization `flux=0.5`, i.e. the
time-averaged flux of a unit-amplitude wave), and `.absorption` is extinction − scattering.
No sphere-area normalization is applied anywhere; the returned numbers are widths.

## Units and conventions
- Lengths (`radius`, `wavelengths`, outputs) in micrometers; `k0 = 2π/λ` in rad/µm.
- `epsilon` is supplied as `[real, imag]` and read as the relative permittivity
  `ε = ε' + i ε''`; a positive imaginary part is lossy in treams' `exp(-iωt)` convention.
- `mu = 1` and `chirality = 0` unless overridden in the config (`"mu"`, `"chirality"` keys
  are accepted); the exterior is vacuum.
- Helicity polarization basis (`poltype="helicity"`); `direction` is normalized internally.
- `kz = 0` exactly: only the normal-incidence channel is represented, so the reported
  widths are per unit cylinder length (µm of width per µm of length, i.e. µm).

## Checks performed
- **Convergence in `mmax`** (λ = 0.5 µm, r = 0.08 µm, ε = 5 + 0.1i): widths are stable to
  ~1e-8 from `mmax = 6` on and already agree to ~5e-6 at the requested `mmax = 4`.
- **Lossless limit**: with `ε = 5 + 0i` the absorption width comes out as 0 to machine
  precision (|value| < 1e-16), i.e. extinction equals scattering — the optical theorem holds.
- **Helicity symmetry**: for the achiral, non-magnetic cylinder, negative-helicity
  illumination reproduces the positive-helicity widths to ~1e-15, as required.
- **Rayleigh limit**: for a lossless cylinder at λ = 1, 2, 4, 8 µm the scattering width
  falls off with successive ratios 5.9, 10.2, 8.8, approaching the expected λ⁻³ scaling of a
  thin dielectric cylinder.
- **Amplitude scaling**: doubling the incident coefficient quadruples the widths, confirming
  the results correspond to a unit-amplitude incident field (no hidden renormalization).

## Output
`run(config)` returns a JSON-serializable dict with `wavelengths`, `scattering_width`,
`extinction_width`, `absorption_width` (wavelength-ordered lists, micrometers), plus the
echoed `units`, `mmax` and `kz`. The CLI reads one config dict from stdin and prints this
dict as JSON:

```
echo '{"radius":0.08,"epsilon":[5,0.1],"wavelengths":[0.5,0.65,0.8],"mmax":4}' | python solution.py
```

Results for the example config are in `results.json`:

| λ (µm) | σ_sca (µm) | σ_ext (µm) | σ_abs (µm) |
|---|---|---|---|
| 0.50 | 0.533035 | 0.561106 | 0.028071 |
| 0.65 | 0.258592 | 0.269540 | 0.010948 |
| 0.80 | 0.240742 | 0.248864 | 0.008123 |
