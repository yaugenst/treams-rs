"""Core-shell (multilayer) sphere cross-section spectrum using treams-rs.

Lengths in micrometers, cross sections in um^2. Permittivities/permeabilities
are relative and dimensionless; the time convention is exp(-i*omega*t), so a
positive imaginary part of epsilon means loss.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as tr


def _material(entry):
    """Build a Material from a scalar, [re, im], or [eps, mu, kappa] entry."""
    if isinstance(entry, (list, tuple)):
        if len(entry) == 2 and all(isinstance(v, (int, float)) for v in entry):
            return tr.Material(complex(entry[0], entry[1]))
        return tr.Material(*[complex(v) if not isinstance(v, (list, tuple))
                             else complex(v[0], v[1]) for v in entry])
    return tr.Material(complex(entry))


def run(config):
    radii = [float(r) for r in config["radii"]]
    materials = [_material(e) for e in config["epsilon_layers"]]
    medium = _material(config.get("epsilon_medium", 1))
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config.get("lmax", 4))

    if len(materials) != len(radii):
        raise ValueError("one permittivity per radius is required "
                         "(the exterior is given separately)")
    if any(b <= a for a, b in zip(radii, radii[1:])) or radii[0] <= 0:
        raise ValueError("radii must be positive and strictly increasing")

    sca, ext, abso = [], [], []
    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl  # vacuum angular wavenumber, 1/um
        tm = tr.multilayer_sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radii=radii,
            materials=materials,   # inside-out, exterior NOT appended
            medium=medium,
            polarization="helicity",
        )
        xs = tm.average_cross_sections  # rotationally & polarization averaged
        sca.append(float(xs.scattering))
        ext.append(float(xs.extinction))
        abso.append(float(xs.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering_cross_section": sca,
        "extinction_cross_section": ext,
        "absorption_cross_section": abso,
        "units": {"length": "um", "cross_section": "um^2"},
        "lmax": lmax,
        "n_layers": len(radii),
    }


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
