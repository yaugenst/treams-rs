# Core–shell sphere cross-section spectrum (treams-rs)

## What is computed
For each wavelength, a concentric multilayer sphere T-matrix is built with
`treams_rs.multilayer_sphere_tmatrix` and its rotationally and
polarization-averaged cross sections are read from
`TMatrix.average_cross_sections`.

- `scattering_cross_section`, `extinction_cross_section` come directly from that
  named tuple; `absorption_cross_section` is its `absorption` field
  (= extinction − scattering).
- Lists are returned in the same order as the input `wavelengths`.

## Units and conventions
- Lengths (`radii`, `wavelengths`) in micrometers; cross sections in µm².
- `k0 = 2*pi/wavelength` is the **vacuum** angular wavenumber (1/µm); the medium
  index enters through the material, not through k0.
- `epsilon_layers` entries are `[real, imag]` relative permittivities, ordered
  **inside-out**, one per entry of `radii` (which are increasing outer layer
  boundaries). The exterior is passed separately via the `medium` argument and
  is **not** appended as an extra finite layer.
- `mu = 1`, `kappa = 0` throughout (treams-rs `Material` defaults); the exterior
  defaults to vacuum if `epsilon_medium` is absent.
- Time convention `exp(-i*omega*t)`: a **positive** imaginary permittivity is
  loss. Verified — flipping the sign of Im(eps) gives negative absorption.
- Helicity polarization basis; results are polarization-averaged, so this choice
  does not affect the output.
- The averaged cross sections require a non-absorbing exterior (satisfied here,
  `epsilon_medium = 1.7689 = 1.33²`).

## Validation performed
1. **Independent analytic Mie.** For a single homogeneous layer
   (r = 0.12, eps = 4+0.06i, exterior 1.7689, λ = 0.58) a from-scratch
   Bohren–Huffman Mie series (own Bessel recurrences, no scipy) gives
   sca/ext/abs = 0.05268818386888, 0.05645633741377, 0.00376815354489 µm²,
   matching the treams-rs result to ~14 significant digits.
2. **Multipole convergence.** For the example, going from lmax = 4 to lmax = 10
   changes scattering by 2.2e-9 and extinction by 2.6e-6 relative — the
   requested lmax = 4 is converged to well below plotting accuracy.
3. **Rotational average vs. explicit illumination.** Plane-wave illumination
   along +z for either helicity reproduces the rotational average exactly
   (a sphere is isotropic), for all three wavelengths.
4. **Lossless limit.** Setting Im(eps) = 0 in both layers yields absorption at
   the 1e-17 level (numerical zero), i.e. energy conservation holds.
5. **Equivalence check.** `multilayer_sphere_tmatrix(..., medium=...)` and
   `TMatrix.sphere(..., materials=[layers..., exterior])` agree bit-for-bit,
   confirming the exterior is handled as the embedding medium.

No finite differences or derivatives are involved in this task.

## Example result (`results.json`)
Config: radii [0.07, 0.12] µm, eps [2.25+0.03i, 4+0.06i], exterior 1.7689,
λ = [0.58, 0.7, 0.82] µm, lmax = 4.

| λ (µm) | σ_sca (µm²) | σ_ext (µm²) | σ_abs (µm²) |
|---|---|---|---|
| 0.58 | 3.431592e-2 | 3.752383e-2 | 3.207911e-3 |
| 0.70 | 1.891246e-2 | 2.117016e-2 | 2.257697e-3 |
| 0.82 | 1.213568e-2 | 1.390107e-2 | 1.765386e-3 |

## Usage
```
python solution.py < example_config.json > results.json
```
or `from solution import run; run(config)`.
