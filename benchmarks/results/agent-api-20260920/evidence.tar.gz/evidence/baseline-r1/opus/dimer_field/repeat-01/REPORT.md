# Dimer scattering and total near field (treams-rs)

## What is computed
Two homogeneous spheres are placed at `x = -separation/2` and `x = +separation/2`
(`y = z = 0`), with `radii[i]` and `epsilon[i]` taken in that order. Each sphere is
described by a Mie T-matrix (`treams_rs.sphere_tmatrix`) truncated at the given
`lmax`. The pair is assembled with `treams_rs.Cluster(..., positions=...)` and
`.solve()`, which inverts the full coupled interaction matrix, so **all orders of
multiple scattering** between the two spheres are included (no Born/single-scattering
truncation). The illumination is a plane wave propagating along `+z` with positive
helicity, created by `treams_rs.plane_wave`.

Outputs:
- `total_field_real`, `total_field_imag`: points x 3 lists of the **total** electric
  field `E_inc + E_sca` at the requested Cartesian points, in the same complex
  Cartesian (x, y, z) component order.
- `scattering_cross_section`, `extinction_cross_section`, `absorption_cross_section`:
  scalars from `Cluster.cross_sections(plane_wave)`.
- Extras for traceability: `wavenumber_k0`, sphere `positions`, and
  `points_outside_particles` (from `Cluster.valid_points`), which flags whether each
  evaluation point lies strictly outside the circumscribing spheres where the
  multipole expansion of the scattered field converges.

## Units and conventions
- Lengths (radii, separation, wavelength, point coordinates) are in micrometers.
  The vacuum angular wavenumber is `k0 = 2*pi/wavelength` (um^-1); for the example
  `k0 = 8.7266 um^-1`.
- `epsilon` entries are `[real, imag]` relative permittivities, combined as
  `eps_re + 1j*eps_im`. Unless otherwise specified `mu = 1`, `kappa = 0`, and the
  exterior medium is vacuum (`Material(1)`), as set explicitly in the code.
- Helicity basis is used throughout (`polarization="helicity"`), matching the
  positive-helicity illumination.
- Incident normalization is the package default: `plane_wave` yields a unit-amplitude
  wave, `E_inc(r) = (x_hat + i*y_hat)/sqrt(2) * exp(i*k0*z)` for +z / positive
  helicity, so `|E_inc| = 1` everywhere. No extra rescaling is applied, and the
  scattered field returned by `Cluster.scatter` shares that normalization, so the two
  are added directly.
- Time convention is treams' `exp(-i*omega*t)`; a positive `Im(epsilon)` is lossy,
  consistent with the positive absorption obtained below.
- Cross sections are in squared micrometers, evaluated with the default incident flux
  of the normalized plane wave.

## Example result (config in `example_config.json`, output in `results.json`)
```
sigma_sca = 0.05648477 um^2
sigma_ext = 0.05910237 um^2
sigma_abs = 0.00261760 um^2
E_tot(0, 0, 0.3)      = ( 0.80919 - 0.26914i,  0.23513 + 0.82034i,  0.03110 + 0.07267i)
E_tot(0.35, 0.2, 0.1) = (-0.22645 - 0.60503i,  0.52804 - 0.43737i, -0.02124 - 0.12125i)
```

## Validation performed
1. **Truncation convergence.** Repeating the example at `lmax = 5` and `7` changes
   `sigma_sca` by 1.4e-5 relative and the field components by <1e-4 relative, so the
   requested `lmax = 3` is well converged for this geometry (results are still
   reported at the fixed `lmax` from the config, as specified).
2. **Energy balance.** `sigma_ext - sigma_sca - sigma_abs = 0` to machine precision.
3. **Lossless limit.** With `Im(epsilon) = 0` for both spheres, the absorption cross
   section drops to 1.4e-17 um^2 (numerically zero) and extinction equals scattering.
4. **Uncoupled limit.** At `separation = 200 um` the dimer scattering cross section
   (0.055123 um^2) matches the sum of the two independent Mie cross sections
   (0.055131 um^2) to 1.5e-4 relative, the residual being the residual far-field
   interference of the two widely separated scatterers.
5. **Vanishing-scatterer limit.** With radii 1e-5 um the total field reduces to the
   incident plane wave to ~1e-14.
6. **Polarization check.** The returned incident field satisfies `E_y = i*E_x`,
   `E_z = 0`, confirming positive helicity for propagation along `+z`.
7. **Evaluation-point validity.** Both example points lie outside the circumscribing
   spheres (`points_outside_particles = [true, true]`), i.e. inside the convergence
   region of the outgoing multipole expansion.

All numerics come from treams-rs kernels (`sphere_tmatrix`, `Cluster.solve/scatter`,
`efield`, `cross_sections`); nothing is reimplemented. No derivatives or optimization
were requested, so no sensitivity machinery is used.

## Usage
```
python solution.py < example_config.json > results.json
```
or `from solution import run; run(config)` with the same config keys.
