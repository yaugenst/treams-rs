"""Two-sphere (dimer) scattering with treams-rs.

Full multiple scattering at fixed lmax; total field = incident + scattered.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def _material(entry):
    """Build a Material from an [real, imag] epsilon entry (mu=1, kappa=0)."""
    eps = complex(entry[0], entry[1]) if np.ndim(entry) else complex(entry)
    return tr.Material(eps)


def run(config):
    radii = [float(r) for r in config["radii"]]
    eps = [_material(e) for e in config["epsilon"]]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float).reshape(-1, 3)

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um
    medium = tr.Material(1)  # vacuum exterior

    positions = np.array(
        [[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]]
    )

    particles = [
        tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=r, material=m, medium=medium,
            polarization="helicity",
        )
        for r, m in zip(radii, eps)
    ]

    cluster = tr.Cluster(particles, positions=positions).solve()

    # Incident: unit-amplitude plane wave along +z, positive helicity.
    illu = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        material=medium,
    )

    scattered = cluster.scatter(illu)

    e_inc = np.asarray(illu.efield(points), dtype=complex).reshape(-1, 3)
    e_sca = np.asarray(scattered.efield(points), dtype=complex).reshape(-1, 3)
    e_tot = e_inc + e_sca

    xs = cluster.cross_sections(illu)

    valid = np.asarray(cluster.valid_points(points, radii), dtype=bool)

    return {
        "total_field_real": e_tot.real.tolist(),
        "total_field_imag": e_tot.imag.tolist(),
        "scattering_cross_section": float(xs.scattering),
        "extinction_cross_section": float(xs.extinction),
        "absorption_cross_section": float(xs.absorption),
        "wavenumber_k0": k0,
        "positions": positions.tolist(),
        "points_outside_particles": valid.tolist(),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
