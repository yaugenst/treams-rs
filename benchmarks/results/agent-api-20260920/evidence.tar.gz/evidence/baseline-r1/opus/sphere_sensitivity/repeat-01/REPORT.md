# Scattering efficiency and analytic sensitivity of a lossy sphere

## Problem

A homogeneous, lossy sphere of radius `radius` and relative permittivity
`epsilon = epsilon_real + 1j*epsilon_imag` (mu = 1, kappa = 0) sits in vacuum and is
illuminated by a positive-helicity plane wave propagating along +z. We report

```
Q = sigma_sca / (pi * radius**2)
```

and the gradient `[dQ/dradius, dQ/depsilon_real]` at fixed `epsilon_imag`,
`wavelength` and `lmax`.

## Units and conventions

* Lengths are micrometers; `k0 = 2*pi/wavelength` is in 1/um; cross sections in um^2.
* `epsilon`, `mu`, `kappa` are relative and dimensionless; the exterior is vacuum
  (`epsilon = mu = 1`). The time convention and the sign of `epsilon_imag > 0` for loss
  are those of treams-rs.
* The T-matrix is built in the **helicity** basis, `treams_rs.SphericalBasis.default(lmax)`
  (2*lmax*(lmax+2) modes, 30 for lmax = 3). The incident wave is
  `polarization="positive_helicity"` — the helicity channel co-rotating with +z propagation.
* Illumination is a unit-amplitude plane wave with the treams-rs default incident flux 0.5,
  so cross sections are the usual power ratios and are independent of that normalization.
* Gradient units: `dQ/dradius` in 1/um, `dQ/depsilon_real` dimensionless.

## Method

`treams_rs.advect.sphere(lmax, k0, radii, epsilon)` returns the helicity Mie T-matrix and is
registered with the installed Advect adapter, which exposes the native first-order pullback
of treams-rs. The materials array carries one more entry than the radii array: the sphere
followed by the embedding medium (`1+0j`).

The scattering cross section is formed from the differentiable T-matrix as

```
sigma_sca = sum_i |(T a)_i|**2 / k0**2
```

with `a` the regular spherical expansion of the plane wave (`PlaneWave.expand(basis)`).
This reproduces `TMatrix.cross_sections(...).scattering` exactly (see checks); the explicit
form is needed because the high-level accessor casts to Python floats and so cannot be
traced. `a` is a constant with respect to `radius` and `epsilon_real`.

Q divides by `pi*radius**2` *inside* the traced function, so the normalization is
differentiated together with the cross section:

```
dQ/dradius = (1/(pi r^2)) dsigma/dr - 2 sigma/(pi r^3)
```

`advect.value_and_grad` over the vector `[radius, epsilon_real]` then yields the value and
both derivatives in one reverse pass. `epsilon_imag`, `wavelength` and `lmax` are captured
as constants. No finite differences enter the returned numbers.

## Results for the example config

`{"radius": 0.1, "epsilon_real": 4.0, "epsilon_imag": 0.06, "wavelength": 0.72, "lmax": 3}`

| quantity | value |
| --- | --- |
| Q | 0.46337644643427434 |
| dQ/dradius | 18.65367030479628 um^-1 |
| dQ/depsilon_real | 0.19972554645618434 |
| sigma_sca | 0.0145574003996446 um^2 |
| sigma_ext | 0.0156358052396052 um^2 |
| sigma_abs | 0.0010784048399606 um^2 |
| size parameter k0*r | 0.87266 |

Full output is in `results.json`.

## Checks

* **Forward consistency**: the traced Q matches `TMatrix.cross_sections(...).scattering`
  from the high-level treams-rs API to 5.6e-17 absolute (reported as
  `checks.value_vs_cross_sections_api`).
* **Optical theorem**: `sigma_ext - sigma_sca - sigma_abs = 0` exactly
  (`checks.optical_theorem_residual`).
* **Gradient validation** (`verify_fd.py`, diagnostic only — not used for the answer):
  central differences with h = 1e-6 * scale against the independent high-level forward
  evaluation agree with the analytic gradient to relative error <= 2.2e-9 for the example
  config and two other configs (r=0.25, eps=6.5+0.4j, wl=1.0, lmax=5; r=0.05, eps=2.1+0.01j,
  wl=0.4, lmax=2).
* `lmax = 3` is ample for a size parameter below 1; the example's absorption efficiency
  (0.0343) and extinction efficiency (0.4977) are physically consistent with a weakly lossy
  sub-wavelength dielectric sphere.

## Usage

```
python solution.py < config.json          # JSON config on stdin, JSON result on stdout
```
or `from solution import run; run(config)`.

Inputs are validated for `radius > 0`, `wavelength > 0`, `lmax >= 1`; nothing is hard-coded
to the example values.
