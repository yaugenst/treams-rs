"""Scattering efficiency of a lossy sphere and its analytic sensitivity.

Q = sigma_sca / (pi * radius**2) for a homogeneous, lossy sphere in vacuum,
illuminated by a positive-helicity plane wave travelling along +z.

The gradient [dQ/dradius, dQ/depsilon_real] is obtained from the native
first-order pullbacks of treams-rs through the installed Advect adapter
(``treams_rs.advect``); both the cross section and the geometric
normalization pi*radius**2 are differentiated.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import advect
import numpy as np
import treams_rs as tr
import treams_rs.advect as tra

anp = advect.numpy


def _incident_coefficients(k0: float, lmax: int) -> tuple[np.ndarray, Any]:
    """Regular spherical coefficients of a +z, positive-helicity plane wave.

    The illumination does not depend on the sphere parameters, so it enters
    the derivative as a constant.
    """
    basis = tr.SphericalBasis.default(lmax)
    wave = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        material=1,
    )
    return wave.expand(basis), basis


def _efficiency(x, *, k0: float, lmax: int, epsilon_imag: float, incident):
    """Q as a differentiable function of x = [radius, epsilon_real]."""
    radius, epsilon_real = x[0], x[1]
    epsilon = anp.stack(
        [epsilon_real + 1j * epsilon_imag, anp.asarray(1.0 + 0.0j)]  # sphere, medium
    )
    tmat = tra.sphere(lmax, k0, anp.stack([radius]), epsilon)
    scattered = tmat @ incident
    # sigma_sca = sum |T a|^2 / k^2 for a unit-amplitude plane wave in vacuum
    # (helicity basis, flux 1/2), matching TMatrix.cross_sections().scattering.
    sigma_sca = anp.sum(anp.abs(scattered) ** 2) / k0**2
    return sigma_sca / (np.pi * radius**2)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    if radius <= 0 or wavelength <= 0 or lmax < 1:
        raise ValueError("require radius > 0, wavelength > 0 and lmax >= 1")

    k0 = 2.0 * np.pi / wavelength
    incident, basis = _incident_coefficients(k0, lmax)

    def objective(x):
        return _efficiency(
            x, k0=k0, lmax=lmax, epsilon_imag=epsilon_imag, incident=incident
        )

    value, gradient = advect.value_and_grad(objective)(
        advect.array([radius, epsilon_real])
    )
    value = float(value)
    gradient = [float(g) for g in np.asarray(gradient)]

    # Independent forward evaluation with the high-level treams-rs API.
    tmat = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=tr.Material(complex(epsilon_real, epsilon_imag)),
        medium=1,
    )
    wave = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        material=1,
    )
    xs = tmat.cross_sections(wave)
    area = np.pi * radius**2
    q_reference = float(xs.scattering) / area

    return {
        "value": value,
        "gradient": gradient,
        "quantity": "Q_scattering_efficiency",
        "gradient_wrt": ["radius", "epsilon_real"],
        "inputs": {
            "radius": radius,
            "epsilon_real": epsilon_real,
            "epsilon_imag": epsilon_imag,
            "wavelength": wavelength,
            "lmax": lmax,
        },
        "derived": {
            "k0": k0,
            "size_parameter": k0 * radius,
            "geometric_cross_section": area,
            "num_modes": len(basis),
            "scattering_cross_section": float(xs.scattering),
            "extinction_cross_section": float(xs.extinction),
            "absorption_cross_section": float(xs.absorption),
            "extinction_efficiency": float(xs.extinction) / area,
            "absorption_efficiency": float(xs.absorption) / area,
        },
        "checks": {
            "value_vs_cross_sections_api": abs(value - q_reference),
            "optical_theorem_residual": abs(
                float(xs.extinction) - float(xs.scattering) - float(xs.absorption)
            ),
        },
        "units": {
            "lengths": "micrometer",
            "cross_sections": "micrometer**2",
            "k0": "1/micrometer",
            "Q": "dimensionless",
            "dQ_dradius": "1/micrometer",
            "dQ_depsilon_real": "dimensionless",
        },
        "method": "treams-rs helicity Mie T-matrix; analytic first-order VJP via treams_rs.advect",
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
