# Square sphere array above a dielectric slab

`solution.py` exposes `run(config)` and a CLI (`python solution.py < config.json`)
that prints the same dictionary as JSON. All numerics come from `treams_rs`.

## Model and conventions

* **Units.** Lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`)
  are micrometers. Permittivities are relative and dimensionless; `mu = 1`,
  `kappa = 0`, and every exterior medium is vacuum. The vacuum angular
  wavenumber is `k0 = 2*pi/lambda` in 1/um, matching treams-rs's convention that
  `radius` and `1/k0` share a length unit.
* **Network order.** Layers are cascaded with `tr.stack` from the negative to
  the positive side of +z: `slab` (homogeneous layer of `slab_epsilon`,
  thickness `slab_thickness`, vacuum on both sides) -> `propagation` over the
  vacuum `gap` -> the periodic sphere array. The array S-matrix is referenced to
  the sphere-center plane, so the propagation distance is exactly `gap`, the
  vacuum distance between the slab top and that plane.
* **Array solve.** `tr.sphere_tmatrix(k0, lmax, radius, material=sphere_epsilon)`
  gives the isolated sphere in the helicity basis; `tr.solve_periodic` performs
  the full Bloch-periodic lattice interaction (Ewald sums, eta chosen natively)
  on the square lattice `tr.Lattice.square(period)` at Bloch vector `[0, 0]`.
  The multipole order is exactly the requested `lmax` — no internal truncation
  sweep. `PeriodicResponse.to_smatrix` projects the solved response onto the
  plane-wave ports.
* **Diffraction orders.** `tr.PlaneWavePorts.default([0, 0])` keeps only the
  zeroth order `(kx, ky) = (0, 0)` with both helicity channels (`pol` labels 1
  and 0). Since every wavelength exceeds the period, this is the complete set of
  propagating orders; evanescent orders are dropped, so near-field coupling
  across the gap between slab and array is neglected, as specified.
* **Illumination.** `tr.plane_wave(direction=[0,0,1],
  polarization="positive_helicity", k0, material=1)` — incidence from the
  negative-z exterior along +z. `SMatrices.power(..., side="negative")` returns
  `PowerBalance` fractions of the incident flux: `transmission` (into +z
  vacuum), `reflection` (back into -z vacuum) and `absorption` (flux missing
  from the retained channels).
* **Output.** Wavelengths are sorted ascending and the three lists are given in
  that same order, together with `energy_balance = T + R + A` per wavelength.

## Example result (config in the prompt), saved to `results.json`

| lambda (um) | T | R | A |
|---|---|---|---|
| 0.65 | 0.887328636 | 0.112671364 | -8.5e-16 |
| 0.74 | 0.902068727 | 0.097931273 |  2.4e-16 |
| 0.83 | 0.911914269 | 0.088085731 | -5.3e-16 |

## Checks performed

* **Energy balance.** `T + R + A = 1` to 1e-15 at every wavelength.
* **Losslessness.** Both permittivities are real, so absorption must vanish; it
  comes out at the 1e-16 round-off level (its sign is meaningless noise).
* **lmax convergence.** Transmission at lmax = 2 / 3 / 4 / 5 is
  0.8873286 / 0.8873380 / 0.8873379 / 0.8873379 at 0.65 um: the reported lmax=2
  value is converged to ~1e-5, and the code uses the requested lmax verbatim.
* **Bare slab against Fresnel.** Removing the array, the treams-rs slab
  reflectance matches the analytic single-layer Airy formula for n = 1.5 to 1e-16
  (e.g. 0.13914018 at 0.65 um).
* **Symmetry.** The achiral, mirror-symmetric structure gives identical results
  for negative-helicity illumination, and reciprocity is confirmed by equal
  transmission for illumination from the positive-z side.
