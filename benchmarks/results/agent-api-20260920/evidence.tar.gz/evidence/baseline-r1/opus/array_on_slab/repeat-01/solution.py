"""Square sphere array above a dielectric slab: zeroth-order power fractions.

Geometry along +z (order of the scattering network, negative to positive side):

    vacuum | slab (thickness t, eps_slab) | vacuum gap | sphere array | vacuum

All numerics come from treams-rs: the periodic sphere interaction is solved with
``solve_periodic`` (Ewald lattice sums) at the fixed ``lmax`` and converted to
zeroth-order plane-wave ports, the planar layers are S-matrices, and the stack is
cascaded with ``stack``.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _power_fractions(
    *,
    wavelength: float,
    radius: float,
    sphere_epsilon: complex,
    period: float,
    gap: float,
    slab_thickness: float,
    slab_epsilon: complex,
    lmax: int,
) -> tr.PowerBalance:
    k0 = 2 * np.pi / wavelength  # vacuum angular wavenumber, 1/um

    # Zeroth diffraction order only, both helicity channels, Bloch vector [0, 0].
    ports = tr.PlaneWavePorts.default([0.0, 0.0])

    # Sphere array: isolated T-matrix, then the full periodic interaction.
    sphere = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon, medium=1
    )
    array = tr.solve_periodic(
        sphere, lattice=tr.Lattice.square(period), kpar=[0.0, 0.0]
    ).to_smatrix(ports)

    # Planar parts: slab embedded in vacuum, then vacuum propagation over the gap.
    slab = tr.slab(
        basis=ports,
        k0=k0,
        thickness=slab_thickness,
        material=slab_epsilon,
        negative_medium=1,
        positive_medium=1,
    )
    spacer = tr.propagation(distance=gap, basis=ports, k0=k0, medium=1)

    network = tr.stack([slab, spacer, array])

    # Illumination from the negative-z side along +z, positive helicity.
    incident = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        material=1,
    )
    return network.power(incident, side="negative")


def run(config: dict[str, Any]) -> dict[str, Any]:
    radius = float(config["radius"])
    sphere_epsilon = float(config["sphere_epsilon"])
    period = float(config["period"])
    gap = float(config["gap"])
    slab_thickness = float(config["slab_thickness"])
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]

    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []
    for wavelength in sorted(wavelengths):
        balance = _power_fractions(
            wavelength=wavelength,
            radius=radius,
            sphere_epsilon=sphere_epsilon,
            period=period,
            gap=gap,
            slab_thickness=slab_thickness,
            slab_epsilon=slab_epsilon,
            lmax=lmax,
        )
        transmission.append(float(balance.transmission))
        reflection.append(float(balance.reflection))
        absorption.append(float(balance.absorption))

    return {
        "wavelengths": sorted(wavelengths),
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "energy_balance": [
            t + r + a for t, r, a in zip(transmission, reflection, absorption)
        ],
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
