"""Sensitivity of the near field of a sphere dimer to its separation.

Two identical spheres sit at (-separation/2, 0, 0) and (+separation/2, 0, 0) and
are illuminated by a positive-helicity plane wave travelling along +z. The
coupled (multiple-scattering) response is built with treams-rs, and the
derivative with respect to the separation is obtained from the package's
analytic pullbacks through its Advect adapter.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import advect as ad
import numpy as np
from treams_rs import advect as tra


def _material(config: dict[str, Any]) -> complex:
    real, imag = (float(v) for v in config["epsilon"])
    return complex(real, imag)


def _value(separation: Any, config: dict[str, Any]) -> Any:
    """sum(|E_total|^2) at the fixed point for a (possibly traced) separation."""
    k0 = 2.0 * np.pi / float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=float)

    # Mie response of one sphere; identical for both particles and independent
    # of the separation, but still built through the differentiable adapter.
    particle = tra.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=float(config["radius"]),
        material=tra.Material(_material(config), float(config.get("mu", 1.0)),
                              float(config.get("chirality", 0.0))),
        medium=tra.Material(float(config.get("epsilon_exterior", 1.0))),
    )

    half = separation / 2.0
    zero = 0.0 * half  # keeps the traced dtype/graph for the constant components
    positions = ad.numpy.stack(
        [
            ad.numpy.stack([-half, zero, zero]),
            ad.numpy.stack([half, zero, zero]),
        ]
    )

    cluster = tra.Cluster([particle, particle], positions=positions)
    incident = tra.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)

    # Cluster.scatter solves (1 - T C) b = T a, i.e. it includes multiple scattering.
    scattered = cluster.scatter(incident)
    total = scattered.efield(point) + incident.efield(point)
    return ad.numpy.sum(ad.numpy.abs(total) ** 2)


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return the near-field intensity and its analytic separation derivative."""
    separation = float(config["separation"])
    value, gradient = ad.value_and_grad(lambda s: _value(s, config))(separation)
    return {
        "value": float(value),
        "gradient": float(gradient),
        "units": {
            "value": "dimensionless (|E|^2 for unit-amplitude incident field)",
            "gradient": "1/micrometer",
        },
        "separation": separation,
        "point": [float(v) for v in config["point"]],
        "wavelength": float(config["wavelength"]),
        "lmax": int(config["lmax"]),
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
