# Dimer near-field intensity and its separation sensitivity

## Task

Two identical spheres at `x = -separation/2` and `x = +separation/2` (y = z = 0) are
illuminated by a positive-helicity plane wave travelling along `+z`. At a fixed
observation point we report

- `value  = sum(|E_total|^2)` with `E_total = E_incident + E_scattered`, and
- `gradient = d value / d separation`, obtained from analytic derivatives.

Both sphere positions move with the separation; point, wavelength, radius,
material and `lmax` are held fixed.

## Files

- `solution.py` — `run(config) -> dict`; CLI reads one JSON config on stdin, prints JSON on stdout.
- `results.json` — output for the example config.
- `validate.py` — checks described below.

Run: `echo '<config json>' | python solution.py`

## Units and conventions

- Lengths (`radius`, `separation`, `wavelength`, `point`) are in micrometers;
  `k0 = 2*pi/wavelength` is in rad/µm.
- `epsilon = [real, imag]` is the relative permittivity of the spheres; `mu = 1`,
  chirality `kappa = 0`, and the exterior is vacuum (these can be overridden with
  the optional keys `mu`, `chirality`, `epsilon_exterior`).
- Incident field: unit-amplitude positive-helicity plane wave along `+z`
  (`treams_rs.advect.plane_wave([0,0,1], "positive_helicity", k0=k0)`), i.e.
  `E_inc ∝ (x̂ + i ŷ) e^{i k z}` with `sum(|E_inc|^2) = 1`. The package uses the
  helicity polarization convention throughout (`poltype="helicity"`).
- `value` is therefore dimensionless: the local intensity normalized to the
  incident intensity. `gradient` has units of 1/µm.
- Time convention and field normalization are those of treams/treams-rs
  (Beutel, Fernandez-Corbaton, Rockstuhl, CPC 297, 109076 (2024)).

## Method

All scattering is done by treams-rs, no physics is reimplemented:

1. `treams_rs.advect.sphere_tmatrix(k0, lmax, radius, material)` — Mie T-matrix
   of one sphere in the helicity basis.
2. Positions `[[-s/2,0,0],[s/2,0,0]]` are built from the traced separation with
   `advect.numpy`, so the geometry dependence stays in the derivative graph.
3. `treams_rs.advect.Cluster([T, T], positions=positions).scatter(incident)`
   solves `(1 - T C) b = T a` with the singular translation coupling `C`
   between the two origins, i.e. **multiple scattering is included** (a
   full-order coupled solve, not a Born/single-scattering approximation).
4. `Wave.efield(point)` evaluates the outgoing multipole field of both spheres at
   the observation point; the incident plane-wave field is added analytically by
   `PlaneWave.efield(point)`.
5. `value = advect.numpy.sum(abs(E_total)**2)`.

The gradient is `advect.value_and_grad(...)` over that graph, which uses the
native treams-rs pullbacks (Mie, translation/expansion, interaction solve,
field evaluation) via the installed Advect adapter. Finite differences are used
only for verification, never to produce the reported numbers.

## Checks

- **Gradient vs. central finite differences** (h = 1e-5 µm) for three different
  configurations (varying separation, point, radius, epsilon, wavelength, lmax):
  relative errors 6e-11 … 2.5e-10.
- **Independent forward path**: the plain NumPy API (`treams_rs.Cluster.scatter`
  and `Cluster.solve().scatter`) reproduces the example value to ~1e-16.
- **Multipole convergence** (example config): value 1.1855506 (lmax 2),
  1.1855316 (lmax 3), 1.1855313 (lmax 4 and 5); gradient -0.40373, -0.40325,
  -0.40327, -0.40327. The requested `lmax` is used as given.
- **Physical sanity**: incident field alone gives `sum(|E|^2) = 1`; at
  separation 5 µm the intensity relaxes towards 1.012 (weak scattering from two
  distant small spheres); the coupled result (1.18555) differs from the
  single-scattering superposition (1.19410), confirming that interparticle
  coupling is active.

## Example result

```json
{"value": 1.1855506354526988, "gradient": -0.40372542061712435}
```

(config: radius 0.08, epsilon [4.0, 0.04], separation 0.3, wavelength 0.72,
lmax 2, point [0.05, 0.02, 0.28]). The full `results.json` also echoes the
inputs and unit labels.

## Validity notes

The observation point must lie outside the circumscribing sphere of each
particle (true for the example: distances 0.30 and 0.29 µm vs. radius 0.08 µm),
and the separation must exceed twice the radius for the two-center expansion to
converge. No check is enforced for these; they are the caller's responsibility.
