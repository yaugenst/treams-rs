# Sphere-radius inverse design from scattering efficiencies

## Problem and forward model

A homogeneous, lossless sphere (relative `epsilon`, `mu = 1`, `kappa = 0`) sits in
vacuum. For each wavelength we build the analytic Mie/T-matrix of the sphere with
`treams_rs.advect.sphere_tmatrix` (the Advect-differentiable wrapper of the same
native sphere operation as `treams_rs.sphere_tmatrix`) and evaluate the scattering
cross section for a `+z` plane wave:

```
Q_sca(lambda, r) = sigma_sca(lambda, r) / (pi r^2),   k0 = 2 pi / lambda
```

Because a sphere is rotationally symmetric and dual-symmetric in its response, the
cross section is independent of the incidence direction and polarization, so the
single-plane-wave result equals the orientation/polarization average. This was
verified numerically: `TMatrix.xs_sca_avg`, `TMatrix.xs(plane_wave)` for both
helicities, and `advect.TMatrix.cross_sections` agree to ~1e-15 relative.

## Units and conventions

* Lengths (radius, bounds, wavelengths) are in micrometers; `k0 = 2*pi/lambda` is in
  1/um and cross sections in um^2. The efficiency `Q` is dimensionless.
* `epsilon`, `mu`, `kappa` are relative/dimensionless; exterior medium is vacuum
  (`medium=1.0`), `mu=1`, `kappa=0`.
* Helicity polarization basis (treams-rs default); `lmax` is the fixed multipole
  truncation used for all wavelengths.
* Efficiencies are normalized by the geometric cross section `pi r^2` of the
  *current* radius, so the `1/r^2` factor also contributes to the gradient.

## Objective and derivatives

```
L(r) = mean_i ( (Q_i(r) - target_i) / target_i )^2
```

`dL/dr` is obtained analytically: the whole forward evaluation is traced by
`advect.value_and_grad`, which uses the native first-order pullbacks of the
treams-rs sphere operation. No finite differences enter the objective, the
gradients, or the optimization steps; finite differences were used only as an
independent check (see below).

## Optimization

Projected gradient descent on the scalar radius, started at `initial_radius` and
clipped to `bounds` at every step: Barzilai-Borwein trial step with Armijo
backtracking line search, stopping at `L < 1e-9`, a vanishing gradient, or 200
iterations. If that local basin fails to reach `L < 1e-7` (possible because `Q(r)`
is oscillatory and the problem can be multimodal), a coarse forward-only scan of
the bounds selects the most promising basins and the *same* analytic-gradient
descent is rerun from them; `loss_history` then contains the concatenated
iterates. All reported quantities are re-evaluated at the final radius.

## Result for the example config

* `radius = 0.10999999 um` (targets were generated at 0.11 um)
* `loss = 1.23e-13`, `initial_loss = 0.6215`, well below the required `1e-7`
* final `gradient = dL/dr = -2.57e-05`
* fitted efficiencies `[1.5627976, 0.8019213, 0.4253870]`, relative residuals ~ -3.5e-7

Results are in `results.json`.

## Checks performed

* Cross-section consistency across three independent treams-rs entry points (above).
* Analytic vs. central-difference derivative: `dQ/dr` 16.49245816 vs 16.49245816;
  final `dL/dr` -2.5650e-5 vs -2.5650e-5 (validation only).
* Round-trip recovery for independent configurations (epsilon = 2.25/4/9/12,
  lmax = 2..6, 1-4 wavelengths, starts inside and far outside the correct basin):
  the true radius is recovered with final loss between 1e-30 and 1e-12.
* Note: with a single wavelength the inverse problem is genuinely degenerate
  (different radii can reproduce the same `Q`); the solver still reaches
  `loss < 1e-7` but the recovered radius need not be unique.

## Usage

```
python solution.py < example_config.json > results.json
```
or `from solution import run; run(config)`.
