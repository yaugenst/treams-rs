"""Infer a lossless sphere radius from target scattering efficiencies.

The forward model is the analytic Mie (homogeneous-sphere) T-matrix of
treams-rs; radius gradients come from the native pullbacks exposed through the
installed Advect adapter (``treams_rs.advect``).
"""

from __future__ import annotations

import json
import sys

import advect
import numpy as np
from treams_rs import advect as tra

anp = advect.numpy

LOSS_TARGET = 1e-9   # internal stopping tolerance (task requires < 1e-7)
MAX_ITER = 200


def _efficiencies(radius, wavelengths, epsilon, lmax):
    """Orientation/polarization-independent Q_sca of a sphere in vacuum.

    Q_sca = sigma_sca / (pi r^2).  For a sphere the cross section does not
    depend on the incidence direction or polarization, so a single +z plane
    wave reproduces the rotational average.
    """
    qs = []
    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl              # vacuum wavenumber, 1/um
        tm = tra.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius,
                                material=epsilon, medium=1.0)
        illu = tra.PlaneWave([0.0, 0.0, 1.0], 0, k0=k0, medium=1.0)
        qs.append(tm.cross_sections(illu).scattering / (np.pi * radius ** 2))
    return anp.stack(qs)


def _make_objective(wavelengths, epsilon, lmax, targets):
    def loss(radius):
        q = _efficiencies(radius, wavelengths, epsilon, lmax)
        return anp.mean(((q - targets) / targets) ** 2)
    return loss, advect.value_and_grad(loss)


def _descend(value_and_grad, r0, lo, hi, history):
    """Projected gradient descent, Armijo backtracking + Barzilai-Borwein."""
    r = float(min(max(r0, lo), hi))
    f, g = value_and_grad(r)
    f, g = float(f), float(g)
    history.append(f)
    step = 1e-3 * max(hi - lo, 1e-12) / max(abs(g), 1e-12)
    prev_r = prev_g = None

    for _ in range(MAX_ITER):
        if f < LOSS_TARGET or abs(g) < 1e-14:
            break
        if prev_r is not None:
            dr, dg = r - prev_r, g - prev_g
            if abs(dg) > 0:
                bb = abs(dr / dg)          # Barzilai-Borwein trial step
                if np.isfinite(bb) and bb > 0:
                    step = bb
        accepted = False
        for _ls in range(60):              # backtracking line search
            cand = float(min(max(r - step * g, lo), hi))
            if cand == r:
                break
            fc = float(value_and_grad(cand)[0])
            if fc <= f - 1e-4 * g * (r - cand):   # Armijo on the taken step
                prev_r, prev_g = r, g
                r = cand
                f, gv = value_and_grad(r)
                f, g = float(f), float(gv)
                history.append(f)
                step *= 2.0
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break
    return r, f, g


def run(config):
    epsilon = complex(config["epsilon"]).real if not isinstance(
        config["epsilon"], (list, tuple)) else config["epsilon"]
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    targets = np.asarray([float(t) for t in config["target_efficiencies"]], float)
    lo, hi = (float(b) for b in config["bounds"])
    if lo > hi:
        lo, hi = hi, lo
    r0 = float(min(max(float(config["initial_radius"]), lo), hi))

    loss_fn, vg = _make_objective(wavelengths, epsilon, lmax, targets)
    initial_loss = float(loss_fn(r0))

    history: list[float] = []
    radius, loss, grad = _descend(vg, r0, lo, hi, history)

    if loss >= 1e-7:
        # The local basin around initial_radius did not reach the tolerance:
        # coarse forward scan to locate the global basin, then the same
        # analytic-gradient descent from there.
        grid = np.linspace(lo, hi, 161)
        vals = [float(loss_fn(g)) for g in grid]
        for idx in np.argsort(vals)[:6]:
            r_try, f_try, g_try = _descend(vg, float(grid[idx]), lo, hi, history)
            if f_try < loss:
                radius, loss, grad = r_try, f_try, g_try
            if loss < LOSS_TARGET:
                break

    q = np.asarray(_efficiencies(radius, wavelengths, epsilon, lmax), float)
    return {
        "radius": float(radius),
        "loss": float(loss),
        "initial_loss": initial_loss,
        "gradient": float(grad),
        "fitted_efficiencies": [float(x) for x in q],
        "loss_history": [float(x) for x in history],
        "converged": bool(loss < 1e-7),
        "bounds": [lo, hi],
        "wavelengths": wavelengths,
        "target_efficiencies": [float(x) for x in targets],
        "relative_residuals": [float(a / b - 1.0) for a, b in zip(q, targets)],
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
