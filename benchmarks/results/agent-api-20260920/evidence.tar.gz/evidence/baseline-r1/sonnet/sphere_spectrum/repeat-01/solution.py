import sys
import json
import math

import treams_rs as t


def run(config):
    radius = config["radius"]
    eps_re, eps_im = config["epsilon"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    material = t.Material(complex(eps_re, eps_im))
    area = math.pi * radius**2

    scattering = []
    extinction = []
    absorption = []
    efficiency = []

    for wavelength in wavelengths:
        k0 = 2 * math.pi / wavelength
        tm = t.TMatrix.sphere(lmax, k0, radius, [material, 1])
        pw = t.plane_wave(
            direction=[0, 0, 1],
            polarization="positive_helicity",
            k0=k0,
            material=1,
        )
        cs = tm.cross_sections(pw)
        scattering.append(cs.scattering)
        extinction.append(cs.extinction)
        absorption.append(cs.absorption)
        efficiency.append(cs.scattering / area)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
