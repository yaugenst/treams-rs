# Homogeneous dielectric sphere spectrum

## Method

`solution.py` uses `treams_rs` to build the T-matrix of a homogeneous, isotropic
sphere (`treams_rs.TMatrix.sphere`) and computes its cross sections
(`TMatrix.cross_sections`) for a normally incident (+z), positive-helicity
plane wave (`treams_rs.plane_wave`) at each requested wavelength.

For each wavelength `wl` in the input:

1. Vacuum angular wavenumber `k0 = 2*pi/wl`.
2. Sphere material `Material(epsilon = epsilon_re + 1j*epsilon_im, mu=1, kappa=0)`
   in a vacuum exterior (`material=1`).
3. T-matrix `TMatrix.sphere(lmax, k0, radius, [material, 1])`.
4. Incident plane wave with `direction=[0, 0, 1]` and
   `polarization="positive_helicity"`.
5. `cross_sections(pw)` gives scattering, extinction, and absorption
   (`absorption = extinction - scattering`), all in area units (same units as
   `radius**2`, i.e. squared micrometers since input lengths are in
   micrometers).
6. Scattering efficiency is `scattering / (pi * radius**2)` (dimensionless).

## Units and conventions

- Lengths (`radius`, `wavelengths`) are in micrometers; cross sections are
  reported in square micrometers.
- `epsilon = [real, imag]` is the relative permittivity of the sphere
  material (not a refractive index); `mu = 1` and chirality `kappa = 0` as per
  the problem statement; the exterior medium is vacuum (`material=1`).
- Illumination is a plane wave propagating along `+z` with positive helicity,
  matching `treams`'s helicity polarization basis.
- `lmax` is the maximum spherical multipole degree used to truncate the
  T-matrix expansion.
- All numerical scattering physics (Mie coefficients via T-matrix, and cross
  sections) is delegated to `treams_rs`; no scattering theory is
  reimplemented here.

## Checks performed

- Energy consistency: for every wavelength, `scattering + absorption`
  reproduces `extinction` returned directly by `treams_rs` to machine
  precision (verified numerically, differences are exactly 0.0 in the tested
  example).
- Spectrum shape: for the example config (radius 0.1 µm, epsilon
  `12 + 0.05j`, lmax 4), the computed spectrum shows the expected Mie-type
  resonance behavior (a low-scattering point near 0.45 µm rising to broad
  resonances at longer wavelengths), consistent with a small high-index
  dielectric sphere.
- The example config was executed end-to-end through the CLI
  (`python3 solution.py < example_config.json`) and the JSON output was saved
  to `results.json`.

## Example results (radius=0.1 µm, epsilon=[12, 0.05], lmax=4)

| wavelength (µm) | scattering (µm²) | extinction (µm²) | absorption (µm²) | efficiency |
|---|---|---|---|---|
| 0.45 | 0.027146 | 0.029162 | 0.002016 | 0.864076 |
| 0.55 | 0.162475 | 0.165116 | 0.002640 | 5.171755 |
| 0.65 | 0.139805 | 0.141890 | 0.002084 | 4.450143 |
| 0.75 | 0.179337 | 0.186677 | 0.007340 | 5.708469 |

Full machine-precision values are in `results.json`.
