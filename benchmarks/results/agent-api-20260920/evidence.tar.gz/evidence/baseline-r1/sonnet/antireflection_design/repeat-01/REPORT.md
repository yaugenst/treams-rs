# Single-Layer Antireflection Coating Optimization

## Problem

A lossless dielectric coating of thickness `d` sits directly on a semi-infinite
substrate (no vacuum gap between coating and substrate); vacuum illuminates the
stack at normal incidence from `+z`. We minimize the reflected power `R(d)` over
`d` in `[bounds[0], bounds[1]]`, starting from `initial_thickness`, using
gradient-based optimization with treams-rs's analytic derivatives.

## Units and conventions

- Lengths (`wavelength`, `thickness`, `bounds`) are in micrometers.
- `epsilon`/`substrate_epsilon` are relative permittivities (dimensionless);
  `mu = 1`, chirality `kappa = 0`, exterior medium is vacuum (`epsilon = 1`).
- The vacuum wavenumber is `k0 = 2*pi/wavelength`.
- Reflection `R` is a power fraction (dimensionless, unpolarized/normal-incidence
  helicity basis; at normal incidence in an isotropic medium the two helicity
  channels are degenerate so `R` is polarization independent).

## Method

The stack is built with `treams_rs.advect.multilayer_slab` (one interior layer,
`negative_medium=vacuum`, `positive_medium=substrate`), producing an `SMatrix`.
A normal-incidence `PlaneWave` (helicity polarization) illuminates the negative
side, and `SMatrix.power(incident).reflection` returns the reflected power `R`.

Because `treams_rs.advect` wraps every native operation as an `advect` primitive
with a recorded analytic pullback (chaining through the native `layer_stack` and
`smatrix_tr` VJPs described in `treams_rs.diff`), `advect.value_and_grad` gives
`dR/d(thickness)` directly from treams-rs's own reverse-mode derivative — no
finite differences and no closed-form (e.g. quarter-wave) formula are used to
produce the optimization step.

Optimization is projected gradient descent with Armijo-style backtracking line
search on `d`, always keeping `d` inside `bounds`:
1. Evaluate `(R, dR/dd)` at the current thickness.
2. Try `d_new = clip(d - step * dR/dd, lo, hi)`; halve `step` until `R` at
   `d_new` improves (or `d_new` is stuck at a bound).
3. Grow `step` slightly after an accepted move and repeat until `R < 1e-10`
   (well below the required `1e-7`) or no further improvement is possible
   (e.g. optimum lies outside `bounds`, or the coating/substrate indices do
   not admit a perfect null).

`loss_history` records `R` at each accepted iterate (including the initial
point).

## Verification

- **Analytic vs. finite-difference gradient**: at several thicknesses the
  `advect` gradient of `R` agrees with a central finite difference
  (`h = 1e-6`) to a relative error of order `1e-10`, confirming the native
  pullback chain is correct (finite differences are used only to validate,
  never to supply the optimizer's step).
- **Physical sanity**: for the example config, `n_coat = sqrt(2.25) = 1.5`
  exactly satisfies the ideal single-layer index-matching condition
  `n_coat = sqrt(n_vacuum * n_substrate) = sqrt(2.25) = 1.5`
  (`n_substrate = sqrt(5.0625) = 2.25`), so a perfect null is physically
  achievable; the optimizer converges to `d ≈ 0.11667 µm`, matching the
  expected quarter-wave optical thickness `wavelength/(4 n_coat) = 0.11667 µm`
  as an emergent result of the gradient search (not imposed).
- Additional configs were checked where the index-matching condition is *not*
  exactly satisfied (e.g. mismatched `epsilon`/`substrate_epsilon`); there the
  optimizer converges to the nearest local minimum of `R(d)`, whose residual
  value matches the standard three-medium interference-minimum formula, and
  respects `bounds` (clipping to an edge when the true minimum lies outside
  the allowed range).

## Example result (`results.json`)

For the example config (`wavelength=0.7`, `epsilon=2.25`,
`substrate_epsilon=5.0625`, `initial_thickness=0.05`, `bounds=[0.025, 0.21]`):

- `thickness ≈ 0.11667 µm`
- `reflection ≈ 2.3e-12` (well under the `1e-7` requirement)
- `initial_reflection ≈ 0.0959`
- `gradient` (final `dR/dd`) `≈ 1.7e-5` (near zero, confirming convergence to
  a stationary point)
- `loss_history`: monotonically decreasing sequence of `R` values from the
  initial point to convergence (see `results.json`).
