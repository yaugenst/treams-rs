"""Single-layer antireflection coating optimization via treams-rs analytic gradients.

Minimizes normal-incidence reflected power of a lossless dielectric coating on a
substrate (vacuum incidence, no vacuum gap after the coating) by gradient descent
on the coating thickness, using treams-rs's native analytic derivative through its
Advect adapter (treams_rs.advect / the `advect` autodiff package). No finite-wave
closed-form (quarter-wave) formula is substituted for the optimization; the
gradient-based loop performs the search.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import advect as ad
import treams_rs.advect as ta
import treams_rs._core as core


def _reflection_fn(basis, k0, eps_coat, eps_sub):
    def reflection(thickness):
        smat = ta.multilayer_slab(
            basis=basis,
            k0=k0,
            thicknesses=ad.asarray([thickness]),
            materials=[eps_coat],
            negative_medium=1.0,
            positive_medium=eps_sub,
        )
        incident = ta.PlaneWave([0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0)
        return smat.power(incident).reflection

    return reflection


def run(config: dict) -> dict:
    wavelength = float(config["wavelength"])
    eps_coat = float(config["epsilon"])
    eps_sub = float(config["substrate_epsilon"])
    t0 = float(config["initial_thickness"])
    lo, hi = (float(v) for v in config["bounds"])

    k0 = 2.0 * np.pi / wavelength

    # Normal-incidence plane-wave port basis (helicity polarization, kx=ky=0).
    basis = core.PlaneWaveBasisByUnitVector.default([0.0, 0.0, 1.0]).bycomp(
        k0, alignment="xy", material=1.0
    )
    reflection = _reflection_fn(basis, k0, eps_coat, eps_sub)
    value_and_grad = ad.value_and_grad(reflection)

    t = min(max(t0, lo), hi)
    r, g = value_and_grad(t)
    initial_reflection = float(r)
    loss_history = [float(r)]

    target = 1e-10
    step = 0.01 * max(hi - lo, 1e-6)
    max_iters = 300
    for _ in range(max_iters):
        if r < target:
            break
        trial_step = step
        r_new, g_new, t_new = r, g, t
        for _ in range(60):
            candidate = min(max(t - trial_step * g, lo), hi)
            r_candidate, g_candidate = value_and_grad(candidate)
            if r_candidate < r or candidate in (lo, hi):
                r_new, g_new, t_new = r_candidate, g_candidate, candidate
                break
            trial_step *= 0.5
        if r_new >= r and t_new == t:
            break
        step = trial_step * 1.5
        t, r, g = t_new, r_new, g_new
        loss_history.append(float(r))

    return {
        "thickness": float(t),
        "reflection": float(r),
        "initial_reflection": initial_reflection,
        "gradient": float(g),
        "loss_history": loss_history,
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
