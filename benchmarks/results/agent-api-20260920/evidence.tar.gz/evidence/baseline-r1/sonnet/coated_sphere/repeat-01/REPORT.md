# Core-Shell Sphere Scattering

## Problem
Compute rotationally averaged scattering, extinction and absorption cross
sections of a concentric core-shell sphere embedded in a homogeneous
dielectric exterior, as a function of wavelength.

## Method
`treams_rs.TMatrix.sphere` builds the exact multilayer Mie T-matrix for a
concentric, isotropic, non-magnetic, achiral sphere:

- `radii`: strictly increasing outer boundaries of each layer (inside-out),
  in micrometers.
- `materials`: one `treams_rs.Material(epsilon=...)` per layer (inside-out,
  matching `radii`), **followed by** one extra `Material` for the exterior
  medium (`epsilon_medium`). The exterior is *not* listed in `radii` — it is
  the semi-infinite region beyond the last radius.
- `k0 = 2*pi/wavelength` is the vacuum angular wavenumber (inverse
  micrometers), consistent with lengths in micrometers.
- `lmax` sets the maximum spherical multipole degree included in the
  T-matrix expansion.

For each wavelength the T-matrix is (re)built (materials are frequency
independent here, so only `k0` changes) and
`TMatrix.average_cross_sections` returns the rotationally and
polarization-averaged `CrossSections` namedtuple (`scattering`,
`extinction`, with `absorption` as a derived property
`extinction - scattering`). All three are in squared-length units
(micrometers^2, consistent with `radii` in micrometers).

## Units and conventions
- Lengths (radii, wavelengths): micrometers.
- Cross sections: micrometers^2.
- Permittivities: relative, complex, given as `[real, imag]` pairs
  (imag >= 0 for a physically passive/absorbing medium).
- `mu = 1`, `kappa (chirality) = 0` for all layers and the exterior (not
  exposed as config options here).
- Default polarization type is "helicity" (treams_rs default); rotational
  averaging removes any basis/orientation dependence, so the result is a
  scalar cross section per wavelength.

## Checks performed
- **Energy balance**: for every wavelength in the example config,
  `scattering + absorption == extinction` to floating-point precision
  (verified numerically, difference exactly `0.0`).
- **lmax convergence**: increasing `lmax` from 2 to 8 for the example
  config converges the scattering cross section to 6+ significant digits
  (0.034292 -> 0.0343159 -> 0.03431592 -> 0.03431592), confirming `lmax=4`
  is already adequate for these small (deeply sub-wavelength) particles,
  and that results are not an artifact of truncation.
- Cross sections are strictly positive and absorption is positive
  (consistent with the lossy, imag(epsilon) > 0 layers in the example).

## Example results
See `results.json`, produced by running:

```
python3 solution.py < example_config.json > results.json
```

for the example config (radii = [0.07, 0.12] um, core epsilon = 2.25+0.03j,
shell epsilon = 4+0.06j, exterior epsilon = 1.7689, wavelengths
[0.58, 0.7, 0.82] um, lmax = 4).

## Notes
`run(config)` does not hard-code any example-specific values; it reads
`radii`, `epsilon_layers`, `epsilon_medium`, `wavelengths` and `lmax`
directly from the input config dictionary and works for any number of
layers/wavelengths.
