import json
import math
import sys

import treams_rs as t


def run(config):
    radii = config["radii"]
    epsilon_layers = config["epsilon_layers"]
    epsilon_medium = config.get("epsilon_medium", 1.0)
    wavelengths = config["wavelengths"]
    lmax = config.get("lmax", 4)

    def to_complex(e):
        if isinstance(e, (list, tuple)):
            return complex(e[0], e[1])
        return complex(e)

    materials = [t.Material(epsilon=to_complex(e)) for e in epsilon_layers]
    materials.append(t.Material(epsilon=to_complex(epsilon_medium)))

    scattering = []
    extinction = []
    absorption = []

    for wl in wavelengths:
        k0 = 2.0 * math.pi / wl
        tm = t.TMatrix.sphere(lmax, k0, radii, materials)
        avg = tm.average_cross_sections
        scattering.append(avg.scattering)
        extinction.append(avg.extinction)
        absorption.append(avg.absorption)

    return {
        "wavelengths": list(wavelengths),
        "scattering_cross_section": scattering,
        "extinction_cross_section": extinction,
        "absorption_cross_section": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
