"""Infer a homogeneous sphere radius from target scattering efficiencies.

Uses treams-rs (via its advect adapter) to compute the scattering efficiency
Q_sca = C_sca / (pi r^2) of a homogeneous sphere at each wavelength, and its
analytic derivative with respect to the radius, then fits the radius by
gradient descent on mean(((Q - target) / target)**2), projected into bounds.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import advect as ad
import treams_rs.advect as adv


def _qsca_and_grad(radius: float, k0s, lmax: int, epsilon: float):
    """Return (efficiencies, d(efficiency)/d(radius)) for each k0 in k0s."""

    def single(r, k0):
        tm = adv.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=r, material=epsilon, medium=1.0,
            polarization="helicity",
        )
        pw = adv.plane_wave([0.0, 0.0, k0], [1.0, 0.0], k0=k0, medium=1.0)
        cs = tm.cross_sections(pw)
        return cs.scattering / (np.pi * r ** 2)

    values = []
    grads = []
    for k0 in k0s:
        v, g = ad.value_and_grad(lambda r, k0=k0: single(r, k0))(radius)
        values.append(float(v))
        grads.append(float(g))
    return np.array(values), np.array(grads)


def _loss_and_grad(radius: float, k0s, lmax: int, epsilon: float, targets: np.ndarray):
    q, dq = _qsca_and_grad(radius, k0s, lmax, epsilon)
    resid = (q - targets) / targets
    loss = float(np.mean(resid ** 2))
    dloss = float(np.mean(2.0 * resid / targets * dq))
    return loss, dloss, q


def run(config: dict) -> dict:
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = np.asarray(config["wavelengths"], dtype=float)
    k0s = 2.0 * np.pi / wavelengths
    targets = np.asarray(config["target_efficiencies"], dtype=float)
    radius = float(config["initial_radius"])
    lo, hi = (float(config["bounds"][0]), float(config["bounds"][1]))

    initial_loss, initial_grad, initial_q = _loss_and_grad(
        radius, k0s, lmax, epsilon, targets
    )

    loss_history = [initial_loss]
    loss = initial_loss
    grad = initial_grad
    q = initial_q

    max_iters = 500
    step = 1e-3
    for _ in range(max_iters):
        if loss < 1e-7:
            break
        trial_radius = radius - step * grad
        trial_radius = min(max(trial_radius, lo), hi)
        trial_loss, trial_grad, trial_q = _loss_and_grad(
            trial_radius, k0s, lmax, epsilon, targets
        )
        if trial_loss < loss:
            radius, loss, grad, q = trial_radius, trial_loss, trial_grad, trial_q
            step *= 1.2
        else:
            step *= 0.5
            if step < 1e-14:
                break
            continue
        loss_history.append(loss)

    return {
        "radius": radius,
        "loss": loss,
        "initial_loss": initial_loss,
        "gradient": grad,
        "fitted_efficiencies": q.tolist(),
        "loss_history": loss_history,
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
