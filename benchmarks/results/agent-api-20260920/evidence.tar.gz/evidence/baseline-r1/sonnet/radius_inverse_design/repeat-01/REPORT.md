# Radius inverse design from scattering efficiencies

## Problem
Given a homogeneous, lossless, non-magnetic, achiral sphere of fixed
permittivity `epsilon` (relative, dimensionless) embedded in vacuum, and a set
of target scattering efficiencies `Q_target(lambda)` measured at several
vacuum wavelengths, find the sphere radius that best reproduces the targets
in a least-squares sense:

    loss(r) = mean( ((Q(r, lambda_i) - Q_target_i) / Q_target_i)^2 )

## Units and conventions
- All lengths (`radius`, `wavelengths`, `bounds`) are in micrometers.
- `epsilon` is the relative permittivity of the sphere; `mu = 1`,
  `chirality (kappa) = 0`, exterior medium is vacuum (`epsilon = mu = 1`),
  matching the task defaults.
- The vacuum angular wavenumber is `k0 = 2*pi / lambda` (inverse micrometers),
  consistent with treams-rs's convention that `radius` and `1/k0` share units.
- The scattering efficiency is the standard normalized cross section
  `Q_sca = C_sca / (pi * r^2)`, where `C_sca` is the scattering cross section
  computed by treams-rs's Mie/T-matrix solver (`sphere_tmatrix`) for a single
  plane-wave illumination. Because a homogeneous sphere is fully isotropic,
  the cross section for one plane wave (any direction/polarization) equals
  the polarization- and direction-averaged cross section
  (`TMatrix.average_cross_sections`); this was checked numerically to agree
  to machine precision and used as a redundant self-consistency check.

## Method
- Numerics: `treams_rs.advect.sphere_tmatrix` builds a homogeneous-sphere
  T-matrix as a differentiable ("Advect") object; `cross_sections` on a
  helicity plane wave gives the scattering cross section as a traced value.
  `advect.value_and_grad` back-propagates through the native pullback to give
  the exact analytic derivative dQ/dr at each wavelength — no finite
  differences and no reimplementation of Mie theory.
- Optimization: the radius is fit by gradient descent on the mean relative
  squared residual, using the exact analytic gradient
  `dloss/dr = mean(2 * resid_i / target_i * dQ_i/dr)`. Steps are backtracked
  (halved) when they increase the loss and grown (x1.2) when they succeed,
  and the radius is clipped to `bounds` after every step (projected gradient
  descent). Iteration stops when `loss < 1e-7` or after 500 iterations / a
  vanishing step size.
- `initial_loss` and `gradient` (the final analytic derivative of the loss at
  the returned radius) are recorded, together with the full `loss_history`
  and the `fitted_efficiencies` at the returned radius.

## Checks performed
- Verified `TMatrix.cross_sections` for one plane wave matches
  `average_cross_sections` for a sphere (isotropy check).
- Verified the analytic gradient from `advect.value_and_grad` against a
  central finite difference (`eps = 1e-6`); relative agreement is at the
  1e-6 level or better.
- Verified recovery of a known ground-truth radius: generated synthetic
  targets from a sphere of radius 0.12 um at 6 wavelengths and confirmed the
  optimizer recovers `r = 0.11999832` um starting from `r0 = 0.08` um with
  `loss = 2.4e-9`.
- Ran the provided example config (see `results.json`): converges to
  `radius = 0.110000` um with `loss = 1.2e-10 < 1e-7`, well inside the bounds
  `[0.06, 0.14]`.
- Confirmed no example values are hard-coded: `run()` only reads keys from
  the supplied `config` dict and re-derives everything numerically.

## Files
- `solution.py`: `run(config)` and CLI (reads JSON config from stdin, writes
  JSON result to stdout).
- `results.json`: output of `python3 solution.py < example_config.json` for
  the example config given in the task.
