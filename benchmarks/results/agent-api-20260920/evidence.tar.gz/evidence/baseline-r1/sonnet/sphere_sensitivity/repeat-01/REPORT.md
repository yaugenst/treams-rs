# Scattering efficiency and sensitivity of a lossy sphere

## Physical setup

A homogeneous, isotropic sphere of radius `radius` (μm) sits at the origin in
vacuum and is illuminated by a plane wave propagating along `+z` with
**positive helicity** (pure right-handed circular polarization in the
helicity basis). The sphere material has relative permittivity
`epsilon_real + i*epsilon_imag` (dimensionless, `epsilon_imag > 0` for a
lossy/absorbing medium), relative permeability `mu = 1`, and zero chirality.
The vacuum wavenumber is `k0 = 2*pi/wavelength`, with `wavelength` in μm
(consistent with `radius` also being in μm — treams-rs only requires that
`radius` and `1/k0` share a length unit).

The scattering efficiency is

    Q = sigma_sca / (pi * radius**2)

where `sigma_sca` is the scattering cross section (μm²) obtained from the
sphere's Mie T-matrix and the incident plane wave.

## Numerics (treams-rs)

- `treams_rs.sphere_tmatrix(...)` builds the homogeneous-sphere T-matrix in
  the helicity multipole basis, expanded up to degree `lmax`.
- `treams_rs.PlaneWave([0, 0, k0], [0, 1], k0=k0, poltype="helicity")`
  represents the +z, positive-helicity incident wave (amplitude 1 on the
  positive-helicity channel, 0 on the negative one).
- `TMatrix.cross_sections(incident)` returns the scattering/extinction cross
  sections (area units, μm²) for a nonabsorbing, propagating exterior medium
  (vacuum here), which is required for the cross-section normalization to be
  well defined.
- `Q` is then `sigma_sca / (pi * radius**2)`.

This was verified against the plain (non-differentiable) `treams_rs` API for
the example config: `Q ≈ 0.4634`.

## Analytic derivatives

Gradients `dQ/dradius` and `dQ/depsilon_real` (holding `epsilon_imag`,
`wavelength`, `lmax` fixed) are obtained with **reverse-mode automatic
differentiation** through the `treams_rs.advect` adapters, which wrap the
native Rust Mie-scattering kernels with analytic pullbacks (via the
`advect` package, treams-rs's declared `[advect]` dependency):

- `treams_rs.advect.sphere_tmatrix(...)` builds the T-matrix from
  differentiable `radius`/`material` inputs (native pullback through the
  spherical Bessel/Mie coefficients).
- `treams_rs.advect.PlaneWave(...).cross_sections(...)` differentiates the
  cross-section contraction itself.
- The final division by `pi * radius**2` (the normalization) is performed
  as part of the traced function, so its derivative with respect to
  `radius` is also captured analytically by `advect.value_and_grad`,
  not just the cross section's.

No finite differences are used to produce the returned gradient; they are
only used below to validate it.

## Verification

For the example config, central finite differences (`h = 1e-6`) give:

    dQ/dradius       ≈ 18.653670304... (analytic: 18.653670304796...)
    dQ/depsilon_real ≈  0.199725546...  (analytic:  0.199725546456...)

Agreement to ~7–8 significant figures, for both the example config and an
independently chosen config (`radius=0.25`, `epsilon_real=6.5`,
`epsilon_imag=0.3`, `wavelength=1.1`, `lmax=5`), confirming the analytic
reverse-mode gradient is correct and not hard-coded to the example.

## I/O contract

`solution.py` exposes `run(config)` taking a dict with keys `radius`,
`epsilon_real`, `epsilon_imag`, `wavelength`, `lmax`, and returning
`{"Q": <float>, "gradient": [dQ/dradius, dQ/depsilon_real]}`. Run from the
command line, it reads one JSON config object from stdin and prints the
result dict as JSON to stdout.

Example result (`results.json`), for the config given in the prompt:

    {"Q": 0.46337644643427434, "gradient": [18.65367030479629, 0.1997255464561844]}
