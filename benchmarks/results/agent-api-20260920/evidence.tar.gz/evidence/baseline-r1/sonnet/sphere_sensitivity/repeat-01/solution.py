"""Scattering efficiency and its gradient for a lossy sphere under +z, positive-helicity incidence.

Uses treams-rs (Mie theory via T-matrices) for the physics and its `advect`-backed
adapters for analytic reverse-mode derivatives of Q = sigma_sca / (pi * radius**2)
with respect to (radius, epsilon_real), holding epsilon_imag/wavelength/lmax fixed.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import advect as ad
import treams_rs as treams
import treams_rs.advect as tadvect


def _scattering_efficiency(radius, epsilon_real, epsilon_imag, k0, lmax):
    material = tadvect.Material(epsilon_real + 1j * epsilon_imag, 1.0, 0.0)
    tm = tadvect.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=material, polarization="helicity"
    )
    incident = tadvect.PlaneWave([0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0)
    cross_sections = tm.cross_sections(incident)
    return cross_sections.scattering / (np.pi * radius**2)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    k0 = 2.0 * np.pi / wavelength

    def q_of(radius_, epsilon_real_):
        return _scattering_efficiency(radius_, epsilon_real_, epsilon_imag, k0, lmax)

    Q, (dQ_dradius, dQ_depsilon_real) = ad.value_and_grad(q_of, argnums=(0, 1))(
        radius, epsilon_real
    )

    return {
        "Q": float(Q),
        "gradient": [float(dQ_dradius), float(dQ_depsilon_real)],
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
