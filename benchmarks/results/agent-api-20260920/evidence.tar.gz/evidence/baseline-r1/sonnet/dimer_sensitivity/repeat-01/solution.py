"""Dimer sensitivity: value=sum|E_total|^2 at a point and dvalue/dseparation.

Two identical homogeneous spheres at (-separation/2, 0, 0) and (+separation/2, 0, 0),
illuminated along +z by a positive-helicity plane wave of unit amplitude, with full
multiple scattering. Lengths in micrometers; epsilon=[real, imag] is relative
permittivity (mu=1, achiral, vacuum exterior). value/gradient are computed with
treams-rs's differentiable native primitives (via the Advect adapter), using its
analytic reverse-mode pullbacks through the cluster T-matrix, plane-wave expansion
and field evaluation; no finite differences are used for the returned gradient.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import advect as ad
import advect.numpy as anp
import treams_rs as t
import treams_rs.advect as ta


def _build(config: dict) -> tuple:
    radius = float(config["radius"])
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=float).reshape(1, 3)

    k0 = 2.0 * np.pi / wavelength
    basis_template = t.SphericalBasis.default(lmax, nmax=2)
    vec = np.array([[0.0, 0.0, k0]])
    pol = np.array([1])  # positive helicity
    ks = np.array([k0, k0])
    radii = np.array([radius, radius])
    epsilons = np.array([epsilon, epsilon])
    pw = t.PlaneWave([0.0, 0.0, k0], [0.0, 1.0], k0=k0)
    einc = pw.efield(point)

    def value_fn(separation):
        half = separation / 2.0
        zero = anp.asarray(0.0)
        positions = anp.stack(
            [
                anp.stack([-half, zero, zero]),
                anp.stack([half, zero, zero]),
            ]
        )
        tmat = ta.cluster(lmax, k0, radii, epsilons, positions)
        inc = ta.plane_expansion(
            positions, vec, destination=basis_template, polarizations=pol,
            fixed_vectors=True,
        )[:, 0]
        scattered = tmat @ inc
        escat = ta.field(
            scattered, point, positions, ks, basis=basis_template, singular=True
        )
        etotal = escat + einc
        return anp.sum(anp.abs(etotal) ** 2)

    return value_fn


def run(config: dict) -> dict:
    value_fn = _build(config)
    separation = float(config["separation"])
    value, gradient = ad.value_and_grad(value_fn)(separation)
    return {"value": float(value), "gradient": float(gradient)}


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
