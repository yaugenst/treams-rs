# Dimer sensitivity: field intensity at a point vs. sphere separation

## Physical setup

Two identical homogeneous, isotropic, non-magnetic spheres (radius `radius`,
relative permittivity `epsilon = eps_re + i*eps_im`, mu=1, chirality=0) sit in
vacuum at Cartesian positions `(-separation/2, 0, 0)` and `(+separation/2, 0, 0)`.
They are illuminated by a unit-amplitude plane wave propagating along `+z` with
positive helicity (equal-magnitude, phase-quadrature Ex/Ey producing a
circularly polarized wave of definite helicity, in treams' helicity
polarization convention). Full multiple scattering between the two spheres is
included via the interacting cluster T-matrix (Foldy–Lax / coupled-dipole-like
solve, generalized to all included multipole orders up to `lmax`).

At the fixed observation point `point = (x, y, z)`, the code evaluates the
total electric field

    E_total(point) = E_incident(point) + E_scattered(point)

and returns

    value    = sum(|E_total|**2)   (sum over the 3 Cartesian components)
    gradient = d(value)/d(separation)

with both sphere positions moving symmetrically (`±separation/2`) as
`separation` changes; the observation point, wavelength, radii, material and
`lmax` are held fixed.

## Units and conventions

- All lengths (`radius`, `separation`, `wavelength`, `point`) are in
  micrometers.
- `epsilon = [real, imag]` is the relative permittivity of the sphere
  material; `mu = 1`, chirality `kappa = 0`, exterior medium is vacuum
  (`epsilon = 1`), following the task's stated defaults.
- The vacuum angular wavenumber is `k0 = 2*pi/wavelength`.
- Polarization/helicity follows treams' convention: helicity labels `0`/`1`
  mean negative/positive helicity; the incident plane wave here has
  coefficients `[0, 1]`, i.e. purely positive helicity, unit amplitude,
  propagating along `+z`.
- The interacting T-matrix maps regular incident multipole coefficients
  (expanded at each sphere's local origin) to outgoing multipole coefficients
  at that same origin, already including all orders of multiple scattering
  between the two spheres (`treams_rs.diff.cluster` / `Cluster.solve()`
  equivalent).
- `value` is dimensionless up to the same units as `|E|**2` for a
  unit-amplitude incident wave (SI-like Gaussian field units used
  internally by treams; only relative comparisons/derivatives are meaningful
  here since the incident amplitude is fixed to 1).

## Numerical method

`solution.py` builds the entire pipeline with treams-rs's native,
differentiable primitives exposed through the `treams_rs.advect` adapter
(built on the `advect` reverse-mode autodiff package):

1. `treams_rs.advect.cluster(lmax, k0, radii, epsilon, positions)` — builds
   the fully interacting (multiple-scattering-included) cluster T-matrix as a
   differentiable function of sphere `positions` (and, more generally, radii
   and permittivities).
2. `treams_rs.advect.plane_expansion(positions, vectors, ...)` — expands the
   incident plane wave into regular multipole coefficients at each sphere's
   (separation-dependent) origin, differentiably in `positions`.
3. Matrix product `T @ incident` (native array op, differentiated by
   `advect`) gives the outgoing (scattered) multipole coefficients at each
   sphere.
4. `treams_rs.advect.field(coefficients, point, origins, ks, ..., singular=True)`
   evaluates the Cartesian scattered E-field at `point`, differentiably in the
   sphere `origins`.
5. The incident field `E_incident(point)` is evaluated once with the ordinary
   (non-traced) `treams_rs.PlaneWave.efield`; it is spatially uniform in the
   sense that it does not depend on the sphere positions, so it contributes
   nothing to `d(value)/d(separation)` beyond its constant additive presence
   in `E_total`.
6. `value = sum(|E_incident + E_scattered|**2)` is formed with `advect.numpy`
   operations so the whole chain from `separation` to `value` is traced.
7. `advect.value_and_grad` performs one reverse-mode pass through this trace
   to obtain `(value, d(value)/d(separation))` analytically — no finite
   differences are used to produce the returned gradient.

This uses only public treams-rs API (`treams_rs`, `treams_rs.diff` via the
`treams_rs.advect` wrappers) and the installed `advect` autodiff package; no
private (`_`-prefixed) symbols are imported directly by `solution.py`.

## Checks performed

- **Consistency with the plain (non-differentiable) API**: for the example
  config, `value` computed through the `advect` pipeline
  (`1.1855506354526986`) exactly matches an independent calculation using
  `treams_rs.TMatrix.sphere` + `treams_rs.Cluster(...).solve()` +
  `Cluster.scatter(...).efield(...)` + `PlaneWave.efield(...)`.
- **Gradient validation against central finite differences** (used only to
  validate, not to produce, the returned gradient):
  - Example config (`separation=0.3`): analytic gradient
    `-0.40372542061712424` vs. central-difference estimate (`h=1e-6`)
    `-0.40372542053912497` (agreement to ~9 significant digits).
  - A second, differently-parameterized config
    (`radius=0.1, epsilon=[3.5, 0.1], separation=0.5, wavelength=0.9, lmax=3,
    point=[0, 0, 0.4]`): analytic gradient `-0.281635590345406` vs.
    finite-difference `-0.28163559018246076` (same level of agreement).
- Verified that `solution.py`'s `run()` is not hard-coded to the example: it
  recomputes `value`/`gradient` from scratch for arbitrary input dictionaries
  with the same keys.

## Example result

For the example config (see `results.json`):

    value    = 1.1855506354526986
    gradient = -0.40372542061712424
