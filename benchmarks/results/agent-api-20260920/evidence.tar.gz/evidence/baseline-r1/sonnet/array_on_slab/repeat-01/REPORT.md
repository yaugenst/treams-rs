# Periodic sphere array on a slab: transmission, reflection, absorption

## Physical setup

A 2D square lattice of identical dielectric spheres sits above a homogeneous
dielectric slab, separated by a vacuum gap. Ordered from the negative-z side
to the positive-z side the stack is:

    vacuum (incidence) | slab | vacuum gap | sphere array | vacuum (exit)

Illumination is a plane wave incident from -z, propagating in +z, with
positive helicity (one of the two circular-polarization eigenstates in the
helicity convention used throughout).

Because all requested wavelengths exceed the lattice period, only the
zeroth diffraction order propagates; both helicities of that order are kept
and the Bloch (in-plane) wavevector is fixed at [0, 0] (normal incidence).

## Units and conventions

- All lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`)
  are in micrometers.
- `sphere_epsilon` and `slab_epsilon` are dimensionless relative
  permittivities; `mu = 1` and chirality `kappa = 0` everywhere, and all
  exterior media are vacuum, per the problem statement.
- The vacuum angular wavenumber is `k0 = 2*pi/wavelength` (inverse
  micrometers), matching the length units used for radius, period, gap and
  thickness.
- Polarization is treated in the helicity basis (`polarization="helicity"`)
  throughout, consistent with the specified illumination helicity.
- The plane-wave basis used for the diffraction/scattering ports is built as
  `treams_rs.PlaneWaveBasis.default([0, 0, 1]).bycomp(k0)`, i.e. the direct
  (zeroth-order) transverse wavevector (0, 0) with both polarization labels,
  matching the required Bloch vector [0, 0] and zeroth-order-only
  truncation.

## Numerical method (treams-rs)

1. Build a homogeneous slab S-matrix with `treams_rs.slab(...)` at the given
   thickness and permittivity, vacuum on both sides.
2. Build a free-space propagation S-matrix with `treams_rs.propagation(...)`
   for the vacuum gap.
3. Build the isolated-sphere T-matrix with `treams_rs.sphere_tmatrix(...)`
   at the fixed `lmax`.
4. Solve the full periodic multiple-scattering problem for the square
   array with `treams_rs.solve_periodic(tmatrix, lattice=[[period,0],
   [0,period]], kpar=[0,0])`, which performs the lattice sum (Ewald
   summation) and interaction solve natively — no hand-rolled diffraction
   physics.
5. Convert the solved periodic response to a diffraction-order S-matrix via
   `PeriodicResponse.to_smatrix(basis)`.
6. Cascade slab -> gap -> array with `treams_rs.stack([...])`, which
   composes all multiple reflections between the three components exactly
   (no Born/single-pass approximation).
7. Construct the incident plane wave with
   `treams_rs.plane_wave(direction=[0,0,1], polarization=
   "positive_helicity", k0=k0, medium=1)` and evaluate
   `SMatrices.power(incident, side="negative")`, which returns transmission
   and reflection power fractions (native `PowerBalance`); absorption is
   `1 - T - R`, exposed as `PowerBalance.absorption`.

All numerical scattering (sphere Mie coefficients, slab Fresnel-type
S-matrices, periodic lattice sums, and power fractions) is computed natively
by treams-rs; this script only assembles inputs and reads outputs.

## Checks performed

- With real (lossless) `sphere_epsilon` and `slab_epsilon`, computed
  absorption is numerically zero (~1e-15, floating-point roundoff) and
  `transmission + reflection ≈ 1` for every wavelength, as expected for a
  lossless stack.
- Varying `radius` and `wavelengths` away from the example values produces
  smoothly varying, physically reasonable transmission/reflection curves
  (checked interactively), confirming the function does not hard-code the
  example answers.

## Example results (`results.json`)

For the example config (`radius=0.06`, `sphere_epsilon=9.0`, `period=0.4`,
`gap=0.12`, `slab_thickness=0.09`, `slab_epsilon=2.25`, `lmax=2`):

| wavelength (um) | transmission | reflection | absorption |
|---:|---:|---:|---:|
| 0.65 | 0.88733 | 0.11267 | ~0 |
| 0.74 | 0.90207 | 0.09793 | ~0 |
| 0.83 | 0.91191 | 0.08809 | ~0 |

## Usage

```
python3 solution.py < config.json > results.json
```

`run(config)` accepts a dictionary with keys `radius`, `sphere_epsilon`,
`period`, `gap`, `slab_thickness`, `slab_epsilon`, `wavelengths` (list),
`lmax`, and returns a wavelength-ordered dictionary with `wavelengths`,
`transmission`, `reflection`, `absorption` lists.
