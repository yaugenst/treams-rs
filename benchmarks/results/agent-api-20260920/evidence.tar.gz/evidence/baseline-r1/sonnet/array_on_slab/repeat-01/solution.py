"""Periodic sphere array above a dielectric slab, separated by a vacuum gap.

Network order along +z: slab -> vacuum gap -> sphere array. All exterior
media are vacuum. Illumination is from the negative-z side, propagating in
+z, with positive helicity. Only the zeroth diffraction order (both
helicities) is retained, since the wavelengths exceed the lattice period.
"""

import json
import sys

import numpy as np
import treams_rs as t


def _power_fractions(config, wavelength):
    radius = config["radius"]
    sphere_epsilon = config["sphere_epsilon"]
    period = config["period"]
    gap = config["gap"]
    slab_thickness = config["slab_thickness"]
    slab_epsilon = config["slab_epsilon"]
    lmax = config["lmax"]

    k0 = 2 * np.pi / wavelength

    # Zeroth diffraction order only, both helicities, Bloch vector [0, 0].
    basis = t.PlaneWaveBasis.default([0, 0, 1]).bycomp(k0)

    slab_sm = t.slab(
        basis=basis,
        k0=k0,
        thickness=slab_thickness,
        material=slab_epsilon,
        negative_medium=1,
        positive_medium=1,
        polarization="helicity",
    )
    gap_sm = t.propagation(
        distance=gap, basis=basis, k0=k0, medium=1, polarization="helicity"
    )
    tmat = t.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=sphere_epsilon,
        medium=1,
        polarization="helicity",
    )
    lattice = [[period, 0.0], [0.0, period]]
    periodic = t.solve_periodic(tmat, lattice=lattice, kpar=[0, 0])
    array_sm = periodic.to_smatrix(basis)

    full = t.stack([slab_sm, gap_sm, array_sm])

    incident = t.plane_wave(
        direction=[0, 0, 1], polarization="positive_helicity", k0=k0, medium=1
    )
    balance = full.power(incident, side="negative")

    return {
        "transmission": float(balance.transmission),
        "reflection": float(balance.reflection),
        "absorption": float(balance.absorption),
    }


def run(config):
    wavelengths = config["wavelengths"]
    transmission = []
    reflection = []
    absorption = []
    for wavelength in wavelengths:
        result = _power_fractions(config, wavelength)
        transmission.append(result["transmission"])
        reflection.append(result["reflection"])
        absorption.append(result["absorption"])

    return {
        "wavelengths": list(wavelengths),
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
