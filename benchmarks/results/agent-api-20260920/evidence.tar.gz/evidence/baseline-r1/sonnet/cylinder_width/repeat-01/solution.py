"""Scattering by a homogeneous infinite cylinder (kz=0, positive-helicity +x illumination)."""
import json
import sys

import numpy as np
import treams_rs as t


def run(config):
    radius = float(config["radius"])
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    wavelengths = config["wavelengths"]
    mmax = int(config["mmax"])

    mu = config.get("mu", 1)
    kappa = config.get("chirality", 0)
    material = t.Material(epsilon, mu, kappa)

    scattering = []
    extinction = []
    absorption = []

    for wl in wavelengths:
        k0 = 2 * np.pi / wl
        tm = t.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=material,
            medium=1,
        )
        pw = t.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        cs = tm.cross_widths(pw)
        scattering.append(cs.scattering)
        extinction.append(cs.extinction)
        absorption.append(cs.absorption)

    return {
        "wavelengths": list(wavelengths),
        "scattering_width": scattering,
        "extinction_width": extinction,
        "absorption_width": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
