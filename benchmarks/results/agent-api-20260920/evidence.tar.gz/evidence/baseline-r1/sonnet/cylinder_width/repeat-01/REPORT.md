# Infinite cylinder scattering — cross widths

## Problem

Compute the scattering, extinction and absorption cross **widths** (units of
length, since the scatterer is a homogeneous infinite cylinder along `z`,
not a 3D body) for plane-wave illumination propagating along `+x`
(perpendicular to the cylinder axis, `kz = 0`) with **positive helicity**
polarization.

## Units and conventions

- Lengths (`radius`, `wavelengths`, and the returned widths) are in
  micrometers (µm).
- `epsilon = [real, imag]` is the relative permittivity of the cylinder,
  dimensionless. Unless given in the config, `mu = 1` and `chirality
  (kappa) = 0`, and the exterior medium is vacuum (`material = 1`).
- The vacuum wavenumber for each wavelength is `k0 = 2*pi/wavelength`.
- `mmax` sets the azimuthal order cutoff (orders `-mmax..mmax`) used to
  build the cylindrical T-matrix.
- Illumination: a plane wave with wavevector along `+x`, `kz = 0`,
  positive-helicity polarization, built with
  `treams_rs.plane_wave(direction=[1,0,0], polarization="positive_helicity", k0=k0, medium=1)`.
- The T-matrix is built with `treams_rs.cylinder_tmatrix(k0=k0, kz=0.0,
  mmax=mmax, radius=radius, material=Material(epsilon, mu, kappa),
  medium=1)`.
- Cross widths (scattering, extinction, absorption = extinction −
  scattering) are obtained from `TMatrixC.cross_widths(incident)`, which
  uses the library's built-in flux normalization (`flux=0.5`, appropriate
  for a single polarization channel plane wave) and returns lengths
  directly — **no sphere-area normalization is applied**, consistent with
  the 2D (line-source-per-length) nature of an infinite cylinder.

## Numerical checks performed

- **mmax convergence**: for the example config (radius 0.08 µm, ε=5+0.1i,
  λ=0.5 µm), increasing `mmax` from 4 to 8 changes the widths only in the
  9th significant digit, confirming the cutoff is adequate for this
  radius/wavelength regime.
- **Energy conservation for lossless media**: setting `epsilon = [2.5, 0]`
  (real, lossless) yields `absorption ≈ 0` (numerical residual
  ~1e-16), i.e. scattering ≈ extinction, as required by optical
  theorem/energy conservation for a non-absorbing scatterer.
- Values are computed directly via `treams_rs` native routines
  (`cylinder_tmatrix`, `plane_wave`, `TMatrixC.cross_widths`); no
  reimplementation of Mie-type cylinder scattering was performed.

## I/O

`run(config)` accepts a dict with keys `radius`, `epsilon` (`[re, im]`),
`wavelengths` (list), `mmax`, and optional `mu`/`chirality`, and returns a
dict with `wavelengths` (echoed, wavelength-ordered) and the three cross
width lists: `scattering_width`, `extinction_width`, `absorption_width`
(all in the same length units as `radius`/`wavelengths`, i.e. µm).

The CLI (`python solution.py`) reads a single JSON config object from
stdin and prints the result dict as JSON to stdout.

## Example results

For the example config (radius=0.08 µm, ε=5+0.1i, λ=[0.5,0.65,0.8] µm,
mmax=4), see `results.json`.
