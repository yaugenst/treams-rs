import json
import sys

import numpy as np
import treams_rs as t


def run(config):
    thickness = config["thickness"]
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    kappa = config.get("kappa", 0.0)
    mu = config.get("mu", 1.0)
    wavelengths = config["wavelengths"]

    material = t.Material(epsilon, mu, kappa)

    basis_dir = t.PlaneWaveBasis.default([0.0, 0.0, 1.0])

    transmission = []
    reflection = []
    absorption = []

    for wl in wavelengths:
        k0 = 2 * np.pi / wl
        basis = basis_dir.bycomp(k0, alignment="xy", material=1)
        smat = t.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1,
            positive_medium=1,
            polarization="helicity",
        )

        t_row = []
        r_row = []
        a_row = []
        # basis.pol is [1, 0]: index 0 is positive helicity, index 1 is negative helicity
        for idx in range(2):
            inc = np.zeros(2, dtype=complex)
            inc[idx] = 1.0
            pb = smat.power(inc, side="negative")
            t_row.append(pb.transmission)
            r_row.append(pb.reflection)
            a_row.append(pb.absorption)

        transmission.append(t_row)
        reflection.append(r_row)
        absorption.append(a_row)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
