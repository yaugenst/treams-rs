# Chiral slab normal-incidence power balance

## Physical setup

A single homogeneous, isotropic, reciprocal chiral slab of finite `thickness`
(micrometers) is bounded by vacuum on both sides (mu=1, kappa=0, epsilon=1),
normal to the z axis. Illumination is a plane wave at normal incidence
(+z propagation) for each wavelength in `wavelengths` (micrometers). The
slab material has relative permittivity `epsilon = eps_re + i*eps_im`
(`config["epsilon"] = [eps_re, eps_im]`), relative permeability `mu` (default
1) and chirality parameter `kappa` (treams' material chirality convention,
which enters the helicity refractive indices as `n_± = sqrt(eps*mu) ± kappa`).

## Method

For each wavelength, `k0 = 2*pi/wavelength` is the vacuum angular
wavenumber. A `treams_rs.Material(epsilon, mu, kappa)` describes the slab. A
normal-incidence plane-wave basis is built with
`treams_rs.PlaneWaveBasis.default([0, 0, 1]).bycomp(k0, alignment="xy",
material=1)`, which yields both helicity polarization labels (0 = negative
helicity, 1 = positive helicity, per treams' convention) at kx=ky=0. The
scattering matrix of the slab between vacuum half-spaces is computed with
`treams_rs.slab(basis=..., k0=k0, thickness=..., material=..., 
negative_medium=1, positive_medium=1, polarization="helicity")`.

For each of the two helicity channels, a unit-amplitude incident wave is
formed (coefficient 1 in that channel, 0 in the other) and
`SMatrix.power(incident, side="negative")` is called, giving a
`PowerBalance` with `.transmission`, `.reflection` and `.absorption`
power fractions normalized to unit incident flux (side="negative" corresponds
to +z incidence onto the slab). Because the returned plane-wave basis lists
positive helicity first (label 1) and negative helicity second (label 0),
the incidence-vector index directly gives the requested (positive, negative)
output order — no reordering is needed.

All numerical scattering (S-matrix construction and power bookkeeping) is
delegated to treams-rs; this script only assembles inputs/outputs.

## Output convention

`run(config)` returns a dict with keys `transmission`, `reflection`,
`absorption`, each a list of shape `(len(wavelengths), 2)`. For each
wavelength row, column 0 is the positive-helicity power fraction and column
1 is the negative-helicity power fraction. These are power fractions (in
[0, 1]), not complex field amplitudes.

## Checks performed

- **Power conservation**: for the example config, `transmission + reflection
  + absorption == 1.0` (to floating-point precision) for every wavelength and
  helicity, verified in the accompanying run.
- **Lossless limit**: setting `epsilon = [eps_re, 0.0]` (zero imaginary part)
  drives absorption to ~0 (≈1e-16, numerical noise), as expected for a
  non-absorbing chiral slab.
- **Reciprocity/no dichroism**: for a reciprocal, isotropic chiral slab
  embedded symmetrically in the same medium (vacuum) on both sides,
  transmission/reflection/absorption for positive and negative helicity are
  found to be numerically equal at each wavelength (matching known results:
  differential circular transmission/absorption for such a symmetric,
  non-magnetic-asymmetric embedding vanishes by reciprocity + mirror
  symmetry arguments, even for nonzero kappa). This was confirmed by testing
  with a larger kappa (0.5) as well as the given kappa (0.08).

## Files

- `solution.py`: `run(config)` implementation and CLI (reads JSON config from
  stdin, writes JSON result to stdout).
- `example_config.json`: the example configuration from the task.
- `results.json`: the output of `run()` on the example config.
