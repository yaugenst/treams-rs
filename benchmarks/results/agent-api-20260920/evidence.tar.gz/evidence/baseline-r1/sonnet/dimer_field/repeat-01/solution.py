"""Multiple scattering from a dimer of spheres illuminated by a helicity plane wave.

Uses treams-rs to compute the coupled T-matrix of two spheres, the total
(incident + scattered) electric field at requested points, and the
scattering/extinction/absorption cross sections.
"""

import json
import sys

import numpy as np
import treams_rs as t


def run(config: dict) -> dict:
    radii = list(config["radii"])
    epsilon = [complex(e[0], e[1]) for e in config["epsilon"]]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float)

    k0 = 2 * np.pi / wavelength
    positions = [[-separation / 2, 0.0, 0.0], [separation / 2, 0.0, 0.0]]

    tmatrices = [
        t.TMatrix.sphere(lmax, k0, radii[i], [epsilon[i], 1])
        for i in range(2)
    ]
    cluster = t.Cluster(tmatrices, positions=positions)
    solved = cluster.solve()

    # +z propagation, positive helicity, unit amplitude (package normalization,
    # flux = 0.5 by default in cross_sections).
    incident = t.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)

    cross_sections = solved.cross_sections(incident)

    scattered = solved.scatter(incident)
    e_incident = incident.efield(points)
    e_scattered = scattered.efield(points)
    e_total = e_incident + e_scattered

    return {
        "total_field_real": e_total.real.tolist(),
        "total_field_imag": e_total.imag.tolist(),
        "scattering_cross_section": float(cross_sections.scattering),
        "extinction_cross_section": float(cross_sections.extinction),
        "absorption_cross_section": float(cross_sections.absorption),
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
