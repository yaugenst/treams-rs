# Dimer scattering: total field and cross sections

## Problem
Two homogeneous, isotropic spheres (radii `radii[0]`, `radii[1]`; relative
permittivities `epsilon[0]`, `epsilon[1]` given as `[real, imag]`) are placed
on the x-axis at `x = ∓separation/2`, `y = z = 0`, embedded in vacuum
(`mu = 1`, chirality `kappa = 0`). They are illuminated by a plane wave
propagating along `+z` with positive helicity. `solution.py` computes, at
the requested `lmax` and `wavelength`, the full multiple-scattering
solution and returns:

- `total_field_real` / `total_field_imag`: the total (incident + scattered)
  electric field at each requested point, as `[Ex, Ey, Ez]` real/imaginary
  parts (points × 3).
- `scattering_cross_section`, `extinction_cross_section`,
  `absorption_cross_section`: scalar cross sections for the whole dimer.

## Units and conventions
- Lengths (radii, separation, wavelength, point coordinates) are in
  micrometers; cross sections come out in µm².
- The vacuum wavenumber is `k0 = 2*pi/wavelength`, used consistently for the
  spheres' T-matrices and the incident plane wave (`treams_rs.TMatrix.sphere`,
  `treams_rs.plane_wave`).
- Each sphere's single-scattering response is built with
  `TMatrix.sphere(lmax, k0, radius, [material, exterior])`, where `material`
  is `complex(eps_real, eps_imag)` and the exterior is vacuum (`1`).
- The two single-sphere T-matrices are assembled into a
  `treams_rs.Cluster` at the specified Cartesian positions and solved with
  `cluster.solve()`, which performs the full multipole/lmax-truncated
  multiple-scattering (Foldy–Lax type) solve between the two origins,
  i.e. this includes all multiple scattering allowed at the given `lmax`.
- The incident wave is `treams_rs.plane_wave([0,0,1], "positive_helicity",
  k0=k0)`, i.e. propagation along `+z`, unit amplitude, positive-helicity
  polarization in treams' helicity convention. This is the package's
  standard incident-field normalization (unit-amplitude field,
  corresponding to `flux = 0.5` used by `cross_sections`, the library
  default).
- The scattered field is obtained via `solved.scatter(incident)`, an
  outgoing multipole wave with per-particle expansion origins; its Cartesian
  field is evaluated at the query points with the native `.efield(r)`
  kernel and added to the incident field's own `.efield(r)` to give the
  total field. Query points are checked with `solved.valid_points` to lie
  outside the circumscribing spheres (in the validity domain of the
  multipole expansion); for the example points this check passes.
- Cross sections are obtained from `solved.cross_sections(incident)`
  (`scattering`, `extinction`, and `absorption = extinction - scattering`),
  in area units (µm²), for the whole two-sphere cluster.

## Checks performed
- `scattering_cross_section <= extinction_cross_section` and
  `absorption_cross_section >= 0` hold for the example configuration.
- Lossless limit: setting both `epsilon` imaginary parts to 0 gives
  `absorption_cross_section ≈ 0` (~1e-17, at floating-point precision).
- Non-interacting limit: separating the spheres by a large distance
  (5 µm at `wavelength = 0.72`, i.e. many wavelengths) makes the dimer's
  scattering/extinction/absorption cross sections converge to the sum of
  the two independently computed single-sphere Mie cross sections
  (agreement to ~4 significant figures), confirming the multiple-scattering
  solve reduces correctly to independent Mie scattering when coupling is
  negligible.
- `run()` was exercised with the given example config and with perturbed
  configs (different `separation`, lossless materials) to confirm no
  hard-coded outputs; the CLI reads one JSON config from stdin and writes
  the result dict as JSON to stdout.

## Files
- `solution.py`: importable `run(config)` and CLI entry point.
- `example_config.json`: the example configuration used to produce
  `results.json`.
- `results.json`: `run()` output for the example configuration.
