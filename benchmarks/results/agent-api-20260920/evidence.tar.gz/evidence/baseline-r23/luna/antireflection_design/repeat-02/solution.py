"""Gradient-based antireflection coating design using treams-rs."""

import json
import sys

import advect
import numpy as np
import treams_rs
import treams_rs.advect as trs_ad


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    lower, upper = (float(x) for x in config["bounds"])
    if not (0.0 < wavelength and lower <= upper):
        raise ValueError("invalid wavelength or bounds")
    if epsilon <= 0.0 or substrate_epsilon <= 0.0:
        raise ValueError("this implementation requires lossless positive media")

    # At normal incidence both helicities are represented.  Reflection changes
    # helicity, while transmission preserves it in the treams convention.
    basis = treams_rs.PlaneWavePorts([(0.0, 0.0, 0), (0.0, 0.0, 1)])
    k0 = 2.0 * np.pi / wavelength

    def objective(thickness):
        smat = trs_ad.multilayer_slab(
            basis=basis,
            k0=k0,
            thicknesses=thickness,
            materials=[epsilon],
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
            polarization="helicity",
        )
        # Input helicity 0 from the negative (vacuum) side reflects into 1.
        r = smat.array[1, 0, 1, 0]
        return advect.numpy.real(r * advect.numpy.conj(r))

    value_and_gradient = advect.value_and_grad(objective)

    def evaluate(x):
        value, gradient = value_and_gradient(np.asarray([x], dtype=float))
        return float(np.asarray(value)), float(np.asarray(gradient)[0])

    thickness = min(upper, max(lower, initial))
    initial_reflection, gradient = evaluate(thickness)
    loss_history = [initial_reflection]
    loss = initial_reflection
    span = upper - lower
    step = max(span / 16.0, 1.0e-4)

    # Projected, backtracked gradient descent.  Every gradient used here is
    # the native analytic pullback of the treams-rs slab response.
    for _ in range(300):
        if loss < 1.0e-12:
            break
        direction = -gradient
        if (thickness <= lower and direction < 0.0) or (
            thickness >= upper and direction > 0.0
        ):
            direction = 0.0
        if direction == 0.0:
            break
        trial_step = step
        improved = False
        for _ in range(40):
            candidate = min(upper, max(lower, thickness + trial_step * direction))
            if candidate == thickness:
                trial_step *= 0.5
                continue
            candidate_loss, candidate_gradient = evaluate(candidate)
            if candidate_loss < loss:
                thickness, loss, gradient = candidate, candidate_loss, candidate_gradient
                loss_history.append(loss)
                step = min(trial_step * 1.35, max(span, 1.0e-4))
                improved = True
                break
            trial_step *= 0.5
        if not improved:
            # A tiny gradient at a nonzero loss is a stationary point; there
            # is no useful projected descent direction left in this interval.
            break

    # Refresh the reported derivative at the final point, including if the
    # loop stopped immediately after reaching the tolerance.
    loss, gradient = evaluate(thickness)
    if not loss_history or loss_history[-1] != loss:
        loss_history.append(loss)
    return {
        "thickness": thickness,
        "reflection": loss,
        "initial_reflection": initial_reflection,
        "gradient": gradient,
        "loss_history": loss_history,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
