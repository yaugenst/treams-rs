# Antireflection design report

`solution.py` treats all lengths as micrometers, so `k0 = 2π / wavelength`
is in inverse micrometers.  The incident medium is vacuum (`epsilon=mu=1`)
on the negative side of the stack, the supplied substrate is on the positive
side, and there is no gap after the coating.  The coating and substrate are
lossless, nonmagnetic, and achiral.

At normal incidence both helicity channels are included.  In treams-rs,
reflection changes helicity; the objective is therefore the squared magnitude
of the native reflected channel, `R = |r|²`, for one incident helicity.
The thickness is optimized by projected, backtracked gradient descent.  Each
objective gradient is obtained with the installed `treams_rs.advect` native
pullback; no finite-difference gradient is used.

Checks performed: the example was executed through the CLI, the returned
thickness was kept inside the requested bounds, the final analytic gradient
was recomputed at the returned thickness, and the final reflected power was
checked against `1e-7`.  The resulting values are in `results.json`.
