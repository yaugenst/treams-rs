"""Gradient-based single-layer antireflection design using treams-rs."""

from __future__ import annotations

import json
import sys
from typing import Any

import advect
import numpy as np
import treams_rs.advect as tr


def _reflection_function(wavelength: float, epsilon: float,
                        substrate_epsilon: float):
    """Return a scalar reflected-power function with a native pullback."""
    k0 = 2.0 * np.pi / wavelength
    # The xy transverse wavevector is zero; the two entries are the two
    # transverse polarization labels.  One polarization is illuminated below.
    basis = tr.PlaneWaveBasisByComp([(0.0, 0.0, 0), (0.0, 0.0, 1)])
    incident = tr.PlaneWave((0.0, 0.0, 1.0), 0, k0=k0, medium=1.0)

    def reflected_power(thickness: Any) -> Any:
        smatrix = tr.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        return smatrix.power(incident, side="negative").reflection

    return reflected_power


def run(config: dict[str, Any]) -> dict[str, Any]:
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    lower, upper = (float(x) for x in config["bounds"])

    if not (wavelength > 0.0 and epsilon > 0.0 and substrate_epsilon > 0.0):
        raise ValueError("wavelength and permittivities must be positive")
    if not lower <= initial <= upper:
        raise ValueError("initial_thickness must lie within bounds")

    reflection = _reflection_function(wavelength, epsilon, substrate_epsilon)
    value_and_grad = advect.value_and_grad(reflection)

    x = float(initial)
    initial_value, initial_gradient = value_and_grad(np.asarray(x, dtype=np.float64))
    loss = float(np.asarray(initial_value))
    gradient = float(np.asarray(initial_gradient))
    loss_history = [loss]

    # Projected gradient descent.  Each proposed move is accepted using only
    # native-gradient information and a reflected-power evaluation; no finite
    # difference derivative is used.
    for _ in range(300):
        if abs(gradient) < 1.0e-10:
            break
        direction = -gradient
        step = 0.02
        accepted = False
        while step > 1.0e-12:
            candidate = min(upper, max(lower, x + step * direction))
            if candidate == x:
                step *= 0.5
                continue
            candidate_loss = float(np.asarray(reflection(np.asarray(candidate))))
            # Armijo decrease, with a small tolerance for roundoff near zero.
            if candidate_loss <= loss + 1.0e-4 * gradient * (candidate - x) + 1.0e-15:
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break
        x = candidate
        loss, gradient = value_and_grad(np.asarray(x, dtype=np.float64))
        loss = float(np.asarray(loss))
        gradient = float(np.asarray(gradient))
        loss_history.append(loss)

    # Recompute the reported derivative on a fresh native trace (native
    # pullback contexts are single-use).
    final_value, final_gradient = value_and_grad(np.asarray(x, dtype=np.float64))
    final_value = float(np.asarray(final_value))
    final_gradient = float(np.asarray(final_gradient))
    return {
        "thickness": x,
        "reflection": final_value,
        "initial_reflection": float(loss_history[0]),
        "gradient": final_gradient,
        "loss_history": loss_history,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
