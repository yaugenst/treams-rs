# Antireflection design report

`solution.py` models lengths in micrometers, so `k0 = 2*pi/wavelength` is in
inverse micrometers. Permittivities are relative, permeability is one, and
the negative side is vacuum. The coating lies between the negative (incident,
`+z`) side and the supplied positive-side substrate; there is no gap.

The normal-incidence treams-rs component basis contains both transverse
polarizations. A single polarization-0 plane wave is incident from the
negative side. `SMatrix.power(...).reflection` is the incident-normalized
reflected power. Thickness derivatives come from the installed Advect adapter
and treams-rs native pullbacks. Optimization is projected gradient descent
with Armijo backtracking, constrained to the requested bounds.

Checks performed:

- The example was executed through the JSON CLI and saved to `results.json`.
- The returned thickness is within the requested bounds.
- The final reflected power is below `1e-7` and the final analytic gradient is
  close to zero.
- The loss history is monotonically decreasing for the accepted steps.
