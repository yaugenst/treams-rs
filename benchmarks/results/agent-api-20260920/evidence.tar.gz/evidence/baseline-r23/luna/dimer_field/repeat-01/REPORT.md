# Report

`solution.py` uses `treams_rs.sphere_tmatrix` for each sphere, couples the
two particles with `Cluster.solve()`, and evaluates the scattered response
with a native `TMatrix.scatter()` call.  The returned electric field is the
sum of the native incident and scattered fields.

Lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers and the cross sections are in square micrometers.  The exterior
is vacuum (`epsilon=mu=1`); sphere permeability is 1 and chirality is 0.
The input epsilon pairs are interpreted as real and imaginary parts.  The
incident wave travels along +z, uses treams-rs incident normalization, and
has positive helicity (helicity channel 1).

Checks performed:

- The example was executed through the CLI and its output was saved in
  `results.json`.
- The reported absorption satisfies `absorption = extinction - scattering`
  to floating-point precision.
- The cluster response is formed by `Cluster.solve()`, hence includes all
  multiple scattering at the requested `lmax` (3 for the example).
