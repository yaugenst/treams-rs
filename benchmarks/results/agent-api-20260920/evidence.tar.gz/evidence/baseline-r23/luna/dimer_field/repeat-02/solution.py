"""Coupled two-sphere scattering and total electric-field evaluation."""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as treams


def _complex_epsilon(value: object) -> complex:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError("each epsilon must be [real, imag]")
    return complex(float(value[0]), float(value[1]))


def _json_complex_array(value: np.ndarray) -> tuple[list[list[float]], list[list[float]]]:
    value = np.asarray(value, dtype=np.complex128)
    return value.real.tolist(), value.imag.tolist()


def run(config: dict) -> dict:
    """Run the fixed-helicity dimer calculation described by *config*."""
    radii = np.asarray(config["radii"], dtype=float)
    epsilons = config["epsilon"]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float)

    if radii.shape != (2,) or np.any(radii <= 0):
        raise ValueError("radii must contain two positive values")
    if len(epsilons) != 2:
        raise ValueError("epsilon must contain two [real, imag] values")
    if not np.isfinite(separation) or separation <= 0:
        raise ValueError("separation must be positive and finite")
    if not np.isfinite(wavelength) or wavelength <= 0:
        raise ValueError("wavelength must be positive and finite")
    if lmax < 1:
        raise ValueError("lmax must be positive")
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
        raise ValueError("points must be a finite point-by-3 array")

    k0 = 2.0 * np.pi / wavelength
    particles = [
        treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=float(radius),
            material=treams.Material(_complex_epsilon(epsilon)),
            medium=treams.Material(1),
            polarization="helicity",
        )
        for radius, epsilon in zip(radii, epsilons, strict=True)
    ]
    cluster = treams.Cluster(
        particles,
        positions=[[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]],
    )
    incident = treams.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        medium=treams.Material(1),
    )
    scattered = cluster.scatter(incident)
    total_field = incident.efield(points) + scattered.efield(points)

    # Solving the cluster produces the complete coupled T-matrix. Its public
    # cross-section routine uses the same incident normalization as the field.
    coupled = cluster.solve()
    cross_sections = coupled.cross_sections(incident)
    real, imag = _json_complex_array(total_field)
    return {
        "total_field_real": real,
        "total_field_imag": imag,
        "scattering": float(cross_sections.scattering),
        "extinction": float(cross_sections.extinction),
        "absorption": float(cross_sections.absorption),
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
