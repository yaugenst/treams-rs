# Dimer calculation report

`solution.py` uses treams-rs spherical T-matrices at the requested `lmax` and
the public `Cluster` solve/scatter operation, so interaction between both
spheres is included to all orders supported by that truncated basis.

Lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. Permittivities are converted from `[real, imag]` to complex
relative epsilon; the exterior is vacuum (`epsilon=mu=1`), with zero
chirality. The incident wave travels along +z and is positive helicity. The
reported electric field is the package-normalized incident field plus the
outgoing scattered field, evaluated at each supplied point.

The cross sections are the native treams-rs scattering, extinction, and
extinction-minus-scattering absorption values, in square micrometers. The
example was executed through the CLI and its output was saved in
`results.json`. Checks performed include finite/positive geometry and
wavelength validation, finite point validation, JSON serialization, and the
native cross-section calculation.
