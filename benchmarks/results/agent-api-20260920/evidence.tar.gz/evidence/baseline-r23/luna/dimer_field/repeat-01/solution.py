"""Two-sphere multiple-scattering calculation using treams-rs."""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _complex_eps(value: Any) -> complex:
    """Convert the input [real, imag] representation to a complex scalar."""
    if len(value) != 2:
        raise ValueError("each epsilon entry must be [real, imag]")
    return complex(float(value[0]), float(value[1]))


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Solve the specified two-sphere dimer and return JSON-compatible data.

    All geometry and wavelength values are passed to treams-rs in the same
    length unit (the micrometer unit used by the input configuration).
    """
    radii = [float(x) for x in config["radii"]]
    epsilons = [_complex_eps(x) for x in config["epsilon"]]
    if len(radii) != 2 or len(epsilons) != 2:
        raise ValueError("radii and epsilon must each contain two entries")

    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    separation = float(config["separation"])
    k0 = 2.0 * np.pi / wavelength

    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=tr.Material(epsilon),
            polarization="helicity",
        )
        for radius, epsilon in zip(radii, epsilons)
    ]
    cluster = tr.Cluster(
        particles,
        positions=[[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]],
    )
    response = cluster.solve()

    # In the helicity convention, channel 1 is positive helicity.  The
    # plane wave points along +z and uses treams-rs' native normalization.
    incident = tr.PlaneWave(
        [0.0, 0.0, 1.0], [0.0, 1.0], k0=k0, poltype="helicity"
    )
    scattered = response.scatter(incident)
    points = np.asarray(config["points"], dtype=float)
    total_field = incident.efield(points) + scattered.efield(points)
    cross_sections = response.cross_sections(incident)

    return {
        "total_field_real": np.asarray(total_field.real).tolist(),
        "total_field_imag": np.asarray(total_field.imag).tolist(),
        "scattering": float(cross_sections.scattering),
        "extinction": float(cross_sections.extinction),
        "absorption": float(cross_sections.absorption),
    }


if __name__ == "__main__":
    payload = json.load(sys.stdin)
    print(json.dumps(run(payload), separators=(",", ":")))
