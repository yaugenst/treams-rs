"""Periodic sphere array above a dielectric slab.

The geometry is assembled from public treams_rs scattering objects.  Lengths
are micrometres, so the vacuum wavenumber is 2*pi / wavelength in inverse
micrometres.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _positive_number(config: dict[str, Any], name: str) -> float:
    value = float(config[name])
    if not np.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")
    return value


def _nonnegative_number(config: dict[str, Any], name: str) -> float:
    value = float(config[name])
    if not np.isfinite(value) or value < 0:
        raise ValueError(f"{name} must be finite and nonnegative")
    return value


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return power fractions for positive-helicity incidence from below."""
    radius = _positive_number(config, "radius")
    period = _positive_number(config, "period")
    gap = _nonnegative_number(config, "gap")
    slab_thickness = _nonnegative_number(config, "slab_thickness")
    sphere_epsilon = float(config["sphere_epsilon"])
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])
    wavelengths = np.asarray(config["wavelengths"], dtype=float)
    if wavelengths.ndim != 1 or len(wavelengths) == 0 or not np.isfinite(wavelengths).all():
        raise ValueError("wavelengths must be a nonempty finite sequence")
    if np.any(wavelengths <= 0):
        raise ValueError("wavelengths must be positive")
    if lmax < 1 or lmax != config["lmax"]:
        raise ValueError("lmax must be a positive integer")
    if not np.isfinite(sphere_epsilon) or not np.isfinite(slab_epsilon):
        raise ValueError("permittivities must be finite real numbers")

    # Sorting is part of the result contract and also makes repeated calls
    # deterministic when a caller supplies wavelengths in another order.
    wavelengths = np.sort(wavelengths)
    ports = tr.PlaneWavePorts.default([[0.0, 0.0]])
    incident = np.array([0.0, 1.0], dtype=np.complex128)
    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / float(wavelength)
        sphere = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=sphere_epsilon,
            medium=1.0,
            polarization="helicity",
        )
        # The native periodic solve includes all reciprocal-lattice channels
        # in the interaction; ports below select only the propagating order.
        array = tr.solve_periodic(
            sphere, lattice=[period, period], kpar=[0.0, 0.0]
        ).to_smatrix(ports)
        slab = tr.slab(
            basis=ports,
            k0=k0,
            thickness=slab_thickness,
            material=slab_epsilon,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        vacuum_gap = tr.propagation(
            distance=gap,
            basis=ports,
            k0=k0,
            medium=1.0,
            polarization="helicity",
        )
        network = tr.stack([slab, vacuum_gap, array])
        powers = network.power(incident, side="negative")
        t = float(powers.transmission)
        r = float(powers.reflection)
        a = float(powers.absorption)
        if abs(a) < 1e-12:
            a = 0.0
        transmission.append(t)
        reflection.append(r)
        absorption.append(a)

    return {
        "wavelengths": [float(x) for x in wavelengths],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    payload = json.load(sys.stdin)
    json.dump(run(payload), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
