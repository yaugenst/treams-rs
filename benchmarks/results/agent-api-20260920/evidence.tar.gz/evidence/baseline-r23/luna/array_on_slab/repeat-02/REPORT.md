# Periodic sphere array above a slab

`solution.py` uses micrometres for all lengths and `k0 = 2*pi/lambda` in
inverse micrometres.  Permittivities are relative, with unit permeability,
zero chirality, and vacuum outside the slab and array.

The network is cascaded along +z as dielectric slab, vacuum propagation over
`gap`, and the native Bloch-periodic sphere-array response.  The sphere
interaction is solved by `treams_rs.solve_periodic` at Bloch vector `[0, 0]`.
The output plane-port basis contains both helicities of only the zeroth
diffraction order.  Incidence is the positive-helicity channel from the
negative-z side.

The returned fractions are incident-normalized transmission, reflection, and
`1 - T - R` absorption, sorted by wavelength.  The example was executed and
`results.json` was checked for finite values and `T + R + A = 1` to numerical
precision.
