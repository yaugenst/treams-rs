# Periodic sphere array above a slab

`solution.py` uses treams-rs native `sphere_tmatrix`, `solve_periodic`,
`to_smatrix`, slab/gap cascading, and `SMatrix.power`.  The sphere and slab
are lossless isotropic materials with relative permeability 1 and chirality 0;
all exterior media are vacuum.

Lengths are micrometres, so the vacuum wavenumber is `k0 = 2*pi/lambda` in
inverse micrometres.  The network is ordered along +z as slab, vacuum gap,
then the sphere array.  Illumination is the +z, positive-helicity channel.
The external port basis contains only diffraction order (0, 0), with both
helicities; the periodic multipole solve retains the full requested `lmax`.

Transmission and reflection are incident-power-normalized fractions, and
absorption is the native balance `1 - T - R`; sub-`1e-12` signed roundoff in
this lossless balance is reported as zero.  Checks performed on the example:
the wavelengths are returned in ascending order, all fractions are finite and
non-negative, and `T + R + A` is 1 to floating-point precision at each
wavelength.
