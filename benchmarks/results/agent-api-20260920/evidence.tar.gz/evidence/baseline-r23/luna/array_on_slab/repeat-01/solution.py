"""Periodic sphere array above a dielectric slab.

All geometry is in micrometres.  The returned powers are normalized to the
incident zeroth-order positive-helicity plane wave.
"""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _finite_positive(config: dict[str, Any], name: str) -> float:
    value = float(config[name])
    if not math.isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return value


def _physical_zero(value: float) -> float:
    """Remove signed floating-point zero from a lossless power balance."""
    return 0.0 if abs(value) < 1e-12 else value


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Evaluate the wavelength-ordered R/T/A response for one configuration."""
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _finite_positive(config, "radius")
    sphere_epsilon = float(config["sphere_epsilon"])
    period = _finite_positive(config, "period")
    gap = _finite_positive(config, "gap")
    slab_thickness = _finite_positive(config, "slab_thickness")
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])
    if lmax < 1 or lmax != config["lmax"]:
        raise ValueError("lmax must be a positive integer")
    wavelengths = [_finite_positive({"wavelength": w}, "wavelength")
                   for w in config["wavelengths"]]
    if not wavelengths:
        raise ValueError("wavelengths must not be empty")

    # The requested output is wavelength ordered even if the input is not.
    wavelengths.sort()
    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    # Two channels are retained: diffraction order (0, 0), helicities 0 and 1.
    # The periodic solve itself still includes all multipoles and lattice
    # interactions; this basis only selects the propagating external ports.
    ports = tr.PlaneWavePorts([(0.0, 0.0, 0), (0.0, 0.0, 1)])
    lattice = [[period, 0.0], [0.0, period]]

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        slab = tr.multilayer_slab(
            basis=ports,
            k0=k0,
            thicknesses=[slab_thickness],
            materials=[slab_epsilon],
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        vacuum_gap = tr.propagation(
            distance=gap,
            basis=ports,
            k0=k0,
            medium=1.0,
            polarization="helicity",
        )
        sphere = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=sphere_epsilon,
            medium=1.0,
            polarization="helicity",
        )
        periodic_spheres = tr.solve_periodic(
            sphere, lattice=lattice, kpar=[0.0, 0.0]
        )
        array = periodic_spheres.to_smatrix(ports)

        # Negative-z to positive-z order: slab, gap, sphere array.
        network = tr.stack([slab, vacuum_gap, array])
        incident = tr.PlaneWave([0.0, 0.0, k0], [0.0, 1.0], k0=k0)
        powers = network.power(incident, side="negative")
        transmission.append(float(powers.transmission))
        reflection.append(float(powers.reflection))
        absorption.append(_physical_zero(float(powers.absorption)))

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    configuration = json.load(sys.stdin)
    print(json.dumps(run(configuration), separators=(",", ":")))
