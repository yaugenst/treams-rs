# Dimer sensitivity report

`solution.py` uses the installed `treams_rs.advect` adapter. Each sphere is a
numerical spherical T-matrix with the requested `lmax`; `Cluster.scatter`
solves the coupled two-sphere multiple-scattering problem. The reported field
is the incident plane-wave electric field plus the scattered field at `point`.

All lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. Permittivity is relative and is formed as
`epsilon[0] + 1j*epsilon[1]`; the exterior has relative epsilon and mu equal
to one, and chirality is zero. Positive helicity means the treams-rs
`positive_helicity` channel for propagation along +z.

The gradient is the native Advect reverse derivative with respect to
`separation`. It includes both origin motions (`x=-separation/2` and
`x=+separation/2`), the interaction solve, and the scattered-field sample;
the incident field is included in the intensity but has no separation
dependence. The example execution is recorded in `results.json`.

Checks performed: the CLI was run on the supplied configuration; the returned
value and gradient are finite; and a centered finite-difference check was used
only as an independent diagnostic of the analytic gradient.
