# Dimer sensitivity report

`solution.py` uses micrometres for all lengths, so `k0 = 2*pi/wavelength`
is in inverse micrometres.  The sphere material is the relative complex
permittivity `epsilon[0] + i*epsilon[1]`; the exterior has relative
permittivity and permeability one, and zero chirality.

The two origins are `(-separation/2, 0, 0)` and `(separation/2, 0, 0)`.
The incident wave travels along +z and uses the treams-rs positive-helicity
channel (helicity label 1).  `treams_rs.advect.cluster` supplies the native
coupled response, including multiple scattering, and `advect.field` evaluates
the outgoing electric field.  The gradient is obtained by Advect reverse mode
through the native treams-rs pullbacks; it differentiates both moving origins.

The reported value is the three-component Cartesian electric intensity,
`sum(abs(E_incident + E_scattered)**2)`, at the requested point.  Checks made
while developing the solution were: the coupled native response agrees with
the public `Cluster.solve()` matrix, the incident multipole coefficients match
the public plane-wave expansion at both x-shifted origins, and the example
calculation completes through the JSON CLI.
