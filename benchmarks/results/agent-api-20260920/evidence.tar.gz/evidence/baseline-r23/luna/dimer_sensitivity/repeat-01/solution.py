"""Dimer electric-field sensitivity using treams-rs and its Advect adapter."""

from __future__ import annotations

import json
import sys
from math import pi

import advect as ad
import treams_rs.advect as tr


def _objective(separation, *, radius, material, wavelength, lmax, point):
    """Return the field intensity at one point for a given separation."""
    k0 = 2.0 * pi / wavelength
    particle = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=material,
        medium=1.0,
        polarization="helicity",
    )

    # The separation is an Advect value here, so both moving origins contribute
    # to the native derivative of the coupled solve and of the field evaluation.
    positions = ad.numpy.stack(
        (
            ad.numpy.array((-separation / 2.0, 0.0, 0.0)),
            ad.numpy.array((separation / 2.0, 0.0, 0.0)),
        )
    )
    cluster = tr.Cluster([particle, particle], positions=positions)
    incident = tr.PlaneWave(
        (0.0, 0.0, 1.0),
        "positive_helicity",
        k0=k0,
        medium=1.0,
    )
    scattered = cluster.scatter(incident)

    sample = ad.numpy.array(point)
    electric = incident.efield(sample) + scattered.efield(sample)
    return ad.numpy.sum(ad.numpy.abs(electric) ** 2)


def run(config):
    """Evaluate the requested value and analytic separation gradient."""
    epsilon = config["epsilon"]
    if len(epsilon) != 2:
        raise ValueError("epsilon must be [real, imag]")
    material = complex(float(epsilon[0]), float(epsilon[1]))

    objective = lambda separation: _objective(
        separation,
        radius=float(config["radius"]),
        material=material,
        wavelength=float(config["wavelength"]),
        lmax=int(config["lmax"]),
        point=tuple(float(x) for x in config["point"]),
    )
    value, gradient = ad.value_and_grad(objective)(float(config["separation"]))
    return {"value": float(value), "gradient": float(gradient)}


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
