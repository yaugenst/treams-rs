"""Two-sphere near-field sensitivity using treams-rs and Advect."""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs as tr
from treams_rs import advect as ta


def _calculate(config: dict):
    radius = float(config["radius"])
    eps_pair = config["epsilon"]
    epsilon = complex(float(eps_pair[0]), float(eps_pair[1]))
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=np.float64).reshape(1, 3)
    k0 = 2.0 * np.pi / wavelength

    # This is a static regular expansion of a +z, positive-helicity plane wave
    # at one origin.  The two sphere origins have z=0, so no incident phase
    # factor is needed when their x separation changes.
    one_particle_basis = tr.SphericalBasis.default(lmax)
    plane = tr.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=k0, poltype="helicity"
    )
    incident_one = plane.in_basis(one_particle_basis).coefficients
    incident = np.concatenate((incident_one, incident_one))
    cluster_basis = tr.SphericalBasis.default(lmax, 2)
    incident_field = plane.efield(point)[0]

    def objective(separation):
        half = separation / 2.0
        zero = ad.numpy.asarray(0.0)
        positions = ad.numpy.stack(
            (
                ad.numpy.stack((-half, zero, zero)),
                ad.numpy.stack((half, zero, zero)),
            )
        )
        # Native coupled sphere scattering, including all inter-particle
        # translations and the native derivative with respect to positions.
        response = ta.cluster(
            lmax,
            k0,
            [radius, radius],
            [epsilon, epsilon],
            positions,
        )
        scattered_coefficients = response @ incident
        scattered_field = ta.field(
            scattered_coefficients,
            point,
            positions,
            [k0, k0],
            basis=cluster_basis,
            poltype="helicity",
            singular=True,
        )[0]
        total = incident_field + scattered_field
        return ad.numpy.real(ad.numpy.sum(ad.numpy.conj(total) * total))

    return objective


def run(config: dict) -> dict:
    """Return the local electric intensity and analytic separation gradient."""
    value, gradient = ad.value_and_grad(_calculate(config))(float(config["separation"]))
    return {"value": float(value), "gradient": float(gradient)}


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
