"""Rotationally averaged cross sections for a concentric multilayer sphere."""

import json
import math
import sys

import treams_rs


def _complex_permittivity(value):
    """Convert a scalar or [real, imaginary] JSON value to a complex number."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ValueError("permittivity pairs must have [real, imaginary] form")
        return complex(float(value[0]), float(value[1]))
    return complex(float(value), 0.0)


def run(config):
    """Return averaged scattering, extinction, and absorption spectra."""
    radii = [float(x) for x in config["radii"]]
    eps_layers = [_complex_permittivity(x) for x in config["epsilon_layers"]]
    wavelengths = [float(x) for x in config["wavelengths"]]
    lmax = int(config["lmax"])

    if len(radii) != len(eps_layers):
        raise ValueError("radii and epsilon_layers must have equal length")
    if not radii or any(r <= 0 for r in radii) or any(a >= b for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be positive and strictly increasing")
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")

    medium = _complex_permittivity(config["epsilon_medium"])
    scattering = []
    extinction = []
    absorption = []

    for wavelength in wavelengths:
        tmatrix = treams_rs.multilayer_sphere_tmatrix(
            k0=2.0 * math.pi / wavelength,
            lmax=lmax,
            radii=radii,
            materials=eps_layers,
            medium=medium,
        )
        averaged = tmatrix.average_cross_sections
        sca = float(averaged.scattering)
        ext = float(averaged.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(float(averaged.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
