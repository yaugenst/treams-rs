# Coated-sphere spectrum

`solution.py` constructs a treams-rs multilayer spherical T-matrix independently
at each wavelength and reads its public rotationally and polarization-averaged
cross-section properties. The radii are interpreted as increasing outer
boundaries, with one material per layer from inside to outside. The exterior is
passed as the `medium` and is not added as a finite layer.

All lengths are in micrometers, so the returned cross sections are in square
micrometers. Wavenumbers use `k0 = 2*pi/wavelength`. A JSON pair `[real, imag]`
is interpreted as the complex relative permittivity `real + i*imag`; a scalar
exterior permittivity has zero imaginary part. Relative permeability is one and
chirality is zero.

Checks performed: the example was executed through the stdin JSON CLI; the
output was saved as `results.json`. The implementation validates positive
wavelengths, positive strictly increasing radii, and matching layer arrays. For
each wavelength it also uses treams-rs' built-in identity
`absorption = extinction - scattering` through its `CrossSections` result.
