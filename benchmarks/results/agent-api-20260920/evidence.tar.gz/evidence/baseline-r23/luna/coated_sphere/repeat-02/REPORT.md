# Coated-sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` solver. The
radii and wavelengths are in micrometres, so the vacuum wavenumber supplied to
treams-rs is `k0 = 2*pi/wavelength` in inverse micrometres. Permittivities are
relative and are passed as complex values; the exterior is supplied as the
medium and is not added as a finite layer. The reported cross sections are in
square micrometres.

The two helicity plane-wave cross sections are averaged. For a concentric
isotropic sphere they are equivalent rotational averages. Absorption is
computed as extinction minus scattering. The example run produced nonnegative
scattering and absorption values, and extinction was greater than scattering at
each wavelength.
