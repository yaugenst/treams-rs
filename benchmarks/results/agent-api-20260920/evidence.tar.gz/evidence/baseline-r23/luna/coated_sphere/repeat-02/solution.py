"""Coated-sphere cross sections using the public treams-rs API."""

import json
import sys

import numpy as np
import treams_rs


def _complex_permittivity(value):
    """Convert a scalar or [real, imaginary] JSON value to a complex number."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ValueError("permittivity pairs must contain [real, imag]")
        return complex(float(value[0]), float(value[1]))
    return complex(value)


def run(config):
    """Return scattering, extinction, and absorption spectra in square micrometres."""
    radii = [float(x) for x in config["radii"]]
    layer_values = config["epsilon_layers"]
    wavelengths = [float(x) for x in config["wavelengths"]]
    lmax = int(config["lmax"])

    if not radii or len(radii) != len(layer_values):
        raise ValueError("radii and epsilon_layers must have the same nonzero length")
    if any(r <= 0 for r in radii) or any(a >= b for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing and positive")
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")
    if lmax < 1:
        raise ValueError("lmax must be positive")

    materials = [_complex_permittivity(value) for value in layer_values]
    medium = _complex_permittivity(config["epsilon_medium"])
    scattering = []
    extinction = []
    absorption = []

    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        tmatrix = treams_rs.multilayer_sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radii=radii,
            materials=materials,
            medium=medium,
            polarization="helicity",
        )

        # Opposite helicities are an orientation average for this isotropic
        # sphere.  Averaging them also avoids selecting a special polarization.
        values = []
        for polarization in ("positive_helicity", "negative_helicity"):
            incident = treams_rs.plane_wave(
                direction=[0.0, 0.0, 1.0],
                polarization=polarization,
                k0=k0,
                medium=medium,
            )
            cross_sections = tmatrix.cross_sections(incident)
            values.append((
                float(cross_sections.scattering),
                float(cross_sections.extinction),
            ))

        scattering_value = sum(value[0] for value in values) / len(values)
        extinction_value = sum(value[1] for value in values) / len(values)
        scattering.append(scattering_value)
        extinction.append(extinction_value)
        absorption.append(extinction_value - scattering_value)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
