# Sphere sensitivity report

`solution.py` uses the installed `treams_rs` sphere T-matrix and its installed
Advect adapter (`treams_rs.advect.sphere`).  The incident field is a unit
positive-helicity plane wave travelling in `+z`, in the helicity basis.

Lengths are in micrometres, so `k0 = 2*pi/wavelength` is in inverse
micrometres.  Relative permittivity is `epsilon_real + i*epsilon_imag`; the
exterior is vacuum (`epsilon=mu=1`), with `mu=1` and chirality zero in the
sphere.  The returned efficiency is dimensionless:

`Q = xs_sca / (pi * radius**2)`.

The scattering cross section is the treams-rs vacuum spherical-wave weighted
norm, `sum(abs(T @ incident)**2)/k0**2`.  Advect's native reverse pullback
supplies derivatives with respect to radius and real permittivity, including
the explicit radius normalization.  Wavelength, `lmax`, and the imaginary
permittivity are held fixed.

Checks performed: the example was executed to create `results.json`; an
independent small central-difference check agreed with both reported
components to the displayed precision (finite differences were validation
only, not used for the result).
