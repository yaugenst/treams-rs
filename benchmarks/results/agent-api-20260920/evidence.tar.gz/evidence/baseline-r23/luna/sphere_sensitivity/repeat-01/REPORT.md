# Sphere sensitivity report

`solution.py` uses `treams_rs.advect.sphere_tmatrix` and its native Advect
pullbacks.  The incident wave travels along `+z` and uses helicity index 1,
the positive-helicity channel.  Vacuum is the exterior medium, with relative
`mu = 1` and chirality `kappa = 0`; the sphere has relative permittivity
`epsilon_real + i epsilon_imag` and `mu = 1`.

Lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers and the scattering cross section is in square micrometers.
The returned efficiency is dimensionless:

`Q = scattering_cross_section / (pi * radius**2)`.

The returned gradient is ordered as
`[dQ/dradius, dQ/depsilon_real]`, with epsilon_imag, wavelength, and lmax
held fixed.  Advect differentiates both the native treams sphere scattering
and the radius-dependent normalization analytically.  Inputs are checked for
positive radius and wavelength and `lmax >= 1`; the CLI reads one JSON object
from stdin and writes one JSON object to stdout.

The example execution is recorded in `results.json`.
