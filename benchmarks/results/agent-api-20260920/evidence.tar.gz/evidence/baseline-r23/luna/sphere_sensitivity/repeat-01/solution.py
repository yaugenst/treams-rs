"""Helicity-resolved sphere scattering sensitivity."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect
import treams_rs.advect as treams


def _objective(radius: Any, epsilon_real: Any, *, epsilon_imag: float,
               wavelength: float, lmax: int) -> Any:
    """Return Q; radius and epsilon_real are Advect differentiable values."""
    k0 = 2.0 * math.pi / wavelength
    sphere = treams.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=treams.Material(epsilon=epsilon_real + 1j * epsilon_imag),
    )
    # In the helicity ordering, polarization index 1 is positive helicity.
    incidence = treams.PlaneWave((0.0, 0.0, 1.0), 1, k0=k0)
    scattering_cross_section = sphere.cross_sections(incidence).scattering
    return scattering_cross_section / (math.pi * radius * radius)


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Calculate scattering efficiency and its analytic parameter gradient."""
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    if radius <= 0.0 or wavelength <= 0.0 or lmax < 1:
        raise ValueError("radius and wavelength must be positive, and lmax >= 1")

    value, gradient = advect.value_and_grad(
        lambda r, e: _objective(
            r,
            e,
            epsilon_imag=epsilon_imag,
            wavelength=wavelength,
            lmax=lmax,
        ),
        argnums=(0, 1),
    )(radius, epsilon_real)

    return {
        "scattering_efficiency": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
