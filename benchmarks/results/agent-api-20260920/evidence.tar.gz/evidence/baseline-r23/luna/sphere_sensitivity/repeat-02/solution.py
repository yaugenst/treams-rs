"""Sphere scattering efficiency and native reverse-mode sensitivities."""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs
import treams_rs.advect as tadv


def _efficiency(radius, epsilon_real, epsilon_imag, wavelength, lmax):
    """Return Q; the first two arguments are differentiated by Advect."""
    k0 = 2.0 * np.pi / wavelength

    # This basis and incident vector are independent of the differentiated
    # parameters.  treams' helicity label 1 is positive helicity.
    basis_tm = treams_rs.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=complex(epsilon_real, epsilon_imag),
        polarization="helicity",
    )
    incident = treams_rs.plane_wave(
        direction=(0.0, 0.0, 1.0),
        polarization="positive_helicity",
        k0=k0,
        poltype="helicity",
    ).in_basis(basis_tm.basis).coefficients

    def objective(r, er):
        # Native sphere() takes one material per layer plus the exterior.
        radii = ad.numpy.stack((r,))
        epsilon = ad.numpy.stack((er + 1j * epsilon_imag, 1.0 + 0j))
        tm = tadv.sphere(lmax, k0, radii, epsilon)
        scattered = tm @ incident
        # For vacuum and the default spherical basis, xs_sca is
        # sum(|scattered|^2)/k0^2.  Divide by pi*r^2 as requested.
        return ad.numpy.sum(ad.numpy.abs(scattered) ** 2) / (
            k0 * k0 * np.pi * r * r
        )

    return ad.value_and_grad(objective, argnums=(0, 1))(
        float(radius), float(epsilon_real)
    )


def run(config):
    """Evaluate the requested efficiency and analytic gradient."""
    required = ("radius", "epsilon_real", "epsilon_imag", "wavelength", "lmax")
    missing = [key for key in required if key not in config]
    if missing:
        raise KeyError("missing config keys: " + ", ".join(missing))
    value, gradient = _efficiency(
        config["radius"],
        config["epsilon_real"],
        config["epsilon_imag"],
        config["wavelength"],
        int(config["lmax"]),
    )
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
