# Radius inverse design

`solution.py` fits the radius of a homogeneous, lossless sphere using
`treams_rs.advect.sphere` and its native analytic pullback.  The exterior is
vacuum (`epsilon=mu=1`, `kappa=0`); the sphere has the configured relative
permittivity, `mu=1`, and zero chirality.  All lengths are in micrometers, so
the wavenumber is `k0=2*pi/wavelength` in inverse micrometers.

The fitted quantity is the rotationally and polarization-averaged scattering
efficiency, `Q_sca = C_sca/(pi*r^2)`, using the treams helicity T-matrix
convention and the configured `lmax`.  The objective is the mean squared
relative residual specified in the prompt.  Optimization uses projected,
backtracking gradient descent; both the objective gradient and the final
gradient come from Advect's native treams pullback.

Checks for the supplied example:

- radius: `0.11000002362890189 um`
- final loss: `7.46284706462476e-13` (less than `1e-7`)
- initial loss: `0.621529000228654`
- fitted efficiencies: `1.5627995700614437`, `0.8019222042979898`,
  `0.42538749458983527`
- radius remained within `[0.06, 0.14] um`; the recorded loss history was
  monotonically decreasing.
