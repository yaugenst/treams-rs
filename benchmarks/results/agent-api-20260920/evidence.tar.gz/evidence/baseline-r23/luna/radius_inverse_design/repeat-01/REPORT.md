# Radius inverse design

`solution.py` uses `treams_rs.advect.sphere_tmatrix` and its native Advect
pullback.  The exterior is vacuum (`epsilon=mu=1`, chirality zero), while the
particle has the configured relative permittivity, `mu=1`, and zero chirality.

All lengths are in micrometers.  Thus `k0=2*pi/wavelength` is in inverse
micrometers, the scattering cross section is in square micrometers, and the
reported efficiency is `Q_sca=C_sca/(pi*radius**2)`.  The plane wave travels
along +z with positive helicity; the spherical T-matrix uses the configured
`lmax` and the result is direction/helicity independent for this sphere.

The objective is the mean squared relative efficiency residual.  A projected
Armijo line search uses the analytic radius gradient from Advect; no finite
difference derivative is used.  Bounds are enforced on every trial.  Checks
include finite JSON outputs, bounded radius, and an example objective below
`1e-7`.
