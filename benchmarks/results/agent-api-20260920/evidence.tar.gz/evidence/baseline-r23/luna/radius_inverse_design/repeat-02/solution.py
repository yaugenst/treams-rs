"""Radius fitting for a homogeneous dielectric sphere."""

from __future__ import annotations

import json
import sys
from typing import Any

import advect as ad
import numpy as np
import treams_rs
import treams_rs.advect as trs_ad


def _objective_factory(config: dict[str, Any]):
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = np.asarray(config["wavelengths"], dtype=float)
    targets = np.asarray(config["target_efficiencies"], dtype=float)
    # The last material is the exterior.  Keeping these as ordinary arrays makes
    # them constants in Advect's trace while the radius remains differentiable.
    eps = np.asarray([epsilon, 1.0], dtype=float)
    mu = np.ones(2, dtype=float)
    kappa = np.zeros(2, dtype=float)

    def objective(radius: Any):
        values = []
        for wavelength in wavelengths:
            k0 = 2.0 * np.pi / wavelength
            matrix = trs_ad.sphere(
                lmax,
                k0,
                ad.numpy.asarray([radius]),
                eps,
                mu,
                kappa,
            )
            # treams' rotationally averaged sphere cross section is
            # 2*pi*sum(|T_ij/k|^2). Divide by pi*r^2 for Q_sca.
            qsca = 2.0 * ad.numpy.sum(ad.numpy.abs(matrix) ** 2) / (k0 * k0 * radius * radius)
            values.append(qsca)
        fitted = ad.numpy.stack(values)
        residual = (fitted - targets) / targets
        return ad.numpy.mean(residual * residual)

    return objective, wavelengths, targets


def _efficiencies(radius: float, config: dict[str, Any]) -> list[float]:
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    result = []
    for wavelength in config["wavelengths"]:
        k0 = 2.0 * np.pi / float(wavelength)
        matrix = treams_rs.TMatrix.sphere(
            lmax,
            k0,
            radius,
            [treams_rs.Material(epsilon), treams_rs.Material(1.0)],
        )
        result.append(float(matrix.xs_sca_avg / (np.pi * radius * radius)))
    return result


def run(config: dict[str, Any]) -> dict[str, Any]:
    objective, wavelengths, targets = _objective_factory(config)
    lo, hi = (float(x) for x in config["bounds"])
    radius = min(hi, max(lo, float(config["initial_radius"])))

    initial_loss, _ = ad.value_and_grad(objective)(radius)
    initial_loss = float(initial_loss)
    loss_history = [initial_loss]

    # Backtracking projected gradient descent. Every direction and step is
    # obtained from the native analytic pullback; no finite differences are used.
    for _ in range(500):
        loss, gradient = ad.value_and_grad(objective)(radius)
        loss = float(loss)
        gradient = float(gradient)
        if loss < 1.0e-12 or abs(gradient) < 1.0e-13:
            break
        step = 0.25 * (hi - lo)
        accepted = False
        while step > 1.0e-15 * max(1.0, hi - lo):
            candidate = min(hi, max(lo, radius - step * gradient))
            candidate_loss = float(objective(candidate))
            # Armijo decrease, with a small fallback for a projected boundary.
            if candidate_loss <= loss - 1.0e-4 * step * gradient * gradient or (
                candidate != radius and candidate_loss < loss
            ):
                radius = candidate
                loss_history.append(candidate_loss)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    final_loss, final_gradient = ad.value_and_grad(objective)(radius)
    final_loss = float(final_loss)
    final_gradient = float(final_gradient)
    return {
        "radius": float(radius),
        "loss": final_loss,
        "initial_loss": initial_loss,
        "gradient": final_gradient,
        "fitted_efficiencies": _efficiencies(float(radius), config),
        "loss_history": [float(x) for x in loss_history],
    }


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
