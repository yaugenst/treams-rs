"""Bounded inverse design for a homogeneous spherical scatterer."""

import json
import sys

import advect as ad
import advect.numpy as anp
import numpy as np
import treams_rs.advect as tr


def _efficiency(radius, wavelength, epsilon, lmax):
    k0 = 2.0 * anp.pi / wavelength
    tm = tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)
    # A plane wave gives the standard single-particle scattering cross section.
    # For a sphere this is independent of its direction and helicity.
    inc = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    csca = tm.cross_sections(inc).scattering
    return csca / (anp.pi * radius * radius)


def _make_loss(config):
    epsilon = config["epsilon"]
    lmax = int(config["lmax"])
    wavelengths = [float(x) for x in config["wavelengths"]]
    targets = [float(x) for x in config["target_efficiencies"]]

    def loss(radius):
        value = 0.0
        for wavelength, target in zip(wavelengths, targets):
            q = _efficiency(radius, wavelength, epsilon, lmax)
            residual = (q - target) / target
            value = value + residual * residual
        return value / len(targets)

    return loss


def run(config):
    """Fit the radius and return JSON-compatible scalar/list results."""
    lower, upper = (float(x) for x in config["bounds"])
    radius = min(upper, max(lower, float(config["initial_radius"])))
    loss = _make_loss(config)
    value_and_grad = ad.value_and_grad(loss)
    initial_loss = float(loss(radius))
    history = [initial_loss]

    # Armijo backtracking uses the analytic Advect pullback.  Projection makes
    # every trial remain in the requested interval.
    for _ in range(300):
        value, derivative = value_and_grad(radius)
        value = float(value)
        derivative = float(derivative)
        if value < 1.0e-14:
            break
        if abs(derivative) < 1.0e-14:
            break
        direction = -derivative
        step = min(0.01, 0.1 / (abs(derivative) + 1.0e-30))
        accepted = False
        for _ in range(60):
            trial = min(upper, max(lower, radius + step * direction))
            trial_value = float(loss(trial))
            displacement = trial - radius
            if trial_value <= value + 1.0e-4 * derivative * displacement:
                accepted = True
                break
            step *= 0.5
        if not accepted or abs(trial - radius) < 1.0e-14:
            break
        radius = trial
        history.append(trial_value)

    final_loss, final_gradient = value_and_grad(radius)
    fitted = [float(_efficiency(radius, w, config["epsilon"], int(config["lmax"])))
              for w in config["wavelengths"]]
    return {
        "radius": float(radius),
        "loss": float(final_loss),
        "initial_loss": initial_loss,
        "gradient": float(final_gradient),
        "fitted_efficiencies": fitted,
        "loss_history": [float(x) for x in history],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")
