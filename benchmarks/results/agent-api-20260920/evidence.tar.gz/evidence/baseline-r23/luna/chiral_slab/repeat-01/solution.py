"""Normal-incidence scattering from a reciprocal chiral slab."""

from __future__ import annotations

import json
import sys
from typing import Any

import treams_rs


def run(config: dict[str, Any]) -> dict[str, list[list[float]]]:
    """Return power fractions for positive and negative helicity channels."""
    thickness = float(config["thickness"])
    eps_data = config["epsilon"]
    epsilon = complex(float(eps_data[0]), float(eps_data[1]))
    kappa = complex(config.get("kappa", 0.0))
    wavelengths = [float(value) for value in config["wavelengths"]]

    # default() emits (kx, ky, pol) = (0, 0, 1), (0, 0, 0):
    # treams' helicity labels are consequently positive, then negative.
    basis = treams_rs.PlaneWavePorts.default([[0.0, 0.0]])
    material = treams_rs.Material(epsilon, 1.0, kappa)
    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    for wavelength in wavelengths:
        k0 = 2.0 * 3.141592653589793 / wavelength
        smatrix = treams_rs.multilayer_slab(
            basis=basis,
            k0=k0,
            thicknesses=[thickness],
            materials=[material],
            negative_medium=treams_rs.Material(1.0),
            positive_medium=treams_rs.Material(1.0),
            polarization="helicity",
        )
        row_t: list[float] = []
        row_r: list[float] = []
        row_a: list[float] = []
        for channel in (0, 1):
            incident = [0j, 0j]
            incident[channel] = 1.0 + 0j
            powers = smatrix.power(incident, side="negative")
            row_t.append(float(powers.transmission))
            row_r.append(float(powers.reflection))
            row_a.append(float(powers.absorption))
        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
