# Report

`solution.py` uses the public `treams_rs.slab` native scattering implementation
with a two-channel normal-incidence plane-wave basis. The returned columns are
positive helicity followed by negative helicity, matching the package's
helicity convention. `transmission`, `reflection`, and `absorption` are power
fractions normalized to incident power; absorption is the native balance
remainder `1 - T - R`, not an amplitude quantity.

All lengths are in micrometers, so each wavelength uses `k0 = 2*pi/wavelength`
in inverse micrometers. The material is `(epsilon, mu, kappa)` with
`epsilon = real + i*imag`, `mu = 1`, and the supplied dimensionless package
chirality `kappa`. Both exterior media are vacuum.

Checks performed: the example was executed and written to `results.json`; each
channel was checked for finite values, nonnegative power (within numerical
tolerance), and `T + R + A = 1`.
