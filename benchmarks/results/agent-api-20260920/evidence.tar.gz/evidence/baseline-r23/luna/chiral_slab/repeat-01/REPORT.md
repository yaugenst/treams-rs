# Chiral slab report

`solution.py` models one homogeneous reciprocal chiral layer with
`treams_rs.multilayer_slab`; no scattering formulas are reimplemented here.

Lengths are in micrometers, so each wavelength uses `k0 = 2*pi/lambda` in
inverse micrometers. The input `epsilon: [real, imag]` is converted to the
complex relative permittivity `real + i*imag`. Relative permeability is one,
and `kappa` is passed unchanged as the dimensionless treams material chirality.
Both exterior media are vacuum.

The incident wave is from the negative-z side and propagates in +z. The
normal-incidence helicity basis is ordered positive, negative, matching the
two channels produced by `PlaneWavePorts.default`. Returned values are power
fractions: native treams transmission and reflection, with absorption formed
as `1 - T - R`.

Checks performed for the example include the expected `(3, 2)` shape and
power balance. The lossy slab gives nonnegative absorption (up to numerical
roundoff), and each channel satisfies `T + R + A = 1` to floating-point
precision.
