"""Power scattering of a reciprocal chiral slab at normal incidence."""

import json
import math
import sys

import numpy as np
import treams_rs


def _number(value, name):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    return value


def run(config):
    """Return T, R, and A for positive and negative helicity.

    The result arrays have shape (len(wavelengths), 2), with columns ordered
    positive helicity then negative helicity.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    thickness = _number(config["thickness"], "thickness")
    if thickness < 0:
        raise ValueError("thickness must be nonnegative")

    epsilon_parts = config["epsilon"]
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _number(epsilon_parts[0], "epsilon real"),
        _number(epsilon_parts[1], "epsilon imag"),
    )
    kappa = complex(_number(config.get("kappa", 0), "kappa"))

    wavelengths = config["wavelengths"]
    if not isinstance(wavelengths, (list, tuple)):
        raise ValueError("wavelengths must be a list")

    transmission = []
    reflection = []
    absorption = []
    # PlaneWaveBasis.default uses labels (1, 0), which are positive and
    # negative helicity respectively in treams-rs' helicity convention.
    directions = treams_rs.PlaneWaveBasis.default([0.0, 0.0, 1.0])
    material = treams_rs.Material([epsilon, 1.0, kappa])

    for wavelength_value in wavelengths:
        wavelength = _number(wavelength_value, "wavelength")
        if wavelength <= 0:
            raise ValueError("wavelengths must be positive")
        k0 = 2.0 * math.pi / wavelength
        basis = directions.bycomp(k0)
        smatrix = treams_rs.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )

        t_row = []
        r_row = []
        a_row = []
        for channel in range(2):
            incident = np.zeros(2, dtype=np.complex128)
            incident[channel] = 1.0
            balance = smatrix.power(incident, side="negative")
            t = float(balance.transmission)
            r = float(balance.reflection)
            a = float(balance.absorption)
            if min(t, r, a) < -1e-10:
                raise ValueError("native power balance returned a negative fraction")
            if not math.isfinite(t + r + a) or abs(t + r + a - 1.0) > 1e-9:
                raise ValueError("native power balance failed its energy check")
            t_row.append(t)
            r_row.append(r)
            a_row.append(a)
        transmission.append(t_row)
        reflection.append(r_row)
        absorption.append(a_row)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
