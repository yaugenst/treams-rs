# Sphere spectrum report

`solution.py` uses the public `treams_rs.sphere_tmatrix` and
`treams_rs.plane_wave` interfaces. The spherical response is truncated at the
requested `lmax`; the incident wave travels in `+z` and has positive helicity.

All lengths are in micrometers, so the returned cross sections are in
square micrometers. `epsilon: [real, imag]` is converted to the complex
relative permittivity `real + i*imag`; the sphere has relative permeability 1
and chirality 0, and the exterior is vacuum. Efficiency is scattering divided
by `pi*radius**2`.

For each wavelength, treams-rs computes scattering and extinction for the
plane-wave illumination. Absorption is its reported extinction minus
scattering. The implementation checks positive finite radius and wavelengths,
and positive multipole cutoff. The example was executed to produce
`results.json`; its absorption values are positive and its extinction values
are at least its scattering values (up to numerical roundoff).
