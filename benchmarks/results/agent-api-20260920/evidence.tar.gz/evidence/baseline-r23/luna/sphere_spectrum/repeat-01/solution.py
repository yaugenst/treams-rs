"""Finite-multipole dielectric-sphere spectrum using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return cross sections for the specified homogeneous sphere.

    Lengths are micrometers.  The two entries in ``epsilon`` are the real and
    imaginary parts of relative permittivity.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")
    radius = float(config["radius"])
    eps_parts = config["epsilon"]
    wavelengths = config["wavelengths"]
    lmax = int(config["lmax"])
    if len(eps_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    if radius <= 0 or not math.isfinite(radius):
        raise ValueError("radius must be positive and finite")
    if lmax < 1:
        raise ValueError("lmax must be positive")

    epsilon = complex(float(eps_parts[0]), float(eps_parts[1]))
    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    efficiency: list[float] = []
    area = math.pi * radius * radius

    for wavelength_value in wavelengths:
        wavelength = float(wavelength_value)
        if wavelength <= 0 or not math.isfinite(wavelength):
            raise ValueError("wavelengths must be positive and finite")
        k0 = 2.0 * math.pi / wavelength
        tmatrix = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=tr.Material(epsilon),
            medium=tr.Material(1),
            polarization="helicity",
        )
        incident = tr.plane_wave(
            direction=(0.0, 0.0, 1.0),
            polarization="positive_helicity",
            k0=k0,
            medium=tr.Material(1),
        )
        cross_sections = tmatrix.cross_sections(incident)
        sca = float(cross_sections.scattering)
        ext = float(cross_sections.extinction)
        abs_ = float(cross_sections.absorption)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(abs_)
        efficiency.append(sca / area)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


if __name__ == "__main__":
    input_config = json.load(sys.stdin)
    print(json.dumps(run(input_config), separators=(",", ":")))
