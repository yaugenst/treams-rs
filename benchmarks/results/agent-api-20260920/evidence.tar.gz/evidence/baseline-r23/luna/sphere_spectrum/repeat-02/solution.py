"""Spectrum of a homogeneous dielectric sphere using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return sphere cross sections for the wavelengths in *config*.

    All lengths are in the units supplied by the configuration.  The material
    is specified as relative epsilon, with unit relative permeability and zero
    chirality, and the exterior is vacuum.
    """
    radius = float(config["radius"])
    epsilon_parts = config["epsilon"]
    wavelengths = config["wavelengths"]
    lmax = int(config["lmax"])

    if not math.isfinite(radius) or radius <= 0:
        raise ValueError("radius must be positive and finite")
    if len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    if not all(math.isfinite(x) for x in (epsilon.real, epsilon.imag)):
        raise ValueError("epsilon must be finite")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength_value in wavelengths:
        wavelength = float(wavelength_value)
        if not math.isfinite(wavelength) or wavelength <= 0:
            raise ValueError("wavelengths must be positive and finite")
        k0 = 2.0 * math.pi / wavelength
        tmatrix = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=[epsilon, 1, 0],
            medium=1,
            polarization="helicity",
        )
        incident = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        cross_sections = tmatrix.cross_sections(incident)
        sca = float(cross_sections.scattering)
        ext = float(cross_sections.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(ext - sca)

    area = math.pi * radius * radius
    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": [value / area for value in scattering],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
