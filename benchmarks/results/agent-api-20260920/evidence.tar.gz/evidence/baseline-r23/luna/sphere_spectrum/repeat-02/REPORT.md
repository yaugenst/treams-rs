# Sphere spectrum report

`solution.py` uses the public `treams_rs.sphere_tmatrix` and
`TMatrix.cross_sections` APIs with the requested multipole cutoff.  For each
wavelength, `k0 = 2*pi/wavelength`; the radius and all reported cross sections
therefore use square micrometres.  The supplied `[real, imag]` pair is used as
relative permittivity, with relative permeability 1, chirality 0, and vacuum
outside.  Illumination is a +z plane wave in the named positive-helicity
channel.  Efficiency is `scattering / (pi*radius**2)` and is dimensionless.

Checks performed:

- The example was executed through the CLI and saved to `results.json`.
- Absorption is formed from the library identity `extinction - scattering`.
- The example gives positive absorption at every wavelength and all returned
  values are finite.
