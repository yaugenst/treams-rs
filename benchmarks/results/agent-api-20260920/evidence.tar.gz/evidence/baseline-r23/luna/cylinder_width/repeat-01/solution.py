"""Infinite-cylinder scattering widths using the public treams-rs API."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as treams


def _permittivity(value: Any) -> complex:
    """Decode the requested [real, imaginary] relative permittivity."""
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError("epsilon must be [real, imag]")
    real, imag = (float(value[0]), float(value[1]))
    return complex(real, imag)


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return scattering, extinction and absorption widths for each wavelength."""
    radius = float(config["radius"])
    epsilon = _permittivity(config["epsilon"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    mmax = int(config["mmax"])
    if radius <= 0 or any(w <= 0 for w in wavelengths) or mmax < 0:
        raise ValueError("radius and wavelengths must be positive; mmax must be nonnegative")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        tmatrix = treams.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],
            mmax=mmax,
            radius=radius,
            material=epsilon,
            medium=1,
            polarization="helicity",
        )
        incident = treams.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        widths = tmatrix.cross_widths(incident)
        scattering.append(float(widths.scattering))
        extinction.append(float(widths.extinction))
        absorption.append(float(widths.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
