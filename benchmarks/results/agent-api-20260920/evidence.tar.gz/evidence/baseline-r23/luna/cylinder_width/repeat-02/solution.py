"""Infinite-cylinder cross widths using the public treams-rs API."""

import json
import sys

import treams_rs


def run(config):
    """Return scattering, extinction, and absorption widths by wavelength."""
    radius = float(config["radius"])
    epsilon = config["epsilon"]
    if not isinstance(epsilon, (list, tuple)) or len(epsilon) != 2:
        raise ValueError("epsilon must be [real, imag]")
    material = complex(float(epsilon[0]), float(epsilon[1]))
    wavelengths = [float(value) for value in config["wavelengths"]]
    mmax = int(config["mmax"])
    if radius <= 0 or not wavelengths or any(value <= 0 for value in wavelengths):
        raise ValueError("radius and wavelengths must be positive")
    if mmax < 0:
        raise ValueError("mmax must be nonnegative")

    # Keep the returned lists in ascending wavelength order, independently of
    # the order in which the caller supplied the wavelengths.
    ordered_wavelengths = sorted(wavelengths)
    scattering = []
    extinction = []
    absorption = []
    for wavelength in ordered_wavelengths:
        k0 = 2.0 * 3.141592653589793 / wavelength
        tmatrix = treams_rs.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],
            mmax=mmax,
            radius=radius,
            material=material,
            medium=1,
            polarization="helicity",
        )
        incident = treams_rs.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            material=1,
        )
        widths = tmatrix.cross_widths(incident)
        scattering.append(float(widths.scattering))
        extinction.append(float(widths.extinction))
        absorption.append(float(widths.absorption))
    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
