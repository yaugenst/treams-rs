# Infinite-cylinder scattering widths

`solution.py` uses the public `treams_rs.cylinder_tmatrix` and
`cross_widths` operations.  The cylinder axis is `z`, `kz=0`, the exterior
medium is vacuum, and illumination is a unit-amplitude positive-helicity
plane wave propagating along `+x`.  `mmax` is passed directly as the azimuthal
cutoff.

All input lengths are micrometers, so the returned cross widths are in
micrometers.  The input `epsilon: [real, imag]` is interpreted as the complex
relative permittivity `real + i*imag`; relative permeability is one and
chirality is zero.  No sphere-area normalization is applied.

Checks performed: absorption is the library's extinction-minus-scattering
quantity, and the CLI output was generated from the supplied example config.
