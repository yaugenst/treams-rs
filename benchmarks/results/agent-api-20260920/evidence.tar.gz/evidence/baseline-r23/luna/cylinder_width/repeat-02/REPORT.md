# Report

`solution.py` treats every supplied length as micrometers, so `k0 = 2π / λ`
is in inverse micrometers and the returned cross sections are cross widths in
micrometers.  The cylinder is infinite and parallel to z, with `kz=0`; the
exterior has relative ε=μ=1 and zero chirality.  The cylinder permittivity is
formed as `epsilon[0] + i*epsilon[1]`.  Illumination is a unit positive-
helicity plane wave travelling along +x.  The native helicity basis and native
`cylinder_tmatrix(...).cross_widths(...)` normalization are used directly;
there is no sphere-area normalization.

For the example, the lists are sorted by increasing wavelength.  Checks made
while developing the solution were that native absorption equals extinction
minus scattering, and that reversing helicity gives the same widths for this
isotropic cylinder.  The example values are recorded in `results.json`.
