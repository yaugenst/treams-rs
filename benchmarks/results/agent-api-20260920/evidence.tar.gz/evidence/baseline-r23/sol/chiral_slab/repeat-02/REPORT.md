# Chiral slab calculation

`solution.py` uses the public `treams_rs.slab` scattering-matrix constructor and
its flux-normalized `power` method. Lengths (slab thickness and vacuum
wavelengths) are in micrometers, so the vacuum angular wavenumber is
`k0 = 2*pi/wavelength` in inverse micrometers. Relative permittivity is formed
as `epsilon[0] + i*epsilon[1]`; relative permeability is 1, the supplied
`kappa` is the dimensionless reciprocal-material chirality, and both exterior
half-spaces are vacuum.

The plane-wave basis is normal to z. In the treams-rs helicity convention,
polarization label 1 is positive helicity and label 0 is negative helicity.
The returned columns are explicitly generated in that order. Incidence is from
the negative-z side and propagates in +z. Transmission and reflection come from
the package's power-flux normalization, not from unnormalized amplitude
moduli; absorption is its remainder `1 - T - R`.

Checks performed on the example include finite output, the requested `(3, 2)`
shape, and energy closure `T + R + A = 1` for every wavelength and helicity.
A separate lossless check (`Im(epsilon) = 0`) gave zero absorption to floating
point precision. For this example, real kappa changes the helicity-dependent
transmission phase but the two power balances coincide, as expected for this
normal-incidence reciprocal slab with helicity-independent impedance and loss.
