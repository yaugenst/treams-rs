# Chiral slab calculation

`solution.py` uses the public `treams_rs` plane-wave slab S-matrix and its
flux-normalized `power` method. No Fresnel or transfer-matrix solver is
reimplemented.

## Units and conventions

- Thickness and vacuum wavelengths are in micrometers, so the vacuum angular
  wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers.
- Relative permittivity is `epsilon[0] + i*epsilon[1]`; relative permeability
  is 1. The supplied `kappa` is passed directly as the dimensionless reciprocal
  material chirality used by treams-rs. Both exterior half-spaces are vacuum.
- Illumination travels in the positive z direction from the negative-z vacuum
  half-space. The output columns are positive helicity and negative helicity,
  in that order.
- Transmission and reflection come from flux-normalized outgoing powers.
  Absorption is the remaining incident-power fraction, `1 - T - R`.

## Checks

- The numerical result is finite and every returned row has two helicity
  entries.
- For every wavelength and helicity in the example, `T + R + A` is unity to
  floating-point precision.
- The example has positive imaginary permittivity and gives nonnegative
  absorption. Its real chirality rotates the transmitted phase but, for this
  reciprocal uniform slab at normal incidence, does not create a power
  difference between the two helicities; the equal example columns are thus
  expected rather than an omitted polarization channel.
