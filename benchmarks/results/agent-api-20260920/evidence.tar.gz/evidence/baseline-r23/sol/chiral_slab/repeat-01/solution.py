"""Normal-incidence power balance of a reciprocal chiral slab."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import treams_rs as treams


def _finite_number(value: Any, name: str) -> float:
    """Return *value* as a finite float, with a useful input error."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite number")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f"{name} must be a finite number") from error
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite number")
    return result


def run(config: Mapping[str, Any]) -> dict[str, list[list[float]]]:
    """Compute slab transmission, reflection, and absorption by helicity.

    Rows follow ``config["wavelengths"]``.  The two columns are positive and
    negative helicity, respectively.  All returned values are power fractions.
    """
    if not isinstance(config, Mapping):
        raise TypeError("config must be a mapping")

    try:
        epsilon_parts = config["epsilon"]
        wavelength_values = config["wavelengths"]
        thickness_value = config["thickness"]
        kappa_value = config["kappa"]
    except KeyError as error:
        raise ValueError(f"missing required config key: {error.args[0]}") from error

    if (
        not isinstance(epsilon_parts, (list, tuple))
        or len(epsilon_parts) != 2
    ):
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _finite_number(epsilon_parts[0], "epsilon[0]"),
        _finite_number(epsilon_parts[1], "epsilon[1]"),
    )
    thickness = _finite_number(thickness_value, "thickness")
    kappa = _finite_number(kappa_value, "kappa")
    if thickness < 0:
        raise ValueError("thickness must be nonnegative")
    if not isinstance(wavelength_values, (list, tuple)) or not wavelength_values:
        raise ValueError("wavelengths must be a nonempty list")
    wavelengths = [
        _finite_number(value, f"wavelengths[{index}]")
        for index, value in enumerate(wavelength_values)
    ]
    if any(value <= 0 for value in wavelengths):
        raise ValueError("wavelengths must be positive")

    # At normal incidence only the two zero-transverse-wavevector helicity
    # channels are needed.  treams-rs conventionally lists label 1 first.
    basis = treams.PlaneWavePorts([(0.0, 0.0, 1), (0.0, 0.0, 0)])
    material = treams.Material(epsilon, 1.0, kappa)
    helicities = ("positive_helicity", "negative_helicity")

    result: dict[str, list[list[float]]] = {
        "transmission": [],
        "reflection": [],
        "absorption": [],
    }
    for wavelength in wavelengths:
        k0 = math.tau / wavelength
        smatrix = treams.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )

        transmission: list[float] = []
        reflection: list[float] = []
        absorption: list[float] = []
        for helicity in helicities:
            incident = treams.plane_wave(
                direction=(0.0, 0.0, 1.0),
                polarization=helicity,
                k0=k0,
                medium=1.0,
            )
            power = smatrix.power(incident, side="negative")
            t_value = float(power.transmission)
            r_value = float(power.reflection)
            a_value = float(power.absorption)
            if not all(math.isfinite(x) for x in (t_value, r_value, a_value)):
                raise RuntimeError("treams-rs returned a non-finite power balance")
            transmission.append(t_value)
            reflection.append(r_value)
            absorption.append(a_value)

        result["transmission"].append(transmission)
        result["reflection"].append(reflection)
        result["absorption"].append(absorption)

    return result


def main() -> None:
    """Read one JSON config from stdin and emit one JSON result to stdout."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
