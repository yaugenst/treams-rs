"""Power balance of a reciprocal chiral slab at normal incidence."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as treams


def _finite_number(value: Any, name: str) -> float:
    """Convert a JSON number to a finite float with a useful error message."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, list[list[float]]]:
    """Return slab power fractions for positive and negative helicity.

    Lengths in ``config`` are in micrometers.  Each row of each returned array
    corresponds to one input wavelength and is ordered positive, then negative
    helicity.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    thickness = _finite_number(config["thickness"], "thickness")
    if thickness < 0:
        raise ValueError("thickness must be nonnegative")

    epsilon_parts = config["epsilon"]
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _finite_number(epsilon_parts[0], "epsilon[0]"),
        _finite_number(epsilon_parts[1], "epsilon[1]"),
    )
    kappa = _finite_number(config["kappa"], "kappa")

    raw_wavelengths = config["wavelengths"]
    if not isinstance(raw_wavelengths, (list, tuple)):
        raise ValueError("wavelengths must be a list")
    wavelengths = [
        _finite_number(value, f"wavelengths[{index}]")
        for index, value in enumerate(raw_wavelengths)
    ]
    if any(value <= 0 for value in wavelengths):
        raise ValueError("wavelengths must be positive")

    # treams-rs helicity labels are 1 = positive and 0 = negative.  Defining
    # the ports explicitly makes the requested output ordering unambiguous.
    basis = treams.PlaneWavePorts([(0.0, 0.0, 1), (0.0, 0.0, 0)])
    material = treams.Material(epsilon, 1.0, kappa)
    illuminations = ([1.0, 0.0], [0.0, 1.0])

    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    for wavelength in wavelengths:
        smatrix = treams.slab(
            basis=basis,
            k0=2.0 * math.pi / wavelength,
            thickness=thickness,
            material=material,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        balances = [
            smatrix.power(incident, side="negative")
            for incident in illuminations
        ]
        transmission.append([float(item.transmission) for item in balances])
        reflection.append([float(item.reflection) for item in balances])
        absorption.append([float(item.absorption) for item in balances])

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main() -> None:
    """Read one JSON configuration from stdin and write one JSON result."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
