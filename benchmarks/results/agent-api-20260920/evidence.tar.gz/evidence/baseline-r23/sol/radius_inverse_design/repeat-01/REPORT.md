# Sphere radius inverse design

`solution.py` models a homogeneous, nonmagnetic, nonchiral sphere in vacuum.
All wavelengths and radii are in micrometers, so the vacuum angular
wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers. Relative
permittivity is dimensionless; relative permeability is one and chirality is
zero. The supplied `lmax` truncates the spherical multipole expansion.

The fitted observable is the unpolarized/orientation-averaged scattering
efficiency. From the helicity-basis T-matrix returned by `treams_rs`, it is

`Q_sca = C_sca/(pi*r^2) = 2*||T||_F^2/(k0*r)^2`.

This agrees with `TMatrix.average_cross_sections.scattering/(pi*r^2)` to
about 3.4e-16 in a direct check. The objective is the requested mean squared
relative residual. `gradient` is `d(loss)/d(radius)`, hence has units of
inverse micrometers; efficiencies and loss are dimensionless.

The T-matrix and its radius sensitivity come from the public
`treams_rs.diff.sphere` native pullback. The optimizer is a bounded,
one-dimensional projected BFGS iteration with an Armijo line search; its
search directions use analytic gradients. A centered finite-difference test
at radius 0.095 micrometers was used only as an independent validation: the
analytic gradient was -20.803642548876827 per micrometer and the step-1e-6
finite-difference value was -20.803642534428235 (relative difference
6.95e-10).

For the example, the inferred radius is 0.10999999999990018 micrometers and
the final loss is 1.3288390046527296e-23. The loss decreased at every accepted
iteration. Additional checks with synthetic targets at radii 0.07, 0.09,
0.12, and 0.135 micrometers all recovered their radii with losses below
1.9e-17 from different starting points.
