"""Radius inversion for a lossless homogeneous sphere using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import numpy as np
import treams_rs


def _validate(config: dict[str, Any]) -> tuple[float, int, np.ndarray, float, float, float, np.ndarray]:
    """Validate and normalize the small public input schema."""
    try:
        epsilon = float(config["epsilon"])
        lmax = int(config["lmax"])
        wavelengths = np.asarray(config["wavelengths"], dtype=float)
        initial = float(config["initial_radius"])
        bounds = np.asarray(config["bounds"], dtype=float)
        targets = np.asarray(config["target_efficiencies"], dtype=float)
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"invalid configuration: {exc}") from exc

    if not math.isfinite(epsilon) or epsilon == 0:
        raise ValueError("epsilon must be a finite, nonzero real number")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")
    if wavelengths.ndim != 1 or wavelengths.size == 0:
        raise ValueError("wavelengths must be a nonempty one-dimensional array")
    if targets.shape != wavelengths.shape:
        raise ValueError("target_efficiencies must match wavelengths")
    if bounds.shape != (2,):
        raise ValueError("bounds must contain exactly [lower, upper]")
    if (not np.all(np.isfinite(wavelengths))) or np.any(wavelengths <= 0):
        raise ValueError("wavelengths must be positive and finite")
    if (not np.all(np.isfinite(targets))) or np.any(targets <= 0):
        raise ValueError("target_efficiencies must be positive and finite")
    lower, upper = float(bounds[0]), float(bounds[1])
    if not (math.isfinite(lower) and math.isfinite(upper) and 0 < lower < upper):
        raise ValueError("bounds must be finite, positive, and strictly increasing")
    if not (math.isfinite(initial) and lower <= initial <= upper):
        raise ValueError("initial_radius must be finite and inside bounds")
    return epsilon, lmax, wavelengths, initial, lower, upper, targets


def _efficiencies(
    radius: float,
    epsilon: float,
    lmax: int,
    wavelengths: np.ndarray,
    *,
    derivatives: bool,
) -> tuple[np.ndarray, np.ndarray | None]:
    """Return average scattering efficiencies and analytic radius derivatives."""
    values = np.empty(wavelengths.size, dtype=float)
    slopes = np.empty(wavelengths.size, dtype=float) if derivatives else None
    # diff.sphere expects all concentric media: sphere first, vacuum last.
    radii = np.asarray([radius], dtype=float)
    permittivities = np.asarray([epsilon, 1.0], dtype=float)

    for i, wavelength in enumerate(wavelengths):
        k0 = 2.0 * math.pi / float(wavelength)
        if derivatives:
            matrix, pullback = treams_rs.diff.sphere(
                lmax, k0, radii, permittivities
            )
        else:
            matrix = treams_rs.sphere_tmatrix(
                k0=k0,
                lmax=lmax,
                radius=radius,
                material=epsilon,
                medium=1.0,
            ).array

        norm_squared = float(np.vdot(matrix, matrix).real)
        values[i] = 2.0 * norm_squared / (k0 * radius) ** 2

        if derivatives:
            # For ||T||_F^2 the matrix cotangent is 2T. The public native
            # pullback returns (k0_bar, radii_bar, epsilon_bar, mu_bar,
            # kappa_bar), and each residual is intentionally consumed once.
            matrix_bar = 2.0 * matrix
            radius_bar = float(pullback.pullback(matrix_bar)[1][0])
            slopes[i] = (2.0 / k0**2) * (
                radius_bar / radius**2 - 2.0 * norm_squared / radius**3
            )
    return values, slopes


def _objective(
    radius: float,
    epsilon: float,
    lmax: int,
    wavelengths: np.ndarray,
    targets: np.ndarray,
    *,
    derivatives: bool,
) -> tuple[float, float | None, np.ndarray]:
    efficiencies, slopes = _efficiencies(
        radius, epsilon, lmax, wavelengths, derivatives=derivatives
    )
    relative_residual = (efficiencies - targets) / targets
    loss = float(np.mean(relative_residual**2))
    if not derivatives:
        return loss, None, efficiencies
    gradient = float(2.0 * np.mean(relative_residual * slopes / targets))
    return loss, gradient, efficiencies


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Infer sphere radius from orientation-averaged scattering efficiencies."""
    epsilon, lmax, wavelengths, initial, lower, upper, targets = _validate(config)
    width = upper - lower

    def evaluate_x(x: float, gradient: bool) -> tuple[float, float | None, np.ndarray]:
        radius = lower + width * x
        loss, grad_radius, efficiencies = _objective(
            radius,
            epsilon,
            lmax,
            wavelengths,
            targets,
            derivatives=gradient,
        )
        grad_x = None if grad_radius is None else width * grad_radius
        return loss, grad_x, efficiencies

    x = (initial - lower) / width
    loss, grad, efficiencies = evaluate_x(x, True)
    initial_loss = loss
    history = [loss]

    # One-dimensional projected BFGS with an Armijo line search. Every search
    # direction is formed from an analytic pullback gradient; trial objective
    # values do not need derivatives.
    inverse_hessian = 1.0
    for _ in range(100):
        projected_grad = grad
        if (x <= 0.0 and grad > 0.0) or (x >= 1.0 and grad < 0.0):
            projected_grad = 0.0
        if abs(projected_grad) <= 1e-12 or loss <= 1e-16:
            break

        direction = -inverse_hessian * grad
        if not math.isfinite(direction) or direction * grad >= 0.0:
            direction = -grad

        alpha = 1.0
        accepted_x = x
        accepted_loss = loss
        for _ in range(60):
            trial_x = min(1.0, max(0.0, x + alpha * direction))
            displacement = trial_x - x
            if displacement == 0.0:
                alpha *= 0.5
                continue
            trial_loss, _, _ = evaluate_x(trial_x, False)
            if trial_loss <= loss + 1e-4 * grad * displacement:
                accepted_x, accepted_loss = trial_x, trial_loss
                break
            alpha *= 0.5
        else:
            break

        old_x, old_grad = x, grad
        x = accepted_x
        loss, grad, efficiencies = evaluate_x(x, True)
        history.append(loss)
        step = x - old_x
        gradient_change = grad - old_grad
        if step * gradient_change > 1e-14:
            inverse_hessian = min(1e6, max(1e-8, step / gradient_change))
        else:
            inverse_hessian = 1.0

        if abs(step) <= 1e-14 * max(1.0, abs(x)):
            break

    radius = lower + width * x
    # Convert the normalized-coordinate derivative back to d(loss)/d(radius).
    gradient_radius = grad / width
    return {
        "radius": float(radius),
        "loss": float(loss),
        "initial_loss": float(initial_loss),
        "gradient": float(gradient_radius),
        "fitted_efficiencies": [float(value) for value in efficiencies],
        "loss_history": [float(value) for value in history],
    }


def _main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
