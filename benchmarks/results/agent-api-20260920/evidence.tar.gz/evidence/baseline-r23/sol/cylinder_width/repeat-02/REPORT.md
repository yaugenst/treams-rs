# Cylinder cross-width calculation

`solution.py` uses the public `treams_rs.cylinder_tmatrix` and
`TMatrixC.cross_widths` interfaces. The cylinder axis is z, the retained axial
sector is `kz = 0`, and azimuthal orders run from `-mmax` through `+mmax`.
The incident plane wave travels along +x and has positive helicity in the
package's helicity convention.

All input lengths are micrometers. The vacuum angular wavenumber is
`k0 = 2 pi / wavelength` in inverse micrometers, so the returned scattering,
extinction, and absorption cross widths are in micrometers (power per unit
cylinder length divided by incident intensity). No sphere-area normalization is
used. The cylinder material is `(epsilon, mu, chirality) = (epsilon, 1, 0)` and
the exterior is vacuum. The complex permittivity uses `epsilon[0] + i
epsilon[1]` with the package's passive-material sign convention.

Checks performed for the example:

- Each absorption value is computed as `extinction - scattering`; all are
  positive for the supplied lossy material.
- Repeating the calculation with zero imaginary permittivity gives absorption
  consistent with zero: the largest absolute residual is
  `1.11e-16` micrometers (the optical-theorem/energy-conservation check).
- Increasing the cutoff from `mmax = 4` to 5 changes the three reported widths
  by at most `2.21e-9` micrometers over the three example wavelengths.
