# Cylinder cross-width calculation

`solution.py` models a homogeneous, infinite cylinder whose axis is the z axis.
For every supplied vacuum wavelength it uses `k0 = 2 pi / wavelength`, `kz = 0`,
the requested azimuthal cutoff `mmax`, and the public `treams_rs.cylinder_tmatrix`
constructor. The exterior is vacuum and both media use relative permeability 1
and zero chirality. The incident plane wave travels along +x and occupies the
positive-helicity channel.

All input lengths are in micrometers. Consequently, the returned scattering,
extinction, and absorption cross widths are in micrometers (length per unit
cylinder length), not areas and not values normalized by a sphere area. Output
lists preserve the order of `config["wavelengths"]`. The complex relative
permittivity convention is `epsilon[0] + i epsilon[1]`.

For the example, direct execution produced finite cross widths with positive
absorption at every wavelength. The energy-balance identity
`absorption = extinction - scattering` holds for every result (to floating-point
precision). The CLI output and an independent `run(config)` call were also
checked to agree exactly after JSON serialization.
