"""Cross widths of a homogeneous infinite cylinder computed with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as treams


def _positive_finite(value: Any, name: str) -> float:
    """Convert a scalar to a positive finite float with a useful error."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a positive finite number")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a positive finite number") from exc
    if not math.isfinite(result) or result <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return result


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return scattering, extinction, and absorption widths for each wavelength.

    Length inputs and output cross widths are in micrometers.  The cylinder is
    in vacuum, is parallel to z, and is illuminated along +x at positive
    helicity.  Results retain the order of ``config["wavelengths"]``.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _positive_finite(config.get("radius"), "radius")

    epsilon_parts = config.get("epsilon")
    if (
        not isinstance(epsilon_parts, (list, tuple))
        or len(epsilon_parts) != 2
        or isinstance(epsilon_parts[0], bool)
        or isinstance(epsilon_parts[1], bool)
    ):
        raise ValueError("epsilon must be [real, imag]")
    try:
        eps_real, eps_imag = map(float, epsilon_parts)
    except (TypeError, ValueError) as exc:
        raise ValueError("epsilon must contain two finite real numbers") from exc
    if not (math.isfinite(eps_real) and math.isfinite(eps_imag)):
        raise ValueError("epsilon must contain two finite real numbers")
    epsilon = complex(eps_real, eps_imag)

    mmax = config.get("mmax")
    if isinstance(mmax, bool) or not isinstance(mmax, int) or not 0 <= mmax <= 128:
        raise ValueError("mmax must be an integer from 0 through 128")

    wavelengths_value = config.get("wavelengths")
    if not isinstance(wavelengths_value, (list, tuple)) or not wavelengths_value:
        raise ValueError("wavelengths must be a nonempty list")
    wavelengths = [
        _positive_finite(value, f"wavelengths[{index}]")
        for index, value in enumerate(wavelengths_value)
    ]

    result: dict[str, list[float]] = {
        "scattering": [],
        "extinction": [],
        "absorption": [],
    }
    material = treams.Material(epsilon, 1, 0)
    for wavelength in wavelengths:
        k0 = 2 * math.pi / wavelength
        tmatrix = treams.cylinder_tmatrix(
            k0=k0,
            kz=0,
            mmax=mmax,
            radius=radius,
            material=material,
            medium=1,
            polarization="helicity",
        )
        incident = treams.plane_wave(
            [1, 0, 0],
            "positive_helicity",
            k0=k0,
            material=1,
            poltype="helicity",
        )
        widths = tmatrix.cross_widths(incident)
        scattering = float(widths.scattering)
        extinction = float(widths.extinction)
        result["scattering"].append(scattering)
        result["extinction"].append(extinction)
        result["absorption"].append(extinction - scattering)

    return result


def main() -> None:
    """Read one JSON config from stdin and write one JSON result to stdout."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
