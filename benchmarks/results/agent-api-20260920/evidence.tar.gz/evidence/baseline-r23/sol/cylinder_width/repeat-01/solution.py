"""Cross widths of a homogeneous infinite cylinder computed with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return cylinder cross widths for each wavelength in the supplied order."""
    radius = float(config["radius"])
    epsilon_parts = config["epsilon"]
    wavelengths = [float(value) for value in config["wavelengths"]]
    mmax = config["mmax"]

    if not math.isfinite(radius) or radius <= 0:
        raise ValueError("radius must be positive and finite")
    if (
        not isinstance(epsilon_parts, (list, tuple))
        or len(epsilon_parts) != 2
    ):
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    if not math.isfinite(epsilon.real) or not math.isfinite(epsilon.imag):
        raise ValueError("epsilon components must be finite")
    if not wavelengths or any(
        not math.isfinite(wavelength) or wavelength <= 0
        for wavelength in wavelengths
    ):
        raise ValueError("wavelengths must be a nonempty list of positive finite values")
    if isinstance(mmax, bool) or not isinstance(mmax, int) or not 0 <= mmax <= 128:
        raise ValueError("mmax must be an integer from 0 to 128")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2 * math.pi / wavelength
        cylinder = tr.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=epsilon,
        )
        incident = tr.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
        )
        widths = cylinder.cross_widths(incident)
        scattering.append(float(widths.scattering))
        extinction.append(float(widths.extinction))
        absorption.append(float(widths.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
