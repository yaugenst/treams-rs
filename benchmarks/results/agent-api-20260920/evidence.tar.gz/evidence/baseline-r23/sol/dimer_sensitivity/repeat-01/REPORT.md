# Dimer field sensitivity

The calculation uses `treams_rs.advect` throughout the scattering path. Each
sphere has a homogeneous spherical T-matrix truncated at `lmax`; `Cluster.scatter`
solves the coupled two-particle system, so all multiple-scattering orders represented
by that truncation are included. The returned electric field is
`E_incident + E_scattered`, evaluated at the fixed laboratory point, and `value` is
`sum(abs(E_total)**2)` over its three Cartesian components.

## Units and conventions

- Radius, center separation, wavelength, and Cartesian coordinates are in micrometers.
  The vacuum angular wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers.
- Relative permittivity is formed as `epsilon[0] + 1j*epsilon[1]`. Relative
  permeability is 1, chirality is 0, and the exterior is vacuum.
- Sphere centers are `(-separation/2, 0, 0)` and `(separation/2, 0, 0)`. Thus both
  origins move in the analytic derivative while the observation point stays fixed.
- Illumination is a unit-amplitude positive-helicity plane wave propagating along
  +z. Positive helicity is channel 1 in treams-rs. Complex phasors and outgoing
  first-kind Hankel waves follow the package convention.
- `value` is in squared electric-field-amplitude units (dimensionless when normalized
  to the unit incident electric amplitude). `gradient` is `dvalue/dseparation`, in
  inverse micrometers.

## Derivative and checks

`advect.value_and_grad` differentiates separation. Native treams-rs pullbacks cover
the moving-origin plane-wave expansion, inter-sphere translations, coupled linear
solve, and outgoing field evaluation; finite differences are not used to produce the
reported gradient.

For the example, the analytic gradient is `-0.40372542061712435`. Centered finite
differences gave `-0.4037254314726013` at a `1e-4` micrometer step and
`-0.4037254207278628` at a `1e-5` micrometer step (absolute errors about `1.09e-8`
and `1.11e-10`). The illumination-specific cluster solve and a full solved cluster
gave scattered electric fields agreeing to `1.43e-17` in maximum component error.
The incident field alone had `sum(abs(E_incident)**2) = 1.0000000000000004`,
confirming the intended unit-amplitude normalization.
