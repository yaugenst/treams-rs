# Dimer field-sensitivity calculation

`solution.py` uses the public `treams_rs.advect` physical-object interface. Each
sphere is represented by a spherical T-matrix truncated at the requested
`lmax`. `Cluster.scatter` solves the coupled finite-cluster problem, so all
orders of multiple scattering retained by that multipole truncation are
included. The outgoing field is added coherently to the incident field before
computing `sum(abs(E_total)**2)`.

## Units and conventions

All input lengths are in micrometers. The vacuum angular wavenumber is
`k0 = 2*pi/wavelength`, in inverse micrometers. Consequently, `value` is in the
package's squared electric-field normalization and `gradient` is that value per
micrometer. The incident wave travels in `+z`, uses the package's
`positive_helicity` channel, and has unit electric-field norm. Vacuum is the
embedding medium; the sphere has relative `epsilon = real + i*imag`, relative
`mu = 1`, and zero chirality. Cartesian centers are `(-d/2, 0, 0)` and
`(+d/2, 0, 0)`, so both center motions contribute to the derivative while the
observation point remains fixed.

## Derivative and checks

The reported derivative comes from `advect.value_and_grad`. Geometry
derivatives pass through treams-rs native analytic pullbacks for the spherical
translation/coupling, the multiple-scattering illumination solve, and outgoing
field evaluation. It is not a finite-difference derivative.

For the supplied example, the analytic result is recorded in `results.json`.
A central finite-difference check with a separation step of `1e-5` micrometers
gave `-0.40372542073`, versus the analytic `-0.40372542062` (absolute difference
about `1.1e-10`). The incident-only field norm-squared was also checked to be
`1` in this normalization. Inputs are rejected if the spheres overlap/touch or
if the observation point is inside either sphere.
