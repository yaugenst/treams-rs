"""Electric-intensity sensitivity for a two-sphere cluster."""

from __future__ import annotations

import json
import sys
from collections.abc import Mapping
from typing import Any

import advect as ad
import numpy as np
import treams_rs.advect as tr


def _validated(config: Mapping[str, Any]) -> tuple[float, complex, float, float, int, np.ndarray]:
    """Extract and validate the fixed physical inputs."""
    required = {"radius", "epsilon", "separation", "wavelength", "lmax", "point"}
    missing = required.difference(config)
    if missing:
        raise ValueError(f"missing config keys: {', '.join(sorted(missing))}")

    radius = float(config["radius"])
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax_raw = config["lmax"]
    if isinstance(lmax_raw, bool) or int(lmax_raw) != lmax_raw:
        raise ValueError("lmax must be an integer")
    lmax = int(lmax_raw)

    epsilon_parts = np.asarray(config["epsilon"], dtype=float)
    point = np.asarray(config["point"], dtype=float)
    if epsilon_parts.shape != (2,):
        raise ValueError("epsilon must be [real, imag]")
    if point.shape != (3,):
        raise ValueError("point must have three Cartesian coordinates")
    if not np.all(np.isfinite(epsilon_parts)) or not np.all(np.isfinite(point)):
        raise ValueError("epsilon and point must be finite")
    if not all(np.isfinite(x) for x in (radius, separation, wavelength)):
        raise ValueError("radius, separation, and wavelength must be finite")
    if radius <= 0 or separation <= 0 or wavelength <= 0 or lmax < 1:
        raise ValueError("radius, separation, wavelength, and lmax must be positive")
    if separation <= 2 * radius:
        raise ValueError("the two spheres must not overlap or touch")

    centers = np.array([[-separation / 2, 0, 0], [separation / 2, 0, 0]])
    if np.any(np.linalg.norm(point - centers, axis=1) <= radius):
        raise ValueError("the field point must be outside both spheres")

    epsilon = complex(epsilon_parts[0], epsilon_parts[1])
    return radius, epsilon, separation, wavelength, lmax, point


def run(config: Mapping[str, Any]) -> dict[str, float]:
    """Return |E_total|^2 and its analytic derivative with separation."""
    radius, epsilon, separation, wavelength, lmax, point = _validated(config)
    k0 = 2 * np.pi / wavelength

    # These quantities are independent of separation. The cluster positions below
    # remain Advect values, so native translation, illumination, and field VJPs
    # carry both centers' motion through the complete multiple-scattering solve.
    sphere = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=tr.Material(epsilon=epsilon),
    )
    incident = tr.plane_wave(
        (0.0, 0.0, 1.0), "positive_helicity", k0=k0, medium=1.0
    )

    def intensity(distance: Any) -> Any:
        zero = distance * 0.0
        positions = ad.numpy.stack(
            (
                ad.numpy.stack((-distance / 2.0, zero, zero)),
                ad.numpy.stack((distance / 2.0, zero, zero)),
            )
        )
        scattered = tr.Cluster((sphere, sphere), positions=positions).scatter(incident)
        total = incident.efield(point) + scattered.efield(point)
        return ad.numpy.real(ad.numpy.sum(ad.numpy.conj(total) * total))

    value, gradient = ad.value_and_grad(intensity)(np.asarray(separation, dtype=float))
    value_float = float(np.asarray(value))
    gradient_float = float(np.asarray(gradient))
    if not np.isfinite(value_float) or not np.isfinite(gradient_float):
        raise FloatingPointError("scattering calculation returned a non-finite result")
    return {"value": value_float, "gradient": gradient_float}


def _main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
