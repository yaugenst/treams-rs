"""Electric-intensity sensitivity for a two-sphere dimer."""

from __future__ import annotations

import json
import sys
from collections.abc import Mapping
from typing import Any

import advect as ad
import numpy as np
import treams_rs.advect as tr


_REQUIRED_KEYS = {
    "radius",
    "epsilon",
    "separation",
    "wavelength",
    "lmax",
    "point",
}


def _validated(config: Mapping[str, Any]) -> tuple[float, complex, float, float, int, np.ndarray]:
    """Validate and normalize the fixed physical inputs."""
    missing = _REQUIRED_KEYS.difference(config)
    if missing:
        raise ValueError(f"missing config keys: {', '.join(sorted(missing))}")

    radius = float(config["radius"])
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    if lmax != config["lmax"] or lmax < 1:
        raise ValueError("lmax must be a positive integer")
    if not all(np.isfinite(x) and x > 0 for x in (radius, separation, wavelength)):
        raise ValueError("radius, separation, and wavelength must be finite and positive")
    if separation <= 2 * radius:
        raise ValueError("the two spheres must not overlap (separation > 2*radius)")

    epsilon_parts = np.asarray(config["epsilon"], dtype=float)
    if epsilon_parts.shape != (2,) or not np.all(np.isfinite(epsilon_parts)):
        raise ValueError("epsilon must be the finite pair [real, imag]")
    epsilon = complex(epsilon_parts[0], epsilon_parts[1])

    point = np.asarray(config["point"], dtype=float)
    if point.shape != (3,) or not np.all(np.isfinite(point)):
        raise ValueError("point must contain three finite Cartesian coordinates")
    centers = np.array([[-separation / 2, 0, 0], [separation / 2, 0, 0]])
    if np.any(np.linalg.norm(point - centers, axis=1) <= radius):
        raise ValueError("point must lie outside both spheres")

    return radius, epsilon, separation, wavelength, lmax, point


def run(config: Mapping[str, Any]) -> dict[str, float]:
    """Return total electric intensity and its analytic separation derivative."""
    radius, epsilon, separation, wavelength, lmax, point = _validated(config)
    k0 = 2 * np.pi / wavelength

    # Only separation is differentiated. All propagation, translation, scattering,
    # solve, and field derivatives below are supplied by treams-rs native pullbacks.
    def objective(distance: np.ndarray) -> Any:
        zero = distance * 0
        positions = ad.numpy.stack(
            (
                ad.numpy.stack((-distance / 2, zero, zero)),
                ad.numpy.stack((distance / 2, zero, zero)),
            )
        )
        material = tr.Material(epsilon)
        sphere = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=material,
            medium=1,
            polarization="helicity",
        )
        dimer = tr.Cluster((sphere, sphere), positions=positions)
        incident = tr.plane_wave(
            (0, 0, 1), "positive_helicity", k0=k0, medium=1
        )
        scattered = dimer.scatter(incident)
        electric = incident.efield(point) + scattered.efield(point)
        return ad.numpy.sum(ad.numpy.real(electric * ad.numpy.conj(electric)))

    value, gradient = ad.value_and_grad(objective)(np.asarray(separation))
    return {"value": float(value), "gradient": float(gradient)}


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
