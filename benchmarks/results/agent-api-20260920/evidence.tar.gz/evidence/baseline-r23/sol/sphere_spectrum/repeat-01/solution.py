"""Spectrum of a homogeneous sphere computed with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as treams


def _finite_number(value: Any, name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite number")
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must be a finite number") from error
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite number")
    return result


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return sphere cross sections and efficiency in wavelength order.

    Length inputs are in micrometers, so all cross sections are in square
    micrometers. ``epsilon`` is ``[real, imag]`` and is interpreted directly as
    relative permittivity.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _finite_number(config.get("radius"), "radius")
    if radius <= 0:
        raise ValueError("radius must be positive")

    epsilon_parts = config.get("epsilon")
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _finite_number(epsilon_parts[0], "epsilon real part"),
        _finite_number(epsilon_parts[1], "epsilon imaginary part"),
    )

    wavelengths_input = config.get("wavelengths")
    if not isinstance(wavelengths_input, (list, tuple)):
        raise ValueError("wavelengths must be a list")
    wavelengths = [
        _finite_number(value, f"wavelengths[{index}]")
        for index, value in enumerate(wavelengths_input)
    ]
    if any(value <= 0 for value in wavelengths):
        raise ValueError("wavelengths must be positive")

    lmax_input = config.get("lmax")
    if isinstance(lmax_input, bool) or not isinstance(lmax_input, int):
        raise ValueError("lmax must be an integer")
    if not 1 <= lmax_input <= 128:
        raise ValueError("lmax must be between 1 and 128")

    material = treams.Material(epsilon)
    vacuum = treams.Material(1)
    geometric_area = math.pi * radius * radius
    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2 * math.pi / wavelength
        tmatrix = treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax_input,
            radius=radius,
            material=material,
            medium=vacuum,
            polarization="helicity",
        )
        incident = treams.plane_wave(
            direction=[0, 0, 1],
            polarization="positive_helicity",
            k0=k0,
            medium=vacuum,
        )
        cross_sections = tmatrix.cross_sections(incident)
        scattering.append(float(cross_sections.scattering))
        extinction.append(float(cross_sections.extinction))
        absorption.append(float(cross_sections.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": [value / geometric_area for value in scattering],
    }


def _main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
