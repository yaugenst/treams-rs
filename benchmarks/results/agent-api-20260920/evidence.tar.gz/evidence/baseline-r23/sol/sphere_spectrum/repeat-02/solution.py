"""Spectrum of a homogeneous dielectric sphere computed with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as treams


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return cross sections and scattering efficiency in wavelength order."""
    radius = float(config["radius"])
    epsilon_parts = config["epsilon"]
    wavelengths = [float(value) for value in config["wavelengths"]]
    lmax = int(config["lmax"])

    if radius <= 0 or not math.isfinite(radius):
        raise ValueError("radius must be finite and positive")
    if len(epsilon_parts) != 2:
        raise ValueError("epsilon must contain [real, imag]")
    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    if not (math.isfinite(epsilon.real) and math.isfinite(epsilon.imag)):
        raise ValueError("epsilon components must be finite")
    if lmax < 1:
        raise ValueError("lmax must be a positive integer")
    if any(wavelength <= 0 or not math.isfinite(wavelength) for wavelength in wavelengths):
        raise ValueError("wavelengths must be finite and positive")

    result: dict[str, list[float]] = {
        "scattering": [],
        "extinction": [],
        "absorption": [],
        "efficiency": [],
    }
    geometric_area = math.pi * radius**2

    for wavelength in wavelengths:
        k0 = 2 * math.pi / wavelength
        tmatrix = treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=treams.Material(epsilon),
            medium=1,
            polarization="helicity",
        )
        incident = treams.plane_wave(
            k0=k0,
            direction=(0, 0, 1),
            polarization="positive_helicity",
            medium=1,
        )
        cross_sections = tmatrix.cross_sections(incident)
        scattering = float(cross_sections.scattering)
        extinction = float(cross_sections.extinction)
        absorption = float(cross_sections.absorption)

        result["scattering"].append(scattering)
        result["extinction"].append(extinction)
        result["absorption"].append(absorption)
        result["efficiency"].append(scattering / geometric_area)

    return result


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("input must be one JSON object")
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
