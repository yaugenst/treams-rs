# Homogeneous dielectric sphere spectrum

`solution.py` uses the public `treams_rs.sphere_tmatrix` constructor with the
requested `lmax` and evaluates its `cross_sections` method for a plane wave
travelling along +z with positive helicity. The sphere has relative material
parameters epsilon = `epsilon[0] + i*epsilon[1]`, mu = 1, and chirality = 0;
the embedding medium is vacuum.

All input lengths are micrometers. The vacuum angular wavenumber is
`k0 = 2*pi/wavelength` in inverse micrometers. Scattering, extinction, and
absorption are therefore returned in square micrometers. Absorption follows
the package convention `extinction - scattering`. Efficiency is dimensionless
and is the scattering cross section divided by the geometric area
`pi*radius**2`.

The output lists preserve the supplied wavelength order. For the example,
checks confirmed that every value is finite, extinction equals scattering plus
absorption to floating-point precision, and all three cross sections are
positive. Because this sphere is isotropic and achiral, the explicit +z,
positive-helicity cross sections were also compared with the treams-rs
rotational/polarization average and agreed to about 1e-16 square micrometers.
The CLI output was parsed back as JSON and compared with a direct `run` call.
