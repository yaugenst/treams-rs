# Homogeneous-sphere spectrum

`solution.py` uses the public `treams_rs.sphere_tmatrix` and `plane_wave`
interfaces. For every requested vacuum wavelength it sets
`k0 = 2*pi/wavelength`, constructs a homogeneous sphere in vacuum, and
illuminates it along +z with positive helicity. The supplied `epsilon` pair is
interpreted as the real and imaginary parts of relative permittivity; relative
permeability is 1 and chirality is 0.

All input lengths are in micrometers. Consequently, scattering, extinction,
and absorption are in square micrometers. `efficiency` is dimensionless and is
the scattering cross section divided by the geometric area `pi*radius**2`.
Lists preserve the input wavelength order, and `lmax` is passed unchanged as
the spherical multipole cutoff.

For the example, the CLI output was checked to be valid JSON with four entries
per quantity. At every wavelength, `absorption` agrees with `extinction -
scattering` (the definition supplied by treams-rs), and all three cross sections
are nonnegative for the passive material. Recomputing each efficiency from the
reported scattering value and geometric area also agrees to floating-point
precision.
