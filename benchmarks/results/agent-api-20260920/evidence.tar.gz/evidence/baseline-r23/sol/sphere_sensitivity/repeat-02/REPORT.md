# Sphere scattering-efficiency sensitivity

`solution.py` uses the public `treams_rs.advect` interface. It constructs a
homogeneous spherical T-matrix, expands a +z-travelling positive-helicity plane
wave, and evaluates the scattering cross section. Advect reverse mode invokes
the native treams-rs analytic sphere pullback. The complete differentiated
quantity is

\[
Q = \frac{C_\mathrm{sca}}{\pi r^2},
\]

so the reported radius derivative includes both the response derivative and
the derivative of the geometrical normalization.

All lengths are in micrometers. Thus `value` is dimensionless,
`gradient[0] = dQ/dradius` is in inverse micrometers, and
`gradient[1] = dQ/depsilon_real` is dimensionless. The input relative
permittivity is `epsilon_real + 1j*epsilon_imag`; relative permeability is one,
chirality is zero, and the exterior is vacuum. `wavelength` is the vacuum
wavelength, with `k0 = 2*pi/wavelength`. `lmax` is held fixed. The incident
polarization is treams-rs's named `positive_helicity` state.

For the supplied example, the scattering cross section is
0.014557400399644605 micrometer squared and `pi*radius**2` is
0.031415926535897934 micrometer squared. The extinction cross section is
0.015635805239605213 micrometer squared, so absorption is positive as expected
for the specified loss. Centered finite differences, used only to check the
analytic result, agreed with the reported derivatives to relative errors of
about 6.2e-12 (radius) and 1.8e-10 (real permittivity).
