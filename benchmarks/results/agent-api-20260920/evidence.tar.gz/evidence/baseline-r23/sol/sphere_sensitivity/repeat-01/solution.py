"""Scattering efficiency and analytic sensitivities for a lossy sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import treams_rs.advect as treams


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return Q_sca and [dQ/dradius, dQ/depsilon_real]."""
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax_value = config["lmax"]

    if isinstance(lmax_value, bool) or int(lmax_value) != lmax_value:
        raise ValueError("lmax must be an integer")
    lmax = int(lmax_value)
    if not math.isfinite(radius) or radius <= 0:
        raise ValueError("radius must be finite and positive")
    if not math.isfinite(wavelength) or wavelength <= 0:
        raise ValueError("wavelength must be finite and positive")
    if not all(math.isfinite(x) for x in (epsilon_real, epsilon_imag)):
        raise ValueError("permittivity components must be finite")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")

    # wavelength and lmax are intentionally closed-over constants: the requested
    # partial derivatives hold both fixed.
    k0 = 2.0 * math.pi / wavelength

    def efficiency(r: float, eps_re: float):
        material = treams.Material(epsilon=eps_re + 1j * epsilon_imag)
        sphere = treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=r,
            material=material,
            medium=1.0,
            polarization="helicity",
        )
        incident = treams.plane_wave(
            (0.0, 0.0, 1.0),
            "positive_helicity",
            k0=k0,
            medium=1.0,
        )
        scattering = sphere.cross_sections(incident).scattering
        # Keep this inside the differentiated function: its radius derivative
        # is part of dQ/dradius.
        return scattering / (math.pi * r**2)

    value, gradient = ad.value_and_grad(efficiency, argnums=(0, 1))(
        radius, epsilon_real
    )
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
