"""Scattering-efficiency sensitivity of a homogeneous lossy sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import numpy as np
import treams_rs.advect as treams


def _objective(
    parameters: np.ndarray,
    *,
    epsilon_imag: float,
    wavelength: float,
    lmax: int,
) -> Any:
    """Return Q while keeping all but radius and Re(epsilon) fixed."""
    radius, epsilon_real = parameters
    k0 = 2 * np.pi / wavelength
    material = treams.Material(epsilon=epsilon_real + 1j * epsilon_imag)
    sphere = treams.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=material,
        medium=1.0,
        polarization="helicity",
    )
    incident = treams.plane_wave(
        [0.0, 0.0, 1.0],
        "positive_helicity",
        k0=k0,
        medium=1.0,
    )
    scattering = sphere.cross_sections(incident).scattering
    # Radius remains an active Advect value here, so this also differentiates
    # the geometrical normalization rather than treating it as constant.
    return scattering / (np.pi * radius**2)


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Calculate Q and [dQ/dradius, dQ/dRe(epsilon)]."""
    required = ("radius", "epsilon_real", "epsilon_imag", "wavelength", "lmax")
    missing = [key for key in required if key not in config]
    if missing:
        raise ValueError(f"missing config keys: {', '.join(missing)}")

    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax_value = config["lmax"]
    if isinstance(lmax_value, bool) or int(lmax_value) != lmax_value:
        raise ValueError("lmax must be an integer")
    lmax = int(lmax_value)

    values = (radius, epsilon_real, epsilon_imag, wavelength)
    if not all(math.isfinite(value) for value in values):
        raise ValueError("radius, permittivity, and wavelength must be finite")
    if radius <= 0 or wavelength <= 0:
        raise ValueError("radius and wavelength must be positive")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")

    parameters = np.array([radius, epsilon_real], dtype=np.float64)

    def objective(active: np.ndarray) -> Any:
        return _objective(
            active,
            epsilon_imag=epsilon_imag,
            wavelength=wavelength,
            lmax=lmax,
        )

    value, gradient = ad.value_and_grad(objective)(parameters)
    return {
        "value": float(value),
        "gradient": [float(component) for component in np.asarray(gradient)],
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
