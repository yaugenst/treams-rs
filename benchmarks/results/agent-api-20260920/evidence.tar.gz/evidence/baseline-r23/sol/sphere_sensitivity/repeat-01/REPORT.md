# Sphere scattering sensitivity

`solution.py` returns the dimensionless scattering efficiency

\[Q_\mathrm{sca}=C_\mathrm{sca}/(\pi r^2).\]

Lengths (`radius` and `wavelength`) are in micrometers, so the vacuum angular
wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers and the treams-rs
scattering cross section is in square micrometers. Relative permittivity is
`epsilon_real + i*epsilon_imag`; relative permeability is 1, chirality is 0,
and the exterior is vacuum. The incident wave travels along +z and has positive
helicity. The finite spherical-wave expansion includes degrees 1 through
`lmax` and uses the helicity basis.

The output gradient is ordered as `[dQ/dradius, dQ/depsilon_real]`.
Consequently its units are inverse micrometers and dimensionless per unit
relative permittivity, respectively. `epsilon_imag`, wavelength, and `lmax` are
held fixed. Advect reverse-mode differentiation uses the native treams-rs
sphere pullback. The normalization by `pi*radius**2` remains inside the traced
objective, so its radius derivative is included.

For the supplied example, the analytic result was checked independently by
centered finite differences (used only as validation). With steps `1e-6` um in
radius and `1e-5` in `epsilon_real`, the finite-difference derivatives agreed
with the returned analytic derivatives to better than `2e-9` relative error.
The CLI result is recorded in `results.json`.
