"""Gradient design of a single-layer antireflection coating."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import advect
import numpy as np
import treams_rs as tr
import treams_rs.advect as tr_ad


def _inputs(config: Mapping[str, Any]) -> tuple[float, float, float, float, float, float]:
    """Validate and normalize the small, fully numeric input schema."""
    required = (
        "wavelength",
        "epsilon",
        "substrate_epsilon",
        "initial_thickness",
        "bounds",
    )
    missing = [key for key in required if key not in config]
    if missing:
        raise ValueError(f"missing configuration keys: {', '.join(missing)}")

    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    bounds = config["bounds"]
    if not isinstance(bounds, (list, tuple)) or len(bounds) != 2:
        raise ValueError("bounds must be a two-element sequence")
    lower, upper = map(float, bounds)

    values = (wavelength, epsilon, substrate_epsilon, initial, lower, upper)
    if not all(math.isfinite(value) for value in values):
        raise ValueError("all numeric inputs must be finite")
    if wavelength <= 0 or epsilon <= 0 or substrate_epsilon <= 0:
        raise ValueError("wavelength and lossless permittivities must be positive")
    if not (0 <= lower < upper):
        raise ValueError("bounds must satisfy 0 <= lower < upper")
    if not lower <= initial <= upper:
        raise ValueError("initial_thickness must lie within bounds")
    return values


def run(config: Mapping[str, Any]) -> dict[str, Any]:
    """Minimize normal-incidence reflected power with analytic pullbacks."""
    wavelength, epsilon, substrate_epsilon, thickness, lower, upper = _inputs(config)
    k0 = 2.0 * np.pi / wavelength

    # Both helicities are retained so that the port power normalization is
    # complete.  Isotropy makes either incident channel physically equivalent.
    basis = tr.PlaneWavePorts([[0.0, 0.0, 0], [0.0, 0.0, 1]])
    incident = np.array([1.0, 0.0])

    def reflected_power(d: Any) -> Any:
        coating = tr_ad.slab(
            basis=basis,
            k0=k0,
            thickness=d,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
            polarization="helicity",
        )
        return coating.power(incident, side="negative").reflection

    value_and_gradient = advect.value_and_grad(reflected_power)

    def evaluate(d: float) -> tuple[float, float]:
        value, derivative = value_and_gradient(float(d))
        return float(np.asarray(value)), float(np.asarray(derivative))

    reflection, gradient = evaluate(thickness)
    initial_reflection = reflection
    history = [reflection]

    # Projected steepest descent with an Armijo line search.  The initial
    # scale limits the first proposed movement to a quarter of the feasible
    # interval, independent of the units/magnitude of the derivative.
    width = upper - lower
    if abs(gradient) > 0:
        step_size = 0.25 * width / abs(gradient)
    else:
        step_size = width

    for _ in range(300):
        if reflection < 1e-14 and abs(gradient) < 1e-9:
            break
        if abs(gradient) < 1e-15:
            break

        old_thickness = thickness
        old_reflection = reflection
        old_gradient = gradient
        accepted = False
        trial_step = step_size

        for _ in range(60):
            candidate = min(upper, max(lower, thickness - trial_step * gradient))
            displacement = candidate - thickness
            if displacement == 0:
                trial_step *= 0.5
                continue
            candidate_reflection, candidate_gradient = evaluate(candidate)
            # For a projected step, g*s is the appropriate directional model.
            if candidate_reflection <= reflection + 1e-4 * gradient * displacement:
                thickness = candidate
                reflection = candidate_reflection
                gradient = candidate_gradient
                history.append(reflection)
                accepted = True
                break
            trial_step *= 0.5

        if not accepted:
            break

        displacement = thickness - old_thickness
        gradient_change = gradient - old_gradient
        if displacement * gradient_change > 0:
            # One-dimensional Barzilai--Borwein curvature estimate.
            step_size = displacement / gradient_change
        else:
            step_size = 1.5 * trial_step
        step_size = min(max(step_size, np.finfo(float).eps), 1e6 * width)

        if thickness in (lower, upper) and reflection >= old_reflection:
            break

    return {
        "thickness": float(thickness),
        "reflection": float(reflection),
        "initial_reflection": float(initial_reflection),
        "gradient": float(gradient),
        "loss_history": [float(value) for value in history],
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise ValueError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
