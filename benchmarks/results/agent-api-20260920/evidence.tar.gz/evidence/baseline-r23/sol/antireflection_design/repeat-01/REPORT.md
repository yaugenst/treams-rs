# Antireflection coating optimization

`solution.py` models a homogeneous coating between vacuum on the negative side
and the supplied substrate on the positive side. The plane normal points in
the `+z` direction, and illumination is from vacuum in that direction. There
is no vacuum propagation layer between the coating and substrate.

Lengths (wavelength, thickness, and bounds) are in micrometers, so the vacuum
angular wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers. Epsilon is
relative and dimensionless. All media use relative permeability 1 and
chirality 0. The returned reflection and `loss_history` are dimensionless
power fractions; `gradient` is `d(reflection)/d(thickness)` in inverse
micrometers.

The numerical model uses the public `treams_rs.advect.slab` operation with a
two-helicity normal-incidence port basis. `advect.value_and_grad` propagates the
native treams-rs analytic pullback to the reflected-power objective. A bounded
projected steepest-descent iteration with Armijo backtracking chooses every
optimization step; no quarter-wave formula or finite-difference derivative is
used.

Checks performed for the example include JSON CLI round-tripping, monotonic
decrease of all accepted losses, enforcement of the thickness bounds, and a
central finite-difference spot check of the analytic initial gradient. The
finite difference is a validation only and is not used by the optimizer.
The analytic initial gradient was `-1.862590377991575 1/um`, versus
`-1.862590377758877 1/um` from the check (relative difference
`1.25e-10`). The final reflected power was `8.57e-22` at a thickness of
`0.11666666667188613 um`.
