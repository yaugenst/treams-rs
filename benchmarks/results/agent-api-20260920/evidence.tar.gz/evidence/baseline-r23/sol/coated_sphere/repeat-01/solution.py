"""Rotationally averaged cross sections of a concentric multilayer sphere."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping, Sequence
from typing import Any

import treams_rs


def _finite_real(value: Any, name: str) -> float:
    """Convert a JSON number to a finite float, rejecting booleans."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite real number")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite real number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite real number")
    return result


def _complex_pair(value: Any, name: str) -> complex:
    """Read a complex number represented by JSON as [real, imaginary]."""
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or len(value) != 2:
        raise ValueError(f"{name} must be a [real, imaginary] pair")
    return complex(
        _finite_real(value[0], f"{name}[0]"),
        _finite_real(value[1], f"{name}[1]"),
    )


def _medium(value: Any) -> complex:
    """Accept the specified real exterior and, defensively, a complex pair."""
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        result = _complex_pair(value, "epsilon_medium")
    else:
        result = complex(_finite_real(value, "epsilon_medium"))
    if result.imag != 0:
        raise ValueError("epsilon_medium must be real: cross sections require a lossless exterior")
    if result.real <= 0:
        raise ValueError("epsilon_medium must be positive")
    return result


def run(config: Mapping[str, Any]) -> dict[str, list[float]]:
    """Compute averaged scattering, extinction, and absorption cross sections.

    Length inputs are in micrometers, so all returned cross sections are in
    square micrometers. Vacuum angular wavenumber is ``2*pi/wavelength``.
    """
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary")

    try:
        raw_radii = config["radii"]
        raw_layers = config["epsilon_layers"]
        raw_wavelengths = config["wavelengths"]
        raw_lmax = config["lmax"]
        raw_medium = config["epsilon_medium"]
    except KeyError as exc:
        raise ValueError(f"missing required config key: {exc.args[0]}") from exc

    if not isinstance(raw_radii, Sequence) or isinstance(raw_radii, (str, bytes)):
        raise ValueError("radii must be a nonempty sequence")
    radii = [_finite_real(value, f"radii[{i}]") for i, value in enumerate(raw_radii)]
    if not radii or any(radius <= 0 for radius in radii):
        raise ValueError("radii must be nonempty and positive")
    if any(left >= right for left, right in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing outer boundaries")

    if not isinstance(raw_layers, Sequence) or isinstance(raw_layers, (str, bytes)):
        raise ValueError("epsilon_layers must be a sequence")
    materials = [
        _complex_pair(value, f"epsilon_layers[{i}]")
        for i, value in enumerate(raw_layers)
    ]
    if len(materials) != len(radii):
        raise ValueError("epsilon_layers must contain exactly one entry per radius")

    if not isinstance(raw_wavelengths, Sequence) or isinstance(raw_wavelengths, (str, bytes)):
        raise ValueError("wavelengths must be a nonempty sequence")
    wavelengths = [
        _finite_real(value, f"wavelengths[{i}]")
        for i, value in enumerate(raw_wavelengths)
    ]
    if not wavelengths or any(wavelength <= 0 for wavelength in wavelengths):
        raise ValueError("wavelengths must be nonempty and positive")

    if isinstance(raw_lmax, bool) or not isinstance(raw_lmax, int):
        raise ValueError("lmax must be an integer")
    if not 1 <= raw_lmax <= 128:
        raise ValueError("lmax must be between 1 and 128")
    medium = _medium(raw_medium)

    result: dict[str, list[float]] = {
        "scattering": [],
        "extinction": [],
        "absorption": [],
    }
    for wavelength in wavelengths:
        tmatrix = treams_rs.multilayer_sphere_tmatrix(
            k0=math.tau / wavelength,
            lmax=raw_lmax,
            radii=radii,
            materials=materials,
            medium=medium,
        )
        cross_sections = tmatrix.average_cross_sections
        result["scattering"].append(float(cross_sections.scattering))
        result["extinction"].append(float(cross_sections.extinction))
        result["absorption"].append(float(cross_sections.absorption))

    return result


def main() -> None:
    """Read one JSON config from stdin and write one JSON result to stdout."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
