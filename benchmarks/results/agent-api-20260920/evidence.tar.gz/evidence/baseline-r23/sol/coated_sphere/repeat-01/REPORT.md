# Core-shell sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` constructor.
The radii are passed unchanged as increasing outer layer boundaries, the
permittivities are passed inside-out as the finite-layer materials, and
`epsilon_medium` is passed separately as the embedding medium. Thus, the
exterior is not appended as another finite layer.

All input lengths are in micrometers. The vacuum angular wavenumber used at
each wavelength is `k0 = 2*pi/wavelength` in inverse micrometers. Relative
permittivities are interpreted as `real + i*imag`; relative permeability is 1
and chirality is 0. The returned rotationally and polarization-averaged
scattering, extinction, and absorption cross sections are in square
micrometers. Absorption follows the package convention
`C_abs = C_ext - C_sca`.

For the supplied example, every cross section is positive and the reported
values satisfy the power-balance identity above to floating-point precision.
As a truncation check, repeating the calculation with `lmax = 5` changes each
directly computed scattering/extinction value by less than `3e-6` relative to
its magnitude. A zero-contrast check (all finite-layer permittivities equal to
the exterior) also returns zero scattering and extinction to machine precision.
