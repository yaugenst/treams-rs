# Core-shell sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` interface.
The radii and finite-layer permittivities are passed inside-out, while the
exterior permittivity is supplied separately as `medium` (it is not appended
as another finite layer). Vacuum permeability and zero chirality are supplied
implicitly by the package's material convention.

Lengths and vacuum wavelengths are in micrometers. The vacuum angular
wavenumber is therefore `k0 = 2*pi/wavelength` in inverse micrometers, and all
three returned cross sections are in square micrometers. Complex layer
permittivities use the convention `epsilon = real + i*imag`. The reported
cross sections use treams-rs's rotational and polarization average. Absorption
is obtained from the power balance `C_abs = C_ext - C_sca`.

For the example, all absorption values are positive and the power-balance
identity holds exactly for the returned numbers. As a truncation check,
increasing `lmax` from 4 to 5 changes the scattering and extinction results by
at most `9.66e-8` square micrometers (about `2.8e-6` relative to the largest
cross section).
