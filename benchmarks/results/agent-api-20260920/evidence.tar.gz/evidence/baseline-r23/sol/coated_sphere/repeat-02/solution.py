"""Rotationally averaged cross sections of a concentric multilayer sphere."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping, Sequence
from typing import Any

import treams_rs


def _complex_permittivity(value: Any, name: str) -> complex:
    """Convert either a real scalar or JSON ``[real, imag]`` to complex."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number or a [real, imag] pair")
    if isinstance(value, (int, float)):
        result = complex(value)
    elif (
        isinstance(value, Sequence)
        and not isinstance(value, (str, bytes))
        and len(value) == 2
    ):
        result = complex(float(value[0]), float(value[1]))
    else:
        raise ValueError(f"{name} must be a number or a [real, imag] pair")
    if not (math.isfinite(result.real) and math.isfinite(result.imag)):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: Mapping[str, Any]) -> dict[str, list[float]]:
    """Compute averaged scattering, extinction, and absorption cross sections.

    Length inputs are in micrometers, so all returned cross sections are in
    square micrometers.  The free-space angular wavenumber is 2*pi/wavelength.
    """
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary")

    try:
        radii = [float(x) for x in config["radii"]]
        layer_values = config["epsilon_layers"]
        wavelengths = [float(x) for x in config["wavelengths"]]
        lmax = int(config["lmax"])
        medium = _complex_permittivity(config["epsilon_medium"], "epsilon_medium")
    except KeyError as exc:
        raise ValueError(f"missing required config key: {exc.args[0]}") from exc
    except (TypeError, OverflowError) as exc:
        raise ValueError("radii, wavelengths, and lmax must be numeric") from exc

    if not radii:
        raise ValueError("radii must contain at least one boundary")
    if len(layer_values) != len(radii):
        raise ValueError("epsilon_layers must contain exactly one entry per radius")
    if any(not math.isfinite(x) or x <= 0 for x in radii):
        raise ValueError("radii must be finite and positive")
    if any(b <= a for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing")
    if any(not math.isfinite(x) or x <= 0 for x in wavelengths):
        raise ValueError("wavelengths must be finite and positive")
    if lmax < 1 or lmax > 128:
        raise ValueError("lmax must be an integer between 1 and 128")
    if medium.imag != 0:
        raise ValueError("rotationally averaged cross sections require a nonabsorbing exterior")

    materials = [
        _complex_permittivity(value, f"epsilon_layers[{i}]")
        for i, value in enumerate(layer_values)
    ]
    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        tmatrix = treams_rs.multilayer_sphere_tmatrix(
            k0=2 * math.pi / wavelength,
            lmax=lmax,
            radii=radii,
            materials=materials,
            medium=medium,
            polarization="helicity",
        )
        cross_sections = tmatrix.average_cross_sections
        sca = float(cross_sections.scattering)
        ext = float(cross_sections.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(ext - sca)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
