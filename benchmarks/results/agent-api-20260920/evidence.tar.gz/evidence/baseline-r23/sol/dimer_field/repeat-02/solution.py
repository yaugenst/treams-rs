"""Electromagnetic response of a two-sphere cluster computed with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import numpy as np
import treams_rs as tr


def _parse_config(config: Mapping[str, Any]) -> tuple[np.ndarray, list[complex], float, float, int, np.ndarray]:
    """Validate and convert the small, fixed input schema."""
    radii = np.asarray(config["radii"], dtype=float)
    epsilon_parts = np.asarray(config["epsilon"], dtype=float)
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float)

    if radii.shape != (2,) or np.any(~np.isfinite(radii)) or np.any(radii <= 0):
        raise ValueError("radii must contain two finite positive values")
    if epsilon_parts.shape != (2, 2) or np.any(~np.isfinite(epsilon_parts)):
        raise ValueError("epsilon must contain two finite [real, imag] pairs")
    if not math.isfinite(separation) or separation <= 0:
        raise ValueError("separation must be finite and positive")
    if separation < float(radii.sum()):
        raise ValueError("the two spheres overlap")
    if not math.isfinite(wavelength) or wavelength <= 0:
        raise ValueError("wavelength must be finite and positive")
    if lmax < 1 or lmax > 128 or lmax != config["lmax"]:
        raise ValueError("lmax must be an integer from 1 through 128")
    if points.ndim != 2 or points.shape[1:] != (3,) or np.any(~np.isfinite(points)):
        raise ValueError("points must be a finite point-by-3 array")

    epsilon = [complex(real, imag) for real, imag in epsilon_parts]
    return radii, epsilon, separation, wavelength, lmax, points


def run(config: Mapping[str, Any]) -> dict[str, Any]:
    """Return total fields and cross sections for the configured dimer.

    Length inputs are interpreted in micrometers.  Electric fields use the
    normalization of a unit-amplitude positive-helicity treams-rs plane wave.
    """
    radii, epsilon, separation, wavelength, lmax, points = _parse_config(config)
    k0 = 2 * math.pi / wavelength
    vacuum = tr.Material(1)

    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=float(radius),
            material=tr.Material(eps),
            medium=vacuum,
            polarization="helicity",
        )
        for radius, eps in zip(radii, epsilon, strict=True)
    ]
    positions = np.array(
        [[-0.5 * separation, 0.0, 0.0], [0.5 * separation, 0.0, 0.0]]
    )
    response = tr.Cluster(particles, positions=positions).solve()
    incident = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        medium=vacuum,
    )

    scattered = response.scatter(incident)
    total_field = incident.efield(points) + scattered.efield(points)
    cross_sections = response.cross_sections(incident)

    return {
        "total_field_real": np.asarray(total_field.real, dtype=float).tolist(),
        "total_field_imag": np.asarray(total_field.imag, dtype=float).tolist(),
        "scattering": float(cross_sections.scattering),
        "extinction": float(cross_sections.extinction),
        "absorption": float(cross_sections.absorption),
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
