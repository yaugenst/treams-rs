# Dimer scattering calculation

`solution.py` uses the public `treams_rs` API to construct each homogeneous
sphere T-matrix and solve their finite cluster. The cluster solve includes all
orders of inter-sphere multiple scattering within the configured spherical-wave
cutoff `lmax`.

## Units and conventions

All input lengths are in micrometers, so `k0 = 2 pi / wavelength` is in inverse
micrometers. Consequently, the scattering, extinction, and absorption cross
sections are in square micrometers. Relative permittivity is formed from each
`[real, imag]` pair. Both spheres use relative permeability 1 and chirality 0,
and the embedding medium is vacuum.

The sphere centers are `(-separation/2, 0, 0)` and
`(+separation/2, 0, 0)`, in the same order as `radii` and `epsilon`. Illumination
is the package's unit-amplitude positive-helicity plane wave propagating along
+z. The reported complex Cartesian electric field is the direct sum of the
package-normalized incident field and the outgoing cluster field. Its columns
are x, y, z, and its rows preserve the input point order. Field samples are
understood to be in the exterior vacuum region.

## Checks

For the supplied example, the solved basis has 60 channels (two particles,
`lmax = 3`, and two helicities). The extinction balance is
`extinction = scattering + absorption`: 0.059102374155315454 =
0.05648477145338327 + 0.002617602701932185 square micrometers (to rounding).
The positive absorption is consistent with the positive imaginary parts of
both permittivities. The two independent public routes `cross_sections` and
`xs` also give identical scattering and extinction values for this case.
