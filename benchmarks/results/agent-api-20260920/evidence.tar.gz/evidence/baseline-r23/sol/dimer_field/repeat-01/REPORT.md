# Two-sphere scattering report

`solution.py` uses `treams_rs` sphere T-matrices and the solved finite-cluster
response, so the result includes all inter-sphere multiple scattering within the
requested `lmax` truncation. The two sphere centers are
`(-separation/2, 0, 0)` and `(separation/2, 0, 0)`, in the same order as the
input radii and permittivities.

## Units and conventions

- All input lengths are in micrometers. The vacuum angular wavenumber is
  `k0 = 2*pi/wavelength`, in inverse micrometers.
- Relative permittivity is formed as `real + i*imag`; relative permeability is
  1, chirality is 0, and the embedding medium is vacuum.
- Illumination is the package's `positive_helicity` plane wave propagating in
  the positive z direction. No additional amplitude rescaling is applied.
- `total_field_real` and `total_field_imag` are the Cartesian `(Ex, Ey, Ez)`
  components of incident plus scattered electric field, in the native package
  incident-field normalization. Each outer entry corresponds to one input
  point.
- Scattering, extinction, and absorption are cross sections in square
  micrometers. Absorption is defined as extinction minus scattering.

## Checks

For the supplied example, the CLI output and a direct call to `run(config)` are
identical. The power identity is satisfied numerically:

`0.059102374155315454 - 0.05648477145338327 = 0.0026176027019321826 um^2`.

As a non-output convergence check, increasing `lmax` from 3 to 4 changes the
three cross sections by at most `1.72e-5` relatively and any reported real or
imaginary field component by at most `2.84e-5`. The requested results remain
the fixed-`lmax=3` values.
