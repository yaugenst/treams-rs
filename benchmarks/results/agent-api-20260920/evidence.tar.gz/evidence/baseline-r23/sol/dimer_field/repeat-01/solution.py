"""Two-sphere electromagnetic scattering with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _positive_finite(value: Any, name: str) -> float:
    result = float(value)
    if not math.isfinite(result) or result <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return result


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return fields and cross sections for the configured sphere dimer."""
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radii_array = np.asarray(config["radii"], dtype=float)
    epsilon_array = np.asarray(config["epsilon"], dtype=float)
    points = np.asarray(config["points"], dtype=float)
    if radii_array.shape != (2,):
        raise ValueError("radii must contain exactly two values")
    if epsilon_array.shape != (2, 2):
        raise ValueError("epsilon must have shape (2, 2): [real, imag] per sphere")
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("points must have shape (number_of_points, 3)")
    if not np.all(np.isfinite(radii_array)) or np.any(radii_array <= 0):
        raise ValueError("radii must be positive and finite")
    if not np.all(np.isfinite(epsilon_array)) or not np.all(np.isfinite(points)):
        raise ValueError("epsilon and points must contain only finite values")

    separation = _positive_finite(config["separation"], "separation")
    wavelength = _positive_finite(config["wavelength"], "wavelength")
    if separation <= float(np.sum(radii_array)):
        raise ValueError("spheres must not overlap or touch")

    lmax_value = config["lmax"]
    if isinstance(lmax_value, bool) or int(lmax_value) != lmax_value:
        raise ValueError("lmax must be a positive integer")
    lmax = int(lmax_value)
    if lmax < 1:
        raise ValueError("lmax must be a positive integer")

    k0 = 2.0 * math.pi / wavelength
    permittivities = [complex(real, imag) for real, imag in epsilon_array]
    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=float(radius),
            material=permittivity,
            medium=1,
        )
        for radius, permittivity in zip(radii_array, permittivities, strict=True)
    ]
    positions = np.array(
        [[-0.5 * separation, 0.0, 0.0], [0.5 * separation, 0.0, 0.0]]
    )
    cluster = tr.Cluster(particles, positions=positions)
    coupled_response = cluster.solve()
    incident = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
        medium=1,
    )
    scattered = coupled_response.scatter(incident)

    total_field = incident.efield(points) + scattered.efield(points)
    cross_sections = coupled_response.cross_sections(incident)
    result = {
        "total_field_real": np.real(total_field).tolist(),
        "total_field_imag": np.imag(total_field).tolist(),
        "scattering": float(cross_sections.scattering),
        "extinction": float(cross_sections.extinction),
        "absorption": float(cross_sections.absorption),
    }
    return result


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout, allow_nan=False, separators=(",", ":"))
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
