# Scattering calculation

`solution.py` uses micrometers for every length and inverse micrometers for the
vacuum angular wavenumber, `k0 = 2*pi/wavelength`. Permittivities are relative,
with relative permeability 1 and chirality 0 throughout. Vacuum is used for
both exterior half-spaces and for the gap.

The plane-wave basis is normal to the xy plane. Positive z points from the slab
toward the array. The network is cascaded in that order: dielectric slab,
vacuum propagation by `gap`, then the sphere-array scattering plane. Thus
`gap` is the distance from the slab's top interface to the sphere-center plane.
The incident wave comes from the negative-z side, propagates along positive z,
and has positive helicity (treams-rs helicity label 1).

For each wavelength, the sphere T-matrix is formed at the requested fixed
`lmax`, and `solve_periodic` performs the full square-lattice interaction at
Bloch vector (0, 0). Conversion to plane-wave ports retains only reciprocal
order G=(0, 0), with both helicities. Transmission and reflection are flux
fractions from the composed treams-rs S-matrix; absorption is `1 - T - R`.

Checks on the example confirm `T + R + A = 1` to floating-point precision.
Because all materials are real and lossless, the computed absorption has only
roundoff-scale values (below 9e-16 in magnitude). The CLI output was also
compared with a direct call to `run`, and all returned values are ordinary
JSON-serializable Python numbers and lists.
