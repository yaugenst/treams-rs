"""Scattering by a square sphere array above a dielectric slab."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import treams_rs as treams


_KEYS = {
    "radius",
    "sphere_epsilon",
    "period",
    "gap",
    "slab_thickness",
    "slab_epsilon",
    "wavelengths",
    "lmax",
}


def _validate(config: Mapping[str, Any]) -> dict[str, Any]:
    """Return validated, plain-Python inputs."""
    missing = _KEYS.difference(config)
    if missing:
        raise ValueError(f"missing config keys: {', '.join(sorted(missing))}")

    values: dict[str, Any] = {}
    for key in _KEYS - {"wavelengths", "lmax"}:
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{key} must be a real number")
        value = float(value)
        if not math.isfinite(value):
            raise ValueError(f"{key} must be finite")
        values[key] = value

    lmax = config["lmax"]
    if isinstance(lmax, bool) or not isinstance(lmax, int) or lmax < 1:
        raise ValueError("lmax must be a positive integer")
    values["lmax"] = lmax

    raw_wavelengths = config["wavelengths"]
    if not isinstance(raw_wavelengths, (list, tuple)) or not raw_wavelengths:
        raise ValueError("wavelengths must be a nonempty sequence")
    wavelengths = []
    for value in raw_wavelengths:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("each wavelength must be a real number")
        value = float(value)
        if not math.isfinite(value) or value <= 0:
            raise ValueError("each wavelength must be finite and positive")
        wavelengths.append(value)
    values["wavelengths"] = wavelengths

    for key in ("radius", "period"):
        if values[key] <= 0:
            raise ValueError(f"{key} must be positive")
    for key in ("gap", "slab_thickness"):
        if values[key] < 0:
            raise ValueError(f"{key} must be nonnegative")
    for key in ("sphere_epsilon", "slab_epsilon"):
        if values[key] <= 0:
            raise ValueError(f"{key} must be positive for a lossless dielectric")
    if any(wavelength <= values["period"] for wavelength in wavelengths):
        raise ValueError("all wavelengths must exceed the period")
    return values


def run(config: Mapping[str, Any]) -> dict[str, list[float]]:
    """Calculate zeroth-order power fractions in input wavelength order."""
    cfg = _validate(config)
    lattice = treams.Lattice.square(cfg["period"])

    # A zero reciprocal-space cutoff retains G=(0, 0) only.  ``default`` order
    # in this basis is positive helicity (label 1), then negative helicity.
    ports = treams.PlaneWavePorts.diffr_orders([0.0, 0.0], lattice, 0.0)

    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    for wavelength in cfg["wavelengths"]:
        k0 = 2.0 * math.pi / wavelength
        particle = treams.sphere_tmatrix(
            k0=k0,
            lmax=cfg["lmax"],
            radius=cfg["radius"],
            material=cfg["sphere_epsilon"],
            medium=1.0,
            polarization="helicity",
        )
        array = treams.solve_periodic(
            particle, lattice=lattice, kpar=[0.0, 0.0]
        ).to_smatrix(ports)
        slab = treams.slab(
            basis=ports,
            k0=k0,
            thickness=cfg["slab_thickness"],
            material=cfg["slab_epsilon"],
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        gap = treams.propagation(
            distance=cfg["gap"],
            basis=ports,
            k0=k0,
            medium=1.0,
            polarization="helicity",
        )
        system = treams.stack([slab, gap, array])
        incident = treams.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1.0,
        )
        power = system.power(incident, side="negative")
        transmission.append(float(power.transmission))
        reflection.append(float(power.reflection))
        absorption.append(float(power.absorption))

    return {
        "wavelengths": list(cfg["wavelengths"]),
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def _main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
