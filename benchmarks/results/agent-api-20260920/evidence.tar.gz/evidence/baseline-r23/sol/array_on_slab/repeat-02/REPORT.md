# Periodic sphere array above a slab

`solution.py` treats all supplied lengths as micrometers. Thus the vacuum
angular wavenumber is `k0 = 2 pi / wavelength` in inverse micrometers.
Permittivities are relative and real; permeability is 1 and chirality is 0 in
every medium.

The component plane-wave basis is normal to z and contains only the reciprocal
order G = (0, 0), at Bloch vector (0, 0), with both helicity labels. In the
`treams_rs` helicity convention label 1 is positive helicity. Illumination is a
positive-helicity plane wave traveling along +z from the negative-z exterior.
The network is cascaded in physical +z order: dielectric slab, vacuum
propagation over `gap`, then the periodic sphere-array S matrix. The gap is the
distance from the slab's top interface to the sphere-center reference plane.

For each wavelength, `treams_rs.sphere_tmatrix` computes the sphere response at
the requested `lmax`; `treams_rs.solve_periodic` then solves the full square
lattice interaction before conversion to the retained plane-wave ports. The
reported transmission and reflection are outgoing power divided by incident
power in the vacuum exteriors. Absorption is `1 - T - R`; residuals below
1e-12 are reported as zero because all specified materials are lossless.

Checks performed for the example:

- all wavelengths exceed the 0.4 micrometer period, so no nonzero vacuum
  diffraction order propagates;
- the port basis is exactly `((0, 0, 1), (0, 0, 0))`;
- at every wavelength, `T + R` differs from 1 by less than 9e-16;
- the isolated periodic array also conserves power to numerical precision.

Result arrays retain the input wavelength order.
