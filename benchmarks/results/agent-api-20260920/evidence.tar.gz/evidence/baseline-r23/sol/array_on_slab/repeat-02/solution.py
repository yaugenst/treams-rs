"""Normal-incidence scattering by a periodic sphere array above a slab."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import treams_rs as treams


_KEYS = {
    "radius",
    "sphere_epsilon",
    "period",
    "gap",
    "slab_thickness",
    "slab_epsilon",
    "wavelengths",
    "lmax",
}


def _finite_float(config: Mapping[str, Any], key: str) -> float:
    value = config[key]
    if isinstance(value, bool):
        raise TypeError(f"{key} must be a real number")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{key} must be finite")
    return result


def _parameters(config: Mapping[str, Any]) -> tuple[float, ...]:
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary")
    missing = _KEYS.difference(config)
    if missing:
        raise KeyError(f"missing config keys: {', '.join(sorted(missing))}")

    radius = _finite_float(config, "radius")
    sphere_epsilon = _finite_float(config, "sphere_epsilon")
    period = _finite_float(config, "period")
    gap = _finite_float(config, "gap")
    slab_thickness = _finite_float(config, "slab_thickness")
    slab_epsilon = _finite_float(config, "slab_epsilon")

    lmax_value = config["lmax"]
    if isinstance(lmax_value, bool) or int(lmax_value) != lmax_value:
        raise ValueError("lmax must be a positive integer")
    lmax = int(lmax_value)

    try:
        wavelengths = tuple(float(value) for value in config["wavelengths"])
    except TypeError as exc:
        raise TypeError("wavelengths must be an iterable of real numbers") from exc

    if radius <= 0 or period <= 0 or lmax <= 0:
        raise ValueError("radius, period, and lmax must be positive")
    if gap < 0 or slab_thickness < 0:
        raise ValueError("gap and slab_thickness must be nonnegative")
    if not wavelengths or any(not math.isfinite(w) or w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be a nonempty list of positive finite values")
    if any(w <= period for w in wavelengths):
        raise ValueError("each wavelength must exceed the period (zeroth-order regime)")

    return (
        radius,
        sphere_epsilon,
        period,
        gap,
        slab_thickness,
        slab_epsilon,
        lmax,
        wavelengths,
    )


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return zeroth-order power fractions for positive-helicity illumination.

    Output arrays follow the order of ``config["wavelengths"]``.
    """
    (
        radius,
        sphere_epsilon,
        period,
        gap_distance,
        slab_thickness,
        slab_epsilon,
        lmax,
        wavelengths,
    ) = _parameters(config)

    lattice = [[period, 0.0], [0.0, period]]
    # bmax=0 selects G=(0, 0), and the constructor includes both helicities.
    ports = treams.PlaneWavePorts.diffr_orders(
        [0.0, 0.0], lattice, 0.0, alignment="xy"
    )

    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength

        isolated_sphere = treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=sphere_epsilon,
            medium=1.0,
            polarization="helicity",
        )
        periodic_sphere = treams.solve_periodic(
            isolated_sphere, lattice=lattice, kpar=[0.0, 0.0]
        ).to_smatrix(ports)

        slab = treams.slab(
            basis=ports,
            k0=k0,
            thickness=slab_thickness,
            material=slab_epsilon,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        gap = treams.propagation(
            distance=gap_distance,
            basis=ports,
            k0=k0,
            medium=1.0,
            polarization="helicity",
        )
        network = treams.stack([slab, gap, periodic_sphere])

        incident = treams.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1.0,
        )
        balance = network.power(incident, side="negative")
        t_value = float(balance.transmission)
        r_value = float(balance.reflection)
        a_value = float(balance.absorption)
        # Real materials are lossless. Remove roundoff-sized signed residuals.
        if abs(a_value) < 1e-12:
            a_value = 0.0
        transmission.append(t_value)
        reflection.append(r_value)
        absorption.append(a_value)

    return {
        "wavelengths": list(wavelengths),
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
