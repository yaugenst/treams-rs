# Infinite cylinder scattering cross widths

## Problem

Homogeneous, infinitely long circular cylinder with its axis along **z**, illuminated
by a plane wave propagating along **+x** with **positive helicity**, at strictly normal
incidence (`kz = 0`). The cylinder T-matrix is built with `treams_rs.cylinder_tmatrix`
and the cross widths are obtained from `CylindricalTMatrix.cross_widths`.

## Units and conventions

- Lengths (`radius`, `wavelengths`) are in **micrometers**; the returned cross widths
  are therefore in **micrometers** (a width, not an area — no sphere-area / `pi r^2`
  normalization is applied anywhere).
- The vacuum angular wavenumber is `k0 = 2*pi/lambda` (1/um).
- `epsilon` is given as `[real, imag]` and is a **relative** permittivity; the
  time convention of treams is `exp(-i omega t)`, so a positive imaginary part means loss.
- `mu = 1`, `kappa = 0` and the exterior is vacuum (`Material(1)`) unless overridden
  (the code also accepts optional `mu` and `kappa`/`chirality` keys).
- The basis is a helicity basis; the incident field is
  `plane_wave(k0=..., direction=[1,0,0], polarization="positive_helicity")`.
- `mmax` is the azimuthal cutoff: cylindrical orders `m = -mmax ... mmax` (both
  polarizations), i.e. a `2*(2*mmax+1)` T-matrix for the single `kz = 0` slice.
- Results are returned as lists in the same order as the input `wavelengths`.

## Output keys

`wavelengths`, `scattering_width`, `extinction_width`, `absorption_width`
(all lists, um), plus echoed metadata (`units`, `kz`, `mmax`, `radius`, `epsilon`,
`incidence`, `polarization`).

## Example result (radius 0.08 um, eps = 5 + 0.1i, mmax = 4)

| lambda (um) | C_sca (um) | C_ext (um) | C_abs (um) |
|---|---|---|---|
| 0.50 | 0.5330353956 | 0.5611064991 | 0.0280711035 |
| 0.65 | 0.2585917234 | 0.2695397227 | 0.0109479993 |
| 0.80 | 0.2407417379 | 0.2488644544 | 0.0081227166 |

## Checks (`check.py`)

1. **Energy balance**: `C_abs = C_ext - C_sca` holds to machine precision, and
   `C_abs > 0` for the lossy material at every wavelength.
2. **Convergence in `mmax`**: increasing the cutoff from 4 to 6 and 10 changes the
   widths by <1e-12 um, so `mmax = 4` is converged for this size parameter
   (`x = 2*pi*a/lambda <= 1.0`).
3. **Independent analytic reference**: the classical Bohren & Huffman normal-incidence
   cylinder coefficients (TM case I and TE case II, evaluated with Bessel/Hankel
   functions only) were coded separately. A positive-helicity wave at normal incidence
   is an equal, decoupled mixture of TM and TE, so the reference width is the mean of
   the two polarizations. Agreement with treams-rs is ~1e-9 relative or better for
   all three wavelengths.

## Files

- `solution.py` — `run(config)` plus a CLI reading a JSON config on stdin and writing
  the result dictionary as JSON on stdout.
- `results.json` — output for the example config.
- `check.py` — the validation script described above.
