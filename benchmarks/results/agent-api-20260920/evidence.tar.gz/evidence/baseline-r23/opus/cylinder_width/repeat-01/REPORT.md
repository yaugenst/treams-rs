# Scattering cross widths of an infinite homogeneous cylinder

## Problem

A homogeneous circular cylinder of radius `radius`, infinite along z, embedded in
vacuum, illuminated by a plane wave of positive helicity propagating along +x
(normal incidence, so the axial wavenumber is `kz = 0`). For each wavelength the
scattering, extinction and absorption **cross widths** are reported.

## Method

The cylindrical T-matrix is built directly by treams-rs
(`treams_rs.cylinder_tmatrix`, Mie-type analytic solution for a homogeneous
infinite cylinder) in the helicity polarization basis, with the single axial
wavenumber `kz = 0` and azimuthal orders `|m| <= mmax`. The incident field is a
`treams_rs.plane_wave` with `direction=[1,0,0]` and
`polarization="positive_helicity"`. Cross widths come from the T-matrix method
`cross_widths(incident)`, which returns the named triple
(scattering, extinction, absorption) in **length units** — the cylindrical
normalization, not a sphere-area normalization. No reimplementation of the
scattering physics is done here.

## Units and conventions

- Lengths (`radius`, `wavelengths`, and all returned cross widths) are in
  **micrometers**. Cross *widths* are cross sections per unit cylinder length.
- Vacuum angular wavenumber `k0 = 2*pi / lambda` (rad/um), with `lambda` the
  vacuum wavelength.
- `epsilon` is given as `[real, imag]` and is relative/dimensionless; it is
  passed as `eps = real + 1j*imag`. A **positive imaginary part means loss**
  (time convention `exp(-i omega t)`), which is verified below by a positive
  absorption. `mu = 1` and `kappa = 0` (defaults of `treams_rs.Material`).
  The exterior is vacuum (optionally overridable with a `medium` key).
- Helicity (circular) polarization basis; `positive_helicity` is the +1 helicity
  channel of the incident plane wave. The incident flux normalization is the
  library default (`flux=0.5`, i.e. unit-amplitude plane wave), so cross widths
  are the usual power-per-incident-intensity quantities.
- Absorption is taken from the library's own `absorption` field, which equals
  extinction - scattering.

## Outputs

`run(config)` returns a dictionary with `wavelengths` (echoed, defining the
order), `scattering_cross_width`, `extinction_cross_width`,
`absorption_cross_width` (lists in the same wavelength order), and `units`.
The CLI reads one JSON config from stdin and prints this dictionary as JSON.

## Results for the example config

radius = 0.08 um, epsilon = 5 + 0.1i, mmax = 4:

| lambda (um) | C_sca (um) | C_ext (um) | C_abs (um) |
|---|---|---|---|
| 0.50 | 0.5330353956 | 0.5611064991 | 0.0280711035 |
| 0.65 | 0.2585917234 | 0.2695397227 | 0.0109479993 |
| 0.80 | 0.2407417379 | 0.2488644544 | 0.0081227166 |

Saved in `results.json`.

## Checks performed

- **Multipole convergence**: increasing `mmax` from 4 to 6 to 10 changes the
  extinction widths only in the 9th significant digit (e.g. 0.5611064991 ->
  0.5611065013 -> 0.5611065013 at 0.5 um), so `mmax = 4` is already converged
  for this size parameter.
- **Energy balance**: absorption equals extinction minus scattering, and is
  positive for `Im(eps) > 0`.
- **Lossless limit**: with `epsilon = [5, 0]` the absorption is ~1e-16, i.e.
  numerically zero, as required by the optical theorem for a transparent
  cylinder.
- **Vacuum limit**: with `epsilon = [1, 0]` all three cross widths vanish
  (<= 1e-17), confirming the exterior medium and geometry setup.
- **Helicity symmetry**: for this achiral cylinder at normal incidence, the
  negative-helicity illumination reproduces the positive-helicity cross widths
  to ~1e-16 relative, as expected by mirror symmetry.
