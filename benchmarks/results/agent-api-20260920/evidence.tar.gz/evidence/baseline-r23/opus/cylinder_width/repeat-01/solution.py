"""Scattering by a homogeneous infinite circular cylinder parallel to z.

Normal incidence (kz = 0), positive-helicity plane wave travelling along +x.
Cross widths (length units, micrometers) are computed with treams-rs.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as tr


def _material(epsilon):
    """Build a Material from ``[real, imag]`` (or a scalar) with mu=1, kappa=0."""
    if np.isscalar(epsilon):
        eps = complex(epsilon)
    else:
        re, im = (list(epsilon) + [0.0])[:2]
        eps = complex(float(re), float(im))
    return tr.Material(eps)


def run(config):
    radius = float(config["radius"])
    mmax = int(config["mmax"])
    material = _material(config["epsilon"])
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]
    medium = tr.Material(config.get("medium", 1))

    scattering, extinction, absorption = [], [], []
    for lam in wavelengths:
        k0 = 2.0 * np.pi / lam
        tm = tr.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],
            mmax=mmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )
        inc = tr.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
        )
        xw = tm.cross_widths(inc)
        scattering.append(float(np.real(xw.scattering)))
        extinction.append(float(np.real(xw.extinction)))
        absorption.append(float(np.real(xw.absorption)))

    return {
        "wavelengths": wavelengths,
        "scattering_cross_width": scattering,
        "extinction_cross_width": extinction,
        "absorption_cross_width": absorption,
        "units": "micrometer",
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
