"""Scattering by a homogeneous infinite circular cylinder parallel to z.

Normal incidence (kz = 0), positive-helicity plane wave travelling along +x.
Cross widths (length units, micrometers) are computed with treams-rs.
"""

from __future__ import annotations

import json
import sys

import math

import treams_rs as tr


def _material(cfg):
    """Build the cylinder material from the config (epsilon is [real, imag])."""
    eps = cfg["epsilon"]
    if isinstance(eps, (list, tuple)):
        epsilon = complex(eps[0], eps[1])
    else:
        epsilon = complex(eps)
    mu = cfg.get("mu", 1)
    if isinstance(mu, (list, tuple)):
        mu = complex(mu[0], mu[1])
    kappa = cfg.get("kappa", cfg.get("chirality", 0))
    if isinstance(kappa, (list, tuple)):
        kappa = complex(kappa[0], kappa[1])
    return tr.Material(complex(epsilon), complex(mu), complex(kappa))


def run(config):
    radius = float(config["radius"])
    mmax = int(config["mmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    material = _material(config)
    eps_c = complex(list(material)[0])
    medium = tr.Material(1)  # vacuum exterior

    scattering, extinction, absorption = [], [], []
    for lam in wavelengths:
        k0 = 2.0 * math.pi / lam  # vacuum angular wavenumber, 1/um
        tm = tr.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],
            mmax=mmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )
        illu = tr.plane_wave(
            k0=k0,
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            material=medium,
        )
        xw = tm.cross_widths(illu)
        scattering.append(float(xw.scattering.real))
        extinction.append(float(xw.extinction.real))
        absorption.append(float(xw.absorption.real))

    return {
        "wavelengths": wavelengths,
        "scattering_width": scattering,
        "extinction_width": extinction,
        "absorption_width": absorption,
        "units": "um",
        "kz": 0.0,
        "mmax": mmax,
        "radius": radius,
        "epsilon": [eps_c.real, eps_c.imag],
        "incidence": "+x",
        "polarization": "positive_helicity",
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
