"""Infer a lossless homogeneous sphere radius from target scattering efficiencies.

Forward model: treams-rs Mie T-matrix of a homogeneous sphere in vacuum.
Gradients: analytic reverse-mode derivatives from the Advect adapter of
``treams_rs`` (``treams_rs.advect``); no finite differences are used for the
optimization.

All lengths are micrometers; epsilon/mu/kappa are relative and dimensionless.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import advect
import numpy as np
import treams_rs.advect as ta

_TWO_PI = 2.0 * np.pi


def _efficiencies(radius: Any, k0s: np.ndarray, epsilon: float, lmax: int) -> list[Any]:
    """Scattering efficiencies Q = sigma_sca / (pi r^2) for each vacuum wavenumber."""
    out = []
    for k0 in k0s:
        tm = ta.sphere_tmatrix(
            k0=float(k0), lmax=lmax, radius=radius, material=epsilon, medium=1.0
        )
        # Plane-wave illumination along +z; a sphere is rotationally symmetric and
        # its cross section is polarization independent, so one helicity suffices.
        pw = ta.plane_wave([0.0, 0.0, float(k0)], 0, k0=float(k0), medium=1.0)
        xs = tm.cross_sections(pw)
        out.append(xs.scattering / (np.pi * radius * radius))
    return out


def _make_loss(k0s: np.ndarray, targets: np.ndarray, epsilon: float, lmax: int):
    def loss(radius):
        qs = _efficiencies(radius, k0s, epsilon, lmax)
        acc = 0.0
        for q, t in zip(qs, targets):
            res = (q - float(t)) / float(t)
            acc = acc + res * res
        return acc / len(targets)

    return loss


def _minimize(loss_and_grad, x0: float, lo: float, hi: float, maxiter: int = 200):
    """Bounded 1-D minimization: secant (quasi-Newton) steps on the analytic
    gradient with backtracking line search and projection onto [lo, hi]."""
    x = float(min(max(x0, lo), hi))
    f, g = loss_and_grad(x)
    history = [float(f)]
    span = max(hi - lo, 1.0e-12)
    step = 0.05 * span  # gradient-descent fallback step when curvature is unusable
    x_prev = None
    g_prev = None

    for _ in range(maxiter):
        if f < 1.0e-14 or abs(g) < 1.0e-14:
            break
        # Curvature estimate from the last two analytic gradients (secant).
        curv = None
        if x_prev is not None and x != x_prev:
            curv = (g - g_prev) / (x - x_prev)
        if curv is not None and curv > 1.0e-12:
            delta = -g / curv
        else:
            delta = -float(np.sign(g)) * step
        if abs(delta) > 0.5 * span:
            delta = float(np.sign(delta)) * 0.5 * span

        # Backtracking (Armijo) line search driven by the analytic gradient.
        accepted = False
        halvings = 0
        for _ls in range(60):
            xn = float(min(max(x + delta, lo), hi))
            if xn == x:
                break
            fn, gn = loss_and_grad(xn)
            if fn <= f + 1.0e-4 * g * (xn - x):
                x_prev, g_prev = x, g
                x, f, g = xn, fn, gn
                accepted = True
                break
            delta *= 0.5
            halvings += 1
        if not accepted:
            break
        history.append(float(f))
        # Grow the fallback step while progress is easy, shrink it otherwise.
        moved = abs(x - x_prev)
        step = min(2.0 * moved, 0.5 * span) if halvings == 0 else max(moved, 1.0e-14)
        if moved <= 1.0e-14 * max(1.0, abs(x)):
            break

    return x, f, g, history


def run(config: dict) -> dict:
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = np.asarray(config["wavelengths"], dtype=float)
    targets = np.asarray(config["target_efficiencies"], dtype=float)
    r0 = float(config["initial_radius"])
    lo, hi = (float(b) for b in config["bounds"])
    if lo > hi:
        lo, hi = hi, lo

    k0s = _TWO_PI / wavelengths  # vacuum angular wavenumber, 1/um
    loss = _make_loss(k0s, targets, epsilon, lmax)
    loss_and_grad = advect.value_and_grad(loss)

    r_start = min(max(r0, lo), hi)
    initial_loss = float(loss(r_start))

    r, f, g, history = _minimize(loss_and_grad, r_start, lo, hi)

    # Robustness for badly placed starting points: restart from a coarse grid
    # (each restart still uses analytic gradients only).
    if f >= 1.0e-7:
        for cand in np.linspace(lo, hi, 17):
            rc, fc, gc, hc = _minimize(loss_and_grad, float(cand), lo, hi)
            if fc < f:
                r, f, g = rc, fc, gc
                history = history + hc
            if f < 1.0e-7:
                break

    fitted = [float(q) for q in _efficiencies(r, k0s, epsilon, lmax)]

    return {
        "radius": float(r),
        "loss": float(f),
        "initial_loss": initial_loss,
        "gradient": float(g),
        "fitted_efficiencies": fitted,
        "loss_history": [float(v) for v in history],
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
