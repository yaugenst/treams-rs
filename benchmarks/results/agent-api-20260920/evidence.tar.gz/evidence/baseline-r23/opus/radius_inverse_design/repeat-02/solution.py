"""Infer a homogeneous lossless sphere radius from target scattering efficiencies.

Forward model: treams-rs Mie T-matrix of a homogeneous sphere in vacuum.
Derivatives: analytic reverse-mode pullbacks through the Advect adapter
(``treams_rs.advect``); no finite differences are used for optimization.

All lengths in micrometers, permittivity relative and dimensionless.
"""

from __future__ import annotations

import json
import sys

import advect
import numpy as np
import treams_rs.advect as tad

__all__ = ["run", "main"]


def _efficiency(radius, k0, epsilon, mu, kappa, lmax):
    """Scattering efficiency Q = sigma_sca / (pi r^2) of a sphere in vacuum.

    The sphere is isotropic, so a single plane wave of one helicity gives the
    rotation- and polarization-averaged scattering cross section.
    """
    material = tad.Material(epsilon, mu, kappa)
    tm = tad.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=material, medium=1.0
    )
    pw = tad.plane_wave([0.0, 0.0, 1.0], [1.0, 0.0], k0=k0, medium=1.0)
    sigma = tm.cross_sections(pw).scattering
    return sigma / (np.pi * radius * radius)


def _make_loss(k0s, targets, epsilon, mu, kappa, lmax):
    def loss(radius):
        total = 0.0
        for k0, tgt in zip(k0s, targets):
            q = _efficiency(radius, k0, epsilon, mu, kappa, lmax)
            total = total + ((q - tgt) / tgt) ** 2
        return total / len(k0s)

    return loss


def _minimize(value_and_grad, r0, lo, hi, max_iter=200, tol=1e-14):
    """Projected quasi-Newton (secant curvature) line search on a bounded scalar."""
    r = float(min(max(r0, lo), hi))
    f, g = value_and_grad(r)
    history = [float(f)]
    r_prev = g_prev = None

    for _ in range(max_iter):
        if f < tol:
            break
        # curvature estimate from successive gradients, fall back to steepest descent
        step = None
        if r_prev is not None and abs(r - r_prev) > 0:
            curv = (g - g_prev) / (r - r_prev)
            if curv > 0:
                step = -g / curv
        if step is None:
            scale = max(hi - lo, 1e-12)
            step = -g / max(abs(g) / (0.05 * scale), 1e-30) if g != 0 else 0.0
        if step == 0.0:
            break

        # Armijo backtracking with projection into the bounds
        alpha, accepted = 1.0, False
        for _ in range(60):
            r_new = min(max(r + alpha * step, lo), hi)
            d = r_new - r
            if d == 0.0:
                break
            f_new, g_new = value_and_grad(r_new)
            if f_new <= f + 1e-4 * g * d:
                accepted = True
                break
            alpha *= 0.5
        if not accepted:
            break

        r_prev, g_prev = r, g
        r, f, g = r_new, f_new, g_new
        history.append(float(f))

    return r, f, g, history


def run(config):
    epsilon = float(config["epsilon"])
    mu = float(config.get("mu", 1.0))
    kappa = float(config.get("chirality", config.get("kappa", 0.0)))
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    targets = [float(t) for t in config["target_efficiencies"]]
    r0 = float(config["initial_radius"])
    lo, hi = (float(b) for b in config["bounds"])
    if lo > hi:
        lo, hi = hi, lo

    k0s = [2.0 * np.pi / w for w in wavelengths]
    loss = _make_loss(k0s, targets, epsilon, mu, kappa, lmax)
    value_and_grad = advect.value_and_grad(loss)

    initial_loss = float(loss(min(max(r0, lo), hi)))
    radius, floss, grad, history = _minimize(value_and_grad, r0, lo, hi)

    # Multi-start safeguard: descent is local, so scan the bound interval if the
    # trajectory from initial_radius stalls in a poor basin.
    if floss >= 1e-9:
        for start in np.linspace(lo, hi, 33):
            r_s, f_s, g_s, h_s = _minimize(value_and_grad, float(start), lo, hi)
            if f_s < floss:
                radius, floss, grad = r_s, f_s, g_s
                history = history + h_s
            if floss < 1e-12:
                break

    fitted = [
        float(_efficiency(radius, k0, epsilon, mu, kappa, lmax)) for k0 in k0s
    ]

    return {
        "radius": float(radius),
        "loss": float(floss),
        "initial_loss": initial_loss,
        "gradient": float(grad),
        "fitted_efficiencies": fitted,
        "loss_history": [float(v) for v in history],
        "wavelengths": wavelengths,
        "target_efficiencies": targets,
        "bounds": [lo, hi],
        "converged": bool(floss < 1e-7),
    }


def main():
    config = json.loads(sys.stdin.read())
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
