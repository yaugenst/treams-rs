# Sphere radius inverse design from scattering efficiencies

## Problem
Given a homogeneous, lossless sphere (fixed relative permittivity `epsilon`, `mu = 1`,
`kappa = 0`) in vacuum, find the radius whose Mie scattering efficiencies best match
measured targets at the given wavelengths:

```
loss(r) = mean_i ( (Q_i(r) - target_i) / target_i )^2 ,   r in [bounds[0], bounds[1]]
```

## Units and conventions
- All lengths (wavelengths, radius, bounds) are in micrometers; `epsilon`, `mu`, `kappa`
  are relative/dimensionless. Exterior is vacuum (`epsilon = mu = 1`).
- Vacuum angular wavenumber `k0 = 2*pi/lambda` (rad/um); treams-rs requires radius and
  `1/k0` in the same length unit, which holds here.
- Cross sections come back in squared length units (um^2). The scattering **efficiency**
  is the geometric-cross-section normalization `Q_sca = sigma_sca / (pi r^2)` —
  dimensionless, and independent of the radius only through the physics, not the units.
- Multipole truncation `lmax` is taken from the config and held fixed; the T-matrix has
  `2*lmax*(lmax+2)` modes in the helicity basis (treams-rs default).
- Illumination: a single plane wave along `+z` with one helicity. A sphere is
  rotationally symmetric and achiral here, so its cross section is independent of
  incidence direction and polarization; this equals the rotation/polarization average
  (verified against `TMatrix.xs_sca_avg`, agreement to ~1e-15 relative).

## Method
- Forward model: `treams_rs.advect.sphere_tmatrix` (the Advect adapter around the native
  Mie/T-matrix routine) plus `TMatrix.cross_sections` on an `advect.plane_wave`. No Mie
  series is reimplemented.
- Derivatives: `advect.value_and_grad` on the loss, i.e. the native first-order VJPs
  (pullbacks) shipped with treams-rs. `dQ/dr` and `dloss/dr` are analytic; finite
  differences are used only as an offline check, never to drive the optimizer.
- Optimizer: bounded 1-D quasi-Newton. Each step uses a secant curvature estimate built
  from two consecutive **analytic** gradients; when the curvature is non-positive it
  falls back to a sign-of-gradient step with adaptive length. Every trial point is
  clipped to the bounds and accepted via an Armijo backtracking test that uses the
  analytic directional derivative. Stops on a vanishing gradient, no further decrease,
  or 200 iterations.
- Robustness: if the loss from `initial_radius` stalls above 1e-7 (e.g. a bad basin or
  an infeasible target), the solver restarts from a coarse grid inside the bounds, still
  using analytic gradients only. The reported `initial_loss` is always the loss at
  `initial_radius` (clipped into the bounds).

## Returned keys
`radius`, `loss` (final), `initial_loss` (at `initial_radius`), `gradient`
(`dloss/dr` at the returned radius), `fitted_efficiencies` (`Q_sca` recomputed at the
returned radius, in config wavelength order), `loss_history` (loss after each accepted
step, starting with `initial_loss`).

## Example result (`results.json`)
`epsilon = 4`, `lmax = 3`, `lambda = [0.58, 0.69, 0.81] um`, start `0.075 um`,
bounds `[0.06, 0.14] um`:

- `radius ≈ 0.1100000 um`, `loss ≈ 6.7e-15` (target `< 1e-7`), `initial_loss ≈ 0.6215`
- `gradient ≈ -6.0e-6` (essentially stationary; the loss is quadratic-flat at the
  minimum, so the residual gradient scales like `sqrt(loss)`)
- `fitted_efficiencies ≈ [1.5627980, 0.8019215, 0.4253871]`, matching the targets to
  ~1e-7 relative
- 10 loss evaluations in the history; runtime well under a second

## Checks performed
1. **Gradient correctness**: analytic `dloss/dr` vs central differences at
   r = 0.08, 0.10, 0.12 um — agreement to 8–9 significant digits.
2. **Forward-model consistency**: plane-wave `Q_sca` vs `TMatrix.xs_sca_avg/(pi r^2)`
   from the non-differentiable API — identical to ~1e-15 relative.
3. **Round trips**: targets synthesized from known radii (`epsilon` 2.25/4/6/12,
   `lmax` 2–5, 1–4 wavelengths, starts above and below the answer) are recovered to
   ~1e-6 um or better with final losses 1e-14 and below.
4. **Edge cases**: with an infeasible target the solver terminates at the active bound
   and reports the (nonzero) loss and the true gradient there; with 0.2% noise on the
   targets it converges to the best-fit radius with a loss floor set by the noise.
