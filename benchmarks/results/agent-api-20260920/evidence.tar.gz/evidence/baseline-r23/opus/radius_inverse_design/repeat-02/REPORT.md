# Sphere radius inverse design from scattering efficiencies

## Task
Given a fixed relative permittivity, fixed `lmax`, a set of vacuum wavelengths and
measured scattering efficiencies, infer the radius of a homogeneous lossless sphere
in vacuum by minimizing

    L(r) = mean_i ( (Q_i(r) - Q_i^target) / Q_i^target )^2

over `r` within `bounds`, starting from `initial_radius`.

## Forward model (treams-rs)
* `treams_rs.advect.sphere_tmatrix(k0, lmax, radius, material=Material(eps, mu, kappa), medium=1.0)`
  builds the Mie T-matrix of the homogeneous sphere in the helicity basis.
* The scattering cross section comes from `TMatrix.cross_sections(plane_wave)`
  (`CrossSections.scattering`). A sphere is isotropic, so a single plane wave of one
  helicity along +z reproduces the rotation- and polarization-averaged result; this was
  verified against `treams_rs.TMatrix.xs_sca_avg` (agreement to ~1e-17 absolute).
* Efficiency: `Q = sigma_sca / (pi r^2)` (geometric-cross-section normalization).

## Units and conventions
* Lengths (radius, wavelengths, bounds) in micrometers; `k0 = 2*pi/lambda` in rad/um.
* `epsilon`, `mu`, `kappa` are relative and dimensionless; defaults `mu = 1`, `kappa = 0`
  (read from optional `mu` / `chirality` keys), exterior is vacuum (`medium = 1`).
* Cross sections in um^2; `Q` is dimensionless. Lossless material, so
  extinction = scattering (checked at the example point).
* `gradient` is dL/dr in 1/um. The radius dependence enters both through the T-matrix
  and through the `pi r^2` normalization; both are differentiated.

## Derivatives and optimizer
Gradients are the analytic reverse-mode pullbacks of treams-rs, obtained through the
installed Advect adapter (`advect.value_and_grad` over `treams_rs.advect`). No finite
differences are used to produce any reported derivative or optimization step.

The optimizer is a projected quasi-Newton line search on the scalar `r`: curvature is
estimated by a secant on successive analytic gradients (steepest descent on the first
step or when the curvature is non-positive), with Armijo backtracking and clamping to
`bounds`. Because 1-D descent is local, a safeguard scans 33 starts across the bound
interval if the trajectory from `initial_radius` does not reach `loss < 1e-9`; the
extra trajectory is appended to `loss_history` when it improves the optimum.

## Checks
* Analytic gradient vs. central finite differences at several radii: agreement to
  ~1e-9 relative on the example, and at the optimum of three additional synthetic cases
  (eps = 9/2.25/12, lmax = 5/2/6, 2-4 wavelengths, starts at or on a bound) the analytic
  and FD gradients match to the FD noise floor.
* Synthetic round trips: targets generated at a known radius are recovered to ~1e-9 um
  (loss ~1e-17 or below) in all test cases.
* Inconsistent (perturbed) targets converge to the best-fit radius with a nonzero
  residual, `converged` reported as `false` rather than forcing the tolerance; when the
  best fit lies outside `bounds`, the result sits on the active bound.

## Example result (`results.json`)
`radius = 0.10999999999820521` um, `loss = 4.31e-21` (< 1e-7), `initial_loss = 0.6215`,
final `gradient = -4.80e-09` 1/um, 13 loss-history entries. The fitted efficiencies
reproduce the supplied targets to ~1e-10.

## Usage
```
python solution.py < config.json > results.json
```
`run(config)` returns the same dictionary: `radius`, `loss`, `initial_loss`, `gradient`,
`fitted_efficiencies`, `loss_history`, plus echoed `wavelengths`, `target_efficiencies`,
`bounds` and a `converged` flag.
