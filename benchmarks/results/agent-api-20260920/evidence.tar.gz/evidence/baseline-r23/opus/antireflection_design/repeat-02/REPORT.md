# Single-layer antireflection coating: analytic-gradient thickness optimization

## Problem and geometry

A lossless coating of relative permittivity `epsilon` lies directly on a substrate
of relative permittivity `substrate_epsilon` (no vacuum gap). Vacuum fills the
+z half space and a plane wave is incident from vacuum at normal incidence,
travelling towards -z. The optimization variable is the coating thickness,
constrained to `bounds` and started from `initial_thickness`.

## Units and conventions

* Lengths (wavelength, thickness, bounds) in micrometers; `k0 = 2*pi/wavelength`
  has units of 1/um.
* Permittivities are relative and dimensionless; `mu = 1`, chirality `0`,
  exterior vacuum, as specified.
* Normal incidence is encoded as a transverse wavevector `(kx, ky) = (0, 0)`:
  `PlaneWaveBasis([[0,0,1,0],[0,0,1,1]]).bycomp(k0)`, i.e. a
  `PlaneWaveBasisByComp` with both polarization labels.
* `treams_rs.advect.multilayer_slab` is called with layers ordered along the
  positive normal: `negative_medium = substrate_epsilon`, one interior layer
  (`thicknesses=[t]`, `materials=[epsilon]`), `positive_medium = 1.0` (vacuum).
  Illumination therefore comes from the **positive** side and propagates in -z,
  which is the requested "from vacuum (+z) into the substrate".
* Polarization basis is helicity; at normal incidence reflection flips helicity
  and both helicities give the same reflectance, so the unit illumination
  `[1, 0]` is representative.
* `reflection` is the **power** reflectance obtained from
  `SMatrix.power(incident, side="positive").reflection` (a `PowerBalance`), i.e.
  the ratio of reflected to incident time-averaged z-directed Poynting flux.
  It equals |r|^2 here because the incident and reflected waves share the vacuum
  half space.

## Derivatives and optimization

Derivatives are the native analytic pullbacks of treams-rs, requested through
the installed Advect adapter: the whole loss (slab S-matrix -> power balance) is
differentiated with `advect.value_and_grad`, giving `dR/dt` exactly, with no
finite differences and no closed-form reimplementation of the physics.

The optimizer is projected gradient descent with a Barzilai-Borwein trial step
(the exact Newton step for a locally quadratic 1-D loss) safeguarded by Armijo
backtracking, with the iterate clipped into `bounds` after every step. It stops
on the reflectance target, a vanishing projected gradient, or a failed line
search (e.g. when a bound is active). No quarter-wave formula is used anywhere in
the computation; the quarter-wave value only appears below as an independent
check of the result.

## Returned keys

`thickness`, `reflection` (final power reflectance), `initial_reflection`
(reflectance at the starting thickness), `gradient` (final analytic
`dR/dthickness`, 1/um), `loss_history` (reflectance at every accepted iterate,
starting with the initial value), plus `iterations`, `bounds`, `target_met` and
`wavelength` for convenience.

## Example result (`results.json`)

Config: `wavelength=0.7`, `epsilon=2.25`, `substrate_epsilon=5.0625`,
`initial_thickness=0.05`, `bounds=[0.025, 0.21]`.

* `initial_reflection = 9.594027e-02`
* `thickness = 0.116666667 um`
* `reflection = 3.10e-21`  (target `< 1e-7` met)
* `gradient = -6.3e-10` (1/um), i.e. a stationary interior point
* 5 accepted iterations; the loss history decreases monotonically
  `9.59e-2 -> 7.08e-3 -> 2.93e-3 -> 6.84e-7 -> 2.01e-10 -> 3.10e-21`.

## Checks

1. **Analytic vs. finite-difference gradient.** At `t = 0.05` the adapter gives
   `dR/dt = -1.862590377991579`; a central difference with `h = 1e-6` gives
   `-1.8625903778`, agreeing to ~9 digits. Same agreement at `t = 0.1166`.
   (Finite differences are used only as a validation, never to supply the
   gradient or a step.)
2. **Independent transfer-matrix cross-check.** With `n1=1, nc=1.5, ns=2.25`,
   the two-interface Airy formula gives `R(0.05) = 0.09594027275235124` versus
   `0.09594027275235117` from treams-rs, and `R(t_opt) = 3.1037e-21`.
3. **Physical optimum.** `nc = 1.5 = sqrt(ns)` is index matched, so a perfect
   null exists at the quarter-wave thickness `wavelength/(4*nc) = 0.1166667 um`;
   the optimizer reaches it from the analytic gradients alone.
4. **Energy balance.** The `PowerBalance` absorption is ~2e-16 (numerical zero),
   confirming the lossless real-permittivity setting and `R + T = 1`.
5. **Other configs.** Non-index-matched cases converge to the correct
   non-zero minimum (e.g. `epsilon=4`, `substrate_epsilon=2.25` converges to a
   half-wave layer with `R = 0.0400 = ((1-1.5)/(1+1.5))^2`, gradient ~1e-15),
   and bound-limited cases stop at the active bound with a non-zero gradient.
   `target_met` reports whether `reflection < 1e-7` was actually achieved.

## CLI

```
echo '{"wavelength":0.7,"epsilon":2.25,"substrate_epsilon":5.0625,"initial_thickness":0.05,"bounds":[0.025,0.21]}' | python solution.py
```
reads one config dict from stdin and prints the result dict as JSON on stdout.
