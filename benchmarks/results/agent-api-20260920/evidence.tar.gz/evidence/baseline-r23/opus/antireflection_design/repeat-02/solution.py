"""Analytic-gradient thickness optimization of a single-layer antireflection coating.

The coating sits directly on a substrate; vacuum occupies the +z half space and
the plane wave is incident from vacuum travelling towards -z.  Scattering is
evaluated with treams-rs (``treams_rs.advect.multilayer_slab``) and the
thickness derivative comes from the native analytic pullback exposed through the
installed Advect adapter.
"""

from __future__ import annotations

import json
import sys

import advect
import numpy as np
import treams_rs.advect as ta
from treams_rs import PlaneWaveBasis

_MAX_ITER = 400
_TARGET = 1e-7


def _basis(k0):
    """Normal incidence: both transverse wavevector components vanish."""
    return PlaneWaveBasis([[0, 0, 1, 0], [0, 0, 1, 1]]).bycomp(k0)


def _make_loss(k0, epsilon, substrate_epsilon):
    basis = _basis(k0)
    incident = np.array([1.0, 0.0])

    def loss(thickness):
        smat = ta.multilayer_slab(
            basis=basis,
            k0=k0,
            thicknesses=advect.numpy.reshape(thickness, (1,)),
            materials=[epsilon],
            negative_medium=substrate_epsilon,
            positive_medium=1.0,
            polarization="helicity",
        )
        # Illumination enters from the positive (vacuum) side.
        return smat.power(incident, side="positive").reflection

    return loss


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    lo, hi = (float(b) for b in config["bounds"])
    if lo > hi:
        lo, hi = hi, lo
    x = min(max(float(config["initial_thickness"]), lo), hi)

    k0 = 2.0 * np.pi / wavelength
    loss = _make_loss(k0, epsilon, substrate_epsilon)
    value_and_grad = advect.value_and_grad(loss)

    def clip(t):
        return float(min(max(t, lo), hi))

    f, g = value_and_grad(np.array(x))
    f, g = float(f), float(g)
    initial_reflection = f
    history = [f]

    step = None
    x_prev = g_prev = None
    for _ in range(_MAX_ITER):
        # Projected gradient at the current (possibly active) bound.
        pg = g
        if (x <= lo + 0.0 and g > 0.0) or (x >= hi - 0.0 and g < 0.0):
            pg = 0.0
        if f < 1e-16 or abs(pg) < 1e-14:
            break

        # Barzilai-Borwein trial step (exact Newton step for a 1-D quadratic).
        if x_prev is not None and g != g_prev:
            step = abs((x - x_prev) / (g - g_prev))
        if step is None or not np.isfinite(step) or step <= 0.0:
            step = max(abs(f / (g * g)), 1e-6 / max(abs(g), 1e-30))

        # Armijo backtracking on the projected step.
        accepted = False
        trial_step = step
        for _ls in range(60):
            x_new = clip(x - trial_step * g)
            if x_new == x:
                break
            f_new, g_new = value_and_grad(np.array(x_new))
            f_new, g_new = float(f_new), float(g_new)
            if f_new <= f - 1e-4 * g * (x - x_new):
                accepted = True
                break
            trial_step *= 0.5
        if not accepted:
            break

        x_prev, g_prev = x, g
        x, f, g = x_new, f_new, g_new
        step = trial_step
        history.append(f)
        if f < _TARGET * 1e-3:
            break

    return {
        "thickness": float(x),
        "reflection": float(f),
        "initial_reflection": float(initial_reflection),
        "gradient": float(g),
        "loss_history": [float(v) for v in history],
        "iterations": len(history) - 1,
        "bounds": [lo, hi],
        "target_met": bool(f < _TARGET),
        "wavelength": wavelength,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
