# Single-layer antireflection coating: analytic-gradient thickness optimization

## Problem

A lossless homogeneous coating of relative permittivity `epsilon` sits directly on a
substrate of relative permittivity `substrate_epsilon` (no vacuum gap). A plane wave
travels along **+z** from vacuum, hits the coating at **normal incidence**, and the
reflected power fraction `R(d)` is minimized over the coating thickness `d`, starting at
`initial_thickness` and staying inside `bounds`.

## Units and conventions

- All lengths (wavelength, thickness, bounds) are in **micrometers**; `k0 = 2*pi/wavelength`
  is in rad/um.
- `epsilon`, `substrate_epsilon` are **relative and dimensionless**; `mu = 1`, `kappa = 0`.
- Planar geometry uses the `xy` port alignment, so the interface normal is **+z**.
  In treams-rs the *negative* side of that normal is vacuum (the incidence side) and the
  *positive* side carries the substrate, matching "from vacuum (+z) into a substrate".
- Normal incidence means one transverse wavevector `(qx, qy) = (0, 0)` with both
  polarizations: `PlaneWavePorts([(0,0,0), (0,0,1)])`.
- `reflection` is the **incident-power-normalized reflected power** returned by
  `SMatrix.power(...).reflection` (a real number in [0,1]), not a field amplitude.
  For a lossless stack `transmission + reflection = 1`.
- `gradient` is `dR/dd` in **1/um**.

## Method

- Forward model: `treams_rs.advect.slab(basis=..., k0=..., thickness=d, material=epsilon,
  negative_medium=1.0, positive_medium=substrate_epsilon)`, illuminated with
  `treams_rs.advect.plane_wave([0,0,1], [1,0], k0=k0, medium=1.0)` from the negative side.
  This is the treams-rs planar S-matrix; nothing is reimplemented.
- Derivatives: `advect.value_and_grad` over that treams-rs call, i.e. the **native analytic
  pullbacks** exposed through the installed Advect adapter. Finite differences appear
  nowhere in the optimizer; they were only used once, offline, as a check (below).
- Optimizer: **projected gradient descent** on `R(d)`, with
  - clipping of every iterate to `bounds`,
  - backtracking (halving toward the current point) so each accepted step strictly
    decreases `R`,
  - a Barzilai-Borwein step size `|dx/dg|` from successive analytic gradients, which in one
    dimension reproduces a Newton step for a locally quadratic loss and gives the fast tail
    convergence seen in `loss_history`,
  - a nudge if the start happens to be an exact stationary point (e.g. a half-wave maximum),
  - stopping at `R <= 1e-12`, when no admissible decreasing step exists, or after 400 steps.
- No closed-form quarter-wave value is inserted anywhere; the quarter-wave thickness is
  only used below as an independent check of the converged result.

## Example result (`results.json`)

Config: `wavelength = 0.7`, `epsilon = 2.25`, `substrate_epsilon = 5.0625`,
`initial_thickness = 0.05`, `bounds = [0.025, 0.21]`.

| quantity | value |
|---|---|
| `initial_reflection` | 9.594027e-02 |
| `thickness` | 0.11666666657669 um |
| `reflection` | 2.55e-19 |
| `gradient` (dR/dd) | -5.66e-09 /um |
| iterations | 5 |

Reflection drops from ~9.6% to 2.5e-19, far below the required 1e-7.

## Checks

1. **Gradient check (validation only).** At `d = 0.05` the analytic gradient is
   -1.862590377991575 /um versus central-difference -1.862590377758877 /um
   (h = 1e-6 um); at `d = 0.09`, -1.4740587058 vs -1.4740587056. Agreement to ~1e-10
   relative.
2. **Physics check.** `n_coat = sqrt(2.25) = 1.5`, `n_sub = sqrt(5.0625) = 2.25`, so the
   impedance-matching condition `n_coat = sqrt(n_sub)` holds exactly and the ideal
   quarter-wave thickness is `wavelength/(4 n_coat) = 0.1166666667` um. The optimizer,
   run purely on analytic gradients, converged to 0.1166666666 um (relative deviation
   ~8e-10).
3. **Energy balance.** At the optimum `transmission + reflection = 1` to ~2e-16, and the
   reported absorption is ~1e-16, consistent with a lossless stack.
4. **Robustness (other configs, not hard-coded).** Runs from initial thicknesses on either
   side of the optimum, at a bound, at a half-wave maximum, and already at the optimum all
   terminate correctly; e.g. `(0.5, 2.1, 4.41, d0=0.5)` -> 0.267400 um (quarter wave
   0.267400), `R = 7e-23`. When no perfect match exists (`epsilon = 2.25`,
   `substrate_epsilon = 4.0`) the run stops at the true local minimum with
   `R = 3.46e-3`, `dR/dd ~ 1e-16`, and reports `converged: false` rather than claiming
   success.

## Interface

- `run(config) -> dict` with keys `thickness`, `reflection`, `initial_reflection`,
  `gradient`, `loss_history` (reflected power at the start and after each accepted step),
  plus `iterations`, `bounds`, `converged`, `wavelength`.
- CLI: `echo '<config json>' | python solution.py` reads one config dict from stdin and
  prints the result dict as JSON on stdout.
