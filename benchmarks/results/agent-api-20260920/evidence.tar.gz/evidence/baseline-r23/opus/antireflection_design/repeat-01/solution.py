"""Analytic-gradient thickness optimization of a single-layer antireflection coating.

The coating is a lossless homogeneous slab between vacuum (negative z side,
where the plane wave comes from, travelling along +z) and the substrate
(positive z side).  Reflected power and its exact derivative with respect to
the slab thickness come from treams-rs planar S-matrices differentiated with
the installed Advect adapter (``treams_rs.advect``); no finite differences are
used to drive the optimization.

Lengths are in micrometers, permittivities are relative and dimensionless.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np

import treams_rs as tr
import treams_rs.advect as tra

# Normal incidence: a single transverse wavevector (0, 0) with both polarizations.
_PORTS = tr.PlaneWavePorts([(0.0, 0.0, 0), (0.0, 0.0, 1)])


def _reflection_fn(wavelength, epsilon, substrate_epsilon):
    """Return R(thickness) built from treams-rs, differentiable in thickness."""
    k0 = 2.0 * np.pi / wavelength

    def reflection(thickness):
        smat = tra.slab(
            basis=_PORTS,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        # x-polarized plane wave travelling along +z, incident from the vacuum side.
        wave = tra.plane_wave([0.0, 0.0, 1.0], [1.0, 0.0], k0=k0, medium=1.0)
        return smat.power(wave, side="negative").reflection

    return reflection


def _value_and_grad(reflection, thickness):
    value, grad = ad.value_and_grad(reflection)(float(thickness))
    return float(value), float(grad)


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(np.real(config["epsilon"]))
    substrate_epsilon = float(config["substrate_epsilon"])
    lower, upper = (float(b) for b in config["bounds"])
    if lower > upper:
        lower, upper = upper, lower
    thickness = min(max(float(config["initial_thickness"]), lower), upper)

    reflection = _reflection_fn(wavelength, epsilon, substrate_epsilon)

    value, grad = _value_and_grad(reflection, thickness)
    initial_reflection = value
    loss_history = [value]

    tol = 1e-12                      # target reflected power (well below 1e-7)
    max_iter = 400
    # First trial step: scaled so the initial move is a fraction of the wavelength.
    step = (0.05 * wavelength) / max(abs(grad), 1e-30)
    prev_thickness = prev_grad = None

    for _ in range(max_iter):
        if value <= tol:
            break
        if grad == 0.0:
            # Stationary start (e.g. an exact half-wave maximum): nudge off it.
            probe = min(max(thickness + 1e-4 * wavelength, lower), upper)
            if probe == thickness:
                probe = min(max(thickness - 1e-4 * wavelength, lower), upper)
            if probe == thickness:
                break
            value, grad = _value_and_grad(reflection, probe)
            thickness = probe
            loss_history.append(value)
            step = (0.05 * wavelength) / max(abs(grad), 1e-30)
            continue
        projected = min(max(thickness - step * grad, lower), upper)
        if projected == thickness:
            break

        # Backtracking: accept only steps that decrease the reflected power.
        trial, new_value, new_grad = projected, None, None
        for _ in range(60):
            new_value, new_grad = _value_and_grad(reflection, trial)
            if new_value < value:
                break
            trial = thickness + 0.5 * (trial - thickness)
            if abs(trial - thickness) < 1e-16:
                break
        else:  # pragma: no cover - loop always breaks
            pass
        if new_value is None or new_value >= value:
            break

        prev_thickness, prev_grad = thickness, grad
        thickness, value, grad = trial, new_value, new_grad
        loss_history.append(value)

        # Barzilai-Borwein step: in one dimension this is an exact Newton step
        # for a locally quadratic loss, giving fast convergence near the minimum.
        dx = thickness - prev_thickness
        dg = grad - prev_grad
        step = abs(dx / dg) if dg != 0.0 else step
        if not np.isfinite(step) or step <= 0.0:
            step = (0.05 * wavelength) / max(abs(grad), 1e-30)

    return {
        "thickness": thickness,
        "reflection": value,
        "initial_reflection": initial_reflection,
        "gradient": grad,
        "loss_history": loss_history,
        "iterations": len(loss_history) - 1,
        "bounds": [lower, upper],
        "converged": bool(value < 1e-7),
        "wavelength": wavelength,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
