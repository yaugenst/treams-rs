# Core–shell sphere cross-section spectrum

## What it does
`solution.py` builds the T-matrix of a concentric multilayer sphere with
`treams_rs.multilayer_sphere_tmatrix` for each requested wavelength and returns
the rotationally (and polarization-) averaged scattering, extinction and
absorption cross sections from `TMatrix.average_cross_sections`.

CLI: `python solution.py < config.json > results.json` (one config dict on
stdin, result dict as JSON on stdout).

## Input conventions
- `radii`: strictly increasing **outer boundaries** of the layers, in µm.
- `epsilon_layers`: one `[real, imag]` relative permittivity per layer, ordered
  **inside-out**; entry *i* fills the region between `radii[i-1]` and `radii[i]`.
  A bare scalar is also accepted.
- `epsilon_medium`: relative permittivity of the unbounded exterior. It is
  passed as the `medium` argument and is **not** appended as an extra finite
  layer, so `len(radii) == len(epsilon_layers)` is enforced.
- `wavelengths`: vacuum wavelengths in µm; the code uses `k0 = 2π/λ` (1/µm).
- `lmax`: multipole truncation order.
- Defaults: `mu = 1`, `kappa = 0`, exterior vacuum (`epsilon_medium = 1`).
  Optional keys `mu_layers`, `kappa_layers`, `mu_medium`, `kappa_medium` are
  honoured if present.
- Sign convention is treams': a positive imaginary part of ε means loss.

## Output
`{"wavelengths", "scattering", "extinction", "absorption", "units", "lmax"}`.
The three cross-section lists are in the same order as the input wavelengths and
are in **µm²**. Cross sections are referenced to the exterior medium (the
incident plane wave propagates in the medium with wavenumber `k0·√(ε_medium)`),
which is the treams convention. `absorption = extinction − scattering`.

## Example result (`results.json`)
Two layers (r = 0.07, 0.12 µm; ε = 2.25+0.03i, 4+0.06i) in ε_medium = 1.7689,
`lmax = 4`:

| λ (µm) | σ_sca (µm²) | σ_ext (µm²) | σ_abs (µm²) |
|---|---|---|---|
| 0.58 | 3.431592e-2 | 3.752383e-2 | 3.207911e-3 |
| 0.70 | 1.891246e-2 | 2.117016e-2 | 2.257697e-3 |
| 0.82 | 1.213568e-2 | 1.390107e-2 | 1.765386e-3 |

## Checks performed
1. **Multipole convergence**: σ_sca is stable to ~10 significant digits between
   `lmax = 4`, 6 and 8 (`lmax = 2` already agrees to 5 digits), so the example
   truncation is converged.
2. **Degenerate-layer test**: setting both layers to the same ε reproduces the
   single homogeneous sphere of radius 0.12 µm to ~1e-16 relative.
3. **Energy balance**: with real permittivities the absorption is 0 to machine
   precision (|σ_abs| < 3e-17 µm²) and σ_sca = σ_ext.
4. **Rayleigh limit**: a 2 nm sphere (ε = 4) in ε_medium = 1.7689 matches the
   analytic dipole result σ_sca = (8/3)π k⁴a⁶|(ε−ε_m)/(ε+2ε_m)|² to 6e-5
   relative (finite-size correction), confirming the medium normalization.

No derivatives or optimization are requested by this task, so no pullbacks are
used; all numerics come from treams-rs.
