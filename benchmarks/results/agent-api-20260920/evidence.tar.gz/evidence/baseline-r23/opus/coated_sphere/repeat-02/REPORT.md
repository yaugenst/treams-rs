# Core–shell sphere spectrum (treams-rs)

## What is computed
For each wavelength, the concentric multilayer sphere T-matrix is built with
`treams_rs.multilayer_sphere_tmatrix(k0=..., lmax=..., radii=..., materials=...,
medium=...)` and the rotationally + polarization averaged cross sections are read
from `TMatrix.average_cross_sections` (`scattering`, `extinction`, `absorption`).
No Mie code is reimplemented.

## Conventions
- **Lengths / units.** All lengths are micrometers, so `k0 = 2*pi/lambda` is in
  1/µm and the returned cross sections are in **µm²**. Wavelength is the
  *vacuum* wavelength; the exterior refractive index enters only through
  `medium`, never through `k0`.
- **Geometry.** `radii` are the increasing *outer* boundaries of each layer;
  `epsilon_layers[i]` is the permittivity of the layer whose outer boundary is
  `radii[i]`, ordered inside-out. The exterior is passed via `medium` and is
  **not** appended as an extra finite layer.
- **Materials.** `[re, im]` pairs are converted to complex relative
  permittivity with the `exp(-i*omega*t)` / positive-imaginary-part lossy
  convention used by treams. `mu = 1` and `kappa = 0` unless the optional keys
  `mu_layers`, `kappa_layers`, `mu_medium`, `kappa_medium` are supplied.
  `epsilon_medium` may likewise be a scalar or a `[re, im]` pair.
- **Basis.** Helicity polarization with multipole order up to `lmax`; the
  averaged cross sections are basis independent (verified below).
- **Output order.** All three lists follow the input wavelength order.

## Output keys
`wavelengths`, `scattering_cross_section`, `extinction_cross_section`,
`absorption_cross_section` (lists, µm²), plus echoes `units`, `lmax`, `radii`,
`epsilon_medium`.

## Example result (`results.json`)
radii `[0.07, 0.12]` µm, eps `[2.25+0.03i, 4+0.06i]`, exterior eps `1.7689`
(n = 1.33), lmax 4:

| λ (µm) | σ_sca (µm²) | σ_ext (µm²) | σ_abs (µm²) |
|---|---|---|---|
| 0.58 | 3.431592e-02 | 3.752383e-02 | 3.207911e-03 |
| 0.70 | 1.891246e-02 | 2.117016e-02 | 2.257697e-03 |
| 0.82 | 1.213568e-02 | 1.390107e-02 | 1.765386e-03 |

## Checks performed
1. **Energy balance.** `absorption = extinction - scattering` holds by
   construction and is positive at every wavelength.
2. **Lossless limit.** With `Im(eps) = 0` in both layers, absorption/scattering
   is 6e-16 — the optical theorem is satisfied to machine precision.
3. **Basis independence.** Helicity vs. parity polarization agree to ~1e-16
   relative.
4. **Multipole convergence.** At λ = 0.58 µm, σ_sca changes by 2e-9 relative
   between lmax 4 and lmax 8 (lmax 1 → 4 changes it by 8%), so lmax = 4 is
   converged for the example size parameter.
5. **Degenerate-layer consistency.** Setting both layers to the same material
   reproduces `sphere_tmatrix` for the homogeneous 0.12 µm sphere exactly
   (identical to all printed digits).
6. **Rayleigh limit.** For a 5 nm homogeneous sphere the result matches the
   quasistatic dipole σ_sca = k⁴|α|²/(6π), k = 2π n_med/λ, to 4e-4 relative; for
   a 4/6 nm coated sphere it matches the coated-sphere effective permittivity
   dipole formula to 9e-4 relative (residual is the expected O(x²) correction).

## Running
```
python solution.py < example_config.json > results.json
```
or `from solution import run; run(config)`.
