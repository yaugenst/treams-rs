"""Core-shell (multilayer) sphere spectrum via treams-rs.

Computes rotationally and polarization averaged scattering, extinction and
absorption cross sections of a concentric layered sphere embedded in an
isotropic dielectric exterior.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as treams


def _as_complex(value: Any) -> complex:
    """Accept [re, im], a number, or a complex-parsable string."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(float(value[0]), 0.0)
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"cannot interpret {value!r} as a complex number")
    if isinstance(value, complex):
        return value
    if isinstance(value, str):
        return complex(value)
    return complex(float(value), 0.0)


def _material(eps: Any, mu: Any = None, kappa: Any = None) -> treams.Material:
    """Build an isotropic material; mu defaults to 1 and kappa to 0."""
    e = _as_complex(eps)
    m = 1.0 + 0.0j if mu is None else _as_complex(mu)
    k = 0.0 + 0.0j if kappa is None else _as_complex(kappa)
    return treams.Material((e, m, k))


def _optional_list(config: dict, key: str, n: int) -> list:
    """Per-layer optional parameter list, or a list of Nones."""
    raw = config.get(key)
    if raw is None:
        return [None] * n
    if not isinstance(raw, (list, tuple)):
        raw = [raw] * n
    if len(raw) != n:
        raise ValueError(f"'{key}' must provide {n} entries, got {len(raw)}")
    return list(raw)


def run(config: dict) -> dict:
    radii = [float(r) for r in config["radii"]]
    eps_layers = list(config["epsilon_layers"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config.get("lmax", 4))

    if len(radii) != len(eps_layers):
        raise ValueError("radii and epsilon_layers must have the same length")
    if len(radii) == 0:
        raise ValueError("at least one layer is required")
    if any(r <= 0.0 for r in radii):
        raise ValueError("radii must be positive")
    if any(b <= a for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing (outer boundaries)")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")
    if not wavelengths:
        raise ValueError("at least one wavelength is required")

    mu_layers = _optional_list(config, "mu_layers", len(radii))
    kappa_layers = _optional_list(config, "kappa_layers", len(radii))
    materials = [
        _material(e, m, k) for e, m, k in zip(eps_layers, mu_layers, kappa_layers)
    ]

    # Exterior: never appended as an extra finite layer, passed as `medium`.
    medium = _material(
        config.get("epsilon_medium", 1.0),
        config.get("mu_medium"),
        config.get("kappa_medium"),
    )

    sca: list[float] = []
    ext: list[float] = []
    abs_: list[float] = []
    for wl in wavelengths:
        if wl <= 0.0:
            raise ValueError("wavelengths must be positive")
        k0 = 2.0 * np.pi / wl  # vacuum wavenumber, 1/um
        tm = treams.multilayer_sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radii=radii,
            materials=materials,
            medium=medium,
            polarization="helicity",
        )
        xs = tm.average_cross_sections
        sca.append(float(xs.scattering))
        ext.append(float(xs.extinction))
        abs_.append(float(xs.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering_cross_section": sca,
        "extinction_cross_section": ext,
        "absorption_cross_section": abs_,
        "units": {
            "wavelength": "um",
            "cross_section": "um^2",
        },
        "lmax": lmax,
        "radii": radii,
        "epsilon_medium": [medium()[0].real, medium()[0].imag],
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
