"""Core-shell (multilayer) sphere cross-section spectrum via treams-rs.

Units: lengths in micrometers, cross sections in um^2.  Permittivities,
permeabilities and chirality are relative/dimensionless.  Time convention and
sign of the imaginary part of epsilon follow treams (Im(eps) > 0 is loss).
"""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _complex(value: Any) -> complex:
    """Accept a scalar, [re, im] pair, or complex-like input."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"cannot interpret {value!r} as a complex number")
    return complex(value)


def _material(eps: Any, mu: Any = None, kappa: Any = None) -> tr.Material:
    return tr.Material(
        _complex(eps),
        1.0 if mu is None else _complex(mu),
        0.0 if kappa is None else _complex(kappa),
    )


def _opt_list(config: dict, key: str, n: int) -> list:
    values = config.get(key)
    if values is None:
        return [None] * n
    if len(values) != n:
        raise ValueError(f"'{key}' must have {n} entries")
    return list(values)


def run(config: dict) -> dict:
    radii = [float(r) for r in config["radii"]]
    eps_layers = list(config["epsilon_layers"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config.get("lmax", 4))

    if len(radii) != len(eps_layers):
        raise ValueError("'radii' and 'epsilon_layers' must have equal length")
    if any(r <= 0 for r in radii):
        raise ValueError("radii must be positive")
    if any(b <= a for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing (outer boundaries)")
    if lmax < 1:
        raise ValueError("lmax must be >= 1")
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")

    mus = _opt_list(config, "mu_layers", len(radii))
    kappas = _opt_list(config, "kappa_layers", len(radii))
    materials = [_material(e, m, k) for e, m, k in zip(eps_layers, mus, kappas)]

    # The exterior is a separate argument: it is *not* appended as a layer.
    medium = _material(
        config.get("epsilon_medium", 1.0),
        config.get("mu_medium"),
        config.get("kappa_medium"),
    )

    sca, ext, abs_ = [], [], []
    for wl in wavelengths:
        k0 = 2.0 * math.pi / wl  # vacuum wavenumber, 1/um
        tm = tr.multilayer_sphere_tmatrix(
            k0=k0, lmax=lmax, radii=radii, materials=materials, medium=medium
        )
        xs = tm.average_cross_sections  # rotation/polarization averaged, um^2
        sca.append(float(xs.scattering))
        ext.append(float(xs.extinction))
        abs_.append(float(xs.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering": sca,
        "extinction": ext,
        "absorption": abs_,
        "units": {"wavelength": "um", "cross_section": "um^2"},
        "lmax": lmax,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
