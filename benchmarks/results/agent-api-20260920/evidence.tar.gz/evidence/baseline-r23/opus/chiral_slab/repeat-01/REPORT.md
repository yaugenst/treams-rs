# Chiral slab at normal incidence — power fractions per helicity

`solution.py` exposes `run(config)` and a CLI (`python solution.py < config.json`)
that reads one config dictionary from stdin and prints the result dictionary as
JSON. `results.json` holds the output for the example config.

## Problem and method

A uniform, isotropic, reciprocal chiral slab of thickness `d` lies normal to z
with vacuum on both sides. A plane wave of definite helicity is incident from
the negative-z side travelling towards +z. For each wavelength the slab
scattering matrix is built with **treams-rs**:

- `treams.Material(epsilon, mu, kappa)` — the package material with relative
  epsilon, mu and dimensionless chirality `kappa`;
- `treams.PlaneWavePorts.default([0.0, 0.0])` — the single specular channel at
  normal incidence (zero transverse wavevector), carrying both polarization
  labels;
- `treams.slab(basis=..., k0=..., thickness=d, material=..., negative_medium=1,
  positive_medium=1, polarization="helicity")` — the homogeneous layer between
  the two vacuum half-spaces;
- `treams.plane_wave(direction=[0,0,1], polarization="positive_helicity" /
  "negative_helicity", k0=k0, material=1, poltype="helicity")` for the
  illumination, and `SMatrices.power(wave, side="negative")` for the balance.

`power` returns a `PowerBalance` namedtuple whose `transmission`, `reflection`
and `absorption` are **power fractions of the incident flux**, not complex
amplitude coefficients. No derivatives or optimization are requested, so none
are computed; nothing is reimplemented numerically.

## Units and conventions

- Lengths (`thickness`, `wavelengths`) are micrometers; epsilon, mu, kappa are
  relative/dimensionless. Vacuum angular wavenumber `k0 = 2*pi/wavelength`
  in 1/um.
- `epsilon` is given as `[real, imag]`; `kappa` (and optional `mu`) accept a
  real scalar or a `[real, imag]` pair. Defaults: `mu = 1`, `kappa = 0`,
  vacuum exterior. The time convention is the package's `exp(-i omega t)`, so a
  positive imaginary part of epsilon means loss.
- Helicity ordering: index 0 is **positive** helicity, index 1 is **negative**
  helicity, matching `helicity_order` in the output. Helicity is defined
  relative to the propagation direction, so the helicity-resolved indices are
  `n_pm = sqrt(eps*mu) +- kappa` (reported under
  `diagnostics.helicity_refractive_indices`).
- `transmission`, `reflection` and `absorption` are each a list of shape
  `(n_wavelengths, 2)`.

## Checks

- **Energy balance.** `T + R + A = 1` for every wavelength and helicity;
  `max_energy_balance_residual` is 0.0 (to machine precision) for the example.
- **Passivity.** All fractions are non-negative; a lossless configuration
  (`Im eps = 0`, real kappa) gives `A = 0` to ~1e-16.
- **Independent analytic cross-check** (`check_analytic.py`, validation only —
  it does not supply any reported number). A direct 4-unknown boundary-matching
  solution of the chiral slab is set up in the lab circular basis: within one
  circular channel the forward wave has index `n + sigma*kappa` and the
  backward wave `n - sigma*kappa`, with common impedance `Z = sqrt(mu/eps)`.
  It reproduces the treams-rs result to <1e-15 for the example and for two
  further configurations, including complex `kappa` and a lossless slab.

## Physics note on the example

For the example config `kappa = 0.08` is **real**, so `n_+` and `n_-` differ
only in their real parts (1.5801 vs 1.4201) while sharing `Im n = 0.0200`.
Consequently the two helicities have identical absorption, and the round-trip
phase inside the slab is `(k_+ + k_-) d = 2 n k0 d`, independent of kappa, so
the reflection is identical as well. The example therefore shows **no circular
dichroism**: the two columns agree to ~1e-15, which is the correct physical
answer rather than a degeneracy in the setup. Real kappa produces optical
rotation (a phase difference), which does not appear in power fractions.
Making `kappa` complex immediately splits the columns — e.g. with
`epsilon = [4, 0.3]`, `kappa = [0.15, 0.05]`, `d = 0.42`, at 0.5 um the
transmissions are 0.1964 (positive) and 0.5643 (negative), with equal
reflections, as expected.

## Example result (`results.json`)

| wavelength (um) | T (+/-) | R (+/-) | A (+/-) |
| --- | --- | --- | --- |
| 0.55 | 0.905416 / 0.905416 | 0.024049 / 0.024049 | 0.070536 / 0.070536 |
| 0.65 | 0.864572 / 0.864572 | 0.080756 / 0.080756 | 0.054673 / 0.054673 |
| 0.80 | 0.826736 / 0.826736 | 0.130154 / 0.130154 | 0.043110 / 0.043110 |
