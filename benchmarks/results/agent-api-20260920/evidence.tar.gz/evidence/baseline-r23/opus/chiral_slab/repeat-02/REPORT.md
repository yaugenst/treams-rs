# Chiral slab power balance (treams-rs)

## Problem and method

A uniform, reciprocal, isotropic chiral slab of thickness `d` lies normal to `z`
with vacuum on both sides. A plane wave of definite helicity is incident from
the `-z` side travelling along `+z`. For each wavelength and each helicity we
report the transmitted, reflected and absorbed **power fractions**.

The scattering is done entirely by treams-rs:

1. `treams_rs.Material(epsilon, mu, kappa)` — relative, dimensionless, complex.
2. `treams_rs.PlaneWaveBasis.default([0, 0, 1]).bycomp(k0)` — the single normal
   mode `(k_x, k_y) = (0, 0)` with both polarization labels.
3. `treams_rs.slab(basis=..., k0=..., thickness=d, material=...,
   negative_medium=1, positive_medium=1, polarization="helicity")` — the slab
   S-matrix, including all internal multiple reflections.
4. `treams_rs.plane_wave(direction=[0,0,1], polarization="positive_helicity" |
   "negative_helicity", k0=k0, medium=1)` — the unit-flux illumination.
5. `SMatrices.power(incident, side="negative")` → `PowerBalance` with
   `.transmission`, `.reflection`, `.absorption`.

No scattering physics is reimplemented; the closed-form expressions below are
used only as an independent check.

## Units and conventions

- Lengths (`thickness`, `wavelengths`) in micrometers; `k0 = 2*pi/lambda` in
  1/um is the vacuum angular wavenumber.
- `epsilon` is given as `[real, imag]`; `mu` defaults to 1, `kappa` to 0. A
  positive imaginary part of epsilon is loss (time convention `exp(-i*omega*t)`,
  treams' convention). `kappa` is the package's material chirality: the two
  helicity eigen-indices are `n_pm = sqrt(eps*mu) pm kappa`, and the wave
  impedance `sqrt(mu/eps)` is helicity independent.
- Helicity labels: treams uses `pol = 1` for positive and `pol = 0` for negative
  helicity. The output lists are ordered **positive then negative**, i.e. shape
  `(n_wavelengths, 2)`.
- Returned quantities are power fractions normalized to the incident flux, not
  complex amplitude coefficients: `T + R + A = 1`.

## Output

`run(config)` returns `wavelengths`, `helicity_order`, `transmission`,
`reflection`, `absorption` (each `(n_wavelengths, 2)`), and
`power_balance_residual = max |T + R + A - 1|`.

CLI: reads one JSON config on stdin, prints the result dictionary as JSON.

## Checks performed

- **Energy conservation**: residual `0.0` for the example; `1.1e-16` for a
  lossless chiral test case, whose absorption is `<4e-16`.
- **Achiral limit**: with `kappa = 0` the result matches the analytic Fresnel
  slab `t = (1-r^2)p/(1-r^2 p^2)`, `r_slab = r(1-p^2)/(1-r^2 p^2)` with
  `r = (1-n)/(1+n)`, `p = exp(i k0 n d)` to ~1e-15.
- **Chiral analytic check**: for real `kappa`, replacing `p` by
  `exp(i k0 n_pm d)` while the round-trip factor stays `exp(2 i k0 n0 d)`
  (helicity flips on each internal reflection) reproduces the treams numbers to
  ~1e-15.
- **No circular dichroism for real kappa**: the two helicities give identical
  `T`, `R`, `A`. This is physical, not a bug — with real `kappa`,
  `Im n_+ = Im n_- = Im sqrt(eps*mu)`, the impedance is helicity independent,
  and the Fabry–Perot round trip involves `n_+ + n_- = 2 n0`; only the phase
  (optical rotation / circular birefringence) differs.
- **Dichroism appears for complex kappa**: with `kappa = 0.08 + 0.01i` the
  example slab gives `T_+ = 0.8729` vs `T_- = 0.9391`, consistent with
  `Im n_+ > Im n_-`.

## Example result (`results.json`)

Config `thickness = 0.16 um`, `epsilon = 2.25 + 0.06i`, `kappa = 0.08`,
`lambda = 0.55, 0.65, 0.80 um`:

| lambda (um) | T (both hel.) | R (both hel.) | A (both hel.) |
|---|---|---|---|
| 0.55 | 0.905416 | 0.024049 | 0.070536 |
| 0.65 | 0.864572 | 0.080756 | 0.054673 |
| 0.80 | 0.826736 | 0.130154 | 0.043110 |
