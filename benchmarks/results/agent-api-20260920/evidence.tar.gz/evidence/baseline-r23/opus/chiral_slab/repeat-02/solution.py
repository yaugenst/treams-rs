"""Power balance of a homogeneous reciprocal chiral slab at normal incidence.

The slab is normal to z, bounded by vacuum, and illuminated from the negative
side (propagation along +z).  Transmitted, reflected and absorbed power
fractions are returned for positive and negative helicity, in that order.

All lengths are micrometers; epsilon, mu and kappa are dimensionless.
Scattering is done by treams-rs (``treams_rs.slab`` -> ``SMatrices.power``).
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as t

HELICITIES = ("positive_helicity", "negative_helicity")


def _complex(value, default=0.0):
    """Accept a scalar or a ``[real, imag]`` pair."""
    if value is None:
        return complex(default)
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"cannot interpret {value!r} as a complex number")
    return complex(value)


def run(config):
    thickness = float(config["thickness"])
    epsilon = _complex(config["epsilon"])
    mu = _complex(config.get("mu", 1.0), 1.0)
    kappa = _complex(config.get("kappa", 0.0))
    wavelengths = np.atleast_1d(np.asarray(config["wavelengths"], dtype=float))

    material = t.Material(epsilon, mu, kappa)
    # Normal incidence: a single mode with vanishing transverse wavevector,
    # carrying both helicity channels (treams labels pol=1 positive, pol=0
    # negative helicity).
    directions = t.PlaneWaveBasis.default([0.0, 0.0, 1.0])

    transmission, reflection, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / float(wavelength)  # vacuum angular wavenumber, 1/um
        smat = t.slab(
            basis=directions.bycomp(k0),
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1,  # vacuum on the -z side
            positive_medium=1,  # vacuum on the +z side
            polarization="helicity",
        )
        row_t, row_r, row_a = [], [], []
        for helicity in HELICITIES:
            incident = t.plane_wave(
                direction=[0.0, 0.0, 1.0],  # +z propagation
                polarization=helicity,
                k0=k0,
                medium=1,
            )
            balance = smat.power(incident, side="negative")
            row_t.append(float(balance.transmission))
            row_r.append(float(balance.reflection))
            row_a.append(float(balance.absorption))
        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

    total = (
        np.asarray(transmission) + np.asarray(reflection) + np.asarray(absorption)
    )
    return {
        "wavelengths": [float(w) for w in wavelengths],
        "helicity_order": ["positive", "negative"],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "power_balance_residual": float(np.max(np.abs(total - 1.0))),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
