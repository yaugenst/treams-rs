"""Normal-incidence power balance of a uniform reciprocal chiral slab.

The slab is normal to z, bounded by vacuum on both sides, and illuminated from
the negative-z side by a plane wave travelling towards +z.  Transmitted,
reflected and absorbed power fractions are returned for positive and negative
helicity at every requested wavelength.

All lengths are micrometers; epsilon, mu and kappa are dimensionless.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as treams


def _to_complex(value):
    """Accept a real number, a complex number or a ``[real, imag]`` pair."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"cannot interpret {value!r} as a complex scalar")
    return complex(value)


def run(config):
    thickness = float(config["thickness"])
    epsilon = _to_complex(config["epsilon"])
    mu = _to_complex(config.get("mu", 1))
    kappa = _to_complex(config.get("kappa", 0))
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]

    material = treams.Material(epsilon, mu, kappa)
    # Single specular channel at normal incidence: transverse wavevector zero.
    # ``default`` yields the two polarization labels (1, 0) of that channel.
    basis = treams.PlaneWavePorts.default([0.0, 0.0])

    transmission, reflection, absorption = [], [], []
    refractive_indices, checks = [], []

    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl  # vacuum angular wavenumber, 1/um
        smat = treams.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1,  # vacuum on the illuminated (-z) side
            positive_medium=1,  # vacuum on the exit (+z) side
            polarization="helicity",
        )

        row_t, row_r, row_a = [], [], []
        for helicity in ("positive_helicity", "negative_helicity"):
            wave = treams.plane_wave(
                direction=[0.0, 0.0, 1.0],
                polarization=helicity,
                k0=k0,
                material=1,
                poltype="helicity",
            )
            balance = smat.power(wave, side="negative")
            row_t.append(float(balance.transmission))
            row_r.append(float(balance.reflection))
            row_a.append(float(balance.absorption))

        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

        # Diagnostics: helicity-resolved indices n_pm = n +- kappa and the
        # energy balance T + R + A = 1 for each helicity.
        k_minus, k_plus = material.ks(k0)
        refractive_indices.append(
            {
                "wavelength": wl,
                "n_positive_helicity": [float((k_plus / k0).real), float((k_plus / k0).imag)],
                "n_negative_helicity": [float((k_minus / k0).real), float((k_minus / k0).imag)],
            }
        )
        checks.append(
            {
                "wavelength": wl,
                "energy_balance_residual": [
                    abs(row_t[i] + row_r[i] + row_a[i] - 1.0) for i in range(2)
                ],
                "min_fraction": min(row_t + row_r + row_a),
            }
        )

    max_residual = max(max(c["energy_balance_residual"]) for c in checks)
    min_fraction = min(c["min_fraction"] for c in checks)

    return {
        "wavelengths": wavelengths,
        "helicity_order": ["positive", "negative"],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "diagnostics": {
            "thickness": thickness,
            "epsilon": [epsilon.real, epsilon.imag],
            "mu": [mu.real, mu.imag],
            "kappa": [kappa.real, kappa.imag],
            "helicity_refractive_indices": refractive_indices,
            "checks": checks,
            "max_energy_balance_residual": max_residual,
            "min_power_fraction": min_fraction,
            "energy_conserving": bool(max_residual < 1e-10),
            "passive": bool(min_fraction > -1e-12),
        },
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
