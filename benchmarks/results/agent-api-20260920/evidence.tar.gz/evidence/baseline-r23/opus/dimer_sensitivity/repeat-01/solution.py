"""Sensitivity of the local field intensity of a sphere dimer to its separation.

Two identical spheres sit at ``x = -separation/2`` and ``x = +separation/2`` and are
illuminated by a positive-helicity plane wave travelling along ``+z``.  The observable
is ``value = sum(|E_total|**2)`` at a fixed point, with ``E_total`` the sum of the
incident plane wave and the multiply-scattered field of the dimer.  Its derivative with
respect to ``separation`` is obtained from the analytic (native) pullbacks of treams-rs
through the Advect adapter -- no finite differences are used.

All lengths are in micrometres; permittivity is relative and dimensionless.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import advect.numpy as anp
import numpy as np

from treams_rs import advect as tad
from treams_rs.diff import SphericalWaveBasis

# Positive-helicity label in the treams-rs helicity convention (0 = negative, 1 = positive).
_POSITIVE_HELICITY = 1


def _intensity(separation, *, lmax, k0, radius, epsilon, point):
    """Differentiable ``sum(|E_inc + E_sca|**2)`` as a function of the separation."""
    # Geometry: both spheres move symmetrically about the origin along x.
    positions = anp.asarray([[-0.5, 0.0, 0.0], [0.5, 0.0, 0.0]]) * separation

    # Vacuum embedding: identical wavenumbers for both helicities.
    ks = np.array([k0, k0])

    # Single-sphere helicity T-matrix (materials: sphere, then the vacuum exterior).
    tmat = tad.sphere(lmax, k0, np.array([radius]), np.array([epsilon, 1.0 + 0.0j]))

    local_basis = SphericalWaveBasis.default(lmax)
    cluster_basis = SphericalWaveBasis(
        SphericalWaveBasis.default(lmax, 2).modes, positions=np.zeros((2, 3))
    )

    # Interacting (multiple-scattering) response in the local bases of both spheres.
    coupled = tad.particle_cluster(
        [tmat, tmat], positions, ks, bases=[local_basis, local_basis]
    )

    # Plane-wave illumination expanded about each sphere centre; the incidence
    # direction is fixed, only the expansion origins move with the separation.
    vectors = np.array([[0.0, 0.0, k0]])
    polarizations = np.array([_POSITIVE_HELICITY])
    incident = tad.plane_expansion(
        positions,
        vectors,
        destination=cluster_basis,
        polarizations=polarizations,
        fixed_vectors=True,
    )

    coefficients = anp.matmul(coupled, incident[:, 0])

    points = np.asarray(point, dtype=float).reshape(1, 3)
    e_sca = tad.field(
        coefficients, points, positions, ks, basis=cluster_basis, singular=True
    )
    e_inc = tad.plane_field(
        np.array([1.0 + 0.0j]),
        points,
        vectors,
        polarizations=polarizations,
        fixed_vectors=True,
    )

    e_total = e_sca + e_inc
    return anp.sum(anp.real(e_total) ** 2 + anp.imag(e_total) ** 2)


def run(config):
    """Return the field intensity at the fixed point and its separation derivative."""
    radius = float(config["radius"])
    eps_re, eps_im = (float(v) for v in config["epsilon"])
    epsilon = complex(eps_re, eps_im)
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = [float(v) for v in config["point"]]

    k0 = 2.0 * np.pi / wavelength

    def objective(sep):
        return _intensity(
            sep, lmax=lmax, k0=k0, radius=radius, epsilon=epsilon, point=point
        )

    value, gradient = ad.value_and_grad(objective)(separation)

    return {
        "value": float(np.real(value)),
        "gradient": float(np.real(gradient)),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
