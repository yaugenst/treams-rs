# Dimer near-field intensity and its separation sensitivity

## Problem

Two identical spheres of radius `radius` and permittivity `epsilon = [Re, Im]`
sit at `x = -separation/2` and `x = +separation/2` (y = z = 0), embedded in
vacuum. A unit-amplitude plane wave of positive helicity propagates along `+z`.
At the fixed observation `point` we form

    value = sum(|E_total|^2)  with  E_total = E_incident + E_scattered,

and return `value` together with `gradient = d value / d separation`, where both
sphere centers move symmetrically with the separation.

## Units and conventions

* Lengths (`radius`, `separation`, `wavelength`, `point`) are in micrometers;
  the vacuum angular wavenumber is `k0 = 2*pi/wavelength` in 1/um.
* `epsilon` is relative and dimensionless, given as `[real, imag]` with the
  `exp(-i w t)` convention of treams (positive imaginary part = loss).
* `mu = 1`, `kappa = 0`, exterior is vacuum, as specified.
* The incident field has unit amplitude, so `sum(|E_inc|^2) = 1` and `value` is
  dimensionless (field intensity normalized to the incident plane wave).
* Multipoles use the helicity basis, default treams ordering
  `(particle, l = 1..lmax, m = -l..l, pol = (1, 0))` with helicity label 1 =
  positive. `lmax` is the multipole truncation per sphere; the cluster basis has
  `2*lmax*(lmax+2)` modes per particle and two expansion origins.

## Method

Everything numerical comes from `treams-rs`; nothing is reimplemented.

1. `treams_rs.advect.cluster(lmax, k0, radii, epsilon, positions)` builds the
   Mie T-matrices of both spheres and solves the coupled system
   `(I - T C) X = T`, i.e. the full interacting cluster T-matrix including all
   orders of multiple scattering.
2. `treams_rs.advect.plane_expansion` expands the plane wave into regular
   multipoles about both (moving) sphere origins; `fixed_vectors=True` keeps the
   wavevector static since only the origins depend on the separation.
3. The scattered multipole amplitudes are `T_cluster @ a_inc`, and
   `treams_rs.advect.field(..., singular=True)` evaluates the radiated field at
   the observation point from the two origins.
4. `treams_rs.advect.plane_field` supplies the incident field at the same point.
5. `advect.value_and_grad` propagates the single scalar input `separation`
   through `positions = [[-s/2,0,0],[s/2,0,0]]` and returns the derivative from
   the native analytic pullbacks of the operations above (geometry/origin
   adjoints of the cluster solve, the plane-wave expansion and the field
   evaluation). No finite differences are used to produce the reported gradient.

## Checks

`check.py` (in this directory) validates three independent configurations:

* The value is reproduced by the completely separate high-level path
  `TMatrix.sphere` -> `Cluster(...).solve()` -> `scatter(plane_wave).efield` plus
  `plane_wave.efield`; agreement to ~1e-16 relative.
* The analytic gradient agrees with a central finite difference of the value
  (`h = 1e-5 * max(1, separation)`) to ~3e-10 relative — finite differences are
  used only as a check, never as the returned derivative.

Example config result (`results.json`):

    {"value": 1.1855506354526988, "gradient": -0.40372542061712424}

## Usage

    python solution.py < config.json    # prints the result dict as JSON

or `from solution import run; run(config)`.
