# Dimer field-intensity sensitivity

## Problem

Two identical spheres sit at `x = -separation/2` and `x = +separation/2` (both centres
on the x axis, `y = z = 0`), embedded in vacuum and illuminated by a positive-helicity
plane wave propagating along `+z` with unit amplitude. At a fixed observation point the
observable is

```
value = sum(|E_total|^2),   E_total = E_incident + E_scattered
```

summed over the three Cartesian components. The returned `gradient` is
`d(value)/d(separation)`, with both sphere centres moving as the separation changes;
the observation point, wavelength, radii, material and `lmax` are held fixed.

## Units and conventions

- Lengths (`radius`, `separation`, `wavelength`, `point`) in micrometres; `k0 = 2*pi/wavelength`
  in rad/um, so `value` and `gradient` carry units of (incident amplitude)^2 and
  (incident amplitude)^2 per micrometre.
- `epsilon = [real, imag]` is the relative, dimensionless sphere permittivity
  (here `4.0 + 0.04j`); `mu = 1`, `kappa = 0`, exterior vacuum (`eps = mu = 1`).
- Helicity basis throughout; the treams-rs label `1` is positive helicity (`0` is
  negative). The incident amplitude is 1, i.e. `|E_incident|^2 = 1` everywhere.
- Multipole cutoff `lmax` per sphere, full `m` range, both polarisations
  (`2*lmax*(lmax+2)` modes per sphere).

## Method (treams-rs)

1. `treams_rs.advect.sphere` builds the single-sphere helicity T-matrix (Mie).
2. `treams_rs.advect.particle_cluster` builds the **interacting** block T-matrix of the
   two-sphere cluster, i.e. it solves `(I - T C) X = T` with the translation coupling
   `C` between the sphere origins. Multiple scattering is therefore included to all
   orders, not in a single-scattering approximation.
3. `treams_rs.advect.plane_expansion` expands the plane wave about each (moving) sphere
   centre; `fixed_vectors=True` keeps the incidence direction constant while retaining
   the analytic origin dependence.
4. The scattered field at the point comes from `treams_rs.advect.field` with
   `singular=True` (outgoing spherical waves), the incident field from
   `treams_rs.advect.plane_field`.

## Derivative

The whole chain above is executed on Advect traced values, so the reported `gradient`
is produced by the native treams-rs analytic pullbacks (Mie, cluster geometry,
plane-wave expansion origins, field evaluation) composed by reverse-mode AD via
`advect.value_and_grad`. The separation enters only through the two positions
`[[-1/2,0,0],[1/2,0,0]] * separation`, which feed the cluster coupling, the illumination
origins and the field-evaluation origins; all three contributions are differentiated.
No finite differences are used to produce the answer.

## Checks

- The forward value reproduces the independent high-level treams-rs path
  (`sphere_tmatrix` -> `Cluster(...).solve().scatter(plane_wave)` plus `efield`) to
  machine precision: 1.1855506354526986 vs 1.1855506354526988.
- The analytic gradient matches a central finite difference (`h = 1e-6 um`) to ~1e-10
  relative error, both for the example config and for other radii, permittivities
  (including lossless and strongly lossy), wavelengths, `lmax` and points.

## Example result

Config: `radius=0.08`, `epsilon=[4.0, 0.04]`, `separation=0.3`, `wavelength=0.72`,
`lmax=2`, `point=[0.05, 0.02, 0.28]`.

```json
{"value": 1.1855506354526988, "gradient": -0.40372542061712424}
```

(Finite-difference cross-check of the gradient: -0.4037254207.)

## Usage

```
echo '{"radius":0.08,"epsilon":[4.0,0.04],"separation":0.3,"wavelength":0.72,"lmax":2,"point":[0.05,0.02,0.28]}' | python solution.py
```
