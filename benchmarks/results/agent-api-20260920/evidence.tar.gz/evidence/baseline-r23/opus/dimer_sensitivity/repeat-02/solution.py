"""Sensitivity of the near-field intensity of a sphere dimer to its separation.

Two identical spheres sit at x = -separation/2 and x = +separation/2 and are
illuminated by a positive-helicity plane wave travelling along +z.  The full
multiple-scattering response is obtained from treams-rs; the derivative with
respect to the separation comes from the native analytic pullbacks exposed
through the Advect adapter (``treams_rs.advect``).
"""

from __future__ import annotations

import json
import sys

import advect
import advect.numpy as anp
import numpy as np

import treams_rs as treams
import treams_rs.advect as tadv


def _parse(config):
    radius = float(config["radius"])
    eps_re, eps_im = (float(v) for v in config["epsilon"])
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=float).reshape(3)
    return radius, complex(eps_re, eps_im), separation, wavelength, lmax, point


def run(config):
    radius, epsilon, separation, wavelength, lmax, point = _parse(config)

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um
    basis = treams.SphericalBasis.default(lmax, 2)  # two expansion origins
    points = point.reshape(1, 3)
    # Plane wave: +z propagation in vacuum, unit amplitude, positive helicity.
    vectors = np.array([[0.0, 0.0, k0]])
    polarizations = np.array([1])
    amplitude = np.array([1.0 + 0.0j])
    radii = np.array([radius, radius])
    epsilons = np.array([epsilon, epsilon])

    def objective(sep):
        half = sep / 2.0
        zero = anp.zeros(()) * half  # traced zero, keeps positions differentiable
        positions = anp.stack(
            [anp.stack([-half, zero, zero]), anp.stack([half, zero, zero])]
        )
        # Interacting (multiple-scattering) T-matrix of the two-sphere cluster.
        tmat = tadv.cluster(lmax, k0, radii, epsilons, positions)
        incident = tadv.plane_expansion(
            positions,
            vectors,
            destination=basis,
            polarizations=polarizations,
            fixed_vectors=True,
        )
        scattered = (tmat @ incident)[:, 0]
        ks = anp.asarray([k0, k0])  # vacuum wavenumbers for both helicities
        e_sca = tadv.field(
            scattered, points, positions, ks, basis=basis, singular=True
        )
        e_inc = tadv.plane_field(
            amplitude, points, vectors,
            polarizations=polarizations, fixed_vectors=True,
        )
        total = e_sca + e_inc
        return anp.sum(anp.real(total) ** 2 + anp.imag(total) ** 2)

    value, gradient = advect.value_and_grad(objective)(separation)

    return {
        "value": float(value),
        "gradient": float(gradient),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
