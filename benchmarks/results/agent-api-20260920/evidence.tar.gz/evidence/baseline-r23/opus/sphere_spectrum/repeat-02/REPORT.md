# Homogeneous dielectric sphere spectrum

`solution.py` exposes `run(config)` and a CLI (`python solution.py < config.json`)
that reads one config dict from stdin and prints the result dict as JSON.

## Problem and method

A single homogeneous sphere of radius `radius` sits in vacuum and is illuminated
by a plane wave travelling along **+z** with **positive helicity**. For each
entry of `wavelengths` the Mie T-matrix is built with
`treams_rs.TMatrix.sphere(lmax, k0, radius, [sphere, medium], poltype="helicity")`
and the illumination with
`treams_rs.plane_wave(direction=[0,0,1], polarization="positive_helicity", k0=k0)`.
Cross sections come from `TMatrix.cross_sections(illumination)`, i.e. from
treams-rs itself; no Mie series is reimplemented here.

## Units and conventions

* All lengths are micrometers (um). The vacuum angular wavenumber is
  `k0 = 2*pi/wavelength` in 1/um, which is the unit convention treams-rs expects
  (radius and 1/k0 share the length unit).
* `epsilon = [real, imag]` is the **relative permittivity**, not a refractive
  index; it is passed straight to `treams_rs.Material`. A positive imaginary
  part is lossy in treams' exp(-i*omega*t) convention (it yields positive
  absorption, confirmed below). `mu=1` and `kappa=0` unless given; the exterior
  is vacuum unless a `medium` key is given.
* `scattering`, `extinction`, `absorption` are cross sections in **um^2**;
  `absorption = extinction - scattering`.
* `efficiency` is the scattering efficiency `Q_sca = C_sca / (pi * radius^2)`,
  dimensionless.
* All four lists follow the input wavelength order; the input `wavelengths` are
  echoed in the output for convenience.
* `lmax` is the multipole cutoff used verbatim (T-matrix dimension `2*lmax*(lmax+2)`).

## Checks performed

* `absorption == extinction - scattering` and `efficiency == scattering/(pi r^2)`
  to machine precision (0.0 deviation).
* Absorption is positive for the lossy example and drops to `<= 3.4e-16 um^2`
  (2e-15 relative to extinction) when `epsilon = [12, 0]`, i.e. the optical
  theorem is satisfied for the lossless sphere.
* Convergence: `lmax = 8` changes the example scattering cross sections by
  `<= 1.8e-10` relative, so `lmax = 4` is converged for `x = 2*pi*r/lambda <= 1.4`.
* Symmetry: for a sphere the cross sections must not depend on the incident
  polarization. Negative-helicity illumination and a parity-basis T-matrix with
  linear x polarization reproduce the reported values to `< 1e-16 um^2`.
* The spectrum sampled on a fine grid from 0.4 to 0.8 um is smooth and shows the
  expected dipole/quadrupole Mie resonances of a high-index sphere
  (`n = sqrt(12) ~ 3.46`), with the strongest feature near 0.72 um.

## Example result (`results.json`)

radius = 0.1 um, epsilon = 12 + 0.05i, lmax = 4:

| lambda (um) | C_sca (um^2) | C_ext (um^2) | C_abs (um^2) | Q_sca |
|---|---|---|---|---|
| 0.45 | 0.0271458 | 0.0291622 | 0.0020164 | 0.86408 |
| 0.55 | 0.1624755 | 0.1651157 | 0.0026402 | 5.17175 |
| 0.65 | 0.1398054 | 0.1418899 | 0.0020845 | 4.45014 |
| 0.75 | 0.1793369 | 0.1866767 | 0.0073398 | 5.70847 |
