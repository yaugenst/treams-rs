"""Spectrum of cross sections for a homogeneous dielectric sphere (treams-rs)."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _complex(value: Any) -> complex:
    """Accept a scalar or a ``[real, imag]`` pair as a complex number."""
    if isinstance(value, (list, tuple)):
        re, im = (list(value) + [0.0])[:2]
        return complex(float(re), float(im))
    if isinstance(value, dict):
        return complex(float(value.get("real", 0.0)), float(value.get("imag", 0.0)))
    return complex(value)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]

    sphere = tr.Material(
        _complex(config.get("epsilon", 1)),
        _complex(config.get("mu", 1)),
        _complex(config.get("kappa", config.get("chirality", 0))),
    )
    medium = tr.Material(
        _complex(config.get("epsilon_medium", 1)),
        _complex(config.get("mu_medium", 1)),
        _complex(config.get("kappa_medium", 0)),
    )

    area = math.pi * radius**2
    out: dict[str, list[float]] = {
        "scattering": [],
        "extinction": [],
        "absorption": [],
        "efficiency": [],
    }
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        tmat = tr.TMatrix.sphere(lmax, k0, radius, [sphere, medium], poltype="helicity")
        illumination = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
            poltype="helicity",
        )
        xs = tmat.cross_sections(illumination)
        out["scattering"].append(float(xs.scattering))
        out["extinction"].append(float(xs.extinction))
        out["absorption"].append(float(xs.absorption))
        out["efficiency"].append(float(xs.scattering) / area)
    return out


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
