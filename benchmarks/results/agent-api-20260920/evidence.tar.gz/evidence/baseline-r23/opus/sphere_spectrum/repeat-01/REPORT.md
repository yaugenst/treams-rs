# Homogeneous dielectric sphere spectrum

## What is computed
For each wavelength in `wavelengths`, `solution.run(config)` builds the Mie
T-matrix of a homogeneous sphere with `treams_rs.TMatrix.sphere` and illuminates
it with a unit-amplitude plane wave travelling along **+z** with **positive
helicity** (`treams_rs.plane_wave(direction=[0,0,1],
polarization="positive_helicity")`). Cross sections come from
`TMatrix.cross_sections`, which returns scattering and extinction, and
absorption = extinction - scattering.

## Units and conventions
- Lengths (`radius`, `wavelengths`) are in micrometers; cross sections are
  therefore areas in **um^2**. `efficiency = scattering / (pi * radius**2)` is
  dimensionless (Q_sca).
- `k0 = 2*pi/wavelength` is the vacuum angular wavenumber, in 1/um, i.e. the
  inverse of the length unit used for the radius, as treams-rs requires.
- `epsilon = [real, imag]` is the **relative permittivity**, not a refractive
  index; it is passed straight to `treams_rs.Material`. A positive imaginary
  part is lossy in the exp(-i*omega*t) convention used here (verified: the
  returned absorption is positive).
- Defaults: sphere `mu = 1`, chirality `kappa = 0`, exterior = vacuum
  (epsilon = mu = 1). Optional config keys `mu`, `kappa`/`chirality`,
  `epsilon_medium`, `mu_medium` are honoured if present.
- Polarization type is `helicity`; `lmax` is the multipole cutoff, so the
  T-matrix has 2*lmax*(lmax+2) modes.
- Output lists follow the input wavelength order (no sorting is applied).

## Checks performed
1. **Independent Mie reference** (`mie_check.py`, textbook a_n/b_n coefficients
   summed to the same lmax, using only spherical Bessel functions): the
   scattering and extinction cross sections agree with the treams-rs results to
   ~1e-15 relative for all four example wavelengths. This is a validation only;
   all reported numbers come from treams-rs.
2. **Multipole convergence**: lmax = 4 vs lmax = 8 differ by < 2e-10 relative
   for the example, so the requested cutoff is converged here.
3. **Helicity symmetry**: the achiral sphere gives identical cross sections for
   positive and negative helicity (agreement to machine precision), as expected.
4. **Lossless limit**: with `epsilon = [12, 0]` the absorption is ~ -2e-16,
   i.e. zero to machine precision, confirming the optical theorem balance.

## Files
- `solution.py` - `run(config)` plus a CLI reading one JSON config from stdin
  and printing the result dictionary as JSON to stdout.
- `results.json` - output for the example config.
- `mie_check.py` - independent validation script (not used by `solution.py`).

## Example result (radius 0.1 um, epsilon 12+0.05i, lmax 4)

| lambda (um) | sigma_sca (um^2) | sigma_ext (um^2) | sigma_abs (um^2) | Q_sca |
|---|---|---|---|---|
| 0.45 | 0.0271458 | 0.0291622 | 0.0020164 | 0.8641 |
| 0.55 | 0.1624755 | 0.1651157 | 0.0026402 | 5.1718 |
| 0.65 | 0.1398054 | 0.1418899 | 0.0020845 | 4.4501 |
| 0.75 | 0.1793369 | 0.1866767 | 0.0073398 | 5.7085 |
