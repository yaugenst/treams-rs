"""Spectrum of a homogeneous dielectric sphere computed with treams-rs.

A plane wave of positive helicity travels along +z through vacuum and hits a
single sphere of the given radius and relative permittivity.  For every
wavelength the scattering, extinction and absorption cross sections (areas) and
the scattering efficiency Q_sca = C_sca / (pi * radius**2) are reported.

Lengths are micrometers, so cross sections come out in um**2 and the
efficiency is dimensionless.
"""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as treams


def _complex(value: Any) -> complex:
    """Accept a scalar, a [real, imag] pair or a complex-looking string."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"expected a scalar or [real, imag] pair, got {value!r}")
    if isinstance(value, dict):
        return complex(float(value.get("real", 0.0)), float(value.get("imag", 0.0)))
    return complex(value)


def run(config: dict) -> dict:
    """Return the cross section spectrum of a homogeneous sphere."""
    radius = float(config["radius"])
    if radius <= 0.0:
        raise ValueError("radius must be positive")

    # epsilon is the relative permittivity (not a refractive index).
    epsilon = _complex(config["epsilon"])
    mu = _complex(config.get("mu", 1.0))
    kappa = _complex(config.get("kappa", 0.0))
    sphere = treams.Material(epsilon, mu, kappa)

    # Unless specified the sphere sits in vacuum.
    medium = treams.Material(*(
        _complex(v) for v in _as_material_args(config.get("medium", 1.0))
    ))

    wavelengths = [float(w) for w in config["wavelengths"]]
    if not wavelengths:
        raise ValueError("wavelengths must not be empty")
    lmax = int(config["lmax"])

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    efficiency: list[float] = []
    geometric = math.pi * radius * radius

    for wavelength in wavelengths:
        if wavelength <= 0.0:
            raise ValueError("wavelengths must be positive")
        # Vacuum angular wavenumber in inverse micrometers.
        k0 = 2.0 * math.pi / wavelength
        tmatrix = treams.TMatrix.sphere(
            lmax, k0, radius, [sphere, medium], poltype="helicity"
        )
        illumination = treams.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
            poltype="helicity",
        )
        xs = tmatrix.cross_sections(illumination)
        scattering.append(float(xs.scattering))
        extinction.append(float(xs.extinction))
        absorption.append(float(xs.absorption))
        efficiency.append(float(xs.scattering) / geometric)

    return {
        "wavelengths": wavelengths,
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


def _as_material_args(value: Any) -> tuple:
    """Normalize a medium specification to (epsilon, mu, kappa)."""
    if isinstance(value, dict):
        return (
            value.get("epsilon", 1.0),
            value.get("mu", 1.0),
            value.get("kappa", 0.0),
        )
    if isinstance(value, (list, tuple)):
        # Two entries are read as [real, imag] of epsilon, like the sphere;
        # three entries are (epsilon, mu, kappa).
        if len(value) == 3:
            return tuple(value)
        return (value, 1.0, 0.0)
    return (value, 1.0, 0.0)


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
