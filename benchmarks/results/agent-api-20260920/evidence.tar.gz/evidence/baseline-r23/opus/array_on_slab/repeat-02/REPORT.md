# Sphere array above a dielectric slab — zeroth-order power balance

## What is computed

For each wavelength, the transmission, reflection and absorption power fractions of
the stack

```
vacuum  |  slab (slab_thickness, slab_epsilon)  |  vacuum gap  |  square sphere array  |  vacuum
```

illuminated from the negative-z vacuum half space by a normally incident plane wave of
**positive helicity** travelling along +z. Results are returned sorted by increasing
wavelength (the input order is not assumed).

## Units and conventions

- Lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) are in micrometers;
  the vacuum angular wavenumber is `k0 = 2*pi/wavelength` in 1/um.
- `sphere_epsilon`, `slab_epsilon` are real relative permittivities; `mu = 1`, `kappa = 0`,
  exterior media are vacuum.
- Polarization basis is **helicity**; the source is built with
  `plane_wave([0,0,1], "positive_helicity", ...)`, so the helicity convention is treams'.
- Lattice: square, `Lattice([period, period], "xy")`, Bloch vector `[0, 0]`.
- Only the zeroth diffraction order is retained, with both helicity channels:
  `PlaneWavePorts.diffr_orders([0,0], lattice, 0.0)` keeps exactly the reciprocal vector
  `G = 0`, i.e. 2 ports per side. Because every wavelength exceeds the period, `G = 0` is
  the only propagating order, so this truncation is physically complete for the far field.
- Reference planes: the slab S-matrix ports lie on its two surfaces; the array S-matrix
  ports lie in the sphere-center plane (the T-matrix origin). The intervening
  `propagation(distance=gap)` is therefore exactly the vacuum distance from the slab top
  surface to the sphere-center plane, as specified.
- `transmission + reflection + absorption = 1` by construction of treams' `PowerBalance`
  (absorption is the flux defect); `energy_balance_residual` reports the floating-point
  residual of that identity.

## Method (treams-rs)

1. `sphere_tmatrix(k0, lmax, radius, material=sphere_epsilon, medium=1)` — isolated Mie
   T-matrix at the requested `lmax` (no truncation beyond the user's `lmax`).
2. `solve_periodic(tmatrix, lattice=..., kpar=[0,0])` — the **full** Bloch-periodic lattice
   interaction (Ewald-summed), not a single-scatterer approximation.
3. `PeriodicResponse.to_smatrix(ports)` — conversion of the solved array to up/down
   plane-wave ports.
4. `slab(...)`, `propagation(...)`, `stack([...])` — layers cascaded from the negative to
   the positive side of the normal, in the order slab → gap → array.
5. `SMatrices.power(plane_wave, side="negative")` — `PowerBalance(transmission, reflection)`
   with `absorption` as the remainder.

No scattering physics is reimplemented; all numerics come from treams-rs.

## Checks performed

- **Energy conservation.** All materials are lossless, and the computed absorption is
  `|A| < 1e-15` at every wavelength (example config: -8.5e-16, 2.4e-16, -5.3e-16), i.e.
  `T + R = 1` to machine precision. Residuals of the balance identity are <= 1.1e-16.
- **Bare slab against the analytic Airy formula.** With the array removed, the slab-only
  transmission at 0.74 um is 0.8740068503137328 versus the closed-form Fabry–Perot value
  0.874006850313733 (n = 1.5, d = 0.09 um) — agreement to ~1e-15.
- **Reciprocity / side symmetry.** Illuminating from the positive-z side with positive
  helicity gives the same transmission to 15 digits (0.902068726988559 vs
  0.9020687269885588 at 0.74 um), as expected for a lossless reciprocal stack.
- **Multipole convergence.** At 0.74 um the transmission is 0.902696 (lmax 1), 0.902069
  (lmax 2), 0.902075 (lmax 3), 0.902075 (lmax 4). The reported values use the `lmax` given
  in the config, as required; lmax 2 is already converged to ~6e-6.
- **Order truncation.** `wavelength > period` for all example wavelengths, so no higher
  order propagates and the single retained order carries all far-field power — consistent
  with the vanishing absorption above.

## Example results (`results.json`)

| lambda (um) | T | R | A |
|---|---|---|---|
| 0.65 | 0.8873286362852495 | 0.11267136371475135 | -8.5e-16 |
| 0.74 | 0.9020687269885590 | 0.09793127301144076 |  2.4e-16 |
| 0.83 | 0.9119142686008943 | 0.08808573139910622 | -5.3e-16 |

## Usage

```
python solution.py < config.json > results.json
```

`run(config)` returns the same dictionary directly.
