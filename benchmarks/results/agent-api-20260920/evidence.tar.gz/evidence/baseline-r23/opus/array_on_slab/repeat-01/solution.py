"""Square sphere array above a dielectric slab: zeroth-order power fractions.

Network along +z: vacuum | slab | vacuum gap | sphere-array plane | vacuum.
Illumination comes from the negative-z side, travelling along +z, with
positive helicity.  All lengths are micrometers, permittivities are relative.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as tr


def _smatrices(cfg, wavelength):
    """Build the total S-matrix of the whole stack at one wavelength."""
    k0 = 2.0 * np.pi / float(wavelength)

    # Square lattice in the xy plane; zeroth diffraction order only (bmax = 0),
    # both helicity channels, at Bloch vector [0, 0].
    lattice = tr.Lattice(float(cfg["period"]) * np.eye(2), "xy")
    basis = tr.PlaneWavePorts.diffr_orders([0.0, 0.0], lattice, 0.0)

    # Isolated sphere T-matrix, then the full periodic interaction (Ewald sum)
    # at the fixed lmax -- this is the solved Bloch-periodic array response.
    tmat = tr.sphere_tmatrix(
        k0=k0,
        lmax=int(cfg["lmax"]),
        radius=float(cfg["radius"]),
        material=float(cfg["sphere_epsilon"]),
        medium=1,
    )
    array = tr.solve_periodic(tmat, lattice=lattice, kpar=[0.0, 0.0]).to_smatrix(basis)

    slab = tr.slab(
        basis=basis,
        k0=k0,
        thickness=float(cfg["slab_thickness"]),
        material=float(cfg["slab_epsilon"]),
        negative_medium=1,
        positive_medium=1,
    )
    gap = tr.propagation(
        distance=float(cfg["gap"]), basis=basis, k0=k0, medium=1
    )

    # Ordered from the negative-z side to the positive-z side.
    return tr.stack([slab, gap, array]), k0


def run(config):
    wavelengths = [float(w) for w in config["wavelengths"]]
    transmission, reflection, absorption = [], [], []

    for wavelength in wavelengths:
        total, k0 = _smatrices(config, wavelength)
        incident = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        balance = total.power(incident)
        transmission.append(float(balance.transmission))
        reflection.append(float(balance.reflection))
        absorption.append(float(balance.absorption))

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "energy_balance": [
            t + r + a for t, r, a in zip(transmission, reflection, absorption)
        ],
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
