"""Periodic sphere array above a dielectric slab: zeroth-order power balance.

Network along +z (illumination from -z, propagating toward +z):

    vacuum | slab (slab_thickness, slab_epsilon) | vacuum gap | sphere array | vacuum

The gap is the vacuum distance from the top slab surface to the sphere-center
plane, which is the reference plane of the array scattering matrix.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as treams


def _power_balance(
    *,
    wavelength: float,
    radius: float,
    sphere_epsilon: float,
    period: float,
    gap: float,
    slab_thickness: float,
    slab_epsilon: float,
    lmax: int,
) -> tuple[float, float, float]:
    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um

    lattice = treams.Lattice([period, period], "xy")
    # Zeroth diffraction order only (both helicities), Bloch vector [0, 0]:
    # a zero cutoff keeps exactly the reciprocal vector G = 0.
    ports = treams.PlaneWavePorts.diffr_orders([0.0, 0.0], lattice, 0.0)

    # Isolated sphere response, then the full Bloch-periodic lattice solve.
    sphere = treams.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon, medium=1
    )
    array = treams.solve_periodic(sphere, lattice=lattice, kpar=[0.0, 0.0])

    stack = treams.stack(
        [
            treams.slab(
                basis=ports, k0=k0, thickness=slab_thickness, material=slab_epsilon
            ),
            treams.propagation(distance=gap, basis=ports, k0=k0, medium=1),
            array.to_smatrix(ports),
        ]
    )

    illumination = treams.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=k0, material=1
    )
    balance = stack.power(illumination, side="negative")
    return balance.transmission, balance.reflection, balance.absorption


def run(config: dict) -> dict:
    radius = float(config["radius"])
    sphere_epsilon = float(config["sphere_epsilon"])
    period = float(config["period"])
    gap = float(config["gap"])
    slab_thickness = float(config["slab_thickness"])
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]

    order = np.argsort(wavelengths)
    results = [None] * len(wavelengths)
    for index in order:
        results[index] = _power_balance(
            wavelength=wavelengths[index],
            radius=radius,
            sphere_epsilon=sphere_epsilon,
            period=period,
            gap=gap,
            slab_thickness=slab_thickness,
            slab_epsilon=slab_epsilon,
            lmax=lmax,
        )

    sorted_pairs = sorted(zip(wavelengths, results), key=lambda pair: pair[0])
    transmission = [pair[1][0] for pair in sorted_pairs]
    reflection = [pair[1][1] for pair in sorted_pairs]
    absorption = [pair[1][2] for pair in sorted_pairs]

    return {
        "wavelengths": [pair[0] for pair in sorted_pairs],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "energy_balance_residual": [
            abs(t + r + a - 1.0)
            for t, r, a in zip(transmission, reflection, absorption)
        ],
        "settings": {
            "lmax": lmax,
            "diffraction_orders": [[0, 0]],
            "polarizations_per_order": 2,
            "bloch_vector": [0.0, 0.0],
            "polarization_basis": "helicity",
            "incident_helicity": "positive",
            "incidence": "+z from the negative-z vacuum half space",
            "stack_order_along_z": ["slab", "vacuum gap", "sphere array"],
        },
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
