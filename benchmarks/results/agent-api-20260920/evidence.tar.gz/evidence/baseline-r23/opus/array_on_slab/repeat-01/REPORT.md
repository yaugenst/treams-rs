# Sphere array above a dielectric slab — zeroth-order power fractions

## Problem and geometry

A square array (period `period`) of identical spheres (`radius`,
`sphere_epsilon`) sits above a homogeneous dielectric slab
(`slab_thickness`, `slab_epsilon`). Ordered along **+z** the network is

```
vacuum | slab | vacuum gap | sphere-array plane | vacuum
```

The `gap` is the vacuum distance from the slab top face to the plane of the
sphere *centers*, which is exactly the reference plane of the array
S-matrix, so it enters as a single homogeneous propagation of length `gap`.

Illumination is a plane wave incident from the **negative-z** side
travelling along **+z** with **positive helicity**.

## Units and conventions

* All lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`)
  are in micrometers and are mutually consistent; `k0 = 2*pi/wavelength`
  has units of 1/µm.
* `sphere_epsilon` and `slab_epsilon` are real relative permittivities;
  `mu = 1` and chirality `0` everywhere, and all exterior media are vacuum.
* The plane-wave port basis uses the **helicity** polarization convention
  (treams-rs default for these constructors), with both helicity channels
  of the zeroth order retained.
* Power fractions are normalized to the incident flux:
  `transmission` is the power leaving on the +z side, `reflection` the
  power leaving on the -z side, `absorption` the remainder.

## Method (treams-rs)

1. `tr.sphere_tmatrix(k0, lmax, radius, material=sphere_epsilon, medium=1)` —
   isolated-sphere Mie T-matrix at the requested, fixed `lmax`.
2. `tr.solve_periodic(tmat, lattice=square, kpar=[0,0])` — the **full**
   Bloch-periodic interaction of the array is solved once per wavelength
   (lattice sums), giving a `PeriodicResponse`, not a single-particle result.
3. `.to_smatrix(basis)` with
   `basis = PlaneWavePorts.diffr_orders([0,0], lattice, bmax=0)` projects
   that response onto the propagating diffraction ports. `bmax = 0` keeps
   only the zeroth reciprocal-lattice vector in both polarizations, which
   is the complete propagating set because all `wavelengths > period`
   (the smallest reciprocal vector `2*pi/period` exceeds `k0`).
4. `tr.slab(...)` for the dielectric layer and `tr.propagation(distance=gap,...)`
   for the vacuum gap, both in the same port basis.
5. `tr.stack([slab, gap, array])` cascades them in negative-to-positive-z
   order, including all multiple reflections between slab and array.
6. `total.power(plane_wave(direction=[0,0,1], polarization="positive_helicity"))`
   returns the `PowerBalance` fractions; the incident side is inferred from
   the wave's propagation direction.

No derivatives or optimization are requested here, so none are computed;
all scattering is done by treams-rs, with no reimplemented physics.

## Checks performed

* **Energy conservation.** Both media are lossless (real permittivities), and
  `T + R + A = 1` to machine precision with `A` at the 1e-16 level
  (reported as-is, including tiny negative round-off).
* **Bare-slab limit.** Removing the array and evaluating only the slab
  reproduces the analytic Fabry–Pérot Fresnel reflectance
  `|r(1-e^{2ink0d})/(1-r^2 e^{2ink0d})|^2`, `r=(1-n)/(1+n)`, to ~1e-15
  (e.g. 0.139140179901048 vs 0.139140179901047 at 0.65 µm).
* **Reciprocity.** Illuminating from the +z side gives the same total
  transmission to ~1e-15.
* **Multipole truncation.** At the requested `lmax = 2` the transmission
  differs from the `lmax = 5` value by ~1e-5; results are reported at the
  fixed `lmax` from the config, as specified.
* **Single propagating order.** `2*pi/period = 15.71 µm^-1` exceeds
  `k0 <= 9.67 µm^-1` for the example wavelengths, so no higher order is
  propagating and the zeroth-order truncation is exact for the far field.

## Interface

* `run(config) -> dict` with keys `wavelengths`, `transmission`,
  `reflection`, `absorption` (lists ordered as the input wavelengths) and
  `energy_balance` (their sum, a convenience check).
* CLI: `python solution.py < config.json` reads one config dictionary from
  stdin and prints the result dictionary as JSON to stdout.

## Example result (`results.json`)

| λ (µm) | T | R | A |
|---|---|---|---|
| 0.65 | 0.8873286362852495 | 0.11267136371475135 | -8.5e-16 |
| 0.74 | 0.9020687269885590 | 0.09793127301144076 | 2.4e-16 |
| 0.83 | 0.9119142686008943 | 0.08808573139910622 | -5.3e-16 |
