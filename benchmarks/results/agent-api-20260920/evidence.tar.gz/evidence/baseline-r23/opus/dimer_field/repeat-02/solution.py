"""Two-sphere (dimer) multiple scattering with treams-rs.

Computes the total electric field at requested points and the scattering,
extinction and absorption cross sections for a helicity-polarized plane wave
travelling along +z.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as treams


def _material(entry):
    """Relative permittivity from a [real, imag] pair (or a plain number)."""
    if np.isscalar(entry):
        return complex(entry)
    real, imag = entry
    return complex(float(real), float(imag))


def run(config):
    radii = [float(r) for r in config["radii"]]
    epsilon = [_material(e) for e in config["epsilon"]]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.atleast_2d(np.asarray(config["points"], dtype=float))

    if len(radii) != 2 or len(epsilon) != 2:
        raise ValueError("exactly two spheres are required")
    if points.shape[-1] != 3:
        raise ValueError("points must be Cartesian triples")

    # Vacuum angular wavenumber; lengths in micrometers, so k0 is 1/um.
    k0 = 2 * np.pi / wavelength
    positions = np.array([[-separation / 2, 0.0, 0.0], [separation / 2, 0.0, 0.0]])

    # Individual Mie responses in vacuum, helicity channels.
    particles = [
        treams.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=eps, medium=1, polarization="helicity"
        )
        for radius, eps in zip(radii, epsilon, strict=True)
    ]

    # Coupled two-body response: solve() includes all orders of multiple
    # scattering between the spheres at the fixed lmax.
    cluster = treams.Cluster(particles, positions=positions).solve()

    # Incident plane wave along +z with positive helicity, package normalization.
    incident = treams.plane_wave(
        [0, 0, 1], "positive_helicity", k0=k0, material=1, poltype="helicity"
    )

    scattered = cluster.scatter(incident)
    total = np.asarray(incident.efield(points)) + np.asarray(scattered.efield(points))

    xs = cluster.cross_sections(incident)

    inside = ~np.asarray(cluster.valid_points(points, radii))

    return {
        "total_field_real": total.real.tolist(),
        "total_field_imag": total.imag.tolist(),
        "scattering_cross_section": float(xs.scattering),
        "extinction_cross_section": float(xs.extinction),
        "absorption_cross_section": float(xs.absorption),
        "k0": float(k0),
        "lmax": lmax,
        "positions": positions.tolist(),
        "points_inside_spheres": inside.tolist(),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
