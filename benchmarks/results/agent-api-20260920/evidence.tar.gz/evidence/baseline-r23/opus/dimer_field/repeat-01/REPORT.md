# Two-sphere (dimer) scattering with treams-rs

## What is computed

`solution.py` builds the Mie T-matrices of two homogeneous spheres, couples them
in a `treams_rs.Cluster`, solves the coupled response (all orders of multiple
scattering at the given `lmax`), and evaluates

* the **total** electric field `E_inc + E_sca` at the requested points,
* the scattering, extinction and absorption cross sections of the dimer.

## Geometry, units and conventions

* Lengths in micrometres (µm); permittivities/permeabilities/chirality are
  relative and dimensionless. Vacuum exterior, `mu = 1`, `kappa = 0`.
* Sphere 1 (`radii[0]`, `epsilon[0]`) at `x = -separation/2`; sphere 2
  (`radii[1]`, `epsilon[1]`) at `x = +separation/2`; both at `y = z = 0`.
* `epsilon` entries are `[real, imag]` with the `exp(-i w t)` convention used by
  treams (positive imaginary part = loss); the example gives
  `Im(eps) > 0` and indeed `sigma_abs > 0`.
* Vacuum angular wavenumber `k0 = 2*pi/wavelength` (1/µm); for the example
  `k0 = 8.72664626 1/µm`.
* Illumination: plane wave along **+z**, **positive helicity**, built with
  `treams_rs.plane_wave(direction=[0,0,1], polarization="positive_helicity")`.
  This is the package's own incident normalization: `|E_inc| = 1` (checked,
  `E_inc(0) = (-0.70711, -0.70711 i, 0)`), so fields are dimensionless field
  amplitudes and cross sections are in µm².
* Helicity polarization basis throughout (`polarization="helicity"`).

## Implementation

1. `sphere_tmatrix(k0, lmax, radius, material, medium=1)` — one Mie T-matrix per
   sphere (dimension `2*lmax*(lmax+2)`, here 30 each).
2. `Cluster(tmats, positions=...).solve()` — the coupled 60x60 dimer T-matrix
   retaining both local origins; multiple scattering is exact at this `lmax`.
3. `solved.scatter(illu)` — outgoing multipole wave; `.efield(points)` gives the
   scattered Cartesian field, `illu.efield(points)` the incident one; the sum is
   returned as `total_field_real` / `total_field_imag`, shape (n_points, 3).
4. `solved.cross_sections(illu)` — `scattering`, `extinction` and the derived
   `absorption = extinction - scattering`, all in µm² (default flux 0.5,
   consistent with the unit-amplitude incident wave).

No finite differences and no re-implementation of scattering physics are used;
all numerics come from treams-rs public API.

## Output keys

`total_field_real`, `total_field_imag` (n_points x 3 lists), plus scalars
`scattering_cross_section`, `extinction_cross_section`,
`absorption_cross_section`. Echoed for traceability: `wavelength`, `k0`,
`lmax`, `positions`, and `points_inside_particles` — indices of requested points
that lie inside a sphere, where the outgoing multipole expansion about that
origin does not converge (empty for the example).

## Example result (`results.json`)

```
sigma_sca = 0.05648477 µm²
sigma_ext = 0.05910237 µm²
sigma_abs = 0.00261760 µm²
E_tot(0, 0, 0.3)      = ( 0.80919 - 0.26914i,  0.23513 + 0.82034i,  0.03110 + 0.07267i)
E_tot(0.35, 0.2, 0.1) = (-0.22645 - 0.60503i,  0.52804 - 0.43737i, -0.02124 - 0.12125i)
```

## Checks performed

* **Multipole convergence**: `lmax = 2,3,4,5,6` give
  `sigma_sca = 0.0564547, 0.0564848, 0.0564855, 0.0564855, 0.0564855` µm²;
  the requested `lmax = 3` is converged to ~1e-5 relative, and the total field
  components agree to <1e-5 between `lmax = 4` and `6`.
* **Energy balance / far field**: integrating `|E_sca|² r² dΩ` on a sphere of
  radius 50 µm (80-point Gauss-Legendre in cos θ x 160 in φ) gives
  0.0564860 µm² vs 0.0564855 µm² from `cross_sections` at `lmax = 6`
  (4x1e-5 relative). Also `sigma_abs = sigma_ext - sigma_sca > 0`, as required
  for lossy spheres.
* **Decoupling limit**: with `separation = 500` µm the dimer cross sections
  (0.0551304 / 0.0578451 µm²) reproduce the sum of the two isolated Mie spheres
  (0.0551313 / 0.0578460 µm²) to 2e-5 relative.
* **Solver consistency**: `Cluster.scatter(illu)` and
  `Cluster.solve().scatter(illu)` fields agree to 3e-17.
* **Incident normalization**: `|E_inc| = 1` exactly.

## CLI

```
python solution.py < config.json > results.json
```
