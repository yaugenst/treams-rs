"""Two-sphere (dimer) multiple scattering with treams-rs.

Computes the total electric field (incident + scattered) at requested points and
the scattering / extinction / absorption cross sections of the coupled dimer for
a positive-helicity plane wave travelling along +z.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as tr


def _material(entry):
    """Turn an ``[real, imag]`` permittivity entry into a complex value."""
    if np.isscalar(entry):
        return complex(entry)
    re, im = entry
    return complex(float(re), float(im))


def run(config):
    radii = [float(r) for r in config["radii"]]
    epsilon = [_material(e) for e in config["epsilon"]]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.atleast_2d(np.asarray(config["points"], dtype=float))

    if len(radii) != 2 or len(epsilon) != 2:
        raise ValueError("exactly two radii and two permittivities are required")

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um
    positions = np.array([[-separation / 2.0, 0.0, 0.0],
                          [+separation / 2.0, 0.0, 0.0]])

    # Individual Mie T-matrices (helicity basis, vacuum exterior, mu = 1, kappa = 0).
    tmats = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=eps, medium=1,
                          polarization="helicity")
        for r, eps in zip(radii, epsilon)
    ]

    # Coupled two-body response: solve() includes all orders of multiple scattering.
    cluster = tr.Cluster(tmats, positions=positions)
    solved = cluster.solve()

    # Positive-helicity plane wave along +z, unit field amplitude (package normalization).
    illu = tr.plane_wave(direction=[0.0, 0.0, 1.0],
                         polarization="positive_helicity", k0=k0, material=1)

    scattered = solved.scatter(illu)

    e_inc = np.asarray(illu.efield(points), dtype=complex).reshape(-1, 3)
    e_sca = np.asarray(scattered.efield(points), dtype=complex).reshape(-1, 3)
    e_tot = e_inc + e_sca

    xs = solved.cross_sections(illu)
    sca, ext, abso = float(xs.scattering), float(xs.extinction), float(xs.absorption)

    # Points inside a particle's circumscribing sphere: the outgoing multipole
    # expansion about that origin does not converge there.
    invalid = [
        i for i, p in enumerate(points)
        if any(np.linalg.norm(p - c) <= rad for c, rad in zip(positions, radii))
    ]

    result = {
        "total_field_real": e_tot.real.tolist(),
        "total_field_imag": e_tot.imag.tolist(),
        "scattering_cross_section": sca,
        "extinction_cross_section": ext,
        "absorption_cross_section": abso,
        "wavelength": wavelength,
        "k0": k0,
        "lmax": lmax,
        "positions": positions.tolist(),
        "points_inside_particles": invalid,
    }
    return result


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
