# Dimer total field and cross sections (treams-rs)

`solution.py` exposes `run(config)` and a CLI (`python solution.py < config.json`)
that reads one config dict from stdin and prints the result dict as JSON.

## Setup

* Sphere 1: radius `radii[0]`, permittivity `epsilon[0]`, centre `(-separation/2, 0, 0)`.
* Sphere 2: radius `radii[1]`, permittivity `epsilon[1]`, centre `(+separation/2, 0, 0)`.
* Exterior: vacuum (eps = mu = 1, chirality 0); spheres have mu = 1, chirality 0.
* Each `epsilon` entry `[re, im]` becomes `re + 1j*im` (time convention `exp(-i w t)`,
  so a positive imaginary part is loss).

## Units and conventions

* Lengths in micrometers; permittivities/permeabilities dimensionless.
* Vacuum angular wavenumber `k0 = 2*pi/wavelength` (1/um); reported as `k0`.
* Cross sections in um^2.
* Fields are complex phasors, Cartesian components `(Ex, Ey, Ez)`, returned as
  `total_field_real` / `total_field_imag`, each a `len(points) x 3` list.
* Illumination: `treams_rs.plane_wave([0,0,1], "positive_helicity", k0=k0)`, i.e.
  propagation along +z with positive helicity, in the package's own incident
  normalization (unit field amplitude, `|Ex|^2+|Ey|^2 = 1`, with treams' helicity
  basis-vector phase; no rescaling is applied).

## Method

1. `sphere_tmatrix(k0=..., lmax=..., radius=..., material=eps, medium=1,
   polarization="helicity")` gives each isolated Mie T-matrix.
2. `Cluster([T1, T2], positions=...).solve()` builds the coupled two-body
   response, which contains **all orders of multiple scattering** between the
   spheres at the fixed `lmax` (the full interaction matrix is inverted, not
   truncated at a finite scattering order).
3. Scattered wave: `cluster.scatter(incident)`; total field at the points is
   `incident.efield(points) + scattered.efield(points)`.
4. Cross sections: `cluster.cross_sections(incident)` (default flux 0.5, matching
   the unit-amplitude plane wave), giving `scattering`, `extinction` and
   `absorption = extinction - scattering`.

All numerics come from treams-rs; nothing is reimplemented. The task is purely
forward (no derivatives requested), so no finite differences enter the results.

## Checks performed

* **lmax convergence** (example config): sigma_sca = 0.055977 / 0.056455 / 0.0564848 /
  0.0564855 / 0.0564855 for lmax = 1..5; the requested lmax = 3 is converged to
  ~1e-5 relative. The reported field component likewise changes by <3e-6 between
  lmax 3 and 5.
* **Isolated-particle limit**: with `separation = 80 um`, the cluster cross
  sections (0.0551572, 0.0578722) match the sum of the two single-sphere Mie
  cross sections (0.0551313, 0.0578461) to ~5e-4 relative, the residual being the
  physical, slowly decaying interference of the two scatterers.
* **Rayleigh limit**: a single a = 0.005 um, eps = 4+0.02i sphere gives
  sigma_sca = 1.8994e-10 vs. the dipole formula k0^4|alpha|^2/(6 pi) = 1.8979e-10,
  and sigma_ext = 2.308e-8 vs. k0 Im(alpha) = 2.285e-8.
* **Lossless case**: two real-epsilon spheres return absorption exactly 0.0.
* **Energy consistency**: absorption = extinction - scattering >= 0 for the
  example (0.002618 um^2).
* **Point validity**: `points_inside_spheres` flags any evaluation point inside a
  sphere's circumscribing radius, where the outgoing multipole expansion does not
  converge. Both example points are outside (all `false`).

## Example result (`results.json`)

sigma_sca = 0.0564848 um^2, sigma_ext = 0.0591024 um^2, sigma_abs = 0.0026176 um^2;
total field at `(0,0,0.3)` = `(0.80919-0.26914i, 0.23513+0.82034i, 0.03110+0.07267i)`
and at `(0.35,0.2,0.1)` = `(-0.22645-0.60503i, 0.52804-0.43737i, -0.02124-0.12125i)`.
