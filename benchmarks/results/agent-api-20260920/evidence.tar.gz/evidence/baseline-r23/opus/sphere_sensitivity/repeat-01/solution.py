"""Scattering efficiency of a lossy sphere and its analytic sensitivities.

Q = sigma_sca / (pi * radius**2) for a homogeneous, lossy sphere in vacuum,
illuminated by a positive-helicity plane wave travelling along +z.

The gradient d(Q)/d(radius, epsilon_real) is obtained by reverse-mode
automatic differentiation through the treams-rs Advect adapter, which uses the
native analytic Mie/T-matrix pullbacks.  The geometric cross section in the
denominator is part of the differentiated expression, so the radius derivative
contains both the cross-section and the normalization contribution.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs.advect as tr

#: Illumination direction (+z) and helicity of the incident plane wave.
_DIRECTION = (0.0, 0.0, 1.0)
_POLARIZATION = "positive_helicity"


def _efficiency(x, *, k0: float, lmax: int, epsilon_imag: float):
    """Q as a traceable function of [radius, epsilon_real]."""
    radius, epsilon_real = x[0], x[1]
    tmatrix = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=epsilon_real + 1j * epsilon_imag,
        medium=1.0,
    )
    incident = tr.plane_wave(_DIRECTION, _POLARIZATION, k0=k0, medium=1.0)
    scattering = tmatrix.cross_sections(incident).scattering
    return scattering / (np.pi * radius**2)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um

    def objective(x):
        return _efficiency(x, k0=k0, lmax=lmax, epsilon_imag=epsilon_imag)

    value, gradient = ad.value_and_grad(objective)(ad.array([radius, epsilon_real]))

    # The scattering cross section itself, for context (same units as um**2).
    cross_section = float(value) * np.pi * radius**2

    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
        "scattering_cross_section": cross_section,
        "geometric_cross_section": float(np.pi * radius**2),
        "k0": float(k0),
        "size_parameter": float(k0 * radius),
        "epsilon": [epsilon_real, epsilon_imag],
        "lmax": lmax,
        "polarization": _POLARIZATION,
        "direction": list(_DIRECTION),
        "units": {
            "length": "um",
            "cross_section": "um^2",
            "value": "dimensionless",
            "gradient": ["1/um", "dimensionless"],
        },
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
