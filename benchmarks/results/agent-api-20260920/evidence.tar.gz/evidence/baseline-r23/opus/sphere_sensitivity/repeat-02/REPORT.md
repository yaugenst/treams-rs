# Scattering efficiency and analytic sensitivity of a lossy sphere

## Problem

A homogeneous, isotropic, lossy sphere in vacuum is illuminated by a unit-amplitude
plane wave propagating along **+z** with **positive helicity**. Reported quantity:

```
Q = sigma_sca / (pi * radius**2)
gradient = [dQ/dradius, dQ/depsilon_real]     (epsilon_imag, wavelength, lmax fixed)
```

## Units and conventions

| Quantity | Convention |
|---|---|
| Lengths (`radius`, `wavelength`) | micrometers |
| `k0 = 2*pi/wavelength` | rad/micrometer (vacuum angular wavenumber) |
| Sphere material | `epsilon = epsilon_real + 1j*epsilon_imag`, `mu = 1`, `kappa = 0` (relative, dimensionless) |
| Exterior | vacuum: `epsilon = 1`, `mu = 1`, `kappa = 0` |
| Cross sections | micrometer**2 |
| `Q` | dimensionless; `dQ/dradius` in 1/micrometer, `dQ/depsilon_real` dimensionless |
| Polarization basis | helicity; `"positive_helicity"` selects amplitudes `(0, 1)` |
| Incident flux | `0.5` (treams-rs default for a unit-amplitude plane wave) |

A positive `epsilon_imag` is absorbing in the library's time convention, confirmed by
the positive absorption cross section `sigma_ext - sigma_sca > 0` in every case tested.

## Method

* `treams_rs.advect.sphere_tmatrix` builds the Mie T-matrix (helicity basis,
  dimension `2*lmax*(lmax+2)`) with differentiable radius and material.
* `treams_rs.advect.plane_wave([0,0,1], "positive_helicity", k0=k0)` is the illumination.
* `TMatrix.cross_sections(illumination).scattering` gives `sigma_sca`.
* The whole expression, **including the normalization `pi*radius**2`**, is traced, so the
  radius derivative contains both the scattering-cross-section term and the
  `-2*sigma_sca/(pi*r**3)` normalization term. Formally
  `dQ/dr = (1/(pi r^2)) dsigma_sca/dr - 2 Q / r`.
* The gradient comes from `advect.value_and_grad` driving the **native analytic pullbacks**
  of treams-rs through the installed Advect adapter. No finite differences and no
  re-implementation of Mie theory are used to produce the returned numbers.

## Checks performed

1. **Central finite differences** (validation only, not used for the reported gradient):
   relative agreement of `1e-12`–`1e-9` for both components, over three parameter sets
   spanning `radius` 0.05–0.25 um, `epsilon_real` 2.25–9, `epsilon_imag` 0.001–0.3.
2. **Energy consistency**: `sigma_ext >= sigma_sca` and `sigma_abs > 0` for all cases.
3. **Multipole convergence**: recomputing with `lmax + 2` changes `Q` by <1e-9 relative
   for the example config (and <5e-5 for the largest, highest-index test case).
4. **Rayleigh limit**: for `radius = 0.05`, `epsilon = 2.25 + 0.001j`, `wavelength = 1.55`
   (`x = 0.2027`), the code gives `Q = 3.9036e-4` against the analytic small-particle
   value `(8/3) x^4 |(m^2-1)/(m^2+2)|^2 = 3.90e-4`.

## Results for the example config

`{"radius": 0.1, "epsilon_real": 4.0, "epsilon_imag": 0.06, "wavelength": 0.72, "lmax": 3}`

| Quantity | Value |
|---|---|
| `Q` | 0.46337644643427434 |
| `dQ/dradius` | 18.65367030479629 um^-1 |
| `dQ/depsilon_real` | 0.1997255464561844 |
| `sigma_sca` | 1.4557400399644607e-2 um^2 |
| `sigma_ext` | 1.5635805239605213e-2 um^2 |
| `sigma_abs` | 1.078404839960606e-3 um^2 |
| size parameter `k0*r` | 0.8726646259971649 |

Full output is in `results.json`.

## Usage

```
python solution.py < config.json            # CLI: config dict on stdin, JSON on stdout
from solution import run; run(config)       # library entry point
```

`run` accepts any values of the same keys (`radius`, `epsilon_real`, `epsilon_imag`,
`wavelength`, `lmax`); nothing is hard-coded to the example.
