# Scattering efficiency of a lossy sphere and its analytic sensitivities

## Problem

A homogeneous, lossy sphere in vacuum is illuminated by a **positive-helicity**
plane wave propagating along **+z**. We report

    Q = sigma_sca / (pi * radius^2)

and its gradient `[dQ/d(radius), dQ/d(epsilon_real)]` at fixed
`epsilon_imag`, `wavelength` and `lmax`.

## Units and conventions

- All lengths are in micrometers (um); `wavelength` is the **vacuum** wavelength,
  so the vacuum angular wavenumber is `k0 = 2*pi/wavelength` [1/um].
- Permittivity is relative and dimensionless, `epsilon = epsilon_real + 1j*epsilon_imag`.
  The positive imaginary part is absorption in the `exp(-i*omega*t)` convention
  used by treams-rs (verified below: extinction > scattering).
- `mu = 1`, `kappa = 0`, exterior is vacuum (`medium = 1`).
- Cross sections are in um^2; `Q` is dimensionless.
- Gradient units: `dQ/d(radius)` in 1/um, `dQ/d(epsilon_real)` dimensionless.
- Helicity basis throughout; the incident wave is selected with the explicit
  name `"positive_helicity"` so the convention is unambiguous. Multipole
  truncation is `lmax` (the default spherical basis of treams-rs).

## Method

`treams_rs.advect.sphere_tmatrix` builds the Mie T-matrix of the sphere with
differentiable radius and material; `treams_rs.advect.plane_wave` defines the
illumination, and `TMatrix.cross_sections(...).scattering` gives sigma_sca.
The whole expression, **including the `pi*radius^2` normalization**, is traced
by Advect, so `ad.value_and_grad` returns the exact total derivative

    dQ/dr = (1/(pi r^2)) * d(sigma_sca)/dr  -  2 * Q / r ,

with `d(sigma_sca)/dr` supplied by the native analytic T-matrix pullback of
treams-rs (no finite differences enter the reported numbers). No private API is
imported.

## Example result (`results.json`)

Config: `radius=0.1`, `epsilon_real=4.0`, `epsilon_imag=0.06`,
`wavelength=0.72`, `lmax=3` (size parameter `k0*r = 0.8727`).

| quantity | value |
|---|---|
| Q | 0.4633764464342743 |
| dQ/d(radius) | 18.65367030479629 um^-1 |
| dQ/d(epsilon_real) | 0.1997255464561844 |
| sigma_sca | 0.0145574004 um^2 |

## Checks (`verify.py`)

Run on the example plus two other configs (`r=0.25, eps=6.5+0.3i, 0.55 um, lmax=5`
and `r=0.05, eps=2.1+0.01i, 1.31 um, lmax=2`):

1. **Value cross-check** against the eager `treams_rs.sphere_tmatrix(...).xs(...)`
   path: relative error ~1e-16.
2. **Gradient validation** by central finite differences of that independent
   eager path: relative agreement 4e-12 ... 2e-10 for both components.
   (Finite differences are used only as a check, never as the reported values.)
3. **Energy balance**: `sigma_ext - sigma_sca > 0` for all lossy cases, and
   `= -9e-18` (numerically zero) when `epsilon_imag = 0`.
4. **Multipole convergence**: increasing `lmax` by one changes `Q` by
   1e-10 ... 4e-7 relative, so the requested truncations are converged.

## Usage

```
echo '{"radius":0.1,"epsilon_real":4.0,"epsilon_imag":0.06,"wavelength":0.72,"lmax":3}' \
  | python solution.py
```

`run(config)` returns the same dictionary; `value` and `gradient` are the
requested outputs, the remaining keys are diagnostics.
