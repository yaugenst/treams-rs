"""Scattering efficiency of a lossy sphere and its analytic sensitivities.

Q = sigma_sca / (pi * radius**2) for a homogeneous, isotropic sphere in vacuum
illuminated by a positive-helicity plane wave travelling along +z.  The
gradient [dQ/dradius, dQ/depsilon_real] is obtained from the native analytic
pullbacks of treams-rs through the installed Advect adapter; the geometric
normalization pi*r**2 is part of the differentiated expression.

Lengths are in micrometers, permittivity is relative and dimensionless.
"""

from __future__ import annotations

import json
import sys

import advect
import numpy as np
import treams_rs.advect as ta

__all__ = ["run", "main"]


def _efficiency(params, *, epsilon_imag, k0, lmax):
    """Q(radius, epsilon_real) built entirely from differentiable operations."""
    radius, epsilon_real = params[0], params[1]
    epsilon = epsilon_real + 1j * epsilon_imag
    tmat = ta.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=ta.Material(epsilon),
        medium=1.0,
    )
    illumination = ta.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0)
    sigma_sca = tmat.cross_sections(illumination).scattering
    return sigma_sca / (np.pi * radius**2)


def _cross_sections(radius, epsilon_real, epsilon_imag, k0, lmax):
    """Plain (non-traced) cross sections for reporting and consistency checks."""
    tmat = ta.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=ta.Material(epsilon_real + 1j * epsilon_imag),
        medium=1.0,
    )
    illumination = ta.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0)
    return tmat.cross_sections(illumination)


def run(config):
    """Return the scattering efficiency and its analytic gradient."""
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    if radius <= 0.0:
        raise ValueError("radius must be positive")
    if wavelength <= 0.0:
        raise ValueError("wavelength must be positive")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")

    k0 = 2.0 * np.pi / wavelength

    def objective(params):
        return _efficiency(params, epsilon_imag=epsilon_imag, k0=k0, lmax=lmax)

    params = advect.array([radius, epsilon_real])
    value, gradient = advect.value_and_grad(objective)(params)
    value = float(value)
    gradient = [float(g) for g in np.asarray(gradient)]

    xs = _cross_sections(radius, epsilon_real, epsilon_imag, k0, lmax)
    sigma_sca = float(xs.scattering)
    sigma_ext = float(xs.extinction)

    return {
        "value": value,
        "gradient": gradient,
        "scattering_efficiency": value,
        "dQ_dradius": gradient[0],
        "dQ_depsilon_real": gradient[1],
        "scattering_cross_section": sigma_sca,
        "extinction_cross_section": sigma_ext,
        "absorption_cross_section": sigma_ext - sigma_sca,
        "geometric_cross_section": float(np.pi * radius**2),
        "size_parameter": float(k0 * radius),
        "k0": float(k0),
        "units": {
            "length": "micrometer",
            "cross_section": "micrometer**2",
            "k0": "1/micrometer",
            "efficiency": "dimensionless",
            "dQ_dradius": "1/micrometer",
            "dQ_depsilon_real": "dimensionless",
        },
        "conventions": {
            "illumination": "unit-amplitude plane wave, +z propagation, positive helicity",
            "polarization_basis": "helicity",
            "medium": "vacuum (epsilon=1, mu=1, kappa=0)",
            "sphere": "epsilon = epsilon_real + 1j*epsilon_imag, mu=1, kappa=0",
            "derivatives": "native treams-rs analytic pullbacks via the Advect adapter",
            "fixed_during_differentiation": ["epsilon_imag", "wavelength", "lmax"],
        },
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
