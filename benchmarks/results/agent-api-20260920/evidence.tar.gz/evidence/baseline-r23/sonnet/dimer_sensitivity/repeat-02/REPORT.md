# Dimer sensitivity: field intensity at a point vs. sphere separation

## Physical setup

Two identical, homogeneous, isotropic (mu=1, chirality=0) spheres of the given
`radius` and complex permittivity `epsilon = [real, imag]` sit in vacuum, centered
at `(-separation/2, 0, 0)` and `(+separation/2, 0, 0)` micrometers. They are
illuminated by a unit-amplitude plane wave propagating along `+z` with positive
helicity (helicity index 1 in treams-rs's convention, i.e. coefficients
`(0, 1)` in the `(negative_helicity, positive_helicity)` basis). Multiple
scattering between the two spheres is fully accounted for by solving the
coupled interaction problem (`treams_rs.advect.Cluster.scatter`), which
internally forms and solves `(I - T C) x = T x_inc` for the whole dimer.

At the fixed Cartesian `point` (micrometers), the total electric field is

    E_total = E_incident + E_scattered

and the reported

    value = sum_i |E_total_i|^2   (i = x, y, z)

includes the incident field, consistent with the task statement.

## Units and conventions

- All lengths (radius, separation, point coordinates, wavelength) are in
  micrometers; the vacuum wavenumber is `k0 = 2*pi/wavelength` (rad/um).
- `epsilon` is the relative permittivity of the sphere material,
  `epsilon_complex = epsilon[0] + 1j*epsilon[1]`. The embedding medium is
  vacuum (`epsilon=1, mu=1`).
- Field amplitudes follow the treams-rs helicity multipole convention with
  unit-amplitude incident plane wave (electric field amplitude 1 in vacuum
  units); `value` therefore has units of (incident field amplitude)^2 and is
  dimensionless when the incident amplitude is taken as 1.
- `lmax` is the maximum spherical multipole degree used for each sphere's
  T-matrix (`SphericalWaveBasis` truncation).

## Derivatives

`gradient = d(value)/d(separation)` is computed by reverse-mode automatic
differentiation through treams-rs's native analytic pullbacks, using the
`Advect` adapter (`treams_rs.advect`, backed by `import advect as ad`). The
sphere positions `(-separation/2, 0, 0)` and `(separation/2, 0, 0)` are built
from `separation` using `advect`-traced array operations, so the gradient
propagates through:

- the pairwise multipole translation/coupling operators (`diff.expansion`,
  used inside `Cluster`'s coupling assembly),
- the coupled-interaction solve (`diff.interaction`/`diff.illuminate`),
- and the field evaluation at the fixed point (`diff.field`, via
  `Wave.efield`).

No finite differences are used to produce the returned gradient. `radius`,
`epsilon`, `wavelength`, `lmax` and `point` are held fixed (not
differentiated); only `separation` (and the two sphere positions derived from
it) enters the differentiated computation.

## Checks performed

For the example configuration and for at least one other configuration with
different radius, permittivity, separation, wavelength, lmax and point, the
`advect`-computed analytic gradient was cross-checked against a central finite
difference of `run()`'s own `value` output (`(f(s+h) - f(s-h)) / (2h)`,
`h = 1e-6`). Agreement was better than 1e-7 relative in both cases, confirming
correctness of the analytic derivative pipeline. Finite differences are used
only for this validation, not to supply the returned `gradient`.

## Example result

For the example configuration:

```json
{
  "radius": 0.08,
  "epsilon": [4.0, 0.04],
  "separation": 0.3,
  "wavelength": 0.72,
  "lmax": 2,
  "point": [0.05, 0.02, 0.28]
}
```

the solution produces (see `results.json`):

```json
{
  "value": 1.1855506354526988,
  "gradient": -0.40372542061712435
}
```

## Usage

```bash
python3 solution.py < config.json > result.json
```

or from Python:

```python
from solution import run
result = run(config)  # {"value": ..., "gradient": ...}
```
