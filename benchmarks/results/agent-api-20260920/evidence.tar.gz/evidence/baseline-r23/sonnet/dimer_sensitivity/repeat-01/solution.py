"""Two-sphere dimer illuminated along +z with positive helicity.

value = sum(|E_total|^2) at a fixed point, including the incident field and
full multiple scattering between the two spheres. gradient = d(value)/d(separation),
with the sphere positions at +-separation/2 along x, computed analytically via
treams-rs' native reverse-mode pullbacks through the Advect adapter.

Units: lengths (radius, separation, wavelength, point) in micrometers.
epsilon = [real, imag] relative permittivity; mu = 1, chirality = 0, vacuum exterior.
"""

import json
import sys

import advect as ad
import numpy as np
import treams_rs.advect as ta


def _value(separation, radius, epsilon, wavelength, lmax, point):
    k0 = 2.0 * np.pi / wavelength
    material = ta._physics.Material(epsilon=complex(epsilon[0], epsilon[1]))

    tmatrix_a = ta.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
    tmatrix_b = ta.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)

    zero = ad.numpy.asarray(0.0)
    half = separation / 2.0
    positions = ad.numpy.stack(
        [
            ad.numpy.stack([-half, zero, zero]),
            ad.numpy.stack([half, zero, zero]),
        ]
    )
    cluster = ta.Cluster([tmatrix_a, tmatrix_b], positions=positions)

    incident = ta.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    scattered = cluster.scatter(incident)

    points = np.asarray([point], dtype=float)
    e_total = incident.efield(points)[0] + scattered.efield(points)[0]
    return ad.numpy.sum(ad.numpy.abs(e_total) ** 2)


def run(config):
    radius = float(config["radius"])
    epsilon = [float(config["epsilon"][0]), float(config["epsilon"][1])]
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = [float(v) for v in config["point"]]
    separation = float(config["separation"])

    def f(sep):
        return _value(sep, radius, epsilon, wavelength, lmax, point)

    value, gradient = ad.value_and_grad(f)(separation)

    return {
        "value": float(value),
        "gradient": float(gradient),
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
