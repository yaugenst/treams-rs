# Dimer sensitivity: total-field intensity vs. separation

## Physical setup

Two identical homogeneous, nonmagnetic, non-chiral spheres (radius, permittivity
`epsilon = eps_re + i*eps_im`, exterior vacuum) sit on the x-axis at
`(-separation/2, 0, 0)` and `(+separation/2, 0, 0)`. They are illuminated by a
plane wave travelling along `+z` with pure positive helicity
(`helicity_+ = 1, helicity_- = 0`, i.e. right-circular in the optics convention
used by treams). Multiple scattering between the two spheres is solved exactly
(non-perturbatively) via the interacting T-matrix of the pair. `value` is the
sum over the three Cartesian components of `|E_total|^2` at a fixed observation
point, where `E_total = E_incident + E_scattered` (scattered field from both
spheres, evaluated as a coherent multipole sum).

## Units and conventions

- Lengths (`radius`, `separation`, `wavelength`, `point` coordinates) are in
  micrometers; `k0 = 2*pi/wavelength` is therefore in rad/um.
- `epsilon` is `[real, imag]`, relative to vacuum; `mu = 1`, chirality `kappa = 0`.
- Fields use treams-rs' helicity basis/normalization (`polarization="helicity"`).
- `lmax` is the maximum spherical multipole degree used for each sphere's
  T-matrix and for the interaction/expansion operators.
- Only `separation` moves the two sphere centers (symmetric about the origin
  along x); `point`, `wavelength`, `radius`, `epsilon`, and `lmax` are held fixed.

## Numerics

Implemented entirely with `treams-rs` (`treams_rs.advect`, the Advect
framework adapter):

1. `treams_rs.advect.sphere_tmatrix` builds each sphere's helicity T-matrix
   (Mie coefficients, generalized to `lmax`).
2. `treams_rs.advect.Cluster` assembles the two T-matrices at their positions,
   forms the inter-particle spherical-wave translation/coupling operator, and
   `Cluster.scatter(incident)` solves `(I - T C) x_scat = T x_inc` for the fully
   interacting response (native `diff.illuminate`).
3. `treams_rs.advect.plane_wave` constructs the incident positive-helicity
   plane wave along `+z`; its `.efield` and the scattered `Wave.efield` are
   evaluated at the requested point and summed to `E_total`.
4. `value = sum(abs(E_total)**2)` is computed with `advect.numpy` ops so that
   the whole pipeline (T-matrix construction -> coupling -> interaction solve
   -> field evaluation) is tracked by Advect's reverse-mode autodiff, which
   uses treams-rs' native pullbacks (analytic VJPs), not finite differences.
5. `gradient = d(value)/d(separation)` is obtained with a single
   `advect.value_and_grad` call differentiating the sphere positions
   `(-separation/2, 0, 0)` / `(+separation/2, 0, 0)` through the entire
   scattering + field pipeline.

Finite differences are only used offline to validate the analytic gradient;
they are never used to produce `run()`'s reported value or gradient.

## Checks performed

- Central finite-difference check of `gradient` against `value_and_grad`
  output for both the example config and an independently perturbed config
  (different radius, epsilon, wavelength, lmax, point, separation): agreement
  to ~1e-8 relative, consistent with the analytic derivative being exact up to
  floating-point/step-size error.
- Verified `run()` is not hard-coded: re-running with substantially different
  `separation`, `radius`, `epsilon`, `wavelength`, `lmax`, and `point` values
  produces different, physically sensible `value`/`gradient` pairs.
- Confirmed the CLI path (`python solution.py` reading a JSON config from
  stdin and printing a JSON `{"value": ..., "gradient": ...}` dict to stdout)
  matches direct calls to `run()`.

## Example result

For the example config (`radius=0.08`, `epsilon=[4.0, 0.04]`,
`separation=0.3`, `wavelength=0.72`, `lmax=2`,
`point=[0.05, 0.02, 0.28]`), see `results.json`:

```
value    = 1.1855506354526988
gradient = -0.40372542061712435
```
