"""Dimer sensitivity: value/gradient of |E_total|^2 at a point vs. sphere separation.

Two identical spheres, centered at (-separation/2, 0, 0) and (+separation/2, 0, 0),
illuminated along +z with positive helicity (helicity +1, i.e. left/right circular
convention fixed by treams). Multiple scattering between the spheres is solved via
treams-rs's Cluster interaction. All lengths are in micrometers, wavelength is the
vacuum wavelength, epsilon = [real, imag] is the relative permittivity of both
spheres (mu=1, chirality=0, vacuum exterior). value = sum(|E_total|^2) over the
three Cartesian field components at the given fixed point, including the incident
field. gradient = d(value)/d(separation), obtained from treams-rs's native analytic
reverse-mode pullback (via the Advect adapter), not from finite differences.
"""

import json
import sys

import numpy as np
import advect as ad
import treams_rs.advect as tra


def _value(separation, radius, epsilon, wavelength, lmax, point):
    k0 = 2.0 * np.pi / wavelength
    material = complex(epsilon[0], epsilon[1])

    tmat = tra.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)

    half = separation / 2.0
    zero = 0.0 * separation
    pos1 = ad.numpy.stack((-half, zero, zero))
    pos2 = ad.numpy.stack((half, zero, zero))
    positions = ad.numpy.stack((pos1, pos2))

    cluster = tra.Cluster([tmat, tmat], positions=positions)
    incident = tra.plane_wave((0.0, 0.0, 1.0), "positive_helicity", k0=k0)
    scattered = cluster.scatter(incident)

    pt = np.asarray(point, dtype=float).reshape(1, 3)
    e_total = incident.efield(pt)[0] + scattered.efield(pt)[0]
    return ad.numpy.sum(ad.numpy.abs(e_total) ** 2)


def run(config):
    radius = config["radius"]
    epsilon = config["epsilon"]
    separation = config["separation"]
    wavelength = config["wavelength"]
    lmax = config["lmax"]
    point = config["point"]

    def f(sep):
        return _value(sep, radius, epsilon, wavelength, lmax, point)

    value, gradient = ad.value_and_grad(f)(np.asarray(float(separation)))

    return {
        "value": float(value),
        "gradient": float(gradient),
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
