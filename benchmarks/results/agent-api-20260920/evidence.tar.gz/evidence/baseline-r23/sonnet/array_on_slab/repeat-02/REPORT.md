# Square Sphere Array on a Dielectric Slab — Periodic Scattering

## Physical setup

A square periodic array of identical dielectric spheres sits above a uniform
dielectric slab, separated by a vacuum gap. Along the propagation axis `+z`
the stack is ordered

```
slab  ->  vacuum gap  ->  sphere array (Bloch-periodic plane)
```

All exterior media (below the slab and above the sphere array) are vacuum.
The structure is illuminated from the `-z` side, propagating along `+z`,
with pure positive helicity. Because all wavelengths in the sweep exceed the
lattice period, only the zeroth diffraction order is propagating; the
plane-wave basis used everywhere therefore contains exactly two modes
(`kx = ky = 0`, both helicities), with in-plane Bloch vector `kpar = [0, 0]`
(normal incidence).

## Units and conventions

- Lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) are in
  micrometers; `sphere_epsilon`/`slab_epsilon` are dimensionless relative
  permittivities (`mu = 1`, chirality `kappa = 0` everywhere, matching the
  task defaults).
- The vacuum angular wavenumber is `k0 = 2*pi/wavelength`.
- The polarization/mode convention used throughout is `helicity`
  (`polarization="helicity"`), consistent with the "positive helicity"
  illumination requested.
- `T`, `R`, `A` are power fractions relative to the incident flux, computed by
  `treams_rs`'s `SMatrices.power(...)`, which returns a `PowerBalance`
  (`transmission`, `reflection`, and derived `absorption = 1 - T - R`).

## Numerical pipeline (native `treams_rs` calls only)

For each wavelength:

1. `t.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon,
   medium=1, polarization="helicity")` — single-sphere Mie T-matrix.
2. `t.solve_periodic(sphere_tmatrix, lattice=t.Lattice.square(period),
   kpar=[0, 0])` — solves the full periodic multipole interaction of the
   square sphere lattice at the fixed `lmax` (native Ewald lattice sums;
   `eta` left at its default so the kernel picks the splitting parameter).
3. `periodic_response.to_smatrix(basis)` — converts the solved periodic
   spherical-wave response into an up/down scattering matrix on the
   zeroth-order plane-wave basis (`basis = t.PlaneWavePorts.default([0, 0])`).
4. `t.multilayer_slab(basis=basis, k0=k0, thicknesses=[slab_thickness],
   materials=[slab_epsilon], negative_medium=1, positive_medium=1,
   polarization="helicity")` — S-matrix of the homogeneous dielectric slab.
5. `t.propagation(distance=gap, basis=basis, k0=k0, medium=1,
   polarization="helicity")` — homogeneous vacuum propagation over the gap
   between the slab top and the sphere-center plane.
6. `t.stack([slab_smatrix, gap_smatrix, sphere_smatrix])` — cascades the three
   layers in order along `+z`, exactly matching slab → gap → array.
7. `t.plane_wave(direction=[0, 0, 1], polarization="positive_helicity",
   k0=k0, medium=1)` defines the incident wave; `full_smatrix.power(incident,
   side="negative")` yields transmission/reflection/absorption fractions for
   that wavelength.

No private API, reimplemented Mie/lattice-sum physics, or finite-difference
substitutes for the requested quantities are used — every scattering step is
delegated to `treams_rs`.

## Checks performed

- **Energy conservation**: `sphere_epsilon` and `slab_epsilon` are real
  (lossless), so `T + R` should equal 1 to numerical precision. For the
  example config, `absorption` values are all `~1e-15` (floating-point noise
  around zero), confirming the pipeline conserves energy as expected.
- **`lmax` convergence**: increasing `lmax` (e.g. 3 → 4) for an independent
  test configuration changes `T`/`R` only in the 6th–7th decimal, confirming
  the periodic multipole sum is well-converged for these particle sizes.
- **Reordering/genericity**: `run()` re-derives every quantity from the input
  `config` dict (no cached or hard-coded example values); re-running with
  different `radius`, `period`, `gap`, `slab_thickness`, `epsilon` values and
  wavelengths produces correspondingly different, physically reasonable
  results.

## Example results (`results.json`)

For the example config (`radius=0.06`, `sphere_epsilon=9.0`, `period=0.4`,
`gap=0.12`, `slab_thickness=0.09`, `slab_epsilon=2.25`, `lmax=2`,
`wavelengths=[0.65, 0.74, 0.83]` µm):

| wavelength (µm) | T | R | A |
|---|---|---|---|
| 0.65 | 0.8873 | 0.1127 | ~0 |
| 0.74 | 0.9021 | 0.0979 | ~0 |
| 0.83 | 0.9119 | 0.0881 | ~0 |

Values are wavelength-ordered, matching the order of `config["wavelengths"]`.
