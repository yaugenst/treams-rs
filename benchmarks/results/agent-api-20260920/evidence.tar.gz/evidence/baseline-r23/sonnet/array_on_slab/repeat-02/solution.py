import sys
import json

import numpy as np
import treams_rs as t


def run(config):
    radius = config["radius"]
    sphere_epsilon = config["sphere_epsilon"]
    period = config["period"]
    gap = config["gap"]
    slab_thickness = config["slab_thickness"]
    slab_epsilon = config["slab_epsilon"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    lattice = t.Lattice.square(period)
    # Zeroth diffraction order only (both helicities), normal incidence (kpar = [0, 0]).
    basis = t.PlaneWavePorts.default([0.0, 0.0])

    transmission = []
    reflection = []
    absorption = []

    for wavelength in wavelengths:
        k0 = 2 * np.pi / wavelength

        sphere_tm = t.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=sphere_epsilon,
            medium=1,
            polarization="helicity",
        )
        periodic = t.solve_periodic(sphere_tm, lattice=lattice, kpar=[0.0, 0.0])
        sphere_smat = periodic.to_smatrix(basis)

        slab_smat = t.multilayer_slab(
            basis=basis,
            k0=k0,
            thicknesses=[slab_thickness],
            materials=[slab_epsilon],
            negative_medium=1,
            positive_medium=1,
            polarization="helicity",
        )
        gap_smat = t.propagation(
            distance=gap, basis=basis, k0=k0, medium=1, polarization="helicity"
        )

        # Order along +z: slab, vacuum gap, sphere array.
        full = t.stack([slab_smat, gap_smat, sphere_smat])

        incident = t.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        pb = full.power(incident, side="negative")

        transmission.append(float(pb.transmission))
        reflection.append(float(pb.reflection))
        absorption.append(float(pb.absorption))

    return {
        "wavelengths": list(wavelengths),
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
