# Square sphere array above a dielectric slab

## Physical setup

Network ordered along +z (as required): **slab -> vacuum gap -> sphere array**.
All exterior (semi-infinite) media are vacuum. The square lattice of identical
spheres sits in the z=0 plane (sphere-center plane); the slab of thickness
`slab_thickness` and permittivity `slab_epsilon` lies below it, separated by a
vacuum gap of thickness `gap` between the slab's top face and the sphere-center
plane. Illumination is a plane wave incident from the negative-z side,
propagating along +z, with **positive helicity**.

Because the wavelengths given exceed the lattice period, only the zeroth
(specular) diffraction order is propagating; both helicity channels of that
order are kept and no other order contributes propagating power, so truncating
the plane-wave port basis to the zeroth order is exact for the power balance
at normal incidence with Bloch vector kpar = [0, 0].

## Units and conventions

- Lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) are in
  micrometers; `k0 = 2*pi/wavelength` is used consistently with radii/period.
- `sphere_epsilon` and `slab_epsilon` are real, relative permittivities;
  `mu = 1`, chirality `kappa = 0` for both materials, and the exterior medium
  is vacuum (`Material(1)`), as specified.
- The **helicity** polarization basis is used throughout (`polarization="helicity"`
  for the sphere T-matrix, the slab S-matrix, the gap propagator, and the
  incident plane wave). In this basis, `treams-rs` labels polarization index
  0/1 as negative/positive helicity; the convenience constructor
  `treams_rs.plane_wave(..., polarization="positive_helicity")` was used to
  avoid any ambiguity about channel ordering.
- The plane-wave port basis used for the slab, the gap and the periodic-array
  conversion is restricted to the single (qx, qy) = (0, 0) direction with both
  polarization labels, and is tagged with the physical square `Lattice` and
  Bloch vector `kpar = [0, 0]` so `PeriodicResponse.to_smatrix` produces
  ports consistent with the slab/gap S-matrices.

## Numerical procedure (treams-rs calls)

For each wavelength:
1. `treams_rs.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=Material(sphere_epsilon), medium=1, polarization="helicity")`
   builds the single-sphere T-matrix.
2. `treams_rs.solve_periodic(tmat, lattice=[[period,0],[0,period]], kpar=[0,0], eta=0)`
   solves the full periodic lattice-sum interaction problem for the square
   array at the fixed `lmax` (native Ewald summation; `eta=0` lets the kernel
   choose the splitting parameter).
3. The solved `PeriodicResponse` is converted with `.to_smatrix(basis)` onto
   the zeroth-order plane-wave basis, giving the array's S-matrix without any
   re-solving.
4. `treams_rs.slab(...)` builds the homogeneous dielectric slab's S-matrix on
   the same basis; `treams_rs.propagation(distance=gap, ...)` builds the
   vacuum-gap S-matrix.
5. `treams_rs.stack([slab, gap, array])` cascades the three S-matrices from
   negative to positive z, giving the S-matrix of the full stack (slab, then
   gap, then array), matching the required +z ordering.
6. `full.power(incident, side="negative")` returns the `PowerBalance`
   (transmission, reflection, absorption fractions) for the positive-helicity
   plane wave incident from the negative-z (vacuum) side.

All scattering, lattice sums and power balances are computed by treams-rs;
no reimplementation of Mie/lattice-sum physics was done here.

## Checks performed

- **Energy conservation**: for the real (lossless) permittivities used here,
  `transmission + reflection + absorption` equals 1 to numerical precision
  (residual absorption is O(1e-16), i.e. floating point noise), for the
  example config and for an independently chosen different config.
- **lmax convergence**: increasing `lmax` from 1 to 4 for the example config
  shows the transmission/reflection values converging (e.g. T at wavelength
  0.65 um changes by ~1e-3 from lmax=1 to lmax=2, and by <1e-5 from lmax=3 to
  lmax=4), confirming lmax=2 in the example is already close to converged and
  that the multipole truncation is being respected.
- **No hardcoding**: `run()` was exercised with a second, differently-valued
  configuration (different radius, permittivities, period, gap, slab
  thickness, wavelengths and lmax) and produced distinct, physically sensible
  results with the same energy-conservation check passing.

## Output

`results.json` contains the wavelength-ordered lists `transmission`,
`reflection`, `absorption` for the example config above.
