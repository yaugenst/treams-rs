"""Transmission/reflection/absorption of a square sphere array above a dielectric slab.

Network along +z: slab -> vacuum gap -> sphere array (all exterior media vacuum).
Illumination from -z side along +z, positive helicity. Only the zeroth
diffraction order (both helicities) is retained, at Bloch vector [0, 0].
"""
import sys
import json

import numpy as np
import treams_rs as tr


def run(config):
    radius = config["radius"]
    sphere_epsilon = config["sphere_epsilon"]
    period = config["period"]
    gap = config["gap"]
    slab_thickness = config["slab_thickness"]
    slab_epsilon = config["slab_epsilon"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    kpar = [0.0, 0.0]
    lattice = [[period, 0.0], [0.0, period]]

    sphere_material = tr.Material(sphere_epsilon)
    slab_material = tr.Material(slab_epsilon)

    transmission = []
    reflection = []
    absorption = []

    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength

        tmat = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=sphere_material,
            medium=1,
            polarization="helicity",
        )
        response = tr.solve_periodic(tmat, lattice=lattice, kpar=kpar, eta=0)

        # Zeroth diffraction order only, both helicities, Bloch vector [0, 0].
        basis = tr.PlaneWaveBasis.default([0.0, 0.0, 1.0]).bycomp(k0=k0)
        basis.lattice = tr.Lattice.square(period)
        basis.kpar = tr.WaveVector(kpar)

        sm_array = response.to_smatrix(basis)
        sm_slab = tr.slab(
            basis=basis,
            k0=k0,
            thickness=slab_thickness,
            material=slab_material,
            negative_medium=1,
            positive_medium=1,
            polarization="helicity",
        )
        sm_gap = tr.propagation(
            distance=gap, basis=basis, k0=k0, medium=1, polarization="helicity"
        )

        # Order along +z: slab, gap, sphere array.
        full = tr.stack([sm_slab, sm_gap, sm_array])

        incident = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        balance = full.power(incident, side="negative")

        transmission.append(balance.transmission)
        reflection.append(balance.reflection)
        absorption.append(balance.absorption)

    return {
        "wavelengths": list(wavelengths),
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
