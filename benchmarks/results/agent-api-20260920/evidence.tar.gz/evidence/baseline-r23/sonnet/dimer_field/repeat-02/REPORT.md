# Dimer scattering: total electric field and cross sections

## Method

`solution.py` uses `treams_rs` to compute the electromagnetic response of a
dimer of two homogeneous, isotropic, non-magnetic spheres illuminated by a
plane wave, including full multiple scattering at a fixed spherical-wave
truncation order `lmax`.

Steps:

1. Each sphere is represented by a single-sphere `TMatrix.sphere(lmax, k0,
   radius, [epsilon, mu])`, with `mu=1` and vacuum exterior (the task's
   defaults). `epsilon` is built as a Python `complex(real, imag)` from the
   `[real, imag]` pair in the config.
2. The two T-matrices are placed at Cartesian positions
   `(-separation/2, 0, 0)` and `(+separation/2, 0, 0)` in a `Cluster`.
3. `Cluster.solve()` computes the fully coupled response (a single T-matrix
   over the joint two-particle spherical-wave basis), which accounts for all
   orders of multiple scattering between the spheres at the given `lmax`.
4. The incident field is a `treams_rs.PlaneWave` with wavevector `(0, 0, k0)`
   (propagation along +z) and helicity polarization `[0, 1]` (positive
   helicity only), using `poltype="helicity"`. `k0 = 2*pi/wavelength` is the
   vacuum angular wavenumber.
5. The incident field is expanded in the solved cluster's basis
   (`incident.expand(solved.basis)`), scattered through the solved response
   (`solved.scatter(...)`) to obtain outgoing multipole coefficients, and the
   scattered field at each requested point is obtained via the `efield`
   operator: `solved.efield(points) @ outgoing`.
6. The **total** field is the sum of this scattered field and the incident
   plane-wave field evaluated at the same points (`incident.efield(points)`),
   per the package's native incident-field normalization (no extra
   rescaling).
7. Scattering, extinction and absorption cross sections are obtained from
   `solved.cross_sections(incident)`, which internally uses the same
   incident-flux normalization as the field evaluation (flux = 0.5 in the
   package's field units, the default for a unit-amplitude plane wave).

No finite differences, private APIs, or reimplemented scattering physics are
used; all numerical work (single-sphere Mie coefficients, translation
addition theorems / multiple scattering, and cross sections) is delegated to
`treams_rs`.

## Units and conventions

- Lengths (`radii`, `separation`, `wavelength`, `points`) are in micrometers,
  matching the task specification and the package's convention that `k0`
  carries units inverse to the length unit used for positions/radii.
- `epsilon` entries are `[real, imag]` relative permittivities; `mu = 1`, and
  the exterior medium is vacuum (`Material` default), as specified.
- The incident plane wave has positive helicity (right-circular in the
  optics convention used by `treams`), propagating along `+z`, with unit
  amplitude in the package's own normalization; no extra scaling is applied
  either to the incident or scattered field.
- Cross sections are returned in squared length units (μm²), consistent with
  the length unit used for radii/wavelength.
- `total_field_real` / `total_field_imag` are lists of length
  `len(points)`, each a 3-vector `[Ex, Ey, Ez]` giving the real and
  imaginary parts of the complex total Cartesian E-field at each point.

## Checks performed

- **Lossless-medium check**: for a symmetric dimer of non-absorbing spheres
  (`epsilon` purely real), the computed extinction and scattering cross
  sections agree to numerical precision, and absorption is ~1e-17 (zero up
  to floating-point noise) — as required by energy conservation for a
  non-absorbing scatterer.
- **Far-field/transversality check**: evaluating the total field far from
  the dimer (`z = 50` μm, i.e. `k0*z >> 1`) recovers an essentially
  transverse field (negligible z-component) with per-component magnitude
  close to the expected `1/sqrt(2)` normalization of a unit-amplitude
  helicity plane wave, confirming the incident+scattered field construction
  and helicity convention are self-consistent.
- **No hardcoding**: `run(config)` was exercised with multiple different
  parameter sets (different radii, epsilon, separation, wavelength, lmax,
  and points), not just the example config, to confirm generality.

## Example result

Running the example config (`example_config.json`) produces `results.json`,
included in this directory, with cross sections
`scattering ≈ 0.05648 μm²`, `extinction ≈ 0.05910 μm²`,
`absorption ≈ 0.00262 μm²` and the corresponding total-field values at the
two requested points.
