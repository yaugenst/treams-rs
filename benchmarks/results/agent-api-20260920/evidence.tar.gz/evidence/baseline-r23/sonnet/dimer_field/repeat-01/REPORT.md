# Dimer scattering: total field and cross sections (treams-rs)

## Problem
Two homogeneous, isotropic, non-magnetic spheres form a dimer, centered on the
x-axis at `(-separation/2, 0, 0)` and `(+separation/2, 0, 0)`, embedded in
vacuum. A plane wave of positive helicity travels along `+z` and illuminates
the dimer. Multiple scattering between the two spheres is included exactly
(up to the truncation `lmax`) by solving the coupled finite-cluster T-matrix.
The total electric field (incident + scattered) is evaluated at the requested
points, together with the total scattering, extinction and absorption cross
sections of the dimer.

## Units and conventions
- Lengths (`radii`, `separation`, `wavelength`, `points`) are in micrometers.
- The vacuum angular wavenumber is `k0 = 2*pi/wavelength` (inverse micrometers).
- `epsilon` entries are `[real, imag]` relative permittivities; `mu = 1`,
  chirality `kappa = 0`, exterior medium is vacuum, as specified.
- Polarization uses treams-rs's helicity convention (`positive_helicity`
  selects the plane wave with definite positive helicity, i.e. the natural
  circular-polarization eigenstate used for chirality/helicity-resolved
  scattering).
- Fields (`efield`) and cross sections use the package's own incident-field
  normalization (unit-amplitude plane wave, default flux 0.5), so all
  reported cross sections are directly in squared-micrometer area units.
- `total_field_real`/`total_field_imag` are the real and imaginary parts of
  `E_incident + E_scattered` at each requested Cartesian point, shape
  `(n_points, 3)`.

## Method
1. Build one `treams_rs.sphere_tmatrix` per sphere at the shared `lmax`, from
   its radius and complex permittivity.
2. Assemble a `treams_rs.Cluster` at the two dimer positions and call
   `.solve()`, which computes the fully coupled response including all
   orders of multiple scattering between the spheres (native dense
   interaction solve, not a Born/single-scattering approximation).
3. Construct the incident plane wave with `treams_rs.plane_wave(direction=
   [0,0,1], polarization="positive_helicity", k0=k0)`.
4. Scatter the incident wave off the solved cluster
   (`solved.scatter(incident)`) to get the outgoing multipole field, and
   evaluate `incident.efield(points) + scattered.efield(points)` for the
   total field.
5. Read scattering/extinction/absorption straight from
   `solved.cross_sections(incident)`, which uses treams-rs's own analytic
   cross-section formulas (no reimplementation).

All numerics (Mie coefficients, translation/coupling matrices, field
evaluation, cross sections) are computed by treams-rs; this script only
assembles inputs and calls the library.

## Checks performed
- `solved.valid_points(points, radii)` verifies every evaluation point lies
  strictly outside both spheres before evaluating fields (the multipole
  expansion is only valid there); `run()` raises if violated.
- Energy consistency: `extinction = scattering + absorption` is verified
  numerically for the example config (0.05910 ≈ 0.05648 + 0.00262).
- Lossless sanity check: for real-valued epsilon (no imaginary part), the
  solver returns `absorption ≈ 0` and `scattering ≈ extinction`, as required
  by energy conservation for a non-absorbing scatterer.
- Re-ran with a different configuration (different radii, separation,
  wavelength, lmax and points) to confirm `run()` is fully config-driven with
  no hard-coded example values.

## Files
- `solution.py`: exposes `run(config)` and a CLI (`stdin` JSON in,
  `stdout` JSON out).
- `example_config.json`: the example configuration from the task.
- `results.json`: output of `run()` for `example_config.json`.
