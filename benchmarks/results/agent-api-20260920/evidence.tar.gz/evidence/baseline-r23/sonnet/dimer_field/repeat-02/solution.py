import json
import sys

import numpy as np
import treams_rs as t


def run(config):
    radii = config["radii"]
    epsilon = config["epsilon"]
    separation = config["separation"]
    wavelength = config["wavelength"]
    lmax = config["lmax"]
    points = config["points"]

    k0 = 2 * np.pi / wavelength

    materials = [[complex(e[0], e[1]), 1] for e in epsilon]

    tmatrices = [
        t.TMatrix.sphere(lmax, k0, r, mat)
        for r, mat in zip(radii, materials)
    ]

    positions = [[-separation / 2, 0, 0], [separation / 2, 0, 0]]
    cluster = t.Cluster(tmatrices, positions=positions)
    solved = cluster.solve()

    incident = t.PlaneWave([0, 0, k0], [0, 1], k0=k0, poltype="helicity")

    inc_coeffs = incident.expand(solved.basis)
    outgoing = solved.scatter(inc_coeffs)

    pts = np.asarray(points, dtype=float)
    efield_op = solved.efield(pts)
    scattered_field = efield_op @ outgoing
    incident_field = incident.efield(pts)
    total_field = scattered_field + incident_field

    cs = solved.cross_sections(incident)

    return {
        "total_field_real": total_field.real.tolist(),
        "total_field_imag": total_field.imag.tolist(),
        "scattering_cross_section": float(cs.scattering),
        "extinction_cross_section": float(cs.extinction),
        "absorption_cross_section": float(cs.absorption),
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
