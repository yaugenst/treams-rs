"""Dimer of spheres: multiple scattering, total field and cross sections via treams-rs."""

import json
import sys

import numpy as np
import treams_rs as t


def run(config):
    radii = config["radii"]
    epsilon = [complex(re, im) for re, im in config["epsilon"]]
    separation = config["separation"]
    wavelength = config["wavelength"]
    lmax = config["lmax"]
    points = np.asarray(config["points"], dtype=float)

    k0 = 2 * np.pi / wavelength
    positions = np.array([[-separation / 2, 0.0, 0.0], [separation / 2, 0.0, 0.0]])

    spheres = [
        t.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=eps)
        for r, eps in zip(radii, epsilon)
    ]
    cluster = t.Cluster(spheres, positions=positions)
    solved = cluster.solve()

    valid = solved.valid_points(points, radii)
    if not np.all(valid):
        raise ValueError("evaluation points must lie outside both spheres")

    incident = t.plane_wave(
        direction=[0.0, 0.0, 1.0], polarization="positive_helicity", k0=k0
    )
    scattered = solved.scatter(incident)

    total_field = incident.efield(points) + scattered.efield(points)

    xs = solved.cross_sections(incident)

    return {
        "total_field_real": total_field.real.tolist(),
        "total_field_imag": total_field.imag.tolist(),
        "scattering_cross_section": float(xs.scattering),
        "extinction_cross_section": float(xs.extinction),
        "absorption_cross_section": float(xs.absorption),
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
