# Single-Layer Antireflection Coating: Analytic-Gradient Thickness Optimization

## Problem

A lossless dielectric coating of thickness `d` sits at normal incidence
between vacuum (`z<0`) and a semi-infinite substrate (`z>0`), with no
vacuum gap between coating and substrate. Given the coating and substrate
permittivities and a starting thickness, minimize the reflected power
fraction `R` for normal-incidence illumination by adjusting `d` inside
`bounds`, using analytic derivatives `dR/dd` supplied by treams-rs.

## Units and conventions

- Lengths (`wavelength`, `initial_thickness`, `bounds`, output `thickness`)
  are in micrometers.
- `epsilon` / `substrate_epsilon` are relative permittivities (dimensionless);
  `mu=1`, chirality `kappa=0`, exterior on the -z side is vacuum (`epsilon=1`).
- Vacuum wavenumber `k0 = 2*pi/wavelength` (inverse micrometers).
- Normal incidence is represented by a `treams_rs.PlaneWaveBasisByComp` with
  transverse wavevector `(0, 0)`, built via
  `PlaneWaveBasis.default([0,0,1]).bycomp(k0=k0, material=1)`. This basis
  carries both polarization labels (0/1), which are degenerate at normal
  incidence for an isotropic, non-chiral stack.
- The layer stack is `treams_rs.advect.slab(basis=..., k0=k0, thickness=d,
  material=epsilon, negative_medium=1.0, positive_medium=substrate_epsilon,
  polarization="helicity")`, i.e. vacuum -> coating(d) -> substrate directly,
  matching "no vacuum gap after the coating".
- Illuminating with unit amplitude on the negative (vacuum) side,
  `SMatrix.power(incident, side="negative").reflection` returns the
  incident-power-normalized reflected power `R` (a real, non-negative
  fraction; `R=0` is a perfect antireflection match).

## Numerics: treams-rs, not a closed-form reimplementation

All scattering (`R(d)`) and its derivative (`dR/dd`) are produced by the
treams-rs native core:

- `treams_rs.advect.slab(...)` builds the vacuum/coating/substrate S-matrix
  with the thickness left as an "advect"-traced quantity.
- `SMatrix.power(...).reflection` is the differentiable reflected-power
  functional built on top of the S-matrix.
- `advect.value_and_grad` runs the native reverse-mode pullback recorded by
  the S-matrix and power-balance primitives to obtain the exact `dR/dd` in
  one pass, alongside `R(d)`.

No Fresnel/quarter-wave closed form is used to *compute* the answer; the
known quarter-wave condition (`n_coat = sqrt(n_vacuum * n_substrate)`) only
serves as a sanity check below. Finite differences are used solely to
*validate* the analytic gradient, never to supply it.

## Optimizer

Because the objective is a smooth, essentially unimodal function of `d`
over one Fabry-Perot fringe (with a possible local minimum below the
achievable-zero point if the coating index does not exactly satisfy the
quarter-wave condition, or a boundary optimum if the bound excludes the
unconstrained minimum), a projected gradient descent with
Barzilai-Borwein (BB) step sizing and a monotone backtracking safeguard is
used:

1. Evaluate `R(d)` and `dR/dd` at the current `d` via treams-rs/advect.
2. Propose a BB step length from the last two iterates and gradients
   (falls back to a fixed fraction of the bounds range initially).
3. Backtrack (halve the step) until the projected point
   `clip(d - step*grad, lo, hi)` strictly decreases `R`, or the point stops
   moving (boundary stall).
4. Stop when `R < 1e-7`, or when no further decrease is possible
   (converged/boundary-limited).

`loss_history` records `R` at every accepted iterate, starting from
`initial_thickness`.

## Example run

Config: `wavelength=0.7`, `epsilon=2.25`, `substrate_epsilon=5.0625`,
`initial_thickness=0.05`, `bounds=[0.025, 0.21]`.

Result (`results.json`):

```json
{
    "thickness": 0.116666822865942,
    "reflection": 7.678594275616505e-13,
    "initial_reflection": 0.09594027275235119,
    "gradient": 9.831792444607697e-06,
    "loss_history": [
        0.09594027275235119,
        0.00015913628077856147,
        1.0515791681991695e-06,
        7.678594275616505e-13
    ]
}
```

Sanity checks performed:

- **Quarter-wave cross-check**: `n_coat = sqrt(2.25) = 1.5 =
  sqrt(1 * sqrt(5.0625)) = sqrt(n_vacuum * n_substrate)`, so a perfect
  antireflection match is physically achievable; the optimizer indeed drives
  `R` to `~1e-13`, far below the `1e-7` target, at
  `d ≈ 0.11667 μm ≈ wavelength/(4*n_coat)`, consistent with (but not derived
  from) the classical quarter-wave result.
- **Gradient validation**: at the optimized thickness, the analytic gradient
  (`9.8318e-6`) matches a central finite difference of `R(d)` with
  `h=1e-7` (`9.8318e-6`) to ~11 significant digits.
- **Bound handling**: tested with a config whose unconstrained optimum lies
  outside `bounds` (large wavelength); the optimizer correctly stops at the
  active bound with a non-zero residual gradient pointing outward, and with
  a non-matching coating index (imperfect quarter-wave), it converges to the
  true non-zero local minimum (gradient ≈ 0) rather than erroring or
  fabricating a spurious `R=0`.

## Files

- `solution.py`: `run(config)` plus a CLI (`stdin` JSON in, JSON `dict` on
  `stdout`).
- `results.json`: output of `run()` for the example config above.
