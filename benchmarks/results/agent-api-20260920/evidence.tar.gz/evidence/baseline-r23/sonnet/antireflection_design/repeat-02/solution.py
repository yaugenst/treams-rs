"""Analytic-gradient thickness optimization of a lossless single-layer AR coating.

Physics: treams-rs (native Rust scattering core) builds the vacuum/coating/
substrate S-matrix at normal incidence and computes the reflected power
fraction for a normally-incident plane wave. The thickness -> reflection map
is differentiated with the ``advect`` adapter's native pullback (reverse-mode
AD through the S-matrix construction and power projection), never by a
closed-form Fresnel/quarter-wave formula and never used as a finite-difference
substitute for the optimization step itself.
"""

import json
import sys

import numpy as np
import treams_rs as t
import treams_rs.advect as ta
import advect as ad


def _make_basis(k0):
    """Normal-incidence plane-wave basis (both polarizations degenerate)."""
    unit_basis = t.PlaneWaveBasis.default([0.0, 0.0, 1.0])
    return unit_basis.bycomp(k0=k0, alignment="xy", material=1)


def _reflection_fn(basis, k0, epsilon, substrate_epsilon, incident):
    def reflection(thickness):
        sm = ta.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
            polarization="helicity",
        )
        return sm.power(incident, side="negative").reflection

    return reflection


def _optimize(reflection, x0, lo, hi, target=1e-7, max_iter=200, max_backtrack=60):
    """Projected gradient descent with Barzilai-Borwein steps and a monotone
    backtracking safeguard, using the exact analytic gradient at every point."""

    def project(value):
        return min(max(value, lo), hi)

    val, grad = ad.value_and_grad(reflection)(x0)
    val, grad = float(val), float(grad)
    x = x0
    history = [val]
    step = 0.2 * (hi - lo)
    x_prev, g_prev = None, None

    for _ in range(max_iter):
        if val < target:
            break
        if x_prev is not None:
            dx, dg = x - x_prev, grad - g_prev
            if abs(dg) > 1e-14:
                bb = dx / dg
                if bb > 0.0 and np.isfinite(bb):
                    step = bb

        t_try = step
        x_new, val_new = x, val
        for _ in range(max_backtrack):
            x_new = project(x - t_try * grad)
            val_new = float(reflection(x_new))
            if val_new < val or abs(x_new - x) < 1e-14:
                break
            t_try *= 0.5

        if abs(x_new - x) < 1e-14 and val_new >= val:
            break

        x_prev, g_prev = x, grad
        x, val = x_new, val_new
        history.append(val)
        val, grad = ad.value_and_grad(reflection)(x)
        val, grad = float(val), float(grad)

    return x, val, grad, history


def run(config):
    """Minimize normal-incidence reflected power of a single coating layer.

    All lengths are in micrometers; permittivities are relative/dimensionless.
    Exterior on the -z side is vacuum; the substrate occupies +z with no gap.
    """
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    x0 = float(config["initial_thickness"])
    lo, hi = (float(v) for v in config["bounds"])

    k0 = 2.0 * np.pi / wavelength
    basis = _make_basis(k0)
    incident = np.array([1.0, 0.0])
    reflection = _reflection_fn(basis, k0, epsilon, substrate_epsilon, incident)

    x, val, grad, history = _optimize(reflection, x0, lo, hi)

    return {
        "thickness": x,
        "reflection": val,
        "initial_reflection": history[0],
        "gradient": grad,
        "loss_history": history,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
