# Antireflection Coating Thickness Optimization

## Task
Minimize the normal-incidence reflected power of a single lossless coating
layer (given `epsilon`), placed directly on a substrate (given
`substrate_epsilon`) with vacuum on the illuminated side and no vacuum gap
between coating and substrate. Optimize the coating `thickness`, starting
from `initial_thickness` and staying within `bounds`, using analytic
thickness derivatives (no closed-form quarter-wave shortcut).

## Units and conventions
- Lengths (`wavelength`, `thickness`, `bounds`) are in micrometers.
- `epsilon`, `substrate_epsilon` are relative, dimensionless permittivities;
  `mu = 1` and chirality `kappa = 0` throughout (defaults), exterior on the
  illuminated side is vacuum (`epsilon = 1`).
- The vacuum angular wavenumber is `k0 = 2*pi/wavelength`.
- Normal incidence is modeled as a plane wave with direction `(0, 0, 1)` in
  a `treams_rs.PlaneWaveBasis` at transverse wavevector `(0, 0)`, using the
  helicity polarization convention.
- The layer stack is `vacuum | coating(epsilon, thickness) | substrate`, built
  with `treams_rs.advect.multilayer_slab` (`negative_medium=1`,
  `positive_medium=substrate_epsilon`), i.e. no vacuum gap after the coating.
- Reflected/transmitted power fractions come from `SMatrix.power(...)`, which
  is normalized to the incident power (`reflection + transmission = 1` for
  this lossless system).

## Method
`treams_rs.advect` wraps the native `treams-rs` scattering primitives
(`layer_stack`, `smatrix_tr`, ...) as Advect-traceable operations with
analytic (native) pullbacks. `run(config)` builds the reflection as a
function of thickness through this traced pipeline and differentiates it
with `advect.value_and_grad`, giving `dR/dthickness` from the native VJP
chain rather than any finite-difference or closed-form approximation.

Optimization is projected gradient descent with backtracking line search:
at each step the thickness update `thickness - step * grad` is clipped to
`bounds`, and `step` is halved until the reflection strictly decreases (or
the thickness is unchanged, e.g. because a bound is active). The loop stops
once the reflection drops below `1e-7`, the gradient magnitude is negligible
(local optimum, possibly bound-limited if the coating cannot be perfectly
index-matched), or a maximum iteration count is reached.

## Checks performed
- **Physics sanity**: for the example config, `sqrt(epsilon) = 1.5` equals
  the ideal quarter-wave index `sqrt(1 * substrate_epsilon) = 1.5`, so a
  perfect zero-reflection design exists at
  `thickness = wavelength / (4*sqrt(epsilon)) ≈ 0.11667 um`; the optimizer
  converges to `thickness ≈ 0.116615 um` with `reflection ≈ 8.6e-8 < 1e-7`.
- **Non-ideal case**: with a mismatched coating index (e.g.
  `epsilon=4, substrate_epsilon=9`, ideal index `3` vs actual `2`), the
  optimizer converges to the quarter-wave thickness
  `wavelength/(4*sqrt(epsilon))` with reflection
  `((n1^2 - n0*ns)/(n1^2 + n0*ns))^2 = (1/7)^2 = 0.020408...`, matching the
  textbook single-layer Fresnel result exactly and confirming the numerical
  scattering solver (not just the optimizer) is correct.
- **Gradient validation**: the analytic `advect` gradient at
  `thickness=0.05` for the example config was cross-checked against a
  central finite difference (`h=1e-6`); both give
  `dR/dthickness ≈ -1.8626` (agreement to 6+ significant figures). Finite
  differences are used here only as an independent check, never to supply
  the reported gradient or drive the optimization steps.
- Energy conservation (`transmission + reflection = 1`, since the coating
  and substrate are lossless) holds at all evaluated thicknesses.

## Example result
For the example config (`wavelength=0.7`, `epsilon=2.25`,
`substrate_epsilon=5.0625`, `initial_thickness=0.05`,
`bounds=[0.025, 0.21]`), saved in `results.json`:

```json
{
  "thickness": 0.11661452761631123,
  "reflection": 8.55558709009249e-08,
  "initial_reflection": 0.09594027275235116,
  "gradient": -0.0032818338248905687,
  "loss_history": [
    0.09594027275235116,
    0.011534551403279815,
    4.045112571819666e-06,
    1.6439002131829162e-06,
    8.55558709009249e-08
  ]
}
```

`run(config)` does not hard-code these values; all quantities are recomputed
from the supplied `epsilon`, `substrate_epsilon`, `wavelength`,
`initial_thickness`, and `bounds` for any input config.
