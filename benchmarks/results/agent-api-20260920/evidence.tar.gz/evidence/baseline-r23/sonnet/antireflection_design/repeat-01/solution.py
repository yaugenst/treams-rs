"""Gradient-based thickness optimization of a single lossless coating.

Minimizes normal-incidence reflected power from vacuum into a substrate
through one homogeneous coating layer, using treams-rs's native S-matrix
scattering together with its analytic (Advect) reverse-mode derivative
of reflection with respect to layer thickness.
"""
import json
import sys

import numpy as np
import advect
import treams_rs as t
import treams_rs.advect as tadv


def _reflection_fn(wavelength, epsilon, substrate_epsilon):
    k0 = 2 * np.pi / wavelength
    basis = t.PlaneWaveBasis.default([0, 0, 1]).bycomp(k0, material=1)
    incident = tadv.PlaneWave([0, 0, 1], [1, 0], k0=k0, medium=1)

    def reflection(thickness):
        smat = tadv.multilayer_slab(
            basis=basis,
            k0=k0,
            thicknesses=[thickness],
            materials=[epsilon],
            negative_medium=1,
            positive_medium=substrate_epsilon,
            polarization="helicity",
        )
        return smat.power(incident).reflection

    return reflection


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = config["epsilon"]
    substrate_epsilon = config["substrate_epsilon"]
    thickness = float(config["initial_thickness"])
    lo, hi = (float(b) for b in config["bounds"])

    reflection = _reflection_fn(wavelength, epsilon, substrate_epsilon)
    value_and_grad = advect.value_and_grad(reflection)

    initial_reflection = float(reflection(thickness))

    target = 1e-7
    max_iter = 500
    loss_history = []
    grad = 0.0
    lr = 0.5 * (hi - lo)
    r, grad = value_and_grad(thickness)
    r, grad = float(r), float(grad)
    loss_history.append(r)
    for _ in range(max_iter):
        if r < target or abs(grad) < 1e-14:
            break

        # Backtracking line search on a gradient-descent step, projected to bounds.
        step = lr
        accepted = False
        candidate = thickness
        for _ in range(40):
            candidate = min(max(thickness - step * grad, lo), hi)
            r_candidate = float(reflection(candidate))
            if r_candidate < r or candidate == thickness:
                accepted = True
                break
            step *= 0.5
        if not accepted or candidate == thickness:
            break
        thickness = candidate
        lr = max(step * 1.5, 1e-8)
        r, grad = value_and_grad(thickness)
        r, grad = float(r), float(grad)
        loss_history.append(r)

    return {
        "thickness": thickness,
        "reflection": r,
        "initial_reflection": initial_reflection,
        "gradient": grad,
        "loss_history": loss_history,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
