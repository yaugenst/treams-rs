"""Scattering efficiency and its gradient for a lossy sphere under +z, positive-helicity incidence.

Uses treams-rs (native T-matrix / cross sections) with the Advect adapter for
analytic derivatives with respect to radius and epsilon_real, holding
epsilon_imag, wavelength and lmax fixed.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import advect as ad
import treams_rs.advect as ta


def _Q(radius, epsilon_real, epsilon_imag: float, wavelength: float, lmax: int):
    """Scattering efficiency Q = sigma_sca / (pi * radius**2).

    radius and wavelength are in micrometers; epsilon_real/epsilon_imag are
    dimensionless (relative permittivity of the sphere, exterior is vacuum
    with mu=1, kappa=0). Incidence is a +z-propagating, positive-helicity
    plane wave.
    """
    k0 = 2.0 * np.pi / wavelength
    material = ta.Material(epsilon_real + 1j * epsilon_imag)
    tmat = ta.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
    incident = ta.plane_wave((0.0, 0.0, 1.0), "positive_helicity", k0=k0)
    cross_sections = tmat.cross_sections(incident)
    return cross_sections.scattering / (np.pi * radius**2)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    def f(r, eps_r):
        return _Q(r, eps_r, epsilon_imag, wavelength, lmax)

    value, (dQ_dr, dQ_deps) = ad.value_and_grad(f, argnums=(0, 1))(
        radius, epsilon_real
    )

    return {
        "Q": float(value),
        "gradient": [float(dQ_dr), float(dQ_deps)],
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
