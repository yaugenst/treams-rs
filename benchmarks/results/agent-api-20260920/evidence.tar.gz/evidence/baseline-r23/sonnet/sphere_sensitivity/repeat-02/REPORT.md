# Sphere scattering efficiency and gradient

## Problem

Homogeneous, lossy sphere in vacuum illuminated by a plane wave propagating
along +z with pure positive helicity (a circularly polarized wave that is
an eigenmode of the helicity operator). We compute the scattering
efficiency

    Q = sigma_sca / (pi * radius**2)

and its gradient with respect to `radius` and `epsilon_real`, holding
`epsilon_imag`, `wavelength` and `lmax` fixed. The normalization
`pi * radius**2` (the geometric cross section) is differentiated together
with the cross section itself, i.e. `dQ/dradius` includes both terms.

## Units and conventions

- Lengths (`radius`, `wavelength`) are in micrometers.
- `epsilon_real`/`epsilon_imag` are the relative (dimensionless) permittivity
  of the sphere; `mu = 1`, chirality `kappa = 0`, exterior is vacuum
  (`epsilon = 1`), following the task defaults.
- Vacuum wavenumber: `k0 = 2*pi/wavelength` (inverse micrometers).
- Incidence: `treams_rs.advect.plane_wave((0, 0, 1), "positive_helicity", k0=k0)`,
  a +z-propagating plane wave with positive helicity, matching the treams-rs
  helicity convention (default exterior mu=1, kappa=0, so helicity states are
  the usual circular polarizations).
- The T-matrix is built for the homogeneous sphere via
  `treams_rs.advect.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=Material(epsilon))`.
- Scattering cross section: `TMatrix.cross_sections(incident).scattering`,
  returned by treams-rs in squared length units (here um^2), consistent with
  the incident-flux normalization built into `cross_sections`.
- `flux` uses the treams-rs default (0.5, matching a unit-amplitude plane
  wave); this cancels in Q since it enters `sigma_sca` linearly and would
  cancel any global scale but does not appear in Q as computed (it is fixed
  internally and not part of the input config).

## Method

`solution.py`'s `run(config)`:

1. Builds `epsilon = epsilon_real + 1j*epsilon_imag` and a `Material`.
2. Builds the sphere T-matrix and the +z positive-helicity plane wave using
   the **Advect-adapter** functions in `treams_rs.advect`
   (`sphere_tmatrix`, `plane_wave`), which retain native forward/pullback
   context for automatic differentiation.
3. Computes `Q = cross_sections(incident).scattering / (pi * radius**2)`.
4. Obtains the value and the analytic gradient
   `[dQ/dradius, dQ/depsilon_real]` in one pass via
   `advect.value_and_grad(f, argnums=(0, 1))`, where `f(radius, epsilon_real)`
   closes over the fixed `epsilon_imag`, `wavelength`, `lmax`. This
   differentiates through the T-matrix construction and the cross-section
   evaluation using treams-rs's own native pullbacks (reverse-mode VJPs),
   not a finite-difference or reimplemented approximation. The `pi*radius**2`
   normalization is part of the same differentiated expression, so its
   `1/radius**2` (and `1/radius**3` in the derivative) dependence is included
   automatically.

No private (`_`-prefixed) API is imported; only public `treams_rs`,
`treams_rs.advect` and `advect` symbols are used.

## Verification

Analytic gradients were cross-checked against central finite differences
(`h = 1e-6`) computed by directly calling the plain (non-Advect)
`treams_rs.sphere_tmatrix`/`cross_sections` API (see scratch checks). Example
config:

```
radius=0.1, epsilon_real=4.0, epsilon_imag=0.06, wavelength=0.72, lmax=3
Analytic: Q=0.463376446434, grad=[18.653670305, 0.199725546]
Finite diff:              grad=[18.653670305, 0.199725546]
```

A second, independently chosen config (`radius=0.2, epsilon_real=2.5,
epsilon_imag=0.15, wavelength=0.9, lmax=4`) was also checked and agreed with
finite differences to ~7 significant digits, confirming the gradient
implementation is not tied to the example values.

## Example results

See `results.json` (produced by running `solution.py` on the example config
above via `run()` / the CLI). Output schema:

```json
{"Q": <float>, "gradient": [<dQ/dradius>, <dQ/depsilon_real>]}
```

## Usage

```
echo '{"radius": 0.1, "epsilon_real": 4.0, "epsilon_imag": 0.06, "wavelength": 0.72, "lmax": 3}' | python solution.py
```
