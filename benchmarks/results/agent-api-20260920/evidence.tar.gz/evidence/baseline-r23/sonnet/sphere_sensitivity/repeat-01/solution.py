"""Scattering efficiency and its gradient for a lossy sphere under +z, positive-helicity incidence."""
import json
import sys

import numpy as np
import advect as ad
import treams_rs.advect as ta


def _scattering_efficiency(radius, epsilon_real, epsilon_imag, wavelength, lmax):
    """Q = scattering cross section / (pi * radius**2), differentiable in radius/epsilon_real."""
    k0 = 2 * np.pi / wavelength
    epsilon = epsilon_real + 1j * epsilon_imag
    material = ta.Material(epsilon)
    tmat = ta.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
    # Positive-helicity (index 1) plane wave propagating along +z.
    incident = ta.plane_wave((0.0, 0.0, 1.0), (0.0, 1.0), k0=k0)
    cs = tmat.cross_sections(incident)
    return cs.scattering / (np.pi * radius ** 2)


def run(config):
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    def f(radius_, epsilon_real_):
        return _scattering_efficiency(radius_, epsilon_real_, epsilon_imag, wavelength, lmax)

    r = np.array(radius)
    er = np.array(epsilon_real)
    Q, (dQ_dr, dQ_der) = ad.value_and_grad(f, argnums=(0, 1))(r, er)

    return {
        "Q": float(Q),
        "gradient": [float(dQ_dr), float(dQ_der)],
        "units": {
            "radius": "micrometer",
            "wavelength": "micrometer",
            "epsilon": "dimensionless",
            "Q": "dimensionless",
            "gradient": ["1/micrometer", "dimensionless"],
        },
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
