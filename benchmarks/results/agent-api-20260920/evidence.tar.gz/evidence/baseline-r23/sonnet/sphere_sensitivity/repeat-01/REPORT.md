# Lossy-sphere scattering efficiency and gradient

## Problem
For a homogeneous, absorbing sphere in vacuum illuminated by a plane wave of
pure positive helicity traveling along +z, compute the scattering efficiency

    Q = sigma_sca / (pi * radius**2)

and its gradient with respect to `radius` and `epsilon_real`, holding
`epsilon_imag`, `wavelength` and `lmax` fixed.

## Units and conventions
- Lengths (`radius`, `wavelength`) are in micrometers; `1/radius**2`-type
  gradient components are therefore in `1/micrometer`.
- `epsilon_real`/`epsilon_imag` are the dimensionless relative permittivity;
  `mu = 1` and chirality `kappa = 0` (nonmagnetic, achiral, as specified),
  exterior medium is vacuum (`epsilon = mu = 1`).
- `k0 = 2*pi/wavelength` is the vacuum wavenumber (inverse micrometers).
- Positive helicity, +z incidence is encoded as a `treams_rs` `PlaneWave`
  with propagation direction `(0, 0, 1)` and helicity amplitude vector
  `(0, 1)` (index 0 = negative helicity, index 1 = positive helicity, per
  `treams_rs`'s negative/positive-helicity ordering convention).
- `Q` is dimensionless.

## Method
- The T-matrix of the homogeneous sphere is built with
  `treams_rs.advect.sphere_tmatrix` (helicity basis, `lmax` truncation),
  which is the `Advect`-differentiable counterpart of
  `treams_rs.sphere_tmatrix`, using the same native numerics.
- The scattering cross section is obtained from `TMatrix.cross_sections`
  (also backend-generic/differentiable) evaluated at the plane-wave
  incidence described above.
- `Q = sigma_sca / (pi * radius**2)` is formed directly from the same
  traced `radius`, so its area normalization is differentiated together with
  the cross section itself — no separate/hand-derived normalization
  derivative is added.
- `advect.value_and_grad(f, argnums=(0, 1))` computes `Q` and
  `[dQ/dradius, dQ/depsilon_real]` in one reverse pass through the native
  `treams-rs` VJPs (T-matrix Mie-coefficient derivatives and cross-section
  contraction), with `epsilon_imag`, `wavelength` and `lmax` held as
  Python/NumPy constants outside the traced arguments.

## Verification
The analytic gradient was cross-checked against central finite differences
(`h = 1e-6`) of the same `_scattering_efficiency` function for both the
example configuration and an independent configuration
(`radius=0.25, epsilon_real=8.0, epsilon_imag=0.3, wavelength=1.0, lmax=4`).
Agreement was better than 1e-6 relative in all four partial derivatives.
Finite differences were used only for validation, never to supply the
returned gradient.

## Example result
For the example config
(`radius=0.1, epsilon_real=4.0, epsilon_imag=0.06, wavelength=0.72, lmax=3`):

```json
{
  "Q": 0.46337644643427434,
  "gradient": [18.65367030479629, 0.1997255464561844],
  "units": {
    "radius": "micrometer",
    "wavelength": "micrometer",
    "epsilon": "dimensionless",
    "Q": "dimensionless",
    "gradient": ["1/micrometer", "dimensionless"]
  }
}
```

See `results.json` for the saved output.
