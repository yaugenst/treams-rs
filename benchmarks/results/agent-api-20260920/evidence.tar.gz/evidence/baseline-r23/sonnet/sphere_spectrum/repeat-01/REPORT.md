# Homogeneous dielectric sphere scattering spectrum

## Method

`solution.py` uses `treams_rs` to compute the T-matrix of a homogeneous,
non-magnetic (`mu=1`), non-chiral (`kappa=0`) dielectric sphere for each
requested wavelength, then evaluates the optical cross sections for a
plane-wave illumination propagating along `+z` with positive helicity
(circular polarization of a fixed handedness in the helicity basis).

For each wavelength `wl` in `config["wavelengths"]`:

1. Vacuum angular wavenumber `k0 = 2*pi/wl`.
2. `t.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon,
   medium=1, polarization="helicity")` builds the sphere's T-matrix in the
   helicity polarization basis (the natural basis for the sphere's
   Mie/vector-spherical-wave solution and for defining "positive
   helicity").
3. `t.plane_wave(direction=[0, 0, 1], polarization="positive_helicity",
   k0=k0, medium=1)` defines the incident +z-propagating, positive-helicity
   plane wave in vacuum.
4. `tm.cross_sections(pw)` returns a `CrossSections` named tuple with
   `.scattering`, `.extinction`, and the derived `.absorption` property
   (`extinction - scattering`), computed analytically from the T-matrix by
   treams-rs (no reimplementation of Mie theory).

The scattering efficiency is `Q_sca = scattering / (pi * radius**2)`, the
sphere's geometric cross-sectional area.

## Units and conventions

- Lengths (`radius`, `wavelengths`) are in micrometers; `k0` is therefore in
  inverse micrometers, consistent between the T-matrix and the plane wave.
- `epsilon = [real, imag]` is the sphere's **relative permittivity**
  (`epsilon_r`), not a refractive index; it is passed as a complex material
  parameter with `mu=1`, `kappa=0` (default non-magnetic, achiral,
  reciprocal medium). The exterior medium is vacuum (`medium=1`).
- Cross sections (`scattering`, `extinction`, `absorption`) are returned in
  area units (micrometers squared), matching the length unit of `radius`.
- `efficiency` is dimensionless: `scattering / (pi * radius**2)`.
- Positive helicity is defined by `treams_rs.plane_wave(...,
  polarization="positive_helicity")`, and the T-matrix is built in the
  matching `polarization="helicity"` basis so that the illumination and the
  scatterer response use consistent conventions.

## Checks performed

- For a **lossless** test case (`epsilon=[4, 0]`), `absorption` evaluates to
  numerical noise (~1e-15, well below `scattering`/`extinction`) and
  `extinction ≈ scattering`, as required by energy conservation for a
  non-absorbing sphere.
- The function was run with a second, independent configuration (different
  radius, epsilon, wavelengths, lmax) to confirm no hard-coded example
  values are used; outputs change smoothly and consistently with `config`.
- All numerical scattering results come directly from `treams_rs`
  (`sphere_tmatrix` + `TMatrix.cross_sections`); no independent Mie-theory
  reimplementation is used.

## Example run

The example config (radius=0.1 um, epsilon=12+0.05j, lmax=4, wavelengths
0.45-0.75 um) was executed and saved to `results.json`:

```
$ python solution.py < example_config.json > results.json
```
