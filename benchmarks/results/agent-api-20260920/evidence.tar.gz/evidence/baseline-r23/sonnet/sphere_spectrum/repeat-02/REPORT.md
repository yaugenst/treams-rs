# Homogeneous Dielectric Sphere Scattering Spectrum

## Method

For each wavelength `wl` in the config, the vacuum angular wavenumber is
`k0 = 2*pi/wl`. The sphere's T-matrix is built with
`treams_rs.TMatrix.sphere(lmax, k0, radius, [material, 1])`, where `material`
is `treams_rs.Material(epsilon)` (relative permittivity, `mu=1`, `kappa=0` by
default) for the interior and `1` (vacuum) for the exterior. The illumination
is a unit-amplitude plane wave propagating along `+z` with positive helicity,
constructed via `treams_rs.plane_wave(direction=[0,0,1],
polarization="positive_helicity", k0=k0, material=1)`. Cross sections are
obtained from `TMatrix.cross_sections(incident)`, which returns scattering,
extinction, and absorption (extinction minus scattering) in area units. All
numerics (Mie coefficients, T-matrix construction, cross-section evaluation)
are computed by treams-rs; no scattering physics is reimplemented here.

## Units and conventions

- Lengths (`radius`, `wavelengths`) are in micrometers; `k0` is in inverse
  micrometers, so cross sections come out in square micrometers.
- `epsilon = [real, imag]` is the relative permittivity (not refractive
  index); it is combined into a complex number `epsilon_re + 1j*epsilon_im`
  passed to `Material`.
- Exterior medium is vacuum (`epsilon=1, mu=1`), consistent with the
  "unless specified" convention in the problem statement.
- Positive helicity, `+z` propagation, and helicity-basis polarization
  (`poltype="helicity"`, the treams-rs default) are used throughout, matching
  the specified illumination.
- `efficiency` is the scattering efficiency, i.e., `scattering / (pi *
  radius**2)`, a dimensionless quantity.

## Output keys

`scattering`, `extinction`, `absorption` (all in um^2), and `efficiency`
(dimensionless), each a list aligned with `wavelengths`.

## Checks performed

- For a non-absorbing test case (`epsilon=[4, 0]`), `scattering ≈ extinction`
  and `absorption ≈ 0` (up to floating-point round-off), as required by
  energy conservation for a lossless scatterer.
- Re-running with different `radius`, `epsilon`, `wavelengths`, and `lmax`
  produces different, self-consistent results, confirming no example values
  are hard-coded.
- The example config (`radius=0.1`, `epsilon=[12, 0.05]`,
  `wavelengths=[0.45, 0.55, 0.65, 0.75]`, `lmax=4`) was run and saved to
  `results.json`; the spectrum shows a Mie-type resonance feature around
  `wl=0.55-0.75 um`, consistent with a high-index (n~3.46) sub-wavelength
  sphere.

## Files

- `solution.py`: exposes `run(config)` and a CLI (`stdin` JSON in, `stdout`
  JSON out).
- `results.json`: output for the example config.
