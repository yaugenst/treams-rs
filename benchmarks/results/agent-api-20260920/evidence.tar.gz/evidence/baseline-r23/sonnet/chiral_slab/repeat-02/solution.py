import json
import math
import sys

import treams_rs as t


def _scattering_for_wavelength(thickness, eps_re, eps_im, kappa, wavelength):
    """Transmission/reflection/absorption power fractions for +/- helicity.

    Returns a dict {"positive": (T, R, A), "negative": (T, R, A)}.
    """
    k0 = 2.0 * math.pi / wavelength
    basis = t.PlaneWaveBasis.default([0.0, 0.0, 1.0]).bycomp(k0)
    material = t.Material(complex(eps_re, eps_im), 1.0, kappa)
    smat = t.slab(basis=basis, k0=k0, thickness=thickness, material=material)

    out = {}
    # Package convention: helicity label 0 is negative, label 1 is positive
    # (see treams_rs.Material.nmp / from_helicity_indices docs).
    for pol, name in ((1, "positive"), (0, "negative")):
        wave = t.PlaneWave([0.0, 0.0, k0], pol, k0=k0, material=1, poltype="helicity")
        balance = smat.power(wave, side="negative")
        transmission = float(balance.transmission)
        reflection = float(balance.reflection)
        absorption = 1.0 - transmission - reflection
        out[name] = (transmission, reflection, absorption)
    return out


def run(config):
    thickness = config["thickness"]
    eps_re, eps_im = config["epsilon"]
    kappa = config["kappa"]
    wavelengths = config["wavelengths"]

    transmission = []
    reflection = []
    absorption = []
    for wavelength in wavelengths:
        res = _scattering_for_wavelength(thickness, eps_re, eps_im, kappa, wavelength)
        t_pos, r_pos, a_pos = res["positive"]
        t_neg, r_neg, a_neg = res["negative"]
        transmission.append([t_pos, t_neg])
        reflection.append([r_pos, r_neg])
        absorption.append([a_pos, a_neg])

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
