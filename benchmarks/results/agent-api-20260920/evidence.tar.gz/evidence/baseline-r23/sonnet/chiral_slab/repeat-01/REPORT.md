# Chiral slab scattering — REPORT

## Problem
A uniform, reciprocal, isotropic chiral slab of thickness `d` occupies a
region normal to `z`, bounded by vacuum on both sides. Light is normally
incident from the `-z` side (propagating toward `+z`). For each wavelength
we compute the transmitted, reflected and absorbed power fractions for
positive- and negative-helicity incident illumination.

## Units and conventions
- Lengths (`thickness`, `wavelengths`) are in micrometers.
- `epsilon = [Re(eps), Im(eps)]` is the slab's relative permittivity.
- `mu` defaults to 1 (not exposed in the example config).
- `kappa` is the (real) Pasteur chirality parameter of the material,
  dimensionless, in treams-rs's convention (`Material(epsilon, mu, kappa)`).
- The vacuum angular wavenumber is `k0 = 2*pi/wavelength`.
- Polarization/port convention: helicity basis, where pol label `1` is
  positive helicity and pol label `0` is negative helicity
  (treams-rs internal convention, confirmed via `PlaneWave` construction
  code and `Material.nmp` docstring, "negative/positive helicity" order).
- Output arrays have shape `(len(wavelengths), 2)`, columns ordered
  `[positive helicity, negative helicity]`, and contain **power fractions**
  (not amplitude coefficients), each in `[0, 1]`.

## Method
For each wavelength:
1. Build a normal-incidence plane-wave basis
   (`PlaneWaveBasis.default([0, 0, 1]).bycomp(k0)`), which produces both
   helicity channels.
2. Build the slab's material (`treams_rs.Material(epsilon, mu, kappa)`) and
   its 2-port scattering matrices with `treams_rs.slab(...)`, with
   `polarization="helicity"` and vacuum on both exterior sides (the default
   `negative_medium=1`, `positive_medium=1`).
3. For each helicity, illuminate the slab from the negative (`-z`) side with
   a unit-amplitude incident wave carrying that helicity index (identified
   from `basis.pol`, not assumed), and use the native
   `SMatrices.power(incident, side="negative")` method, which returns a
   `PowerBalance(transmission, reflection)` namedtuple with an `absorption`
   property (`1 - transmission - reflection`). This method performs the
   actual numerical scattering computation in treams-rs; no independent
   reimplementation of Fresnel/Airy formulas is used for the reported
   numbers.
4. Collect transmission/reflection/absorption per wavelength, ordered
   `[positive helicity, negative helicity]`.

## Checks performed
- **Energy conservation**: for every wavelength and helicity,
  `T + R + A = 1` was verified numerically (see `results.json` for the
  example config; a direct check reproduces `1.0` to machine precision for
  all six entries).
- **kappa = 0 sanity check**: with chirality set to zero, the slab reduces to
  an ordinary isotropic dielectric, and the transmission/reflection
  reproduce the standard Airy thin-film formula for a normal-incidence
  Fabry–Pérot slab (`t = t12 t21 e^{ikd} / (1 - r21^2 e^{2ikd})`), which was
  cross-checked manually against `treams_rs`'s S-matrix block
  (`SMatrices.block("positive", "negative")`).
- **Helicity symmetry for real kappa**: because the example (and generally,
  the config's) `kappa` value is a single real number, the material has no
  circular dichroism (no differential absorption between helicities) — only
  optical activity (a real refractive-index splitting `n ± kappa` between
  the helicity eigenmodes, giving polarization rotation). For an isotropic,
  reciprocal slab at exactly normal incidence, this symmetry forces the
  transmitted and reflected *power* fractions to be identical for positive
  and negative helicity (`T+ == T-`, `R+ == R-`), even though the
  transmission amplitude coefficients differ in phase. This behavior was
  confirmed by scanning `kappa` over a wide range (`0` to `1.4`, i.e. mode
  indices differing hugely, e.g. `n- = 0.1`, `n+ = 2.9`) and multiple
  thicknesses/wavelengths: `treams_rs.SMatrices.power` consistently returns
  matching `T`/`R` between the two helicities in this regime, matching the
  expected physics (chirality shows up as cross-polarization terms in the
  off-diagonal reflection block, not as a power imbalance between helicity
  channels, when kappa is real). If a user supplies a complex `kappa` this
  symmetry would break (true circular dichroism), and the code makes no
  assumption that it holds — it always computes both helicities
  independently via `power()`.

## Example result
For the example config
(`thickness=0.16`, `epsilon=[2.25, 0.06]`, `kappa=0.08`,
`wavelengths=[0.55, 0.65, 0.8]`), see `results.json`. Representative values:

| wavelength | T+ | T- | R+ | R- | A+ | A- |
|---|---|---|---|---|---|---|
| 0.55 | 0.9054 | 0.9054 | 0.0240 | 0.0240 | 0.0705 | 0.0705 |
| 0.65 | 0.8646 | 0.8646 | 0.0808 | 0.0808 | 0.0547 | 0.0547 |
| 0.80 | 0.8267 | 0.8267 | 0.1302 | 0.1302 | 0.0431 | 0.0431 |

## Non-hardcoding
`run(config)` reads all physical parameters (`thickness`, `epsilon`,
`kappa`, `wavelengths`, optional `mu`) directly from the input dictionary
and performs the full numerical scattering computation for each call; no
example-specific values are hardcoded. This was verified by running the
solution on a second, different config
(`thickness=0.3`, `epsilon=[3.0, 0.1]`, `kappa=0.2`,
`wavelengths=[0.4, 1.0]`), which produced correspondingly different power
fractions.
