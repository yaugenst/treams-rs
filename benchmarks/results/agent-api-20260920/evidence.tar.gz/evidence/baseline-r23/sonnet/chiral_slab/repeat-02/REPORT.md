# Chiral slab scattering (treams-rs)

## Physical setup
A single homogeneous, reciprocal, isotropic chiral slab of thickness `thickness`
(micrometers) lies between z = 0 and z = thickness, normal to z, with vacuum
(`epsilon=1, mu=1, kappa=0`) on both sides. Light is normally incident from the
negative-z side (`+z` propagation). The slab material has relative permittivity
`epsilon = eps_re + i*eps_im` (dimensionless), relative permeability `mu = 1`,
and chirality parameter `kappa` (dimensionless, real, treams-rs convention).
Wavelengths are vacuum wavelengths in micrometers; the vacuum wavenumber used
internally is `k0 = 2*pi/wavelength`.

## Method
For each wavelength:
1. Build a normal-incidence plane-wave basis with both helicity labels via
   `treams_rs.PlaneWaveBasis.default([0, 0, 1]).bycomp(k0)`.
2. Build the slab material `treams_rs.Material(epsilon, mu=1, kappa)`.
3. Assemble the slab scattering matrix with `treams_rs.slab(basis=..., k0=...,
   thickness=..., material=...)` (vacuum exterior on both sides by default).
4. For each helicity (`pol=1` -> positive helicity, `pol=0` -> negative
   helicity, following the package's `Material.nmp` / `from_helicity_indices`
   convention of negative/positive order), construct an incident
   `treams_rs.PlaneWave([0, 0, k0], pol, k0=k0, material=1,
   poltype="helicity")` and call `SMatrices.power(wave, side="negative")`.
5. `PowerBalance.transmission` and `.reflection` are power fractions
   (normalized by incident flux) already computed by treams-rs from the
   analytic multilayer scattering solution; absorption is obtained from
   energy conservation as `1 - transmission - reflection`.

No scattering physics is reimplemented; all numerical scattering coefficients
come from treams-rs's own slab/S-matrix machinery (`treams_rs.slab`,
`SMatrices.power`).

## Output convention
`run(config)` returns a dict with keys `transmission`, `reflection`,
`absorption`, each a list of shape `(len(wavelengths), 2)`. For each
wavelength the pair is ordered `[positive helicity, negative helicity]`, as
requested. All entries are real-valued power fractions in [0, 1] (not complex
amplitude coefficients).

## Checks performed
- Energy conservation: `transmission + reflection + absorption == 1` was
  verified numerically for all wavelengths and both helicities, both for the
  example config and an independent test config (`thickness=0.5,
  epsilon=[3.0, 0.2], kappa=-0.15`).
- Since `kappa` here is real (no dissipative/gain chirality), the slab shows
  optical activity (circular birefringence: different phase for the two
  helicity eigenmodes) but no circular dichroism in power: for a reciprocal
  chiral slab embedded symmetrically in vacuum on both sides, the transmitted/
  reflected/absorbed power fractions are identical for positive and negative
  helicity to machine precision, which is exactly what the computation
  reproduces (this is the expected physical result since a purely real
  `kappa` does not introduce differential absorption/impedance between the
  two circular polarizations; only a complex `kappa` or asymmetric exterior
  media would break that degeneracy). This was validated by also sweeping
  `kappa` over several values and confirming the near-identical (positive,
  negative) results persist while transmission/reflection still vary
  correctly with `kappa`, `epsilon`, `thickness` and `wavelength`.
- `results.json` in this directory contains the output for the example
  config given in the task.
