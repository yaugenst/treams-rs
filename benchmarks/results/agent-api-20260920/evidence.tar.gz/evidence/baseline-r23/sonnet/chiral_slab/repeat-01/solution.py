import json
import sys
import math

import treams_rs as trs


def run(config):
    thickness = float(config["thickness"])
    eps_re, eps_im = config["epsilon"]
    kappa = complex(config["kappa"])
    mu = complex(config.get("mu", 1.0))
    wavelengths = config["wavelengths"]

    material = trs.Material(complex(eps_re, eps_im), mu, kappa)
    basis_dir = trs.PlaneWaveBasis.default([0.0, 0.0, 1.0])

    transmission = []
    reflection = []
    absorption = []

    for wl in wavelengths:
        k0 = 2.0 * math.pi / wl
        basis = basis_dir.bycomp(k0)
        pol = list(basis.pol)
        pos_idx = pol.index(1)
        neg_idx = pol.index(0)

        smat = trs.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            polarization="helicity",
        )

        amp_pos = [0, 0]
        amp_pos[pos_idx] = 1
        amp_neg = [0, 0]
        amp_neg[neg_idx] = 1

        pb_pos = smat.power(amp_pos, side="negative")
        pb_neg = smat.power(amp_neg, side="negative")

        transmission.append([pb_pos.transmission, pb_neg.transmission])
        reflection.append([pb_pos.reflection, pb_neg.reflection])
        absorption.append([pb_pos.absorption, pb_neg.absorption])

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
