import json
import math
import sys

import treams_rs as t


def run(config):
    radius = config["radius"]
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    mu = config.get("mu", 1.0)
    kappa = config.get("kappa", 0.0)
    wavelengths = config["wavelengths"]
    mmax = config["mmax"]

    material = t.Material(epsilon, mu, kappa)
    medium = t.Material(1, 1, 0)

    scattering = []
    extinction = []
    absorption = []

    for wl in wavelengths:
        k0 = 2.0 * math.pi / wl
        tmat = t.CylindricalTMatrix.cylinder(
            [0.0], mmax, k0, radius, [material, medium]
        )
        pw = t.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
        )
        cw = tmat.cross_widths(pw)
        scattering.append(cw.scattering)
        extinction.append(cw.extinction)
        absorption.append(cw.extinction - cw.scattering)

    return {
        "wavelengths": list(wavelengths),
        "scattering_width": scattering,
        "extinction_width": extinction,
        "absorption_width": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
