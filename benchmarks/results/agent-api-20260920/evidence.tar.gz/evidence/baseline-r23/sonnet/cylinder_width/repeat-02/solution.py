import json
import sys

import numpy as np
import treams_rs as t


def run(config):
    radius = float(config["radius"])
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    wavelengths = config["wavelengths"]
    mmax = int(config["mmax"])

    scattering = []
    extinction = []
    absorption = []

    for wl in wavelengths:
        k0 = 2 * np.pi / wl
        tm = t.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=[epsilon, 1],
        )
        pw = t.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
        )
        cw = tm.cross_widths(pw)
        scattering.append(cw.scattering)
        extinction.append(cw.extinction)
        absorption.append(cw.absorption)

    return {
        "wavelengths": list(wavelengths),
        "scattering_width": scattering,
        "extinction_width": extinction,
        "absorption_width": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
