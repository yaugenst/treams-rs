# Infinite Cylinder Scattering — Cross Widths

## Problem
Homogeneous, infinite, non-magnetic dielectric cylinder of circular cross-section,
axis along z, illuminated by a plane wave with axial wavenumber kz=0 (i.e.
propagation entirely in the xy-plane) traveling along +x with pure positive
helicity polarization. The cylinder response is computed via a T-matrix using
`treams_rs`.

## Units and conventions
- All lengths (radius, wavelength) are in micrometers (µm).
- `epsilon = [real, imag]` is the relative permittivity of the cylinder
  material; `mu = 1` and `kappa = 0` (achiral, non-magnetic) as specified.
  The exterior medium is vacuum (`epsilon=1, mu=1`).
- The vacuum angular wavenumber is `k0 = 2*pi/wavelength`.
- Cross **widths** (not areas) are returned, in the same length unit as the
  input radius/wavelength (µm), consistent with the 2D (per-unit-length)
  nature of an infinite cylinder scattering problem. No sphere-area
  normalization is applied.
- Polarization convention: helicity basis. The incident wave is prepared with
  `polarization="positive_helicity"` and `direction=[1,0,0]` (propagation
  along +x), giving kz=0 automatically since the direction lies in the xy
  plane.

## Method
For each wavelength:
1. Build the cylinder T-matrix with `treams_rs.cylinder_tmatrix(k0=k0, kz=0.0,
   mmax=mmax, radius=radius, material=[epsilon, 1])`. This is the built-in
   helper for a homogeneous, infinite, single-layer dielectric cylinder in
   vacuum, using cylindrical vector-wave functions with azimuthal orders
   `-mmax..mmax`.
2. Construct the incident positive-helicity plane wave with
   `treams_rs.plane_wave(direction=[1,0,0], polarization="positive_helicity",
   k0=k0)`.
3. Call `tm.cross_widths(pw)`, which returns a `CrossSections` namedtuple with
   `.scattering`, `.extinction`, and the derived `.absorption` property
   (`extinction - scattering`), all in length units for a cylinder (as stated
   in the `treams_rs` docstring: "in area units (sphere) or length
   (cylinder)").
4. Collect the three widths per wavelength into wavelength-ordered lists.

No custom re-implementation of Mie-type cylinder scattering is used; all
numerical scattering physics comes from `treams_rs`'s native cylindrical
T-matrix and cross-section routines.

## Checks performed
- **mmax convergence**: re-ran the example config with `mmax=8` instead of
  `mmax=4`; results agreed to ~6 significant figures for all three
  wavelengths, confirming `mmax=4` is already converged for this
  radius/wavelength ratio (size parameter `2*pi*radius/wavelength <~ 1`).
- **Physical consistency**: extinction ≥ scattering ≥ 0 and the derived
  absorption ≥ 0 for all wavelengths in the example, as physically required
  for a passive (Im(epsilon) > 0) lossy medium.
- Verified `treams_rs.cylinder_tmatrix` (convenience function) and the
  equivalent `treams_rs.CylindricalTMatrix.cylinder(...)` classmethod produce
  identical cross widths, confirming consistent use of the library API.

## Example results (radius=0.08 µm, epsilon=5+0.1j, mmax=4)

| wavelength (µm) | scattering width (µm) | extinction width (µm) | absorption width (µm) |
|---|---|---|---|
| 0.50 | 0.533035 | 0.561106 | 0.028071 |
| 0.65 | 0.258592 | 0.269540 | 0.010948 |
| 0.80 | 0.240742 | 0.248864 | 0.008123 |

Saved in `results.json`. The `run(config)` function does not hard-code these
values; it recomputes them (and any other configuration) directly from
`treams_rs`.

## CLI usage
```
python3 solution.py < config.json > result.json
```
reads one JSON config dict from stdin and prints the JSON result dict to
stdout.
