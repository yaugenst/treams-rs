# Cylinder scattering cross widths

## Problem
Homogeneous, infinite dielectric/magnetic cylinder of radius `radius` (µm), aligned
along z, embedded in vacuum, illuminated by a plane wave propagating along
+x (perpendicular to the cylinder axis, `kz = 0`) with pure positive helicity.
For each requested wavelength we compute the scattering, extinction and
absorption cross widths (per unit length, i.e. length units — µm here, *not*
areas) using `treams_rs`'s native cylindrical T-matrix solver.

## Units and conventions
- Lengths (`radius`, `wavelengths`) are in micrometers; the returned cross
  widths are therefore also in micrometers (length, since the cylinder is
  infinite along z and the standard normalization is per unit length).
- `epsilon = [Re, Im]` is the relative permittivity of the cylinder interior;
  `mu` defaults to 1 and chirality `kappa` defaults to 0 unless supplied in
  the config. The exterior medium is vacuum (`epsilon=mu=1, kappa=0`).
- The vacuum wavenumber is `k0 = 2*pi/wavelength`.
- Illumination direction is the unit vector `(1, 0, 0)` (propagation along
  +x), with `kz = 0` fixed by that direction, and polarization set to
  `positive_helicity` (treams' helicity/duality eigenbasis, not linear
  polarization).
- `mmax` sets the azimuthal order cutoff (orders `-mmax..mmax`) of the
  cylindrical wave basis used to build the T-matrix.

## Method
1. Build a `Material` for the cylinder interior from `(epsilon, mu, kappa)`
   and one for the vacuum exterior.
2. Construct the cylindrical T-matrix with
   `treams_rs.CylindricalTMatrix.cylinder([0.0], mmax, k0, radius, [material, medium])`
   for each wavelength (one axial wavenumber `kz = 0`).
3. Build the incident plane wave with `treams_rs.plane_wave(direction=[1,0,0],
   polarization="positive_helicity", k0=k0, material=medium)`.
4. Call `tmatrix.cross_widths(plane_wave)`, which returns `scattering` and
   `extinction` (both length units, per `CrossSections`' docstring: "area
   units (sphere) or length (cylinder)" — no sphere-area normalization is
   applied here since the scatterer is a cylinder).
5. Absorption width is obtained as `extinction - scattering`, consistent
   with energy conservation (optical theorem).

All numerical scattering is delegated to `treams_rs`; no custom Mie-type
cylinder solver is implemented here.

## Checks performed
- **`mmax` convergence**: for the example config, results are already
  converged to ~10 significant digits between `mmax=8` and `mmax=12`, and
  agree with `mmax=4` to about 4-5 significant digits (see below), showing
  the field expansion has converged well before `mmax=4`.
- **Passivity**: for the lossy example material (`Im(epsilon) = 0.1 > 0`),
  the computed absorption width (`extinction - scattering`) is positive at
  all wavelengths, as required by energy conservation for a passive
  scatterer.
- No sphere-area normalization is used anywhere; outputs are pure length
  cross widths as returned natively by `treams_rs` for the cylindrical
  geometry.

## Example results (`example_config.json` -> `results.json`)
Radius = 0.08 µm, epsilon = 5 + 0.1i, mmax = 4, wavelengths = [0.5, 0.65, 0.8] µm:

| wavelength (µm) | scattering width (µm) | extinction width (µm) | absorption width (µm) |
|---|---|---|---|
| 0.50 | 0.533035 | 0.561106 | 0.028071 |
| 0.65 | 0.258592 | 0.269540 | 0.010948 |
| 0.80 | 0.240742 | 0.248864 | 0.008123 |

## Interface
`solution.py` exposes `run(config) -> dict` with keys
`wavelengths`, `scattering_width`, `extinction_width`, `absorption_width`
(all lists ordered by input wavelength). Running `python3 solution.py` reads
a JSON config object from stdin and prints the same dictionary as JSON to
stdout.
