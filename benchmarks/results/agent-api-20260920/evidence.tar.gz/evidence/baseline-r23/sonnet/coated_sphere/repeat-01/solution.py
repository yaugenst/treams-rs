import json
import math
import sys

import treams_rs as t


def run(config):
    radii = config["radii"]
    epsilon_layers = config["epsilon_layers"]
    epsilon_medium = config["epsilon_medium"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    materials = [t.Material(complex(re, im)) for re, im in epsilon_layers]
    materials.append(t.Material(epsilon_medium))

    scattering = []
    extinction = []
    absorption = []
    for wl in wavelengths:
        k0 = 2 * math.pi / wl
        tmat = t.TMatrix.sphere(lmax, k0, radii, materials)
        xs = tmat.average_cross_sections
        scattering.append(xs.scattering)
        extinction.append(xs.extinction)
        absorption.append(xs.absorption)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
