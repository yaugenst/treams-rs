# Concentric Core-Shell Sphere Scattering

## Method

Given per-layer permittivities (inside-out) and a strictly increasing sequence
of outer layer radii, the T-matrix of the concentric multilayer sphere is
built with `treams_rs.TMatrix.sphere(lmax, k0, radii, materials)`, where
`materials` is the list of layer permittivities followed by the exterior
(embedding) permittivity as its final entry — the exterior is *not* passed as
an extra finite layer, only as the medium the sphere is embedded in. This is
a thin, direct wrapper around treams-rs's native multilayer Mie solution; no
scattering physics is reimplemented here.

For each requested wavelength, the vacuum wavenumber is `k0 = 2*pi/wavelength`
and a fresh T-matrix is constructed and its
`average_cross_sections` property is read, which gives the rotationally and
polarization-averaged scattering and extinction cross sections; absorption is
obtained from the same object as `extinction - scattering`.

## Units and conventions

- All lengths (radii, wavelengths) are in micrometers; cross sections are
  therefore returned in square micrometers.
- `epsilon_layers` entries are `[real, imag]` relative permittivities, one per
  layer, ordered from the innermost core outward, matching the order of
  `radii` (strictly increasing outer boundaries of each layer).
- `epsilon_medium` is the (real, non-absorbing) relative permittivity of the
  exterior embedding medium; magnetic permeability defaults to 1 and
  chirality to 0 for every layer and the medium (isotropic, achiral,
  non-magnetic case), matching the task's stated defaults.
- `lmax` is the maximum spherical multipole degree used for the T-matrix
  expansion.
- Results are returned as three lists, one entry per wavelength, in the same
  order as the input `wavelengths` list.

## Checks performed

- **Homogeneous limit**: shrinking the inner core radius to a negligible
  value (1e-6 um) while keeping the same permittivity as the outer shell
  reproduces, to machine precision, the cross sections of a single
  homogeneous sphere of the outer radius and shell permittivity built
  directly with `TMatrix.sphere(lmax, k0, [r_outer], [eps_shell,
  eps_medium])`. This validates that the multilayer construction correctly
  reduces to the single-sphere case.
- **Energy conservation**: for lossless materials (zero imaginary part in all
  layer permittivities), the computed absorption cross section is
  numerically zero (~1e-17, at floating-point round-off) and scattering
  equals extinction, as required by energy conservation for a
  non-absorbing scatterer in a non-absorbing medium.
- **lmax convergence**: for the example configuration, cross sections are
  already converged to ~4 significant figures at `lmax=4` and are
  indistinguishable from `lmax=8` onward (checked lmax = 2, 4, 6, 8, 10),
  confirming the multipole expansion is well converged for the requested
  geometry and wavelength range.
- **Positivity**: extinction ≥ scattering ≥ 0, so absorption ≥ 0 for the
  lossy example configuration at all three requested wavelengths.

## Example results (`results.json`)

For the example config (radii `[0.07, 0.12]` um, `epsilon_layers =
[[2.25, 0.03], [4, 0.06]]`, `epsilon_medium = 1.7689`, wavelengths
`[0.58, 0.7, 0.82]` um, `lmax = 4`):

| wavelength (um) | scattering (um^2) | extinction (um^2) | absorption (um^2) |
|---|---|---|---|
| 0.58 | 0.034316 | 0.037524 | 0.003208 |
| 0.70 | 0.018912 | 0.021170 | 0.002258 |
| 0.82 | 0.012136 | 0.013901 | 0.001765 |
