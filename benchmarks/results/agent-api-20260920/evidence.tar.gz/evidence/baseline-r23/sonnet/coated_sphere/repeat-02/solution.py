import json
import math
import sys

import treams_rs as t


def run(config):
    radii = config["radii"]
    epsilon_layers = config["epsilon_layers"]
    epsilon_medium = config["epsilon_medium"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    layer_materials = [complex(e[0], e[1]) for e in epsilon_layers]
    materials = layer_materials + [epsilon_medium]

    scattering = []
    extinction = []
    absorption = []
    for wl in wavelengths:
        k0 = 2.0 * math.pi / wl
        tm = t.TMatrix.sphere(lmax, k0, radii, materials)
        avg = tm.average_cross_sections
        scattering.append(avg.scattering)
        extinction.append(avg.extinction)
        absorption.append(avg.absorption)

    return {
        "wavelengths": list(wavelengths),
        "scattering_cross_section": scattering,
        "extinction_cross_section": extinction,
        "absorption_cross_section": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
