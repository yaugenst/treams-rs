# Core-Shell Sphere Spectrum

## Method

`solution.py` builds a concentric multilayer sphere T-matrix with
`treams_rs.TMatrix.sphere(lmax, k0, radii, materials)` for each requested
wavelength, then reads off the rotationally- and polarization-averaged
scattering, extinction and absorption cross sections from the
`average_cross_sections` property. No custom Mie/scattering math is
reimplemented; all numerics come from treams-rs.

- `radii`: strictly increasing outer boundaries of each layer, inside-out.
- `epsilon_layers`: one `[Re(eps), Im(eps)]` pair per layer, inside-out,
  combined into `complex(re, im)` for `treams_rs.Material`.
- `epsilon_medium`: the (real, non-absorbing) exterior permittivity, appended
  as the last entry of the `materials` list passed to `TMatrix.sphere` — the
  exterior is *not* one of the finite layers, matching the API convention
  that `materials` has one entry per layer *plus* the embedding medium.
- `mu = 1` and chirality `kappa = 0` throughout (default `Material` values),
  as specified for this problem.

## Units and conventions

- All lengths (radii) are in micrometers.
- Wavelengths are vacuum wavelengths in micrometers; the vacuum angular
  wavenumber is `k0 = 2*pi/wavelength` (inverse micrometers), as required by
  `TMatrix.sphere`.
- Permittivities, permeabilities and chirality are dimensionless
  (relative) quantities.
- Returned cross sections (`scattering`, `extinction`, `absorption`) are in
  squared length units (µm²), in the same order as the input `wavelengths`
  list.

## Checks performed

- Verified `scattering + absorption == extinction` exactly for every
  wavelength in the example config (energy balance from
  `CrossSections.absorption = extinction - scattering`).
- Verified qualitative Mie trends for the example config: scattering and
  extinction both decrease monotonically with increasing wavelength over the
  probed range, and absorption is a modest positive fraction of extinction,
  consistent with the lossy (`Im(eps) > 0`) layers.
- `run()` takes the full config dictionary and does not hard-code any
  example-specific values; it was executed via `python3 solution.py <
  example_config.json` and the output was saved to `results.json`.
