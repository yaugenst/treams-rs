"""Infer a homogeneous sphere radius from target scattering efficiencies.

Uses treams-rs's analytic Mie/T-matrix response together with its Advect
adapter for exact reverse-mode radius gradients (no finite differences in
the optimization loop).
"""

import json
import sys

import numpy as np
import advect
import treams_rs.advect as ta


def _qsca(radius, wavelength, epsilon, lmax):
    """Scattering efficiency of a lossless homogeneous sphere in vacuum."""
    k0 = 2.0 * np.pi / wavelength
    tmatrix = ta.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=epsilon, medium=1.0
    )
    # A sphere's response is rotationally degenerate in m, so a single plane
    # wave illumination already yields the orientation-averaged cross section.
    incident = ta.plane_wave((0.0, 0.0, 1.0), 0, k0=k0, medium=1.0)
    scattering = tmatrix.cross_sections(incident).scattering
    return scattering / (np.pi * radius**2)


def _make_loss(wavelengths, targets, epsilon, lmax):
    def loss(radius):
        terms = []
        for wavelength, target in zip(wavelengths, targets):
            q = _qsca(radius, wavelength, epsilon, lmax)
            terms.append(((q - target) / target) ** 2)
        return sum(terms) / len(terms)

    return loss


def run(config):
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    targets = [float(q) for q in config["target_efficiencies"]]
    initial_radius = float(config["initial_radius"])
    lo, hi = (float(b) for b in config["bounds"])

    loss = _make_loss(wavelengths, targets, epsilon, lmax)
    value_and_grad = advect.value_and_grad(loss)

    radius = min(max(initial_radius, lo), hi)
    initial_loss, _ = value_and_grad(radius)
    initial_loss = float(initial_loss)

    loss_history = [initial_loss]
    value = initial_loss
    grad = None
    step = 0.5 * (hi - lo) if hi > lo else 1.0
    max_iters = 500
    tol = 1e-10

    for _ in range(max_iters):
        value, grad = value_and_grad(radius)
        value = float(value)
        grad = float(grad)
        if value < tol:
            break

        trial_step = step
        candidate = min(max(radius - trial_step * grad, lo), hi)
        candidate_value = float(loss(candidate))
        backtracks = 0
        while candidate_value > value and backtracks < 40:
            trial_step *= 0.5
            candidate = min(max(radius - trial_step * grad, lo), hi)
            candidate_value = float(loss(candidate))
            backtracks += 1

        if candidate == radius:
            break

        radius = candidate
        step = trial_step * 1.5
        loss_history.append(candidate_value)
        value = candidate_value

    final_value, final_grad = value_and_grad(radius)
    final_value = float(final_value)
    final_grad = float(final_grad)
    if loss_history[-1] != final_value:
        loss_history.append(final_value)

    fitted_efficiencies = [
        float(_qsca(radius, wavelength, epsilon, lmax)) for wavelength in wavelengths
    ]

    return {
        "radius": radius,
        "loss": final_value,
        "initial_loss": initial_loss,
        "gradient": final_grad,
        "fitted_efficiencies": fitted_efficiencies,
        "loss_history": loss_history,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
