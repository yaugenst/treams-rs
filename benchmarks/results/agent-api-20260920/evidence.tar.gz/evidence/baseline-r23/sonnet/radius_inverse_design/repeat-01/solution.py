"""Infer a homogeneous sphere radius from target scattering efficiencies.

Fits the sphere radius (fixed epsilon, vacuum exterior, fixed lmax) so that the
Mie scattering efficiency Q_sca = sigma_sca / (pi r^2) at a set of wavelengths
matches supplied target efficiencies, minimizing
mean(((Q - target) / target) ** 2) via gradient descent using treams-rs's
analytic (Advect) radius derivative.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import advect as ad
import advect.numpy as anp
from treams_rs import advect as tadv


def _qsca(radius: "ad.numpy.TracedArray | np.ndarray", k0: float, epsilon: float, lmax: int):
    """Scattering efficiency of a homogeneous, lossless sphere at one k0."""
    tmatrix = tadv.sphere(lmax, k0, radius, [epsilon, 1.0])
    # Vacuum exterior: helicity wavenumber equals k0 for every mode.
    sigma_sca = 2 * np.pi / k0**2 * anp.sum(anp.abs(tmatrix) ** 2)
    return sigma_sca / (np.pi * radius[0] ** 2)


def run(config: dict) -> dict:
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = np.asarray(config["wavelengths"], dtype=float)
    initial_radius = float(config["initial_radius"])
    lo, hi = (float(b) for b in config["bounds"])
    targets = np.asarray(config["target_efficiencies"], dtype=float)
    k0s = 2 * np.pi / wavelengths

    def loss_fn(r):
        qs = anp.stack([_qsca(r, float(k0), epsilon, lmax) for k0 in k0s])
        return anp.mean(((qs - targets) / targets) ** 2)

    r = np.array([np.clip(initial_radius, lo, hi)])
    value, gradient = ad.value_and_grad(loss_fn)(r)
    initial_loss = float(value)
    loss_history = [float(value)]

    step = 0.01
    max_iters = 500
    for _ in range(max_iters):
        if value < 1e-9:
            break
        t = step
        for _ in range(60):
            r_new = np.clip(r - t * gradient, lo, hi)
            value_new = float(loss_fn(r_new))
            if value_new < value:
                break
            t *= 0.5
        else:
            break
        r = r_new
        value = value_new
        loss_history.append(value)
        value, gradient = ad.value_and_grad(loss_fn)(r)

    final_radius = float(r[0])
    fitted_efficiencies = [
        float(_qsca(r, float(k0), epsilon, lmax)) for k0 in k0s
    ]

    return {
        "radius": final_radius,
        "loss": float(value),
        "initial_loss": initial_loss,
        "gradient": float(gradient[0]),
        "fitted_efficiencies": fitted_efficiencies,
        "loss_history": loss_history,
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
