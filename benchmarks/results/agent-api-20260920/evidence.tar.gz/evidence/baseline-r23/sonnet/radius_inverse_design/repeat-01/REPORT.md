# Radius inverse design: fitting a sphere radius to target scattering efficiencies

## Task
Given a homogeneous, lossless sphere of fixed relative permittivity `epsilon`
(mu = 1, chirality = 0, vacuum exterior) and a fixed spherical-multipole cutoff
`lmax`, find the radius that reproduces a set of measured scattering
efficiencies `Q_sca(wavelength)` as closely as possible, minimizing

    loss(r) = mean( ((Q_sca(r, wavelength_i) - target_i) / target_i)^2 )

starting from `initial_radius` and respecting `bounds = [lo, hi]`.

## Units and conventions
- All lengths (radius, wavelength) are in micrometers.
- `epsilon` is the relative (dimensionless) permittivity of the sphere;
  the exterior is vacuum (epsilon = 1, mu = 1).
- The vacuum wavenumber is `k0 = 2*pi/wavelength`.
- The scattering efficiency is the usual Mie-theory dimensionless quantity
  `Q_sca = sigma_sca / (pi * r^2)`, the scattering cross section normalized
  by the geometric cross section.

## Numerical method (treams-rs)
- The homogeneous-sphere T-matrix is built with the differentiable
  `treams_rs.advect.sphere(lmax, k0, radii, epsilon_layers)` adapter, which
  wraps the native Mie T-matrix construction (`treams_rs.diff.sphere`) with a
  first-order VJP through the `advect` autodiff library. `radii` is a
  1-element array `[r]`, and `epsilon_layers = [epsilon, 1.0]` describes one
  homogeneous layer (the sphere) embedded in vacuum.
- The rotationally/polarization-averaged scattering cross section is
  computed from the helicity T-matrix `T` exactly as
  `treams_rs.TMatrix.xs_sca_avg` does for a vacuum exterior (where every mode
  shares the same wavenumber `k0`):

      sigma_sca = 2*pi/k0^2 * sum_ij |T_ij|^2  (squared Frobenius norm)

  This is evaluated with `advect.numpy` operations so that the whole
  `Q_sca(r)` pipeline stays inside the autodiff trace.
- `advect.value_and_grad` differentiates `loss(r)` through the native T-matrix
  pullback, giving the exact analytic gradient `d(loss)/dr` — no finite
  differences are used to supply the optimization step.
- Optimization: gradient descent with a simple backtracking line search
  (halve the step until the loss decreases), clipping `r` into `bounds` after
  every step, starting at `initial_radius`. Iteration stops once
  `loss < 1e-9` or the line search can no longer find a strictly decreasing,
  in-bounds step (e.g. because the true minimum lies at or beyond a bound).

## Checks performed
- Analytic gradient validated against a central finite difference of `Q_sca`
  with respect to `r` (relative agreement to ~1e-8) during development.
- Verified recovery of a known planted radius: generating synthetic targets
  from a chosen `r_true` (different `epsilon`, `lmax`, and wavelength grid
  than the example) and confirming the optimizer converges back to `r_true`
  with `loss < 1e-9`.
- Confirmed the routine is not specialized to the example: it was re-run with
  different `epsilon`, `lmax`, wavelengths, `initial_radius`, and `bounds`,
  and with a target set requiring the optimum to sit at a bound (in which
  case the optimizer stops cleanly at the bound instead of diverging).

## Example result
For the supplied example config (`epsilon=4.0`, `lmax=3`,
`wavelengths=[0.58, 0.69, 0.81]`, `initial_radius=0.075`,
`bounds=[0.06, 0.14]`), the optimizer converges to

    radius ≈ 0.10999914 um,  loss ≈ 9.9e-10  (< 1e-7 requirement)

in 22 gradient steps; see `results.json` for the full output including
`fitted_efficiencies`, the final `gradient`, and `loss_history`.
