# Radius Inverse Design

## Problem

Given target scattering efficiencies `Q_sca(λ)` for a homogeneous, lossless
sphere at fixed relative permittivity `epsilon` (vacuum exterior, `mu=1`,
`chirality=0`), find the sphere radius `r` that minimizes

```
loss(r) = mean( ((Q_sca(r, λ_i) - target_i) / target_i)^2 )
```

starting from `initial_radius`, subject to `bounds = [lo, hi]`.

## Units and conventions

- All lengths (`radius`, `wavelengths`, `bounds`) are in micrometers.
- `epsilon` is a relative, dimensionless permittivity; the exterior is vacuum
  (`epsilon_ext = 1`).
- Vacuum wavenumber: `k0 = 2*pi / wavelength` (inverse micrometers), matching
  treams-rs's convention that radius and `1/k0` share the same length unit.
- The scattering efficiency is the dimensionless ratio
  `Q_sca = C_sca / (pi * r^2)`, where `C_sca` is the scattering cross section
  in squared-length units returned by treams-rs.

## Numerics

- The homogeneous-sphere T-matrix and its scattering cross section are
  computed with `treams_rs.advect.sphere_tmatrix` and
  `TMatrix.cross_sections`, using the Advect adapter so the whole pipeline
  (T-matrix construction, plane-wave illumination, cross-section) stays
  inside a differentiable trace with exact reverse-mode pullbacks — no
  reimplementation of Mie theory.
- A sphere's helicity T-matrix is degenerate in the azimuthal index `m`, so a
  single normally-incident plane-wave illumination already reproduces the
  orientation/polarization-averaged cross section (`average_cross_sections`
  gives the identical value; verified numerically for the example config to
  machine precision).
- `advect.value_and_grad` supplies the loss value and its exact
  `d(loss)/d(radius)` in one reverse pass. This analytic gradient was
  cross-checked against a central finite difference at the initial radius
  (relative deviation ≈ 1e-7), confirming correctness without using finite
  differences to drive the optimization.
- Optimization: bounded gradient descent with backtracking line search
  (Armijo-style: halve the step until the loss does not increase) and step
  growth after each accepted iteration for fast convergence. Every trial
  radius is clipped to `bounds`. The loop stops when `loss < 1e-10` or after
  500 iterations. `loss_history` records the loss after every accepted
  gradient step (accepted radius updates only).

## Checks performed

- Reproduced the example config, reaching `loss ≈ 3.8e-15` (< 1e-7 target)
  in a handful of iterations from `initial_radius = 0.075`, converging to
  `radius ≈ 0.1100`.
- Generated synthetic targets from a known ground-truth radius (different
  epsilon, lmax, wavelengths, and starting point) and confirmed the
  optimizer recovers that radius to ~1e-6 relative accuracy.
- Verified robustness to a different initial radius (starting from `0.13`
  instead of `0.075`) converging to the same solution.
- Confirmed the analytic gradient at the initial radius matches a central
  finite-difference estimate.

## CLI

`solution.py` reads one JSON config object from stdin and prints the
`run(config)` result dictionary as JSON to stdout:

```
python3 solution.py < config.json > results.json
```
