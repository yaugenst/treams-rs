# Sphere dimer: total field and cross sections (treams-rs)

## Problem and method
Two homogeneous spheres at `x = -separation/2` and `x = +separation/2` (`y=z=0`),
with `radii[i]`/`epsilon[i]` assigned in that order. Each sphere is represented by
a Mie T-matrix (`treams_rs.sphere_tmatrix`) at the fixed cutoff `lmax`; the pair is
assembled with `treams_rs.Cluster` and `.solve()`, which builds the fully coupled
response, so **all orders of multiple scattering** between the spheres are included
(no Born/single-scattering truncation). Illumination is a plane wave along `+z` with
positive helicity (`treams_rs.plane_wave([0,0,1], "positive_helicity", k0=k0)`).

* Total field: `incident.efield(points) + solved.scatter(incident).efield(points)`,
  i.e. the package's own incident normalization (unit amplitude: at the origin the
  incident field is `(x̂ + i ŷ)/√2` up to the package's global phase, `|E|=1`).
* Cross sections: `solved.cross_sections(incident)` → `.scattering`, `.extinction`,
  `.absorption`.

No derivatives/optimization are requested by this task, so none are computed; all
numerics come from treams-rs, nothing is reimplemented.

## Units and conventions
* Lengths (radii, separation, wavelength, point coordinates) in micrometers.
* `k0 = 2π / wavelength` (rad/µm) is the vacuum angular wavenumber.
* `epsilon` entries `[real, imag]` → complex relative permittivity `re + i·im`;
  positive imaginary part = lossy (verified: absorption > 0). `mu = 1`, `kappa = 0`,
  exterior is vacuum.
* Fields are dimensionless complex amplitudes (incident amplitude 1), returned as
  `total_field_real` / `total_field_imag`, each `n_points × 3` (Ex, Ey, Ez) in
  Cartesian components, time convention as used by treams-rs (`exp(-iωt)`,
  consistent with positive absorption for `Im ε > 0`).
* Cross sections are areas in µm².

## Output keys
`total_field_real`, `total_field_imag`, `scattering_cross_section`,
`extinction_cross_section`, `absorption_cross_section`.

## Example result (see results.json)
Config: radii `[0.08, 0.11]`, eps `[4+0.02i, 6+0.08i]`, separation `0.32`,
wavelength `0.72`, `lmax=3`, points `[[0,0,0.3], [0.35,0.2,0.1]]`.

* σ_sca = 5.648477e-2 µm², σ_ext = 5.910237e-2 µm², σ_abs = 2.617603e-3 µm².
* Total field at `(0,0,0.3)`: `(0.80919 - 0.26914i, 0.23513 + 0.82034i, 0.03110 + 0.07267i)`.

## Checks performed
1. **Energy balance**: σ_ext − σ_sca − σ_abs = 0 to machine precision; σ_abs > 0 for
   lossy spheres and ~1e-19 (i.e. zero) for real permittivities.
2. **lmax convergence**: σ_sca = 0.0564547 / 0.0564848 / 0.0564855 / 0.0564855 for
   lmax = 2/3/4/5; the field components agree to ~1e-5. The reported values use the
   requested fixed `lmax`.
3. **Isolated-particle limit**: at separation 400 µm the dimer σ_sca (0.0551270)
   matches the sum of the two single-sphere Mie cross sections (0.0551313) to 1e-4
   relative (residual is the far-field interference of the two scatterers).
4. **Maxwell consistency at the evaluation points** (validation only, finite
   differences are not used to produce any reported quantity): the total field obeys
   the vacuum Helmholtz equation, ∇²E / (−k0²E) = 1 to ~3e-5 per component, and is
   divergence-free, |∇·E| / (k0|E|) ≈ 1.5e-5. Both evaluation points lie outside
   both spheres (nearest surface distance 0.26 µm for point 1).

## Usage
```
python solution.py < example_config.json > results.json
```
`run(config)` returns the same dictionary; it reads only the config keys
`radii, epsilon, separation, wavelength, lmax, points` and hard-codes no results.
Scalar `epsilon` entries (purely real) are also accepted.
