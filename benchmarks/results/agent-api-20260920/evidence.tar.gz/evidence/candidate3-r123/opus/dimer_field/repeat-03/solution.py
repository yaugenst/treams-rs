"""Two-sphere (dimer) electromagnetic scattering with treams-rs.

Geometry: spheres at x = -separation/2 and x = +separation/2 (y = z = 0),
radii and permittivities given in that order. Illumination is a plane wave
propagating along +z with positive helicity. All multiple scattering between
the spheres is included exactly at the fixed multipole cutoff lmax.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def _complex_eps(entry):
    """Convert an [real, imag] pair (or a scalar) to a complex permittivity."""
    if isinstance(entry, (list, tuple)):
        re, im = (list(entry) + [0.0])[:2]
        return complex(float(re), float(im))
    return complex(entry)


def run(config):
    radii = [float(r) for r in config["radii"]]
    epsilon = [_complex_eps(e) for e in config["epsilon"]]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float).reshape(-1, 3)

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um

    positions = [[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]]
    particles = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=tr.Material(eps))
        for r, eps in zip(radii, epsilon)
    ]

    cluster = tr.Cluster(particles, positions=positions)
    solved = cluster.solve()  # full multiple-scattering (coupled) response

    incident = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)

    cross = solved.cross_sections(incident)
    total = incident.efield(points) + solved.scatter(incident).efield(points)
    total = np.asarray(total).reshape(-1, 3)

    return {
        "total_field_real": np.real(total).tolist(),
        "total_field_imag": np.imag(total).tolist(),
        "scattering_cross_section": float(cross.scattering),
        "extinction_cross_section": float(cross.extinction),
        "absorption_cross_section": float(cross.absorption),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
