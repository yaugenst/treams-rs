"""Two-sphere (dimer) scattering with treams-rs.

Full multiple scattering at fixed lmax; total field = incident + scattered.
Lengths in micrometers, materials relative/dimensionless.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def _material(eps):
    re, im = eps
    return tr.Material(complex(float(re), float(im)))


def run(config):
    radii = [float(r) for r in config["radii"]]
    eps = config["epsilon"]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float).reshape(-1, 3)

    k0 = 2.0 * np.pi / wavelength

    positions = [[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]]
    particles = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=_material(e))
        for r, e in zip(radii, eps)
    ]

    system = tr.Cluster(particles, positions=positions)
    response = system.solve()  # includes all multiple scattering

    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    cross = response.cross_sections(incident)

    scattered = response.scatter(incident)
    total = np.asarray(incident.efield(points)) + np.asarray(scattered.efield(points))

    return {
        "total_field_real": np.real(total).tolist(),
        "total_field_imag": np.imag(total).tolist(),
        "scattering_cross_section": float(np.real(cross.scattering)),
        "extinction_cross_section": float(np.real(cross.extinction)),
        "absorption_cross_section": float(np.real(cross.absorption)),
    }


def main():
    print(json.dumps(run(json.load(sys.stdin))))


if __name__ == "__main__":
    main()
