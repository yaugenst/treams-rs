"""Two-sphere (dimer) multiple-scattering fields and cross sections with treams-rs.

Lengths in micrometers, permittivities/permeabilities/chirality dimensionless,
exterior vacuum, mu=1, kappa=0 unless specified.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def _material(eps):
    """Build a Material from an [real, imag] permittivity entry."""
    if np.isscalar(eps):
        value = complex(eps)
    else:
        re, im = eps
        value = complex(re, im)
    return tr.Material(value)


def run(config):
    radii = [float(r) for r in config["radii"]]
    epsilon = list(config["epsilon"])
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float).reshape(-1, 3)

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um

    positions = [[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]]
    particles = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=_material(e))
        for r, e in zip(radii, epsilon)
    ]

    cluster = tr.Cluster(particles, positions=positions)
    solved = cluster.solve()  # full multiple scattering at fixed lmax

    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    cross = solved.cross_sections(incident)

    total = np.asarray(incident.efield(points)) + np.asarray(
        solved.scatter(incident).efield(points)
    )

    return {
        "total_field_real": np.real(total).tolist(),
        "total_field_imag": np.imag(total).tolist(),
        "scattering_cross_section": float(np.real(cross.scattering)),
        "extinction_cross_section": float(np.real(cross.extinction)),
        "absorption_cross_section": float(np.real(cross.absorption)),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
