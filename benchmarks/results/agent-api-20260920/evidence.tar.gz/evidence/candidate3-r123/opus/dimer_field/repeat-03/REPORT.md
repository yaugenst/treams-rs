# Dimer scattering with treams-rs

## What is computed
Two homogeneous spheres in vacuum at `x = -separation/2` and `x = +separation/2`
(`y = z = 0`), with `radii[i]` and `epsilon[i]` taken in that order. Each sphere
is represented by its Mie T-matrix (`treams_rs.sphere_tmatrix`) truncated at the
given `lmax`; the two are assembled with `treams_rs.Cluster` and `.solve()`,
which inverts the full coupled system and therefore contains **all orders of
multiple scattering** between the spheres at that cutoff (no Born/single-scattering
approximation).

Illumination: `plane_wave([0,0,1], "positive_helicity", k0)` — propagation along
+z, positive helicity, using the package's own incident normalization
(|E_inc| = 1, with E_y = i·E_x at the origin, E_z = 0).

Outputs:
- `total_field_real`, `total_field_imag`: `(npoints, 3)` lists of the Cartesian
  components of the **total** field `E_inc(r) + E_scat(r)`, split into real and
  imaginary parts (time convention of the package, `exp(-iωt)`).
- `scattering_cross_section`, `extinction_cross_section`,
  `absorption_cross_section`: scalars from `solved.cross_sections(incident)`,
  i.e. the cluster cross sections for this illumination.

## Units and conventions
- All lengths (radii, separation, wavelength, point coordinates) are in
  micrometers; `k0 = 2π/wavelength` in µm⁻¹.
- `epsilon` entries are `[real, imag]` relative permittivities (dimensionless);
  `mu = 1`, `kappa = 0`, exterior is vacuum, as specified.
- Cross sections are areas in µm².
- Fields are dimensionless relative to the unit-amplitude incident plane wave.

## Checks performed (example config)
- **Energy balance**: `extinction - scattering - absorption = 0.0` exactly
  (to double precision) for the example.
- **Multipole convergence**: raising `lmax` from 3 → 6 changes the scattering
  cross section by ~1.3·10⁻⁶ relative and the total field by ≤3·10⁻⁵ in absolute
  amplitude, so the requested `lmax = 3` result is well converged. Results are
  reported at the `lmax` given in the config, as required.
- **Isolated-sphere limit**: pushing `separation` to 200 µm gives extinction
  0.0578379 µm² versus the sum of the two single-sphere Mie extinctions
  0.0578460 µm² (0.014 % apart, the residual being genuine far-field
  interference at finite separation).
- **Incident normalization/helicity**: at the origin the incident field is
  `(0.6124 - 0.3536i, 0.3536 + 0.6124i, 0)`, i.e. unit amplitude, transverse
  (E_z = 0) and satisfying `E_y = i E_x`, confirming positive helicity along +z.

## Example results (`results.json`)
| quantity | value (µm²) |
|---|---|
| scattering | 0.0564847714533833 |
| extinction | 0.0591023741553155 |
| absorption | 0.0026176027019322 |

Total field:
- at `(0, 0, 0.3)`: `(0.80919 - 0.26914i, 0.23513 + 0.82034i, 0.03110 + 0.07267i)`
- at `(0.35, 0.2, 0.1)`: `(-0.22645 - 0.60503i, 0.52804 - 0.43737i, -0.02124 - 0.12125i)`

## Usage
```
python solution.py < config.json > results.json
```
or `from solution import run; run(config_dict)`. No derivatives or optimization
are requested by this task, so none are computed; all numerics come from
treams-rs public API (`sphere_tmatrix`, `Material`, `Cluster`, `plane_wave`).
