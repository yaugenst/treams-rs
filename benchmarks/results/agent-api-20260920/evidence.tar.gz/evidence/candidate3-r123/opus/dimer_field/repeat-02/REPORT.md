# Two-sphere (dimer) scattering with treams-rs

## What is computed
Two homogeneous spheres are placed at `x = -separation/2` and `x = +separation/2`
(`y = z = 0`), with `radii[i]`, `epsilon[i]` taken in that order (`mu = 1`,
`kappa = 0`, vacuum exterior). Each sphere is described by a Mie T-matrix
(`treams_rs.sphere_tmatrix`) truncated at the fixed `lmax` from the config.
The pair is assembled with `treams_rs.Cluster(...)` and `.solve()`, which builds
the fully coupled (all orders of multiple scattering) cluster response; no
Born/single-scattering approximation is made.

Illumination is a plane wave travelling along `+z` with positive helicity,
`treams_rs.plane_wave([0,0,1], "positive_helicity", k0=2*pi/wavelength)`.

Outputs:
- `total_field_real`, `total_field_imag`: `(len(points), 3)` lists giving the
  Cartesian components of the **total** field
  `E_tot = incident.efield(points) + response.scatter(incident).efield(points)`,
  in the package's incident normalization (see below).
- `scattering_cross_section`, `extinction_cross_section`,
  `absorption_cross_section`: scalars from `response.cross_sections(incident)`.

## Units and conventions
- Lengths (radii, separation, wavelength, point coordinates) are in micrometers;
  cross sections are therefore in µm².
- `k0 = 2*pi/wavelength` is the vacuum angular wavenumber (µm⁻¹).
- `epsilon` entries are `[real, imag]` relative permittivities; a positive
  imaginary part is lossy in this convention (absorption comes out positive).
- Incident normalization is that of `treams_rs.plane_wave`: unit electric-field
  amplitude, `|E_inc| = 1`, with the spatial phase `exp(+i k0 z)` and the
  positive-helicity polarization vector `(x̂ + i ŷ)/√2` (verified numerically).
  Fields are complex phasors; the time convention is `exp(-i ω t)`. Returned
  field values are dimensionless relative to that unit incident amplitude.
- Field points are evaluated in the global (cluster) coordinate frame and are
  assumed to lie outside both spheres, where the outgoing multipole expansion
  converges. For the example config the two points are at distances 0.340 and
  0.552 / 0.283 µm from the sphere centres, comfortably outside the 0.08 and
  0.11 µm radii.

## Checks performed (example config)
- **Energy balance:** `extinction - scattering - absorption = 0.0` (exactly at
  double precision), and absorption > 0 as expected for lossy epsilon.
- **Multipole convergence:** repeating the calculation at `lmax = 2…6` gives
  cross sections 0.056455, 0.0564848, 0.0564855, 0.0564855, 0.0564855 µm²
  (scattering); the total field changes by < 3e-5 in absolute amplitude between
  `lmax = 3` and `lmax = 6`, so the requested `lmax = 3` is converged to ~1e-4
  relative. The reported result uses the `lmax` given in the config.
- **Independent-scatterer limit:** setting `separation = 200 µm` reproduces the
  sum of the two isolated-sphere cross sections to ~1e-4 relative
  (0.055123 vs 0.055131 µm² scattering), confirming the cluster coupling and
  the translation/positioning are consistent.
- **Incident field:** sampled directly, confirming unit amplitude, the
  `exp(+i k0 z)` phase progression and the `(1, i, 0)/√2` helicity vector.

## Results for the example config
See `results.json`. Cross sections: scattering 5.6485e-2 µm²,
extinction 5.9102e-2 µm², absorption 2.6176e-3 µm².

## Usage
```
python solution.py < config.json   # prints the result dictionary as JSON
```
or `from solution import run; run(config_dict)`. All inputs are read from the
config; nothing is hard-coded. No derivatives or optimization are requested by
this task, so none are computed.
