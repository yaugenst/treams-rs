# Core-shell sphere spectrum (treams-rs)

## What is computed
For each wavelength, a concentric multilayer T-matrix is built with
`treams_rs.TMatrix.sphere(lmax, k0, radii, materials)` and the
rotationally- and polarization-averaged cross sections are read from
`tm.average_cross_sections` (scattering, extinction, absorption).
No scattering physics is reimplemented here.

## Conventions
- **Lengths**: micrometers. `k0 = 2*pi/lambda_vac` is the vacuum angular
  wavenumber in 1/µm, so radii and 1/k0 share the same unit.
- **Cross sections**: µm² (squared length units of the radii).
- **Layers**: `radii` are increasing *outer* boundaries and `epsilon_layers`
  gives one `[real, imag]` relative permittivity per layer, ordered
  inside-out. `len(radii) == len(epsilon_layers)`.
- **Exterior**: `epsilon_medium` is passed as the trailing entry of the
  `materials` sequence, which `TMatrix.sphere` interprets as the surrounding
  medium — it is *not* appended as an extra finite layer, and it consumes no
  radius. The exterior is real-valued (non-absorbing), as required by the
  rotational averages.
- **Defaults**: `mu = 1`, `kappa = 0` for every layer and for the exterior
  (overridable through optional `mu_layers`, `kappa_layers`, `mu_medium`,
  `kappa_medium` keys). Permittivities, permeabilities and chirality are
  relative/dimensionless; complex convention follows treams-rs, with a
  positive imaginary epsilon meaning loss.
- **Averages**: `average_cross_sections` is the average over incidence
  directions and over both polarizations (unpolarized illumination), i.e. the
  orientation-averaged response of a single sphere at the origin.
- Output lists are in the same order as the input `wavelengths`.

## Example configuration and result
radii `[0.07, 0.12]` µm, epsilon `[2.25+0.03j, 4+0.06j]` inside-out,
exterior epsilon `1.7689` (n = 1.33), lmax 4, at 0.58 / 0.70 / 0.82 µm
(see `results.json`):

| lambda (µm) | sigma_sca (µm²) | sigma_ext (µm²) | sigma_abs (µm²) |
|---|---|---|---|
| 0.58 | 3.43159e-2 | 3.75238e-2 | 3.20791e-3 |
| 0.70 | 1.89125e-2 | 2.11702e-2 | 2.25770e-3 |
| 0.82 | 1.21357e-2 | 1.39011e-2 | 1.76539e-3 |

## Checks performed
1. **Energy balance**: `sigma_abs = sigma_ext - sigma_sca > 0` at every
   wavelength, and `sigma_ext > sigma_sca` throughout.
2. **Multipole convergence**: recomputing the example at lmax = 2, 3, 4, 6, 10
   gives sigma_sca(0.58 µm) = 3.429186e-2, 3.431586e-2, 3.431592e-2,
   3.4315923e-2, 3.4315923e-2. lmax = 4 is converged to ~1e-6 relative; the
   result is stable to machine level by lmax = 6.
3. **Degenerate-layer limit**: setting both layers to the same permittivity
   (4+0.06j) reproduces the homogeneous sphere of radius 0.12 µm computed with
   `treams_rs.sphere_tmatrix` to ~1e-15 relative (sca 5.268818379388e-2 both).
4. **Lossless limit**: with real permittivities in both layers the absorption
   returns 0 to within 3e-17 µm².
5. **Rotational average**: an independent Gauss-Legendre (20x20) angular
   quadrature of `tm.cross_sections(plane_wave(...))` over both helicities
   reproduces `average_cross_sections` to 8 significant digits.

## Usage
```
python solution.py < config.json > results.json
```
or `from solution import run; run(config)`. No derivatives/optimization are
requested by this task, so none are computed.
