# Core-shell sphere spectrum (treams-rs)

`solution.py` exposes `run(config) -> dict` and a CLI that reads one JSON config
dict from stdin and prints the result dict as JSON to stdout:

```
python solution.py < example_config.json > results.json
```

## Physical setup

A concentric multilayer sphere in a homogeneous, nonabsorbing exterior,
illuminated by plane waves. For each vacuum wavelength the T-matrix is built
with `treams_rs.multilayer_sphere_tmatrix(k0=2*pi/lambda, lmax=..., radii=...,
materials=..., medium=...)` and the rotationally and polarization-averaged cross
sections are read from the `average_cross_sections` property
(`scattering`, `extinction`, and `absorption = extinction - scattering`).

## Units and conventions

- Lengths (`radii`, `wavelengths`) are in micrometers; cross sections are
  therefore in um^2. Wavelengths are **vacuum** wavelengths; the vacuum
  wavenumber is `k0 = 2*pi/lambda` in 1/um.
- `epsilon_layers` gives one relative permittivity per layer, **inside-out**,
  each as `[real, imag]` (a bare scalar is also accepted). The `exp(-i omega t)`
  convention is used, so a positive imaginary part means loss; the example
  layers give positive absorption, as expected.
- `radii` are increasing **outer** boundaries of the layers, so
  `len(radii) == len(epsilon_layers)`. The exterior is **not** appended as an
  extra finite layer: it is passed separately as `medium` from
  `epsilon_medium` (here 1.7689, i.e. refractive index 1.33, water).
- Defaults follow the task statement: `mu = 1`, `kappa = 0`, vacuum exterior if
  `epsilon_medium` is absent. Optional keys `mu_layers`, `kappa_layers`,
  `mu_medium` and `polarization` ("helicity", default, or "parity") are honored
  if present.
- Cross sections are averaged over orientation and incident polarization, which
  for a sphere equals the value for any single plane-wave illumination.
- Outputs `scattering`, `extinction`, `absorption` are lists in the same order
  as the input `wavelengths`. Efficiencies (cross section divided by the
  geometric cross section `pi * r_outer^2`) and the size parameters
  `2*pi*n_medium*r_outer/lambda` are reported alongside for convenience.

## Results for the example config

| lambda (um) | C_sca (um^2) | C_ext (um^2) | C_abs (um^2) |
|---|---|---|---|
| 0.58 | 3.431592e-02 | 3.752383e-02 | 3.207911e-03 |
| 0.70 | 1.891246e-02 | 2.117016e-02 | 2.257697e-03 |
| 0.82 | 1.213568e-02 | 1.390107e-02 | 1.765386e-03 |

Full output is in `results.json`.

## Checks performed

1. **Multipole convergence.** At 0.58 um, C_sca changes by 7e-8 relative from
   lmax=3 to 4 and by <1e-9 from lmax=5 to 8; the requested lmax=4 is
   converged to ~1e-6 relative. (The size parameter is only ~1.7.)
2. **Basis independence.** `polarization="parity"` reproduces the helicity-basis
   cross sections to ~1e-16 relative.
3. **Lossless limit.** Setting both Im(eps) to zero gives absorption of order
   1e-17 um^2, i.e. zero to machine precision — the optical theorem balance
   C_ext = C_sca holds.
4. **Degenerate-layer limit.** Using the same material in both layers reproduces
   the homogeneous-sphere result from `treams_rs.sphere_tmatrix` with
   radius 0.12 um to 15 digits, confirming the inside-out layer ordering and
   that the medium is not treated as a finite layer.
5. **Plane-wave consistency.** `cross_sections` for an explicit axial plane wave
   in the exterior medium matches `average_cross_sections` to 1e-16 relative,
   as required by spherical symmetry.
6. **Input validation.** Mismatched `radii`/`epsilon_layers` lengths (the common
   mistake of appending the exterior), non-increasing or nonpositive radii,
   nonpositive wavelengths, and an absorbing exterior (for which averaged cross
   sections are undefined) raise clear errors.

No derivatives or optimization were requested, so no sensitivity machinery is
used; all numerics come from treams-rs.
