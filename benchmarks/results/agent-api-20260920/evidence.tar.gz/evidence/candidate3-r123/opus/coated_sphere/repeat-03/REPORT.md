# Core-shell sphere cross-section spectrum (treams-rs)

## What is computed
For each wavelength, the T-matrix of a concentric multilayer sphere is built with
`treams_rs.multilayer_sphere_tmatrix` and the rotationally and polarization-averaged
scattering, extinction and absorption cross sections are read from
`TMatrix.average_cross_sections`. No Mie code is reimplemented.

## Units and conventions
- **Lengths**: micrometers. `radii` and `wavelengths` are in um, cross sections in um^2.
- **Wavenumber**: the vacuum wavenumber `k0 = 2*pi/lambda` (1/um) is passed to treams;
  the exterior index enters through `medium`, not through `k0`.
- **Materials**: dimensionless relative values. Each `epsilon_layers[i] = [real, imag]`
  becomes `real + 1j*imag`. With the `exp(-i omega t)` convention used here a
  **positive imaginary part is loss**, which is confirmed by the positive absorption
  obtained for the example.
- **Defaults**: `mu = 1`, `kappa = 0` for every layer and for the exterior;
  `epsilon_medium` defaults to vacuum (1). Optional keys `mu_layers`, `kappa_layers`,
  `mu_medium`, `kappa_medium` are honoured if present.
- **Layer ordering**: `radii` are increasing *outer* boundaries and `epsilon_layers`
  is inside-out, so layer *i* occupies `radii[i-1] < r < radii[i]` (core: `r < radii[0]`).
  The exterior is passed separately as `medium` and is **not** appended as a finite layer;
  the number of materials equals the number of radii.
- **Averaging**: `average_cross_sections` is the average over incidence directions and
  polarizations, i.e. the unpolarized/rotationally averaged cross section. It requires a
  lossless propagating exterior, which `epsilon_medium = 1.7689` (n = 1.33) satisfies.
- **Basis**: helicity polarization, `lmax` multipole orders (default 4). The averaged
  cross sections are basis-independent.

## Output
`run(config)` returns `wavelengths`, and `scattering`, `extinction`, `absorption` as
lists in the same order as the input wavelengths, plus `units`, `lmax`, `n_layers` and
the exterior refractive index. The CLI reads one JSON config on stdin and prints this
dictionary as JSON.

## Example result (radii 0.07/0.12 um, eps 2.25+0.03i / 4+0.06i, n_ext = 1.33, lmax 4)
| lambda (um) | C_sca (um^2) | C_ext (um^2) | C_abs (um^2) |
|---|---|---|---|
| 0.58 | 3.431592e-02 | 3.752383e-02 | 3.207911e-03 |
| 0.70 | 1.891246e-02 | 2.117016e-02 | 2.257697e-03 |
| 0.82 | 1.213568e-02 | 1.390107e-02 | 1.765386e-03 |

## Checks performed
1. **Energy balance**: `C_ext - C_sca - C_abs = 0` exactly (0.0 at double precision) at
   every wavelength.
2. **Multipole convergence**: going from `lmax = 4` to `lmax = 8` changes C_sca by
   < 3e-9 relative and C_abs by < 4e-5 relative; `lmax = 4` is already converged here.
3. **Homogeneous limit**: setting both layers to the same permittivity reproduces
   `sphere_tmatrix` for a single 0.12 um sphere to ~1e-15 relative — confirms the
   layer/radius ordering and that the exterior is not double-counted.
4. **Lossless limit**: with real permittivities the absorption is 0 to round-off
   (|C_abs| < 3e-17), so the loss sign convention and the balance are consistent.
5. **Rayleigh limit**: a 5 nm sphere of eps = 4 in the n = 1.33 exterior gives
   C_sca = 4.9439e-10 um^2 versus the analytic dipole value
   `k^4 |alpha|^2 / (6 pi)` = 4.9420e-10 um^2 (0.04 % difference, the expected size
   of the neglected radiative correction), with `k = 2 pi n_ext / lambda`.

No derivatives or optimization are requested by this task, so none are computed.
