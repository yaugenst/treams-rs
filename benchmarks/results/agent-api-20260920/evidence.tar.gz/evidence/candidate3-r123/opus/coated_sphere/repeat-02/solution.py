"""Core-shell (multilayer) sphere spectrum with treams-rs.

Computes rotationally and polarization-averaged scattering, extinction and
absorption cross sections of a concentric multilayer sphere embedded in a
homogeneous dielectric exterior, for a list of vacuum wavelengths.

Lengths are in micrometers, so cross sections come out in um^2.
Permittivities, permeabilities and chirality are relative/dimensionless.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as treams


def _complex(value: Any) -> complex:
    """Accept a scalar or a ``[real, imag]`` pair as one complex number."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) != 2:
            raise ValueError(f"expected a scalar or [real, imag], got {value!r}")
        return complex(float(value[0]), float(value[1]))
    return complex(value)


def _material(eps: Any, mu: Any = 1.0, kappa: Any = 0.0) -> treams.Material:
    return treams.Material(_complex(eps), _complex(mu), _complex(kappa))


def _materials(config: dict, key: str, count: int, default: Any) -> list[complex]:
    values = config.get(key)
    if values is None:
        return [_complex(default)] * count
    values = list(values)
    if len(values) != count:
        raise ValueError(f"'{key}' must have {count} entries, got {len(values)}")
    return [_complex(v) for v in values]


def run(config: dict) -> dict:
    """Return averaged cross section spectra of a concentric multilayer sphere.

    Config keys: ``radii`` (increasing outer boundaries, um), ``epsilon_layers``
    (one ``[real, imag]`` permittivity per layer, inside-out), ``epsilon_medium``
    (exterior, real and nonabsorbing), ``wavelengths`` (vacuum, um) and ``lmax``.
    Optional: ``mu_layers``, ``kappa_layers``, ``mu_medium``, ``polarization``.
    """
    radii = [float(r) for r in config["radii"]]
    eps_layers = list(config["epsilon_layers"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config.get("lmax", 4))

    if len(radii) != len(eps_layers):
        raise ValueError(
            f"{len(radii)} radii but {len(eps_layers)} layer permittivities; "
            "the exterior must not be appended as a finite layer"
        )
    if len(radii) == 0:
        raise ValueError("at least one layer is required")
    if radii[0] <= 0.0 or any(b <= a for a, b in zip(radii, radii[1:])):
        raise ValueError(f"radii must be positive and strictly increasing: {radii}")
    if not wavelengths or any(w <= 0.0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")

    n_layers = len(radii)
    mu_layers = _materials(config, "mu_layers", n_layers, 1.0)
    kappa_layers = _materials(config, "kappa_layers", n_layers, 0.0)
    layers = [
        _material(e, m, k) for e, m, k in zip(eps_layers, mu_layers, kappa_layers)
    ]

    eps_medium = _complex(config.get("epsilon_medium", 1.0))
    mu_medium = _complex(config.get("mu_medium", 1.0))
    if abs(eps_medium.imag) > 1e-12 or abs(mu_medium.imag) > 1e-12:
        raise ValueError("the exterior must be nonabsorbing for cross sections")
    medium = _material(eps_medium, mu_medium)
    polarization = str(config.get("polarization", "helicity"))

    n_medium = float(np.sqrt((eps_medium * mu_medium).real))

    scattering, extinction, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength  # vacuum wavenumber, 1/um
        tmat = treams.multilayer_sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radii=radii,
            materials=layers,
            medium=medium,
            polarization=polarization,
        )
        xs = tmat.average_cross_sections
        scattering.append(float(xs.scattering))
        extinction.append(float(xs.extinction))
        absorption.append(float(xs.absorption))

    geometric = float(np.pi * radii[-1] ** 2)
    return {
        "wavelengths": wavelengths,
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "units": {
            "wavelengths": "um",
            "cross_sections": "um^2",
        },
        "geometry": {
            "radii": radii,
            "outer_radius": radii[-1],
            "geometric_cross_section": geometric,
            "n_layers": n_layers,
        },
        "efficiencies": {
            "scattering": [s / geometric for s in scattering],
            "extinction": [e / geometric for e in extinction],
            "absorption": [a / geometric for a in absorption],
        },
        "settings": {
            "lmax": lmax,
            "polarization": polarization,
            "epsilon_medium": [eps_medium.real, eps_medium.imag],
            "refractive_index_medium": n_medium,
            "size_parameters_outer": [
                2.0 * np.pi * n_medium * radii[-1] / w for w in wavelengths
            ],
        },
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
