"""Core-shell (concentric multilayer) sphere spectrum via treams-rs.

Lengths in micrometers, permittivities relative/dimensionless.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def _complex(value):
    """Accept a scalar, a [real, imag] pair, or a complex-like string."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0], 0.0)
        if len(value) != 2:
            raise ValueError(f"expected [real, imag], got {value!r}")
        return complex(value[0], value[1])
    return complex(value)


def _material(eps, mu, kappa):
    return tr.Material([_complex(eps), _complex(mu), _complex(kappa)])


def run(config):
    radii = [float(r) for r in config["radii"]]
    eps_layers = list(config["epsilon_layers"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config.get("lmax", 4))

    if len(radii) != len(eps_layers):
        raise ValueError("radii and epsilon_layers must have equal length")
    if any(b <= a for a, b in zip(radii, radii[1:])) or radii[0] <= 0:
        raise ValueError("radii must be positive and strictly increasing")

    n = len(radii)
    mu_layers = config.get("mu_layers", [1.0] * n)
    kappa_layers = config.get("kappa_layers", [0.0] * n)

    materials = [
        _material(e, m, k) for e, m, k in zip(eps_layers, mu_layers, kappa_layers)
    ]
    # The exterior is passed as the medium, never as an extra finite layer.
    medium = _material(
        config.get("epsilon_medium", 1.0),
        config.get("mu_medium", 1.0),
        config.get("kappa_medium", 0.0),
    )

    sca, ext, absn = [], [], []
    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl
        tm = tr.TMatrix.sphere(lmax, k0, radii, materials + [medium])
        xs = tm.average_cross_sections
        sca.append(float(xs.scattering))
        ext.append(float(xs.extinction))
        absn.append(float(xs.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering_cross_section": sca,
        "extinction_cross_section": ext,
        "absorption_cross_section": absn,
        "units": {"length": "micrometer", "cross_section": "micrometer^2"},
        "lmax": lmax,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
