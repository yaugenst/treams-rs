"""Core-shell (concentric multilayer) sphere cross-section spectrum via treams-rs.

Units: lengths in micrometers (radii, wavelengths); cross sections in um^2.
Materials are relative/dimensionless; epsilon entries are [real, imag] with
the exp(-i omega t) convention, so a positive imaginary part means loss.
"""

import json
import math
import sys

import treams_rs as treams


def _complex(value):
    """Accept a scalar, a complex, or a [real, imag] pair."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0], 0.0)
        if len(value) != 2:
            raise ValueError(f"expected [real, imag], got {value!r}")
        return complex(value[0], value[1])
    return complex(value)


def _material(epsilon, mu, kappa):
    return treams.Material([_complex(epsilon), _complex(mu), _complex(kappa)])


def _sequence_or_default(config, key, count, default):
    values = config.get(key)
    if values is None:
        return [default] * count
    if len(values) != count:
        raise ValueError(f"'{key}' must have {count} entries")
    return list(values)


def run(config):
    radii = [float(r) for r in config["radii"]]
    epsilon_layers = list(config["epsilon_layers"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config.get("lmax", 4))

    if len(radii) != len(epsilon_layers):
        raise ValueError("'radii' and 'epsilon_layers' must have equal length")
    if not radii:
        raise ValueError("at least one layer is required")
    if any(r <= 0.0 for r in radii):
        raise ValueError("radii must be positive")
    if any(b <= a for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing outer boundaries")
    if lmax < 1:
        raise ValueError("lmax must be at least 1")
    if not wavelengths or any(w <= 0.0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")

    # Optional non-default mu/kappa; defaults are mu=1, kappa=0.
    mu_layers = _sequence_or_default(config, "mu_layers", len(radii), 1.0)
    kappa_layers = _sequence_or_default(config, "kappa_layers", len(radii), 0.0)

    # The exterior is a half space, never one of the finite layers.
    medium = _material(
        config.get("epsilon_medium", 1.0),
        config.get("mu_medium", 1.0),
        config.get("kappa_medium", 0.0),
    )

    materials = [
        _material(eps, mu, kappa)
        for eps, mu, kappa in zip(epsilon_layers, mu_layers, kappa_layers)
    ]

    scattering, extinction, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength  # vacuum wavenumber, 1/um
        tmat = treams.multilayer_sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radii=radii,
            materials=materials,
            medium=medium,
            polarization="helicity",
        )
        # Rotationally (and polarization-) averaged cross sections, um^2.
        xs = tmat.average_cross_sections
        scattering.append(float(xs.scattering))
        extinction.append(float(xs.extinction))
        absorption.append(float(xs.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "units": {"length": "um", "cross_section": "um^2"},
        "lmax": lmax,
        "n_layers": len(radii),
        "medium_refractive_index": abs(
            (complex(medium()[0]) * complex(medium()[1])) ** 0.5
        ),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
