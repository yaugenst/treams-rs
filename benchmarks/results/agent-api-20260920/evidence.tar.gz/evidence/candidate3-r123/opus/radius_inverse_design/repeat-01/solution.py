"""Infer a homogeneous lossless sphere radius from target scattering efficiencies.

The forward model is Mie scattering evaluated with treams-rs; radius gradients
come from the Advect adapter's analytic reverse-mode pullbacks.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs.advect as tr

TOL_LOSS = 1e-7
TOL_GRAD = 1e-10
MAX_ITER = 200


def _efficiencies(radius, k0s, epsilon, lmax):
    """Scattering efficiencies Q = sigma_sca / (pi r^2), one per vacuum wavenumber."""
    out = []
    for k0 in k0s:
        tmat = tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)
        wave = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
        out.append(tmat.cross_sections(wave).scattering / (np.pi * radius**2))
    return out


def _make_loss(k0s, targets, epsilon, lmax):
    def loss(radius):
        total = 0.0
        for q, target in zip(_efficiencies(radius, k0s, epsilon, lmax), targets):
            total = total + ((q - target) / target) ** 2
        return total / len(targets)

    return loss


def _descend(loss_fn, r0, lo, hi):
    """Projected gradient descent with Barzilai-Borwein steps and Armijo backtracking."""
    value_and_grad = ad.value_and_grad(loss_fn)
    r = float(min(max(r0, lo), hi))
    val, grad = value_and_grad(r)
    val, grad = float(val), float(grad)
    history = [val]
    step = 0.1 * (hi - lo) / max(abs(grad), 1e-30)

    for _ in range(MAX_ITER):
        if val < TOL_LOSS or abs(grad) < TOL_GRAD:
            break
        trial_step = step
        improved = False
        for _ in range(60):
            cand = float(min(max(r - trial_step * grad, lo), hi))
            if cand == r:
                break
            cand_val, cand_grad = value_and_grad(cand)
            cand_val, cand_grad = float(cand_val), float(cand_grad)
            # Armijo condition on the actually taken (projected) step.
            if cand_val <= val - 1e-4 * grad * (r - cand):
                dr, dg = cand - r, cand_grad - grad
                r, val, grad = cand, cand_val, cand_grad
                history.append(val)
                # Barzilai-Borwein step for the next iteration.
                step = abs(dr / dg) if dg != 0.0 else trial_step
                step = min(max(step, 1e-12), 1e3)
                improved = True
                break
            trial_step *= 0.5
        if not improved:
            break
    return r, val, grad, history


def run(config):
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    targets = [float(q) for q in config["target_efficiencies"]]
    lo, hi = (float(b) for b in config["bounds"])
    r_init = float(config["initial_radius"])

    k0s = [2.0 * np.pi / w for w in wavelengths]
    loss_fn = _make_loss(k0s, targets, epsilon, lmax)

    initial_loss = float(loss_fn(float(min(max(r_init, lo), hi))))
    radius, loss, grad, history = _descend(loss_fn, r_init, lo, hi)

    # Safeguard: if the local descent stalled in a secondary minimum, restart
    # from the best point of a coarse scan of the admissible interval.
    if loss > TOL_LOSS:
        grid = np.linspace(lo, hi, 81)
        for start in sorted(grid, key=lambda g: float(loss_fn(float(g)))):
            r2, l2, g2, h2 = _descend(loss_fn, float(start), lo, hi)
            history.extend(h2)
            if l2 < loss:
                radius, loss, grad = r2, l2, g2
            if loss <= TOL_LOSS:
                break

    return {
        "radius": float(radius),
        "loss": float(loss),
        "initial_loss": initial_loss,
        "gradient": float(grad),
        "fitted_efficiencies": [float(q) for q in _efficiencies(radius, k0s, epsilon, lmax)],
        "loss_history": [float(v) for v in history],
    }


def main():
    print(json.dumps(run(json.load(sys.stdin))))


if __name__ == "__main__":
    main()
