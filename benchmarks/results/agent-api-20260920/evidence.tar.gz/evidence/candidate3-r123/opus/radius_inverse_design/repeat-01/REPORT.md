# Sphere radius inverse design from scattering efficiencies

## Problem and forward model

A homogeneous, lossless sphere of relative permittivity `epsilon` (mu = 1, kappa = 0) sits in
vacuum. For each vacuum wavelength `lambda` the Mie T-matrix is built with
`treams_rs.sphere_tmatrix(k0=2*pi/lambda, lmax=lmax, radius=r, material=epsilon)` and
illuminated by a unit plane wave travelling along +z. The scattering efficiency is

    Q(lambda, r) = sigma_sca(lambda, r) / (pi * r^2)

with `sigma_sca = tmat.cross_sections(plane_wave(...)).scattering`. For a sphere the
plane-wave cross section is independent of incidence direction and polarization; it was checked
to agree with `TMatrix.average_cross_sections` to ~1e-15 relative, so the single-plane-wave
evaluation is the rotationally averaged result.

## Units and conventions

- All lengths (radius, wavelengths, bounds) are in micrometers; `k0 = 2*pi/lambda` is in 1/um,
  so `k0*r` is dimensionless, matching treams-rs' requirement that radius and 1/k0 share a unit.
- `epsilon`, `mu`, `kappa` are relative/dimensionless; the exterior is vacuum (`medium=1`).
- Cross sections come back in squared length units (um^2); dividing by the geometric cross
  section `pi*r^2` gives the dimensionless efficiency `Q`.
- `lmax` is the fixed multipole cutoff, taken from the config and never adjusted.
- Targets are measurements: they are fitted, not assumed to correspond to any exact radius.

## Objective and gradients

    L(r) = mean_i ( (Q_i(r) - target_i) / target_i )^2

`L` is dimensionless; `dL/dr` has units 1/um. The derivative is analytic: the whole objective is
evaluated inside `treams_rs.advect` (the Advect adapter with native Rust pullbacks) and
differentiated by `advect.value_and_grad`. No finite differences enter the optimization or the
reported gradient; finite differences were used only as an offline check and agreed to ~1e-9
relative at r = 0.1 um.

## Optimizer

Projected gradient descent on the single variable `r`, started at `initial_radius` (clipped into
`bounds`) and kept inside `bounds` by projection at every trial point:

- step length from the Barzilai-Borwein rule `|dr/dg|` using the previous accepted step,
- Armijo backtracking (halving, factor 1e-4) evaluated on the actually taken projected step,
- stop when `L < 1e-7`, `|dL/dr| < 1e-10`, no step improves, or 200 iterations.

If the local descent stalls above the `1e-7` target (possible because Mie efficiencies are
non-monotonic in `r`), a safeguard restarts the same descent from the points of an 81-point scan
of the bounds, best-first, and keeps the lowest minimum. The safeguard did not trigger for the
example config. `loss_history` lists the accepted objective values, beginning with the loss at
the starting radius.

## Result for the example config

    epsilon = 4.0, lmax = 3, wavelengths = [0.58, 0.69, 0.81] um,
    initial_radius = 0.075 um, bounds = [0.06, 0.14] um

| quantity | value |
|---|---|
| radius | 0.110000217 um |
| initial_loss | 6.215290e-01 |
| loss | 6.279101e-11 |
| gradient dL/dr | 5.794e-04 1/um |
| fitted Q | 1.5628110, 0.8019276, 0.4253905 |

Five accepted steps take the loss from 6.2e-01 to 6.3e-11, far below the 1e-7 requirement; the
relative mismatch per wavelength is below 1e-5. Full output is in `results.json`, produced by
`python solution.py < example_config.json > results.json`.

## Checks

- Analytic vs. central-difference gradient of `L` at r = 0.1 um: -17.1297317467 vs.
  -17.1297317280.
- Plane-wave vs. rotationally averaged cross section: identical to machine precision.
- Round-trip recovery on synthetic targets generated with the NumPy-only `treams_rs` API at
  known radii, starting far from the answer (including at the opposite bound):
  (eps 4, lmax 3, r 0.13), (eps 2.25, lmax 4, r 0.061, at the lower bound),
  (eps 9, lmax 5, r 0.30), (eps 12, lmax 6, r 0.25) were all recovered to <=1e-6 um with final
  losses 1e-12 or smaller.
- Inconsistent (unreachable) targets terminate cleanly at the global best interior minimum with
  a vanishing gradient, rather than failing.

## Interface

`run(config)` takes the config dictionary and returns JSON-serializable
`radius`, `loss`, `initial_loss`, `gradient`, `fitted_efficiencies`, `loss_history`.
The CLI reads one config dictionary as JSON on stdin and prints the result dictionary as JSON on
stdout.
