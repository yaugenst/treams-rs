# Dimer near-field sensitivity to separation

## Problem

Two identical homogeneous spheres of radius `radius` and relative permittivity
`epsilon = epsilon[0] + 1j*epsilon[1]` are placed at

    r1 = (-separation/2, 0, 0)    r2 = (+separation/2, 0, 0)

in vacuum (`mu = 1`, `kappa = 0`, exterior vacuum) and illuminated by a
positive-helicity plane wave propagating along `+z`. With the coupled
(multiple-scattering) response of the dimer, the quantity of interest at the
fixed observation `point` is

    value = sum_i |E_total,i|^2,   E_total = E_incident + E_scattered

and the reported `gradient = d value / d separation`, where **both** sphere
centres move with the separation (each by ∓1/2 per unit separation), while the
observation point, wavelength, radii, material and `lmax` are held fixed.

## Units and conventions

* All lengths (radius, separation, wavelength, point coordinates) are in
  micrometers; `k0 = 2*pi/wavelength` is in 1/µm. `gradient` therefore has
  units of (intensity)/µm.
* `epsilon` is the **relative permittivity** `[real, imag]`, not a refractive
  index. Passive loss corresponds to a positive imaginary part (here 0.04),
  consistent with the treams-rs convention.
* The incident wave is normalised to unit field amplitude: at any point
  `sum |E_inc|^2 = 1` exactly (verified numerically). `value` is thus the local
  intensity enhancement relative to the incident plane wave.
* Polarisation is selected by the explicit helicity name
  `"positive_helicity"`, so the helicity convention is unambiguous.
* `lmax` is the fixed multipole cutoff per sphere; it is an integer label and is
  not differentiated.

## Method

`solution.py` builds the whole geometry **inside** the differentiated objective
using `treams_rs.advect` and `advect.numpy`:

1. `tr.sphere_tmatrix(k0, lmax, radius, material)` for each sphere (Mie
   T-matrix).
2. `tr.Cluster(spheres, positions=positions).solve()` — the full coupled finite
   response, i.e. multiple scattering between the two spheres is included
   (`.solve()` assembles and inverts the interaction matrix; `.scatter()` then
   propagates the requested illumination).
3. `incident.efield(points) + cluster.scatter(incident).efield(points)` gives
   the total field, and `sum(|E|^2)` the scalar value.

The positions array is built from the traced `separation` with
`advect.numpy.stack`, so the geometric dependence is carried through the native
pullbacks. The derivative comes from `advect.value_and_grad` (reverse-mode,
first order, analytic) — no finite differences are used to produce the reported
gradient.

## Results (example config)

    radius 0.08, epsilon [4.0, 0.04], separation 0.3,
    wavelength 0.72, lmax 2, point [0.05, 0.02, 0.28]

    value    =  1.1855506354526986
    gradient = -0.4037254206171242   (per µm of separation)

Saved in `results.json` together with the echoed inputs, the derived
`k0 = 8.726646...` 1/µm and the two sphere positions.

## Checks

* **Finite-difference validation** (validation only, not used for the reported
  numbers): central differences of `value` in `separation` reproduce the
  analytic gradient to ~9 significant digits, for the example config
  (`-0.4037254207` at h=1e-5 vs `-0.4037254206`) and for two additional
  parameter sets (lossy high-index, and lossless on-axis) with agreement to
  9–10 digits.
* **Incident normalisation**: `sum |E_inc|^2 = 1.0000000000000004` at the
  observation point.
* **Multiple scattering matters**: the single-scattering (independent-sphere)
  superposition gives 1.19410 versus the coupled 1.18555, a 0.7 % difference —
  confirming the coupled solve is doing something and is not equal to a bare
  superposition.
* **Multipole convergence**: value/gradient at `lmax = 2, 3, 4, 5` are
  1.185551/-0.40373, 1.185532/-0.40325, 1.185531/-0.40327, 1.185531/-0.40327.
  The requested `lmax = 2` is already converged to ~2e-5 in value and ~1e-3
  relative in gradient; `lmax` is taken from the config and not overridden.

## Usage

    python solution.py < config.json > results.json

or `from solution import run; run(config)`, which returns a JSON-serialisable
dict with scalar `value` and `gradient`.
