"""Sensitivity of the near-field intensity of a sphere dimer to its separation.

Two identical spheres sit at x = -separation/2 and x = +separation/2, are
illuminated by a positive-helicity plane wave travelling along +z, and the
full multiple-scattering field is evaluated at a fixed observation point.
The gradient d|E|^2/d(separation) comes from treams-rs analytic pullbacks
driven through the Advect reverse-mode adapter.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import advect.numpy as anp
import numpy as np
import treams_rs.advect as tr


def _objective(separation, *, k0, lmax, radius, epsilon, point):
    """value(separation) = sum(|E_total|^2) at the fixed observation point."""
    half = separation / 2.0
    zero = 0.0 * separation  # traced zero keeps the position array differentiable
    positions = anp.stack(
        [
            anp.stack([-half, zero, zero]),
            anp.stack([half, zero, zero]),
        ]
    )
    sphere = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=tr.Material(epsilon=epsilon)
    )
    cluster = tr.Cluster([sphere, sphere], positions=positions)
    wave = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    # scatter() solves (I - T C) x = T a, i.e. it includes multiple scattering.
    total = cluster.scatter(wave).efield(point) + wave.efield(point)
    return anp.sum(anp.abs(total) ** 2)


def run(config):
    radius = float(config["radius"])
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(float(eps_re), float(eps_im))
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=float).reshape(1, 3)

    if wavelength <= 0.0:
        raise ValueError("wavelength must be positive")
    if radius <= 0.0:
        raise ValueError("radius must be positive")
    if separation <= 2.0 * radius:
        raise ValueError("spheres must not overlap: separation > 2 * radius")

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um

    def objective(sep):
        return _objective(
            sep, k0=k0, lmax=lmax, radius=radius, epsilon=epsilon, point=point
        )

    value, gradient = ad.value_and_grad(objective)(separation)

    return {
        "value": float(np.real(value)),
        "gradient": float(np.real(gradient)),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
