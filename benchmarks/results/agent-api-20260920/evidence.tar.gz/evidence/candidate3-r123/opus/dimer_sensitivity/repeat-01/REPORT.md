# Dimer near-field intensity and its separation sensitivity

## Problem

Two identical homogeneous spheres in vacuum sit at `x = -separation/2` and
`x = +separation/2` (both on the x axis, `y = z = 0`). A plane wave of unit
amplitude and positive helicity propagates along `+z`. At a fixed observation
point the total electric field (incident + scattered, with full multiple
scattering between the two spheres) is evaluated and

    value = sum(|E_total|^2)   (sum over the three Cartesian components)

is reported together with `gradient = d value / d separation`. Both sphere
centers move with the separation (each by ±1/2 of it); the observation point,
wavelength, radii, material and `lmax` are held fixed.

## Units and conventions

- Lengths (`radius`, `separation`, `wavelength`, `point`) in micrometers.
  The vacuum angular wavenumber is `k0 = 2*pi/wavelength` in 1/um.
- `epsilon = [real, imag]` is the relative permittivity of the sphere material,
  dimensionless. `mu = 1` and `kappa = 0` (non-magnetic, achiral); the exterior
  is vacuum. treams-rs uses the `exp(-i*omega*t)` convention, so a positive
  imaginary part of epsilon means absorption — consistent with the example.
- Helicity polarization basis is used throughout (`"positive_helicity"` plane
  wave, helicity T-matrices). The incident field is normalized to unit
  amplitude: `sum(|E_inc|^2) = 1` exactly (checked numerically), so `value` is
  the intensity enhancement relative to the incident plane wave and is
  dimensionless.
- `value` and `gradient` are real; `gradient` has units of 1/um.

## Method (treams-rs)

`solution.py` builds everything inside the differentiable `treams_rs.advect`
namespace:

1. `tr.sphere_tmatrix(k0, lmax, radius, material=tr.Material(epsilon=...))`
   gives the Mie T-matrix of one sphere (both spheres are identical).
2. `tr.Cluster([sphere, sphere], positions=...)` with the traced position array
   assembles the two-body problem; `cluster.scatter(wave)` solves
   `(I - T C) x = T a` — i.e. the interaction/multiple-scattering problem — and
   returns the outgoing multipole wave of the cluster.
3. The scattered field at the point comes from `Wave.efield(point)`, the
   incident field from `PlaneWave.efield(point)`; they are summed before taking
   `sum(|E|^2)`.

The traced positions are built as `stack([[-sep/2, 0, 0], [sep/2, 0, 0]])`
(with a traced zero) so the derivative flows into *both* sphere centers and
through the translation/coupling matrices, the interaction solve and the field
evaluation.

## Derivatives

`advect.value_and_grad` drives the native treams-rs pullbacks
(`diff.expansion` for the translation coupling, `diff.illuminate` for the
interaction solve, `diff.field` for the field sampling, `diff.sphere` for the
Mie matrix). No finite differences enter the returned gradient. Reverse mode
over a real-valued objective with the real Hermitian pairing used by both
Advect and the native core yields a real gradient directly.

## Checks

- Incident field alone: `sum(|E_inc|^2) = 1.0` to machine precision, and
  `E_inc . conj(E_inc)` has zero z component (transverse, circularly polarized).
- Central finite differences in `separation` (step 1e-5 um) reproduce the
  analytic gradient with relative error ~1e-10 to 1e-9 for the example and for
  four additional configurations spanning dielectric, lossy, plasmonic
  (`epsilon` real part negative), `lmax` from 1 to 4, observation points inside
  and outside the plane of the dimer, and separations from 0.25 to 0.9 um.
  These FD checks are validation only.
- Guard rails: positive wavelength and radius, and `separation > 2*radius`
  (non-overlapping spheres, required for the multipole translation expansion).

## Example result

Config
`{"radius":0.08,"epsilon":[4.0,0.04],"separation":0.3,"wavelength":0.72,"lmax":2,"point":[0.05,0.02,0.28]}`
gives (`results.json`)

    value    =  1.1855506354526988
    gradient = -0.40372542061712435   (per micrometer)

so the intensity at that point is ~19% above the incident intensity and
decreases as the spheres are pulled apart.

## Usage

    python solution.py < config.json          # prints the result dict as JSON
    from solution import run; run(config)      # returns the same dict
