"""Dimer field-intensity sensitivity with respect to sphere separation.

Two identical spheres sit at x = -separation/2 and x = +separation/2 and are
illuminated by a positive-helicity plane wave travelling along +z.  The
objective is the total (incident + multiply-scattered) electric field intensity
at a fixed observation point; its derivative with respect to the separation is
obtained from the native treams-rs pullbacks through the Advect adapter.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import advect.numpy as anp
import numpy as np
import treams_rs.advect as tr


def _objective(separation, k0, lmax, radius, epsilon, point):
    """Total |E|^2 at ``point`` for a dimer with the given separation."""
    material = tr.Material(epsilon)
    particles = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
        for _ in range(2)
    ]
    # Both centres move with the separation, so the positions must be built
    # from the traced parameter inside the objective.
    half = separation / 2
    zero = anp.asarray(0.0)
    positions = anp.stack(
        [anp.stack([-half, zero, zero]), anp.stack([half, zero, zero])]
    )
    cluster = tr.Cluster(particles, positions=positions)
    wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
    field = wave.efield(point) + cluster.solve().scatter(wave).efield(point)
    return anp.sum(anp.abs(field) ** 2)


def run(config):
    radius = float(config["radius"])
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(float(eps_re), float(eps_im))
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=float).reshape(1, 3)

    k0 = 2.0 * np.pi / wavelength

    def objective(s):
        return _objective(s, k0, lmax, radius, epsilon, point)

    value, gradient = ad.value_and_grad(objective)(separation)

    return {"value": float(value), "gradient": float(gradient)}


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
