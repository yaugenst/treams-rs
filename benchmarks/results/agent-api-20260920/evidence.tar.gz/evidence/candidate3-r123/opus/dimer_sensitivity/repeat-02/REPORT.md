# Dimer field-intensity sensitivity

## Problem

Two identical homogeneous spheres are placed at `x = -separation/2` and
`x = +separation/2` (both on the x-axis, y = z = 0) and illuminated by a
positive-helicity plane wave propagating along `+z`. At a fixed observation
point we evaluate

    value = sum(|E_total|^2)   with   E_total = E_incident + E_scattered

and its derivative `gradient = d(value)/d(separation)`. Both sphere centres
move with the separation; the observation point, wavelength, radii, material
and `lmax` are held fixed.

## Units and conventions

* Lengths (`radius`, `separation`, `wavelength`, `point`) are in micrometers.
  The vacuum angular wavenumber is `k0 = 2*pi/wavelength` (rad/µm), so `radius`
  and `1/k0` share the same length unit as required by `sphere_tmatrix`.
* `epsilon = [real, imag]` is the dimensionless relative permittivity,
  assembled into `complex(real, imag)`. `mu = 1`, `kappa = 0` (defaults of
  `tr.Material`), and the exterior is vacuum (default medium).
* Polarization is `"positive_helicity"`, using treams-rs' helicity convention;
  the incident plane wave has unit amplitude, so `value` is dimensionless
  relative to the incident intensity.
* `lmax` is the fixed multipole cutoff per sphere (a static, non-differentiable
  label).
* `sum(abs(E)**2)` sums the squared magnitudes of the three complex Cartesian
  components at the single observation point.

## Method

`treams_rs.advect` is used for the whole calculation:

1. `tr.sphere_tmatrix(k0, lmax, radius, material)` builds the Mie T-matrix of
   each sphere.
2. Positions are assembled from the traced `separation` with
   `advect.numpy.stack`, so the geometry dependence is recorded.
3. `tr.Cluster(particles, positions).solve()` forms the fully coupled response,
   i.e. multiple scattering between the two spheres is included (the coupled
   linear system, not a single-scattering approximation).
4. `wave.efield(point) + response.scatter(wave).efield(point)` gives the total
   field including the incident wave.
5. `advect.value_and_grad` returns the value and the analytic derivative via
   treams-rs' native Rust pullbacks. No finite differences enter the returned
   gradient.

Only the public `treams_rs.advect` / `advect` namespaces are used.

## Checks

* Finite-difference validation (central differences, h = 1e-6 µm) of the
  analytic gradient — used for verification only:

  | config | value | analytic gradient | FD gradient | rel. error |
  |---|---|---|---|---|
  | example (lmax=2) | 1.1855506355 | -0.4037254206 | -0.4037254205 | 1.9e-10 |
  | example, lmax=3 | 1.1855315617 | -0.4032503172 | -0.4032503169 | 6.0e-10 |
  | example, lmax=4 | 1.1855312895 | -0.4032677235 | -0.4032677234 | 1.4e-10 |
  | r=0.12, s=0.5, λ=0.6, ε=9+0.5i | 0.4019578473 | 0.7488558172 | 0.7488558172 | 1.6e-11 |

* Multipole convergence: going from `lmax = 2` to `lmax = 4` changes the
  example value by ~2e-5 (relative 1.6e-5) and the gradient by ~5e-4, so the
  requested `lmax = 2` is already close to converged for these small spheres
  (`k0*radius ≈ 0.70`).
* Symmetry: replacing `separation` by `-separation` merely exchanges the two
  identical spheres. The computed value is unchanged and the gradient changes
  sign, as it must.

## Files

* `solution.py` — `run(config)` plus a CLI reading one JSON config on stdin and
  printing the result dictionary as JSON on stdout.
* `results.json` — output for the example config:
  `{"value": 1.1855506354526986, "gradient": -0.4037254206171242}`.
