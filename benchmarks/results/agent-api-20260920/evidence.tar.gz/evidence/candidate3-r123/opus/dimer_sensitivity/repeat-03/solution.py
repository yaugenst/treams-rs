"""Sensitivity of the near-field intensity of a sphere dimer to its separation.

Two identical spheres sit at x = -separation/2 and x = +separation/2, are
illuminated by a positive-helicity plane wave travelling along +z, and the
quantity of interest is

    value = sum(abs(E_total)**2)

at a fixed observation point, where E_total is the incident field plus the
multiple-scattering field of the coupled dimer.  The gradient
dvalue/dseparation is obtained from treams-rs analytic pullbacks through the
Advect adapter (``treams_rs.advect``); both sphere positions move with the
separation.
"""

from __future__ import annotations

import json
import sys

import numpy as np

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _objective(separation, k0, lmax, radius, material, point):
    """Traced intensity at ``point`` for a dimer with the given separation."""
    half = separation / 2.0
    zero = 0.0 * half  # keep the traced dtype for the untouched coordinates
    positions = anp.stack(
        [anp.stack([-half, zero, zero]), anp.stack([half, zero, zero])]
    )

    spheres = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
        for _ in range(2)
    ]
    cluster = tr.Cluster(spheres, positions=positions).solve()

    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    points = anp.asarray([point])
    total = incident.efield(points) + cluster.scatter(incident).efield(points)
    return anp.sum(anp.abs(total) ** 2)


def run(config):
    """Return the near-field intensity and its separation derivative."""
    radius = float(config["radius"])
    eps_re, eps_im = (float(x) for x in config["epsilon"])
    material = complex(eps_re, eps_im)
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = [float(x) for x in config["point"]]

    k0 = 2.0 * np.pi / wavelength

    def objective(sep):
        return _objective(sep, k0, lmax, radius, material, point)

    value, gradient = ad.value_and_grad(objective)(separation)

    return {
        "value": float(value),
        "gradient": float(gradient),
        "separation": separation,
        "wavelength": wavelength,
        "k0": float(k0),
        "lmax": lmax,
        "radius": radius,
        "epsilon": [eps_re, eps_im],
        "point": point,
        "positions": [[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]],
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
