"""Square sphere array above a dielectric slab: helicity-resolved power balance.

Network ordered along +z: slab, vacuum gap, sphere array. Illumination comes
from the negative-z side along +z with positive helicity. Only the zeroth
diffraction order (both helicities) at Bloch vector [0, 0] is retained.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import treams_rs as tr

TWO_PI = 2.0 * 3.141592653589793


def _spectrum_point(
    wavelength: float,
    *,
    radius: float,
    sphere_epsilon: float,
    period: float,
    gap: float,
    slab_thickness: float,
    slab_epsilon: float,
    lmax: int,
) -> tr.PowerBalance:
    k0 = TWO_PI / wavelength

    # Isolated sphere response, then the full periodic interaction of the array.
    particle = tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon)
    response = tr.solve_periodic(particle, lattice=tr.Lattice.square(period), kpar=[0, 0])

    ports = tr.PlaneWavePorts.default([0, 0])  # zeroth order, both helicities
    array = response.to_smatrix(ports)
    layer = tr.slab(k0=k0, basis=ports, thickness=slab_thickness, material=slab_epsilon)
    vacuum_gap = tr.propagation(k0=k0, basis=ports, distance=gap)

    network = tr.stack([layer, vacuum_gap, array])  # negative to positive z
    wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
    return network.power(wave, side="negative")


def run(config: dict[str, Any]) -> dict[str, Any]:
    radius = float(config["radius"])
    sphere_epsilon = float(config["sphere_epsilon"])
    period = float(config["period"])
    gap = float(config["gap"])
    slab_thickness = float(config["slab_thickness"])
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])
    wavelengths = sorted(float(w) for w in config["wavelengths"])

    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        power = _spectrum_point(
            wavelength,
            radius=radius,
            sphere_epsilon=sphere_epsilon,
            period=period,
            gap=gap,
            slab_thickness=slab_thickness,
            slab_epsilon=slab_epsilon,
            lmax=lmax,
        )
        transmission.append(float(power.transmission))
        reflection.append(float(power.reflection))
        # Lossless inputs leave a round-off-sized negative absorption.
        absorbed = float(power.absorption)
        absorption.append(0.0 if -1e-12 < absorbed < 0.0 else absorbed)

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "balance_residual": [
            t + r + a - 1.0 for t, r, a in zip(transmission, reflection, absorption)
        ],
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
