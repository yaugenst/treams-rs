# Sphere array above a dielectric slab — T/R/A spectra

## What is computed
A square periodic array of identical homogeneous spheres sits above a uniform
dielectric slab with a vacuum propagation gap between the slab top face and the
sphere-center plane. Illumination comes from the negative-z side, travelling
along +z, with **positive helicity**. For each vacuum wavelength the code
returns the transmission, reflection and absorption power fractions.

## Units and conventions
- All lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) are in
  micrometers. The vacuum angular wavenumber is `k0 = 2*pi/wavelength`, so
  `1/k0` shares the same length unit.
- `sphere_epsilon`, `slab_epsilon` are real relative permittivities; `mu = 1`,
  `kappa = 0`, and all exterior media (below the slab, in the gap, above the
  array) are vacuum.
- Polarization basis is helicity; the incident field is the positive-helicity
  plane wave along `[0, 0, 1]`.
- Power fractions are normalized by the incident axial flux, so
  `transmission + reflection + absorption = 1`. Both output helicity channels
  are summed into each fraction (helicity is not preserved by the achiral
  slab/array, so conversion into negative helicity is included).
- Results are returned sorted by increasing wavelength, together with the
  sorted `wavelengths` list.

## Method (treams-rs)
1. `tr.sphere_tmatrix(k0, lmax, radius, material)` — Mie T-matrix of the
   isolated sphere at the fixed multipole cutoff `lmax`.
2. `tr.solve_periodic(particle, lattice=tr.Lattice.square(period), kpar=[0, 0])`
   — the **full** periodic lattice interaction (Ewald-summed lattice sums) at
   Bloch vector `[0, 0]`, solved once per wavelength. The isolated particle
   T-matrix is passed in, as required (never an already coupled cluster).
3. `tr.PlaneWavePorts.default([0, 0])` — zeroth diffraction order only, both
   helicities. This is valid because every wavelength exceeds the period, so
   higher orders (`|G| = 2*pi/period > k0`) are evanescent. The example has
   `period = 0.4` and `wavelengths >= 0.65`.
4. `array.to_smatrix(ports)` converts the periodic response to a scattering
   matrix on those channels; `tr.slab(...)` and `tr.propagation(...)` give the
   layer and the vacuum gap.
5. `tr.stack([slab, gap, array])` cascades from the negative to the positive
   side of z, i.e. in the order the wave encounters them. The propagation
   distance equals `gap` and ends exactly at the array's particle-center plane.
6. `network.power(plane_wave(...), side="negative")` yields the
   `PowerBalance(transmission, reflection, absorption)` fractions.

No scattering physics is reimplemented; treams-rs supplies the T-matrix,
lattice sums, layer S-matrices and power balance.

## Checks performed
- **Energy conservation**: `power_sum = T + R + A = 1` to ~1e-15 at every
  wavelength; with purely real permittivities the absorption comes out at the
  1e-16 level (numerical zero), as it must for lossless media.
- **Bare-slab limit**: shrinking the sphere radius to 1e-4 um reproduces the
  standalone slab result to ~1e-10.
- **Analytic Fresnel**: the isolated slab (n = 1.5, d = 0.09 um) matches the
  closed-form single-layer Airy reflectance to ~1e-15 at all three wavelengths.
- **Multipole convergence**: transmission at lmax = 1, 2, 3, 4 is
  0.888113 / 0.887329 / 0.887338 / 0.887338 at 0.65 um — the requested
  lmax = 2 is converged to ~1e-5, and lmax is honoured as given, not raised.
- **Gap sensitivity**: changing `gap` from 0.12 to 0.30 um changes transmission
  (0.8873 -> 0.8381), confirming the Fabry-Perot coupling between slab and array
  is actually present rather than the two being treated independently.
- **Input ordering**: shuffled input wavelengths produce identical,
  wavelength-sorted output.

## Files
- `solution.py` — `run(config)` plus a CLI reading one JSON config on stdin and
  printing the result dictionary as JSON on stdout.
- `results.json` — output for the example config.
