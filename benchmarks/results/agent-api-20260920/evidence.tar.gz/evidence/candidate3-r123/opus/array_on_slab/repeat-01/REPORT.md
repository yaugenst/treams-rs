# Sphere array on a dielectric slab — power spectra

## What is computed
For each vacuum wavelength the code builds, with `treams-rs` (0.1.0):

1. `tr.sphere_tmatrix(k0, lmax, radius, material=sphere_epsilon)` — the isolated
   sphere in vacuum at the fixed multipole cutoff `lmax`.
2. `tr.solve_periodic(particle, lattice=tr.Lattice.square(period), kpar=[0, 0])` —
   the full Bloch-periodic interaction of the square array (Ewald splitting chosen
   by the native kernel, `eta=0`), solved once per wavelength.
3. `response.to_smatrix(ports)` with `ports = tr.PlaneWavePorts.default([0, 0])`:
   the zeroth diffraction order only, both helicity channels. This is valid because
   every requested wavelength exceeds the period, so no other order propagates
   (a higher order would open at `wavelength < period` at normal incidence).
4. `tr.slab(k0, ports, thickness=slab_thickness, material=slab_epsilon)` and
   `tr.propagation(k0, ports, distance=gap)` for the vacuum gap.
5. `tr.stack([slab, gap, array])` — layers ordered from negative to positive z, i.e.
   slab, then gap, then the sphere array. The propagation distance ends at the
   sphere-center plane, matching "slab top to sphere-center plane".
6. `network.power(tr.plane_wave([0, 0, 1], "positive_helicity", k0), side="negative")`
   — illumination from the negative-z side along +z with positive helicity.

## Units and conventions
- Lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) in micrometers;
  `k0 = 2*pi/wavelength` in rad/µm.
- `sphere_epsilon`, `slab_epsilon` are real relative permittivities; `mu = 1`,
  `kappa = 0`, all exterior media vacuum.
- Polarization basis is helicity; the incident field is pure positive helicity, but
  both zeroth-order helicity channels are kept as output ports, so helicity
  conversion by the interfaces is included in the totals.
- `transmission`, `reflection`, `absorption` are power fractions of the incident
  flux (they sum to 1 for lossless media). Absorption values in `(-1e-12, 0)`,
  which are round-off for real permittivities, are reported as `0.0`.

## Output
`run(config)` returns `wavelengths` (sorted ascending) and the three same-length,
wavelength-ordered lists, plus `balance_residual = T + R + A - 1` per wavelength.
The CLI reads one config dict as JSON on stdin and prints the result dict as JSON.

## Checks performed
- **Energy balance**: `|T + R + A - 1| <= 9e-16` for every example wavelength.
- **Slab alone vs. analytic Fresnel**: with the array removed, `tr.slab` reproduces
  the closed-form single-layer normal-incidence reflectance
  `|r(1-e^{2ink0d})/(1-r^2 e^{2ink0d})|^2`, `r=(1-n)/(1+n)`, `n=1.5`, to ~1e-15 at
  all three wavelengths.
- **Multipole convergence**: transmission at `lmax = 2, 3, 4` is
  `0.887329 / 0.887338 / 0.887338` (λ=0.65 µm) and similarly stable at the other
  wavelengths, so the requested `lmax = 2` is converged to ~1e-5. The reported
  numbers use the `lmax` from the config, as specified.
- No absorption appears for the real permittivities of the example, as expected.

## Example result (`results.json`)
| λ (µm) | T | R | A |
| --- | --- | --- | --- |
| 0.65 | 0.8873286 | 0.1126714 | 0.0 |
| 0.74 | 0.9020687 | 0.0979313 | 2.4e-16 |
| 0.83 | 0.9119143 | 0.0880857 | 0.0 |
