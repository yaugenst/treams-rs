"""Transmission, reflection and absorption of a sphere array on a dielectric slab.

Geometry along +z: vacuum | slab | vacuum gap | square sphere array | vacuum.
Illumination from the negative-z side, propagating along +z, positive helicity.
All lengths in micrometers; permittivities are relative and dimensionless.
"""

import json
import math
import sys

import treams_rs as tr


def _single_wavelength(wavelength, config):
    k0 = 2.0 * math.pi / wavelength

    ports = tr.PlaneWavePorts.default([0, 0])  # zeroth order, both helicities

    particle = tr.sphere_tmatrix(
        k0=k0,
        lmax=int(config["lmax"]),
        radius=float(config["radius"]),
        material=float(config["sphere_epsilon"]),
    )
    lattice = tr.Lattice.square(float(config["period"]))
    array = tr.solve_periodic(particle, lattice=lattice, kpar=[0, 0]).to_smatrix(ports)

    layer = tr.slab(
        k0=k0,
        basis=ports,
        thickness=float(config["slab_thickness"]),
        material=float(config["slab_epsilon"]),
    )
    gap = tr.propagation(k0=k0, basis=ports, distance=float(config["gap"]))

    network = tr.stack([layer, gap, array])
    wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
    power = network.power(wave, side="negative")

    return (
        float(power.transmission),
        float(power.reflection),
        float(power.absorption),
    )


def run(config):
    wavelengths = [float(w) for w in config["wavelengths"]]
    order = sorted(range(len(wavelengths)), key=lambda i: wavelengths[i])

    transmission, reflection, absorption = [], [], []
    for i in order:
        t, r, a = _single_wavelength(wavelengths[i], config)
        transmission.append(t)
        reflection.append(r)
        absorption.append(a)

    return {
        "wavelengths": [wavelengths[i] for i in order],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "energy_balance": [
            t + r + a for t, r, a in zip(transmission, reflection, absorption)
        ],
        "max_energy_balance_error": max(
            abs(t + r + a - 1.0)
            for t, r, a in zip(transmission, reflection, absorption)
        ),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
