"""Square sphere array above a dielectric slab: T/R/A spectra via treams-rs.

Network order along +z (illumination side first): slab, vacuum gap, array.
"""

import json
import math
import sys

import treams_rs as tr


def _single_wavelength(wavelength, radius, sphere_epsilon, period, gap,
                       slab_thickness, slab_epsilon, lmax):
    """Power fractions for one vacuum wavelength (micrometers)."""
    k0 = 2.0 * math.pi / wavelength

    # Isolated sphere response, then the full periodic (lattice-coupled) solve.
    particle = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon
    )
    lattice = tr.Lattice.square(period)
    array = tr.solve_periodic(particle, lattice=lattice, kpar=[0, 0])

    # Zeroth diffraction order only, both helicities, Bloch vector [0, 0].
    ports = tr.PlaneWavePorts.default([0, 0])

    network = tr.stack([
        tr.slab(k0=k0, basis=ports, thickness=slab_thickness,
                material=slab_epsilon),
        tr.propagation(k0=k0, basis=ports, distance=gap),
        array.to_smatrix(ports),
    ])

    wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
    power = network.power(wave, side="negative")
    return float(power.transmission), float(power.reflection), float(power.absorption)


def run(config):
    radius = float(config["radius"])
    sphere_epsilon = float(config["sphere_epsilon"])
    period = float(config["period"])
    gap = float(config["gap"])
    slab_thickness = float(config["slab_thickness"])
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]

    order = sorted(range(len(wavelengths)), key=lambda i: wavelengths[i])
    wls = [wavelengths[i] for i in order]

    transmission, reflection, absorption = [], [], []
    for wl in wls:
        t, r, a = _single_wavelength(
            wl, radius, sphere_epsilon, period, gap,
            slab_thickness, slab_epsilon, lmax,
        )
        transmission.append(t)
        reflection.append(r)
        absorption.append(a)

    return {
        "wavelengths": wls,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "power_sum": [t + r + a for t, r, a in
                      zip(transmission, reflection, absorption)],
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
