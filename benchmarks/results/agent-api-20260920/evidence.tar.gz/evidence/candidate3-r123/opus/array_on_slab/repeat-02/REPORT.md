# Sphere array above a dielectric slab — treams-rs

## What is computed
For each wavelength, the zeroth-order power fractions of a plane wave incident from the
negative-z side, propagating along `+z` with **positive helicity**, on the stack

```
vacuum | slab | vacuum gap | square array of spheres | vacuum
```

ordered along `+z` exactly as specified.

## Model and API use
* `tr.sphere_tmatrix(k0, lmax, radius, material=sphere_epsilon)` — isolated-sphere Mie
  T-matrix at the fixed multipole cutoff `lmax`, exterior vacuum.
* `tr.solve_periodic(particle, lattice=tr.Lattice.square(period), kpar=[0, 0])` — the full
  periodic (lattice-sum / Ewald) interaction of the array is solved once per wavelength at
  Bloch vector `[0, 0]`; `.to_smatrix(ports)` projects it onto plane-wave channels.
* `tr.PlaneWavePorts.default([0, 0])` — the zeroth diffraction order only, both helicity
  channels. Valid here because all wavelengths exceed the period (0.65–0.83 µm vs 0.4 µm),
  so no higher order is open at normal incidence.
* `tr.slab(k0, basis=ports, thickness=slab_thickness, material=slab_epsilon)` and
  `tr.propagation(k0, basis=ports, distance=gap)` for the layer and the vacuum gap. Per the
  library convention the propagation distance ends at the array's **particle-center plane**,
  which is the gap definition requested (slab top → sphere-center plane).
* `tr.stack([layer, gap, array])` cascades from the negative to the positive side.
* `network.power(tr.plane_wave([0, 0, 1], "positive_helicity", k0), side="negative")` returns
  `transmission`, `reflection`, `absorption` as fractions of the incident flux.

No scattering physics is reimplemented; all of it comes from treams-rs.

## Units and conventions
* Lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) in micrometers;
  `k0 = 2π/λ_vacuum` in rad/µm, so only the ratio of lengths to wavelength matters.
* `sphere_epsilon`, `slab_epsilon` are real relative permittivities; `mu = 1`, `kappa = 0`,
  exterior media vacuum.
* Helicity basis; "positive helicity" for propagation along `+z`.
* Outputs are dimensionless power fractions with `T + R + A = 1`.

## Output keys
`wavelengths` (sorted ascending), `transmission`, `reflection`, `absorption`
(index-aligned with the sorted wavelengths), plus `energy_balance` and
`max_energy_balance_error` as diagnostics. Results are always returned in ascending
wavelength order regardless of the input ordering.

## Checks performed (example config)
1. **Energy conservation**: `T + R + A = 1` to 1.1e-16. With real permittivities the media
   are lossless and `A` comes out at the 1e-16 level (sign of the residual is numerical
   noise; it is reported unmodified).
2. **lmax convergence** at λ = 0.74 µm: T = 0.902696 (lmax 1), 0.9020687 (2), 0.9020751 (3),
   0.9020751 (4). The requested `lmax` is used as given, not silently raised.
3. **Vanishing-sphere limit**: with `radius = 1e-4` µm the stack reproduces the bare slab,
   T = 0.8740069 vs 0.8740069 for `tr.slab` alone, and the bare-slab reflection
   R = 0.12599314969 matches the analytic Fabry–Pérot value
   `|r(1-e^{2ink0 d})/(1-r² e^{2ink0 d})|²` with `r = (1-n)/(1+n)`, `n = 1.5`, to 1e-14.
4. **Symmetry**: the achiral structure gives the same transmission for negative helicity
   (0.90206873) and for positive-helicity incidence from the `+z` side (0.90206873),
   as required by mirror symmetry and reciprocity.
5. **Input-order independence**: shuffling the input wavelength list returns identical
   sorted output.

## Results (example config)
| λ (µm) | T | R | A |
|---|---|---|---|
| 0.65 | 0.887329 | 0.112671 | ~0 |
| 0.74 | 0.902069 | 0.097931 | ~0 |
| 0.83 | 0.911914 | 0.088086 | ~0 |

Stored in `results.json`.

## CLI
```
python solution.py < config.json    # config dict on stdin, result dict as JSON on stdout
```
