# Chiral slab at normal incidence — power fractions

## What is computed
A uniform, isotropic, reciprocal chiral slab of thickness `d`, normal to z, is
illuminated at normal incidence from the negative-z side (propagation along
+z). The exterior is vacuum on both sides. For each wavelength and for each
incident helicity we return the transmitted, reflected and absorbed **power
fractions** (normalized by the incident flux), not amplitude coefficients.

## Units and conventions
- Lengths (`thickness`, `wavelengths`) are in micrometers; `k0 = 2*pi/lambda`
  is passed to treams-rs in the matching 1/um unit.
- `epsilon = [real, imag]`, `kappa` (scalar or `[real, imag]`) and the optional
  `mu` are relative/dimensionless. Defaults: `mu = 1`, `kappa = 0`, vacuum
  exterior. A positive imaginary part of epsilon is loss in the package's
  time convention (verified: absorption comes out positive).
- Material model: `Material(epsilon, mu, kappa)`; the two circular eigenmodes
  have `n± = sqrt(eps*mu) ± kappa` and a **common** wave impedance
  `Z = sqrt(mu/eps)` that is independent of kappa.
- Polarization basis is helicity (`polarization="helicity"`). In treams the
  helicity label `pol = 1` is **positive** helicity and `pol = 0` is negative.
  The default normal-incidence port basis `PlaneWavePorts.default([0, 0])`
  orders its two ports as `pol = [1, 0]`, so the amplitude vector `[1, 0]`
  selects positive helicity. The code does not rely on that ordering: it reads
  `basis.pol` and builds the unit amplitude vector for each label.
  Outputs are ordered **positive helicity first, then negative**, giving lists
  of shape `(n_wavelengths, 2)`.

Two independent confirmations of the helicity assignment (both in `checks.py`
/ the notes below):
1. `Material.nmp = (n - kappa, n + kappa)` is indexed by the same `pol` label;
   with a lossy `kappa = 0.08 + 0.05i` the `pol = 1` channel has the larger
   `Im n` and indeed shows the smaller transmission (0.359 vs 0.621) and the
   larger absorption (0.609 vs 0.347).
2. For real kappa the transmitted amplitude phase of the `pol = 1` channel
   tracks the single-pass phase `k0 (n + kappa) d`, not `k0 (n - kappa) d`.

(The docstring of `treams_rs.slab` states that `power([0, 1])` gives the
positive-helicity balance; the basis labels and both tests above show the
opposite, so the assignment used here is the label-based one.)

## Method
`treams_rs.slab(basis=PlaneWavePorts.default([0,0]), k0=..., thickness=...,
material=Material([eps, mu, kappa]), negative_medium=..., positive_medium=...)`
builds the slab S-matrix; `SMatrices.power(amplitudes, side="negative")`
returns the `PowerBalance(transmission, reflection, absorption)` for incidence
from the negative side. No scattering physics is reimplemented.

## Physics note
For a **real** kappa the power fractions are identical for the two helicities.
This is correct, not a bug: the impedance (hence the interface Fresnel
coefficient) does not depend on kappa, the two eigenmodes share the same
`Im n`, and reflection inside the slab flips the helicity, so a Fabry–Perot
round trip accumulates `k0 (n_+ + n_-) d = 2 k0 n d`, independent of kappa.
Kappa only shifts the *phase* of the transmitted amplitude (optical rotation).
Circular dichroism in power appears when kappa has an imaginary part, as the
lossy-kappa test shows.

## Checks performed (`checks.py`, all passing)
- `T + R + A = 1` for every wavelength and helicity (max deviation 0).
- Lossless slab (`Im eps = 0`, real kappa, `d = 0.4`): `A < 5e-16` and
  `T + R = 1` to 4e-16.
- `kappa = 0` reproduces the analytic Airy/Fabry–Perot result for a lossy
  dielectric slab, `t = (1-r^2)e^{i k0 n d}/(1 - r^2 e^{2 i k0 n d})` with
  `r = (Z-1)/(Z+1)`: agreement to ~7e-16 in both T and R.
- `d -> 0` gives `T -> 1`; a vacuum slab gives `T = 1`, `R = 0` exactly.
- Helicity-ordering tests described above.

Note that `absorption` is reported by the package as the flux defect
`1 - T - R`, which is why the sum rule is exact by construction; the
independent validation of the absolute level is the analytic `kappa = 0`
comparison and the lossless-slab test.

## Files
- `solution.py` — `run(config)` plus a CLI (config dict as JSON on stdin,
  result dict as JSON on stdout).
- `results.json` — output for the example config.
- `checks.py` — the validation script above.

## Example result (`results.json`)
| lambda (um) | T (+ / -) | R (+ / -) | A (+ / -) |
|---|---|---|---|
| 0.55 | 0.905416 / 0.905416 | 0.024049 / 0.024049 | 0.070536 / 0.070536 |
| 0.65 | 0.864572 / 0.864572 | 0.080756 / 0.080756 | 0.054673 / 0.054673 |
| 0.80 | 0.826736 / 0.826736 | 0.130154 / 0.130154 | 0.043110 / 0.043110 |
