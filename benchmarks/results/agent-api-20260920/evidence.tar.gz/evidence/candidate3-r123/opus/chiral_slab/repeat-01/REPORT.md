# Chiral slab at normal incidence — treams-rs

## What is computed
A uniform, isotropic, reciprocal chiral slab of thickness `d` normal to z, with vacuum on
both sides, is illuminated at normal incidence from the `-z` side (propagation along `+z`).
For every wavelength and each incident helicity the transmitted, reflected and absorbed
**power fractions** are returned.

## Units and conventions
- Lengths (`thickness`, `wavelengths`) are micrometers. The vacuum angular wavenumber is
  `k0 = 2*pi/lambda` in 1/um.
- `epsilon` is given as `[real, imag]` and is relative/dimensionless; `mu` (optional,
  default 1) and `kappa` (default 0) are relative/dimensionless as well. Each may be given
  as a scalar or as a `[real, imag]` pair.
- `kappa` is the package chirality parameter of `treams_rs.Material(epsilon, mu, kappa)`:
  the two circular eigenwaves inside the slab have indices `n_mp = sqrt(eps*mu) -/+ kappa`,
  i.e. positive helicity sees `n + kappa`. A positive `Im(epsilon)` means loss
  (time convention `exp(-i omega t)`, outgoing branch with `Im k_z >= 0`).
- Outputs `transmission`, `reflection`, `absorption` have shape `(n_wavelengths, 2)`,
  column 0 = positive helicity, column 1 = negative helicity (also stated in the returned
  `helicity_order` field). They are fractions of the incident power flux, not amplitudes;
  `T + R + A = 1` by construction (`A` is taken from `PowerBalance.absorption`).

## Method
`treams_rs.slab(basis=PlaneWavePorts.default([0, 0]), k0=..., thickness=..., material=...,
negative_medium=1, positive_medium=1, polarization="helicity")` builds the exact plane-wave
S-matrix of the layer between the two vacuum half-spaces (both interfaces plus all internal
multiple reflections). Illumination is a `treams_rs.plane_wave` with
`polarization="positive_helicity"` / `"negative_helicity"` travelling along `+z`, and
`SMatrices.power(illu, side="negative")` returns the power balance. No scattering physics is
reimplemented here; only the config is unpacked and the results are reshaped.

Helicity labelling was verified rather than assumed: the slab docstring's example index is
inconsistent with the basis ordering, so the channel identity was fixed numerically. For an
impedance-matched chiral layer (`eps = mu = 2`, `kappa = 0.3`) the forward transmission
block is diagonal with entries `exp(i n_pm k0 d)`; the channel picked by the
`positive_helicity` plane wave carries `n + kappa`, confirming column 0 = positive helicity
(consistent with `Material.ks`, which is ordered negative/positive helicity).

## Checks performed
- **Analytic Fabry–Perot reference.** For a chiral slab at normal incidence
  `t_pm = (1-r^2) e^{i n_pm k0 d} / (1 - r^2 e^{2 i n k0 d})` with `r = (Z-1)/(Z+1)`,
  `Z = sqrt(mu/eps)` (the round trip involves `n_+ + n_- = 2n` because reflection flips
  helicity). Agreement with treams-rs to <1e-15 for the example and for several other
  `(eps, kappa, d, lambda)` combinations.
- **Energy conservation.** `T + R + A - 1 = 0` to machine precision; for a lossless slab
  (`Im eps = 0`) the absorption is < 6e-16.
- **Limits.** `thickness = 0` and a vacuum slab give `T = 1`, `R = 0`; `kappa = 0` makes the
  two helicities identical and reproduces the plain dielectric Fabry–Perot result.
- **Expected symmetry.** With *real* `kappa` both helicities have the same `T`, `R`, `A`
  (a reciprocal isotropic chiral slab in a symmetric environment rotates the polarization
  but shows no circular dichroism at normal incidence); the example output shows this
  degeneracy to ~1e-15. Giving `kappa` an imaginary part (e.g. `[0.1, 0.03]`) does split the
  two helicities, confirming the chirality actually enters the calculation.

## Files
- `solution.py` — `run(config)` plus a CLI reading one JSON config on stdin and printing the
  result dict as JSON on stdout.
- `results.json` — output for the example config
  (`d = 0.16 um`, `eps = 2.25 + 0.06i`, `kappa = 0.08`, `lambda = 0.55, 0.65, 0.8 um`),
  produced with `echo '<config>' | python solution.py > results.json`.
