"""Power fractions for normal incidence on a uniform reciprocal chiral slab.

Lengths are in micrometers; epsilon, mu and kappa are relative/dimensionless.
Scattering is computed with treams-rs (``treams_rs.slab``), which builds the
plane-wave S-matrix of one homogeneous layer between two exterior media.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as treams


def _complex(value: Any) -> complex:
    """Accept a scalar or a ``[real, imag]`` pair as a complex number."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"expected scalar or [real, imag], got {value!r}")
    return complex(value)


def run(config: dict) -> dict:
    thickness = float(config["thickness"])
    epsilon = _complex(config["epsilon"])
    mu = _complex(config.get("mu", 1.0))
    kappa = _complex(config.get("kappa", 0.0))
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]

    material = treams.Material(epsilon, mu, kappa)
    # Two normal-incidence channels (kx = ky = 0); index 0 is positive and
    # index 1 is negative helicity in this basis.
    basis = treams.PlaneWavePorts.default([0, 0])
    transmission, reflection, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um
        smat = treams.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1,  # vacuum below the slab (incidence side)
            positive_medium=1,  # vacuum above the slab
            polarization="helicity",
        )
        row_t, row_r, row_a = [], [], []
        for helicity in ("positive", "negative"):
            illu = treams.plane_wave(
                direction=[0, 0, 1],
                polarization=f"{helicity}_helicity",
                k0=k0,
                material=1,
            )
            balance = smat.power(illu, side="negative")
            row_t.append(float(balance.transmission))
            row_r.append(float(balance.reflection))
            row_a.append(float(balance.absorption))
        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

    return {
        "wavelengths": wavelengths,
        "helicity_order": ["positive", "negative"],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
