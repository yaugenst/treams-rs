# Chiral slab at normal incidence — power fractions per helicity

## Problem and model

A uniform, isotropic, reciprocal chiral slab of thickness `d` lies normal to `z`
with vacuum on both sides. A plane wave of definite helicity travels along `+z`
and hits the slab from the negative-`z` side. For every requested vacuum
wavelength we report the transmitted, reflected and absorbed **power fractions**
(not amplitude coefficients) for positive and negative helicity.

The calculation is done with `treams_rs`, the Rust-backed treams API:

* `tr.Material(epsilon, mu, kappa)` — relative, dimensionless permittivity,
  permeability and the package chirality parameter `kappa`.
* `tr.PlaneWavePorts.default([0, 0])` — the transverse wavevector
  `(kx, ky) = (0, 0)`, i.e. normal incidence, with both helicity channels.
* `tr.slab(basis=..., k0=..., thickness=..., material=..., negative_medium=1,
  positive_medium=1, polarization="helicity")` — the plane-wave S-matrix of one
  homogeneous layer between two vacuum half spaces.
* `network.power(tr.plane_wave([0, 0, 1], helicity, k0=k0), side="negative")` —
  `PowerBalance` with `.transmission`, `.reflection`, `.absorption`.

No scattering physics is reimplemented; the closed-form expressions below are
used only as an *independent check* of the package output.

## Units and conventions

* **Lengths** (`thickness`, `wavelengths`) are in micrometers. The vacuum
  angular wavenumber is `k0 = 2*pi/wavelength` in 1/um; only the ratio
  `d/wavelength` matters, so any consistent length unit works.
* **`epsilon`** is given as `[real, imag]` (a bare number is also accepted) and
  is the *relative permittivity*, not a refractive index. The convention is
  passive-lossy for **positive** imaginary part, as used here (`+0.06`).
* **`mu`** defaults to 1 and **`kappa`** defaults to 0; both may be supplied as
  a number or a `[real, imag]` pair. The exterior is vacuum on both sides.
* **Chirality**: the two helicity eigenwaves see `n_pm = sqrt(eps*mu) ± kappa`
  with the *same* impedance `Z = sqrt(mu/eps)`. For the example,
  `n_+ = 1.5801 + 0.0200i`, `n_- = 1.4201 + 0.0200i` (reported under
  `checks.refractive_indices`).
* **Helicity ordering**: results are lists of shape `(n_wavelengths, 2)` with
  index 0 = **positive** helicity, index 1 = **negative** helicity, for `+z`
  incidence. Rather than relying on the raw port ordering, the illumination is
  built explicitly as `tr.plane_wave([0, 0, 1], "positive_helicity"/"negative_helicity")`.
  (For the record, this corresponds to port amplitude `[1, 0]` = positive and
  `[0, 1]` = negative in `PlaneWavePorts.default([0, 0])`, whose `pol` labels are
  `[1, 0]`; this was verified by expanding the plane waves in the port basis and
  against the analytic result with a complex `kappa`, which lifts the helicity
  degeneracy.)
* **Power fractions** are normalized to the incident flux; both exterior media
  are vacuum, so transmission is simply `|t|^2` with no index/impedance factor.
  `absorption` is returned by the package as `1 - T - R`.

## Example result (`results.json`)

Config: `d = 0.16 um`, `eps = 2.25 + 0.06i`, `kappa = 0.08`, `lambda = 0.55,
0.65, 0.8 um`.

| lambda (um) | T (+ / -) | R (+ / -) | A (+ / -) |
|---|---|---|---|
| 0.55 | 0.905416 / 0.905416 | 0.024049 / 0.024049 | 0.070536 / 0.070536 |
| 0.65 | 0.864572 / 0.864572 | 0.080756 / 0.080756 | 0.054673 / 0.054673 |
| 0.80 | 0.826736 / 0.826736 | 0.130154 / 0.130154 | 0.043110 / 0.043110 |

The two helicities give **identical power fractions**. This is the expected
physics, not a bug: for a reciprocal isotropic slab with *real* `kappa` in
vacuum, the chirality enters the co-polarized transmission only through the
common phase factor `exp(i*k0*kappa*d)`, so it produces optical rotation but no
circular dichroism. A nonzero `Im(kappa)` (allowed by the input parser) makes
that factor lossy/gainy and does split the two helicities — this is exactly how
the helicity ordering was validated.

## Checks performed

1. **Closed-form chiral slab.** Independent derivation in the circular-vector
   channels (forward and backward waves in the same channel carry `n_+` and
   `n_-`, respectively, with a common impedance): agreement with `treams_rs` to
   `9e-16` in all T, R, A values for both helicities at all three wavelengths.
2. **Achiral limit** `kappa = 0`: matches the standard Fabry–Pérot/Fresnel slab
   formulas to `1e-15`, and both helicities coincide.
3. **Lossless limit** `Im(eps) = 0`: absorption is zero to `5e-16` (a tiny
   negative value of that size is returned, since `A = 1 - T - R`), and
   `T + R = 1`.
4. **Trivial limits**: a vacuum slab and a zero-thickness slab give `T = 1`,
   `R = 0` to machine precision.
5. **Energy balance** is reported in the output (`checks.energy_balance`,
   `checks.max_energy_balance_error`); it is identically 1 by construction of
   `absorption`, so checks 1–4 carry the actual verification weight.

## Files

* `solution.py` — `run(config) -> dict`; CLI reads one JSON config from stdin
  and prints the result dict as JSON to stdout.
* `results.json` — output for the example config.
* `check.py` — validation script (finite differences/derivatives are not
  involved; no derivative quantities are requested by this task).

Reproduce with:

```
echo '{"thickness":0.16,"epsilon":[2.25,0.06],"kappa":0.08,"wavelengths":[0.55,0.65,0.8]}' \
  | python solution.py > results.json
```
