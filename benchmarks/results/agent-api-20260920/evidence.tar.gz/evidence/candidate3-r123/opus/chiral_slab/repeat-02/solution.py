"""Normal-incidence power balance of a uniform reciprocal chiral slab.

The slab is normal to z, has thickness ``thickness`` (micrometers) and material
``Material(epsilon, mu, kappa)``; vacuum fills both half spaces.  For each
vacuum wavelength the transmitted, reflected and absorbed power fractions are
computed for a +z propagating plane wave of positive and of negative helicity,
using the plane-wave S-matrix of treams-rs.
"""

import json
import sys

import numpy as np
import treams_rs as tr

HELICITIES = ("positive_helicity", "negative_helicity")


def _complex(value, default=0.0):
    """Accept a number, a [real, imag] pair or None."""
    if value is None:
        return complex(default)
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"expected a scalar or [real, imag] pair, got {value!r}")
    return complex(value)


def run(config):
    thickness = float(config["thickness"])
    epsilon = _complex(config["epsilon"], 1.0)
    mu = _complex(config.get("mu"), 1.0)
    kappa = _complex(config.get("kappa"), 0.0)
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]

    material = tr.Material(epsilon, mu, kappa)
    # Normal incidence: a single transverse wavevector (kx, ky) = (0, 0) with
    # both helicity channels on either side of the slab.
    ports = tr.PlaneWavePorts.default([0.0, 0.0])

    transmission, reflection, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2 * np.pi / wavelength  # vacuum angular wavenumber, 1/um
        network = tr.slab(
            basis=ports,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1,  # vacuum below the slab
            positive_medium=1,  # vacuum above the slab
            polarization="helicity",
        )
        rows = []
        for helicity in HELICITIES:
            # +z propagating illumination coming from the negative-z vacuum.
            incident = tr.plane_wave([0, 0, 1], helicity, k0=k0)
            power = network.power(incident, side="negative")
            rows.append((power.transmission, power.reflection, power.absorption))
        transmission.append([float(r[0]) for r in rows])
        reflection.append([float(r[1]) for r in rows])
        absorption.append([float(r[2]) for r in rows])

    balance = [
        [t + r + a for t, r, a in zip(trow, rrow, arow)]
        for trow, rrow, arow in zip(transmission, reflection, absorption)
    ]
    return {
        "wavelengths": wavelengths,
        "helicity_order": ["positive", "negative"],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "checks": {
            "energy_balance": balance,
            "max_energy_balance_error": float(
                max(abs(v - 1.0) for row in balance for v in row)
            ),
            "min_fraction": float(
                min(min(min(t), min(r), min(a))
                    for t, r, a in zip(transmission, reflection, absorption))
            ),
            "refractive_indices": {
                "negative_helicity": [material.nmp[0].real, material.nmp[0].imag],
                "positive_helicity": [material.nmp[1].real, material.nmp[1].imag],
            },
        },
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
