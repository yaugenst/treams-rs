"""Power fractions for normal incidence on a uniform reciprocal chiral slab.

The slab is normal to z, bounded by vacuum (or given exterior media) on both
sides, and illuminated from the negative side along +z.  Scattering is solved
with treams-rs (``treams_rs.slab``) in the helicity (circular) polarization
basis.  Lengths are in micrometers; epsilon, mu and kappa are dimensionless.
"""

import json
import sys

import numpy as np
import treams_rs as tr

TWO_PI = 2.0 * np.pi


def _complex(value):
    """Accept a scalar, [real, imag] pair, or complex-like input."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0], 0.0)
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError("expected a scalar or a [real, imag] pair")
    return complex(value)


def _helicity_amplitudes(basis):
    """Unit amplitude vectors for positive and negative helicity, in that order.

    ``basis.pol`` labels each port with the treams helicity index: 1 is
    positive helicity, 0 is negative helicity.
    """
    pol = np.asarray(basis.pol)
    amps = []
    for label in (1, 0):
        (idx,) = np.nonzero(pol == label)
        vec = np.zeros(pol.size)
        vec[idx[0]] = 1.0
        amps.append(vec)
    return amps


def run(config):
    thickness = float(config["thickness"])
    epsilon = _complex(config["epsilon"])
    mu = _complex(config.get("mu", 1.0))
    kappa = _complex(config.get("kappa", config.get("chirality", 0.0)))
    wavelengths = [float(w) for w in config["wavelengths"]]

    material = tr.Material([epsilon, mu, kappa])
    negative_medium = tr.Material(_complex(config.get("epsilon_below", 1.0)))
    positive_medium = tr.Material(_complex(config.get("epsilon_above", 1.0)))

    basis = tr.PlaneWavePorts.default([0.0, 0.0])
    amplitudes = _helicity_amplitudes(basis)

    transmission, reflection, absorption = [], [], []
    for lam in wavelengths:
        k0 = TWO_PI / lam
        smat = tr.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=negative_medium,
            positive_medium=positive_medium,
            polarization="helicity",
        )
        row_t, row_r, row_a = [], [], []
        for amp in amplitudes:  # positive helicity first, then negative
            balance = smat.power(amp, side="negative")
            row_t.append(float(balance.transmission))
            row_r.append(float(balance.reflection))
            row_a.append(float(balance.absorption))
        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
