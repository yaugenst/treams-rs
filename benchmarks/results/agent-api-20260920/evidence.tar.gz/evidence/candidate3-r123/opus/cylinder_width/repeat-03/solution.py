"""Scattering, extinction and absorption cross widths of a homogeneous
infinite circular cylinder aligned with z, illuminated at normal incidence
(kz = 0) by a positive-helicity plane wave travelling along +x.

All numerics come from treams-rs (cylindrical T-matrix of a homogeneous
cylinder plus its plane-wave cross-width routine).
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as treams


def _complex(value):
    """Accept a scalar, [re, im] pair or a complex-parsable string."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) != 2:
            raise ValueError("expected [real, imag]")
        return complex(float(value[0]), float(value[1]))
    if isinstance(value, str):
        return complex(value)
    return complex(value)


def run(config):
    radius = float(config["radius"])
    epsilon = _complex(config["epsilon"])
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]
    mmax = int(config["mmax"])

    # Optional overrides; defaults are the conventions stated in the task.
    mu = _complex(config.get("mu", 1.0))
    kappa = _complex(config.get("kappa", 0.0))
    medium = treams.Material(
        _complex(config.get("epsilon_medium", config.get("medium_epsilon", 1.0))),
        _complex(config.get("mu_medium", config.get("medium_mu", 1.0))),
        _complex(config.get("kappa_medium", config.get("medium_kappa", 0.0))),
    )
    material = treams.Material(epsilon, mu, kappa)

    if radius <= 0.0:
        raise ValueError("radius must be positive")
    if mmax < 0:
        raise ValueError("mmax must be non-negative")
    if not wavelengths:
        raise ValueError("at least one wavelength is required")

    scattering, extinction, absorption = [], [], []
    for lam in wavelengths:
        if lam <= 0.0:
            raise ValueError("wavelengths must be positive")
        k0 = 2.0 * np.pi / lam  # vacuum angular wavenumber, 1/um

        tm = treams.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],  # normal incidence: no axial wavenumber
            mmax=mmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )
        inc = treams.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
        )
        xw = tm.cross_widths(inc)  # length units (um), default flux=0.5

        scattering.append(float(xw.scattering))
        extinction.append(float(xw.extinction))
        absorption.append(float(xw.absorption))

    return {
        "wavelengths": wavelengths,
        "radius": radius,
        "epsilon": [epsilon.real, epsilon.imag],
        "mmax": mmax,
        "kz": 0.0,
        "units": {
            "length": "um",
            "cross_widths": "um (cross section per unit cylinder length)",
        },
        "scattering_cross_width": scattering,
        "extinction_cross_width": extinction,
        "absorption_cross_width": absorption,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
