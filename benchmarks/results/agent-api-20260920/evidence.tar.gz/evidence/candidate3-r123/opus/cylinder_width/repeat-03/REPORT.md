# Cross widths of a homogeneous infinite cylinder (kz = 0, positive helicity)

## Problem and method

A homogeneous circular cylinder of radius `radius`, relative permittivity
`epsilon = [re, im]`, `mu = 1`, `kappa = 0`, infinite along **z**, embedded in
vacuum. Illumination is a plane wave propagating along **+x** (i.e. exactly
perpendicular to the cylinder axis, so the axial wavenumber is `kz = 0`) with
positive helicity. For each wavelength the code builds the cylindrical
T-matrix with `treams_rs.cylinder_tmatrix(k0=2*pi/lambda, kz=[0.0], mmax=...,
radius=..., material=..., medium=1, polarization="helicity")`, builds the
illumination with `treams_rs.plane_wave(direction=[1,0,0],
polarization="positive_helicity", k0=k0, material=1)`, and evaluates
`tmatrix.cross_widths(incident)`. No scattering physics is re-implemented.

## Units and conventions

* Lengths (`radius`, `wavelengths`) are in micrometres; `epsilon`, `mu`,
  `kappa` are relative and dimensionless.
* `k0 = 2*pi/lambda` is the **vacuum** angular wavenumber in 1/um; the
  wavelength in the config is the vacuum wavelength.
* Because the object is infinite in z, the reported quantities are **cross
  widths**: cross section per unit cylinder length, hence length units (um).
  They are *not* normalised by any area (no `pi a^2` sphere normalisation) and
  are not dimensionless efficiencies. To obtain the usual cylinder efficiency
  divide by the geometric width `2 * radius`.
* Normalisation uses the treams default `flux = 0.5`, which is the flux of the
  unit-amplitude helicity plane wave produced by `plane_wave`, so the widths
  are the physical ratios (scattered/absorbed power per unit length) /
  (incident intensity).
* `mmax` is the azimuthal cutoff: cylindrical orders `m = -mmax..mmax` for both
  polarisations, i.e. a `2*(2*mmax+1)` dimensional T-matrix at the single
  `kz = 0` label.
* Helicity labelling follows treams: polarisation index 1 = positive helicity.
* Sign/time convention is treams' `exp(-i omega t)`, so a lossy medium has
  positive imaginary `epsilon`; the example `[5, 0.1]` is absorbing.
* Outputs are lists ordered exactly as the input `wavelengths`.

## Output keys

`scattering_cross_width`, `extinction_cross_width`, `absorption_cross_width`
(all lists of floats in um, wavelength-ordered), plus echoes of the inputs and
a `units` block. Absorption is taken from treams' `CrossSections.absorption`
(extinction minus scattering).

## Results (example config)

radius = 0.08 um, epsilon = 5 + 0.1i, mmax = 4:

| lambda (um) | C_sca (um) | C_ext (um) | C_abs (um) |
|---|---|---|---|
| 0.50 | 0.5330353956 | 0.5611064991 | 0.0280711035 |
| 0.65 | 0.2585917234 | 0.2695397227 | 0.0109479993 |
| 0.80 | 0.2407417379 | 0.2488644544 | 0.0081227166 |

## Checks performed

1. **Analytic reference.** Compared against the textbook normal-incidence
   cylinder series (Bohren & Huffman): for TE and TM separately
   `C = (4/k) * sum_m |b_m|^2` and `(4/k) * sum_m Re b_m`, with the
   helicity result being the mean of the TE and TM values (a helicity state is
   an equal-intensity superposition of the two decoupled normal-incidence
   channels). Agreement with treams is to machine precision
   (relative error <= 4.4e-16) for all three wavelengths. The Bessel/Hankel
   functions for this check came from `treams_rs.special`; the check is a
   validation only, the reported numbers come from treams.
2. **Energy balance.** `C_ext - C_sca - C_abs = 0` exactly (0.0).
3. **Lossless limit.** With `epsilon = [5, 0]` the absorption is 1e-16, i.e.
   zero to round-off.
4. **Cutoff convergence.** At lambda = 0.5 um the widths change by <2e-10
   between `mmax = 4` and `mmax = 10` (mmax=1: 5.3150e-1, mmax=3: 5.330354e-1,
   mmax>=4: 5.3303540e-1), so `mmax = 4` is converged for this small particle.
   Larger particles need a larger `mmax`; treams caps `mmax` at 128.
5. **Extinction paradox.** For a large lossless cylinder (a = 5 um,
   epsilon = 4, lambda = 0.5 um, mmax = 110) the extinction width reaches
   0.947 * 4a, approaching the expected twice-geometric-width limit
   `C_ext -> 2 * (2a)`. This also confirms the flux normalisation (the
   alternative `flux = 1` normalisation would give exactly the geometric
   width, which is unphysical for extinction).

## Usage

```
echo '{"radius":0.08,"epsilon":[5,0.1],"wavelengths":[0.5,0.65,0.8],"mmax":4}' \
  | python solution.py > results.json
```

`run(config)` accepts the same dictionary. Optional keys `mu`, `kappa` and
`epsilon_medium`/`mu_medium`/`kappa_medium` override the stated defaults
(1, 0, vacuum). A scalar `wavelengths` or a scalar/string `epsilon` is also
accepted. Non-positive radius or wavelength and negative `mmax` raise
`ValueError`.
