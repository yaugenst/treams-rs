# Infinite cylinder cross widths (kz = 0, positive helicity along +x)

## What is computed
For each wavelength the cylindrical T-matrix of a homogeneous infinite cylinder
along z is built with `treams_rs.cylinder_tmatrix` at a single axial wavenumber
`kz = 0` (normal incidence) and azimuthal cutoff `mmax`. It is illuminated by a
plane wave propagating along +x with positive helicity
(`treams_rs.plane_wave(direction=[1,0,0], polarization="positive_helicity")`),
and `TMatrixC.cross_widths` returns the named scattering, extinction and
absorption **cross widths**.

## Units and conventions
- Lengths (radius, wavelengths, outputs) are in micrometers. Cross widths of an
  infinite cylinder are a cross section per unit length, so they carry length
  units (µm) — no sphere-area normalization is applied.
- `k0 = 2*pi/wavelength` is the vacuum angular wavenumber (µm^-1).
- `epsilon` is given as `[real, imag]` and is relative/dimensionless; `mu = 1`
  and `kappa = 0` unless supplied. The exterior is vacuum by default
  (optional keys `mu`, `kappa`, `epsilon_medium`, `mu_medium`, `kappa_medium`
  are honoured if present). The time convention is `exp(-i omega t)`, so a
  positive imaginary epsilon means loss.
- The T-matrix is set up in the helicity polarization basis, matching the
  helicity illumination; basis size is `2*(2*mmax+1)` modes.
- Outputs are wavelength-ordered lists in the same order as the input
  `wavelengths`.

## Checks performed
- **Convergence in mmax**: for the example (r = 0.08 µm, eps = 5+0.1i,
  lambda = 0.5 µm) the widths agree to ~1e-12 relative between mmax = 4, 8, 12,
  so the requested cutoff is fully converged.
- **Energy balance / lossless limit**: with eps = 5+0i the extinction equals the
  scattering width to machine precision and absorption is ~1e-16, i.e. the
  optical theorem is satisfied.
- **Helicity symmetry**: for the achiral, lossless cylinder the positive- and
  negative-helicity illuminations give identical widths, as required by mirror
  symmetry of a non-chiral scatterer.
- Absorption is positive for the lossy example and equals extinction minus
  scattering.

## Example result (`results.json`)
| lambda (µm) | sigma_sca (µm) | sigma_ext (µm) | sigma_abs (µm) |
|---|---|---|---|
| 0.50 | 0.533035 | 0.561106 | 0.028071 |
| 0.65 | 0.258592 | 0.269540 | 0.010948 |
| 0.80 | 0.240742 | 0.248864 | 0.008123 |

## Usage
```
echo '{"radius":0.08,"epsilon":[5,0.1],"wavelengths":[0.5,0.65,0.8],"mmax":4}' \
  | python solution.py
```
`run(config)` returns the same dictionary directly.
