# Scattering by a homogeneous infinite cylinder (kz = 0)

## What is computed

For each wavelength, `solution.py` builds the cylindrical T-matrix of a homogeneous
infinite cylinder aligned with **z** (`treams_rs.cylinder_tmatrix`, single axial
wavenumber `kz = 0`, azimuthal orders `-mmax .. +mmax`, helicity polarization basis),
illuminates it with a positive-helicity plane wave propagating along **+x**
(`treams_rs.plane_wave`), and evaluates `TMatrixC.cross_widths(...)`, which returns
the scattering and extinction **cross widths** together with the derived absorption
width. All numerics come from treams-rs; nothing is reimplemented.

## Units and conventions

- Lengths (`radius`, `wavelengths`) are in micrometers; `k0 = 2*pi/wavelength` in 1/um.
- `epsilon` is given as `[real, imag]`, dimensionless and relative. `mu = 1` and
  `chirality = 0` unless the config overrides them (optional keys `mu`,
  `chirality`/`kappa`, `medium`); the exterior is vacuum by default.
- Time convention is treams' `exp(-i w t)`, so a **positive** imaginary part of
  epsilon means loss (verified: absorption comes out positive here).
- Because the scatterer is infinite along z, the reported quantities are cross
  **widths** with units of length (um), i.e. power per unit cylinder length divided
  by the incident intensity. **No sphere-area normalization is applied** — the values
  are the raw length-unit widths returned by `cross_widths`, not divided by any
  geometric cross-section.
- `absorption = extinction - scattering`.
- With `kz = 0` the illumination is at normal incidence; the wavevector is
  `k0 * n_host * (1, 0, 0)` and positive helicity is selected by name, so the
  library's own helicity convention is used rather than a hand-built coefficient pair.

## Output

`run(config)` returns a JSON-serializable dict with `wavelengths`,
`scattering_cross_width`, `extinction_cross_width`, `absorption_cross_width`
(lists in the same order as the input wavelengths), plus `units` and the echoed
`settings`. The CLI reads one config dict from stdin and prints this dict as JSON.

## Results for the example config

radius = 0.08 um, epsilon = 5 + 0.1i, mmax = 4:

| lambda (um) | sigma_sca (um) | sigma_ext (um) | sigma_abs (um) |
|---|---|---|---|
| 0.50 | 0.5330353956 | 0.5611064991 | 0.0280711035 |
| 0.65 | 0.2585917234 | 0.2695397227 | 0.0109479993 |
| 0.80 | 0.2407417379 | 0.2488644544 | 0.0081227166 |

Saved in `results.json`.

## Checks performed

1. **Azimuthal convergence.** Extinction changes by < 3e-9 (relative ~5e-9) between
   `mmax = 4`, 6 and 12 for the example; `mmax = 4` is converged for this size
   parameter, and results are stable to `mmax = 16`.
2. **Energy consistency / losses.** With a lossless cylinder (`epsilon = 5 + 0i`)
   the absorption width is -1.1e-16 um, i.e. zero to machine precision, so
   extinction and scattering agree exactly as required by the optical theorem.
3. **Trivial scatterer.** `epsilon = 1` (index-matched to vacuum) gives scattering
   and extinction widths of order 1e-17 um or smaller.
4. **Polarization consistency.** For this achiral cylinder at normal incidence, TE and
   TM channels decouple, so a circularly polarized wave must give the mean of the two
   linear results. At lambda = 0.5 um: E||z gives sigma_sca = 0.7249536, E||y gives
   0.3411172, mean 0.5330354 — identical to the positive-helicity value above.
   Negative-helicity illumination reproduces the same widths, as expected for an
   achiral scatterer.
5. **Sign/ordering.** Absorption is positive for a lossy cylinder and decreases with
   increasing wavelength here, consistent with the shrinking size parameter.

No derivatives or optimization are requested by this task, so no pullback/adjoint
machinery is used; the finite-difference-free rule is respected trivially.
