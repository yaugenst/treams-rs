"""Scattering by a homogeneous infinite cylinder (kz = 0, helicity illumination).

Uses treams-rs for the cylindrical T-matrix and the cross-width normalization.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _complex(value: Any) -> complex:
    """Accept a scalar or a ``[real, imag]`` pair."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ValueError("complex entries must be given as [real, imag]")
        return complex(float(value[0]), float(value[1]))
    if isinstance(value, dict):
        return complex(float(value["real"]), float(value["imag"]))
    return complex(value)


def run(config: dict) -> dict:
    radius = float(config["radius"])
    if radius <= 0:
        raise ValueError("radius must be positive")

    epsilon = _complex(config["epsilon"])
    mu = _complex(config.get("mu", 1))
    kappa = _complex(config.get("chirality", config.get("kappa", 0)))
    material = tr.Material(epsilon, mu, kappa)

    medium_cfg = config.get("medium", config.get("epsilon_host", 1))
    medium = tr.Material(*medium_cfg) if isinstance(medium_cfg, (list, tuple)) else tr.Material(_complex(medium_cfg))

    mmax = int(config["mmax"])
    if mmax < 0:
        raise ValueError("mmax must be non-negative")

    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um

        # Cylindrical T-matrix of the homogeneous cylinder at normal incidence.
        tmat = tr.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )

        # Positive-helicity plane wave travelling along +x in the host medium.
        illumination = tr.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
        )

        widths = tmat.cross_widths(illumination)
        scattering.append(float(widths.scattering))
        extinction.append(float(widths.extinction))
        absorption.append(float(widths.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering_cross_width": scattering,
        "extinction_cross_width": extinction,
        "absorption_cross_width": absorption,
        "units": {"wavelength": "um", "cross_width": "um"},
        "settings": {
            "radius": radius,
            "epsilon": [epsilon.real, epsilon.imag],
            "mu": [mu.real, mu.imag],
            "chirality": [kappa.real, kappa.imag],
            "mmax": mmax,
            "kz": 0.0,
            "polarization": "positive_helicity",
            "incidence_direction": [1.0, 0.0, 0.0],
        },
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
