"""Scattering by a homogeneous infinite cylinder parallel to z (kz = 0).

Cross widths (length units, micrometers) for positive-helicity plane-wave
illumination travelling along +x, computed with treams-rs cylindrical
T-matrices.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as treams


def _complex(value: Any) -> complex:
    """Accept a scalar or a ``[real, imag]`` pair."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ValueError(f"expected [real, imag], got {value!r}")
        return complex(float(value[0]), float(value[1]))
    return complex(value)


def _material(epsilon: Any, mu: Any = 1, kappa: Any = 0) -> treams.Material:
    return treams.Material(_complex(epsilon), _complex(mu), _complex(kappa))


def run(config: dict) -> dict:
    radius = float(config["radius"])
    mmax = int(config["mmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]

    material = _material(
        config["epsilon"], config.get("mu", 1), config.get("kappa", 0)
    )
    medium = _material(
        config.get("epsilon_medium", config.get("medium_epsilon", 1)),
        config.get("mu_medium", 1),
        config.get("kappa_medium", 0),
    )

    scattering, extinction, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        tm = treams.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],
            mmax=mmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )
        illu = treams.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
        )
        xw = tm.cross_widths(illu)
        scattering.append(float(xw.scattering))
        extinction.append(float(xw.extinction))
        absorption.append(float(xw.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering_cross_width": scattering,
        "extinction_cross_width": extinction,
        "absorption_cross_width": absorption,
        "units": "micrometer",
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
