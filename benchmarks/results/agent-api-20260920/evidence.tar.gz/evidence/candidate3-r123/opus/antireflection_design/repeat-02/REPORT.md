# Single-layer antireflection coating: analytic-gradient thickness optimization

## Problem and conventions

A plane wave propagates along **+z** from vacuum, hits a single homogeneous
lossless coating of thickness `d`, and enters a semi-infinite substrate; there
is no vacuum gap between coating and substrate.

```
   vacuum (eps = 1)   |   coating (eps)   |   substrate (substrate_epsilon)
        z < 0              0 < z < d               z > d
```

* **Units** — all lengths (`wavelength`, `initial_thickness`, `bounds`,
  returned `thickness`) are in micrometers. Permittivities are relative and
  dimensionless; `mu = 1`, `kappa = 0` everywhere (treams-rs defaults).
* `k0 = 2*pi/wavelength` (rad/µm) is passed to treams-rs.
* Normal incidence is encoded as the zero transverse wavevector,
  `PlaneWavePorts.default([0, 0])`.
* Incidence along +z is illumination from the **negative** side of the slab
  S-matrix, so `negative_medium = 1.0` (vacuum) and
  `positive_medium = substrate_epsilon`. Reflected power is the
  `reflection` field of `SMatrix.power([0, 1], side="negative")`, i.e. the
  fraction of incident power returned to the vacuum half space. The port
  amplitude `[0, 1]` selects the positive-helicity channel; at normal
  incidence with achiral isotropic media reflectance is
  polarization-independent, so this equals the s/p reflectance.
* `reflection` is a **power** fraction (|r|^2), in [0, 1], not a field
  amplitude.

## Method

`run(config)` builds the reflectance with `treams_rs.advect.slab` (the Advect
adapter over the Rust `slab` S-matrix) and differentiates it with
`advect.value_and_grad`, which invokes treams-rs' **native analytic pullbacks**.
Finite differences are used nowhere in the optimization or in the reported
gradient; they only appear in the validation below.

The optimizer is projected gradient descent on `d`:

* Barzilai–Borwein step sizes from successive (d, dR/dd) pairs,
* Armijo backtracking line search (sufficient-decrease constant 1e-4),
* clipping of every trial point to `bounds` (projection), so the iterate never
  leaves `[lo, hi]`,
* stop on `R < 1e-14`, on a stalled line search (a stationary or
  bound-constrained point), or after 400 iterations.

No closed-form quarter-wave thickness is inserted at any point; the reported
thickness is the endpoint of the gradient iteration started at
`initial_thickness`.

## Returned keys

| key | meaning |
| --- | --- |
| `thickness` | optimized coating thickness (µm), inside `bounds` |
| `reflection` | reflected power fraction at `thickness` |
| `initial_reflection` | reflected power fraction at `initial_thickness` (clipped to bounds) |
| `gradient` | final analytic `dR/dthickness` (1/µm) from the treams-rs pullback |
| `loss_history` | reflectance after each accepted step, first entry = initial value |
| `iterations`, `bounds`, `wavelength`, `converged` | bookkeeping; `converged` is `reflection < 1e-7` |

## Example result (`results.json`)

Config `wavelength = 0.7`, `epsilon = 2.25`, `substrate_epsilon = 5.0625`,
`initial_thickness = 0.05`, `bounds = [0.025, 0.21]`:

* `initial_reflection = 9.594e-02`
* `thickness = 0.1166666667 µm`, `reflection = 1.79e-19` (well below the 1e-7
  target), `gradient = 4.7e-09`, 6 accepted steps.

## Checks

1. **Gradient validation** (finite differences used only as a check): at
   `d = 0.05` the analytic derivative is `-1.8625903780` versus a central
   difference of `-1.8625903778` (h = 1e-6); agreement to ~1e-9 relative.
2. **Physics sanity** — here `n_coat = 1.5` and `n_sub = 2.25`, so
   `n_coat = sqrt(n_sub)` is index-matched and a perfect zero exists; the
   converged thickness equals the quarter-wave value `wavelength/(4*n_coat)
   = 0.7/6 = 0.116667 µm`. This is a *post-hoc* consistency check, not an input.
3. **Power balance** — `transmission + reflection + absorption = 1` with
   `absorption ~ 1e-16` (lossless, real permittivities).
4. **Non-matched case** — `wavelength = 0.6`, `eps = 1.5`, `substrate = 6.25`:
   the optimizer returns `d = 0.1224745`, `R = 0.0625`, matching a brute-force
   scan of 20001 thicknesses (`d = 0.12248`, `R = 0.0625`). The residual
   reflectance is the correct floor for a non-matched coating.
5. **Bound handling** — with `bounds = [0.025, 0.08]` the iterate stops at the
   upper bound `0.08` with a still-negative gradient, the expected
   Karush–Kuhn–Tucker behaviour for an active constraint.
6. **Stationary start** — starting at the half-wave point `d = 0.2333` (a local
   maximum with a near-zero gradient) the line search still escapes and reaches
   `R = 5.8e-19`.

Note: reflectance is periodic in `d` with period `wavelength/(2*n_coat)`, so a
local gradient method converges to the minimum in the basin containing
`initial_thickness`; that is the intended behaviour for a local design task.

## Usage

```bash
echo '{"wavelength":0.7,"epsilon":2.25,"substrate_epsilon":5.0625,
       "initial_thickness":0.05,"bounds":[0.025,0.21]}' | python solution.py
```
