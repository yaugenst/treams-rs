"""Thickness optimization of a single lossless antireflection coating.

Geometry (all lengths in micrometers): vacuum half space (negative side) ->
coating of thickness ``d`` and permittivity ``epsilon`` -> substrate half space
with ``substrate_epsilon``.  A plane wave travels along +z, i.e. it is incident
from the negative side.  Reflected power fractions and their analytic
derivative with respect to ``d`` come from treams-rs through the Advect
adapter (native Rust pullbacks); no finite differences are used for the
optimization itself.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs.advect as tr

_BASIS = tr.PlaneWavePorts.default([0, 0])  # normal incidence, kx = ky = 0


def _reflection_factory(k0, epsilon, substrate_epsilon):
    """Return R(d) built from treams-rs objects, traceable by Advect."""

    def reflection(thickness):
        smat = tr.slab(
            basis=_BASIS,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        # Channel [0, 1]: unit amplitude in the positive-helicity port.
        return smat.power([0, 1], side="negative").reflection

    return reflection


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    d0 = float(config["initial_thickness"])
    lo, hi = (float(v) for v in config["bounds"])
    if lo > hi:
        lo, hi = hi, lo

    tol = float(config.get("tolerance", 1e-12))
    max_iter = int(config.get("max_iterations", 400))

    k0 = 2.0 * np.pi / wavelength
    reflection = _reflection_factory(k0, epsilon, substrate_epsilon)
    value_and_grad = ad.value_and_grad(reflection)

    def evaluate(d):
        # Fresh transform call per step: each reverse pass is single use.
        val, grad = value_and_grad(float(d))
        return float(val), float(grad)

    d = min(max(d0, lo), hi)
    loss, grad = evaluate(d)
    initial_reflection = float(reflection(float(min(max(d0, lo), hi))))
    loss_history = [loss]

    # R(d) oscillates with period lambda / (2 n_coat); never move more than a
    # quarter period per step so the search cannot jump over a minimum.
    period = wavelength / (2.0 * np.sqrt(epsilon))
    max_move = min(0.25 * period, max(hi - lo, 1e-12))
    step = 0.1 * max_move / max(abs(grad), 1e-12)
    for _ in range(max_iter):
        if loss <= tol:
            break
        # Projected-gradient stationarity: no descent possible inside bounds.
        if abs(grad) < 1e-14 or (
            (d <= lo + 1e-15 and grad > 0.0) or (d >= hi - 1e-15 and grad < 0.0)
        ):
            break

        accepted = False
        trial_step = min(step, max_move / abs(grad))
        for _ in range(60):
            cand = min(max(d - trial_step * grad, lo), hi)
            if abs(cand - d) < 1e-15:
                break
            cand_loss, cand_grad = evaluate(cand)
            # Armijo condition on the projected step.
            if cand_loss <= loss - 1e-4 * grad * (d - cand):
                d, loss, grad = cand, cand_loss, cand_grad
                step = trial_step * 2.0  # grow for the next iteration
                accepted = True
                break
            trial_step *= 0.5
        if not accepted:
            break
        loss_history.append(loss)

    final_loss, final_grad = evaluate(d)
    return {
        "thickness": float(d),
        "reflection": float(final_loss),
        "initial_reflection": float(initial_reflection),
        "gradient": float(final_grad),
        "loss_history": [float(v) for v in loss_history],
        "iterations": len(loss_history) - 1,
        "bounds": [lo, hi],
        "converged": bool(final_loss < 1e-7),
        "transmission": float(1.0 - final_loss),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
