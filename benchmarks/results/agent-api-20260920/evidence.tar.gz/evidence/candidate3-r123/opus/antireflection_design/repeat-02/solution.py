"""Analytic-gradient thickness optimization of a single lossless AR coating.

Geometry (all lengths in micrometers, permittivities relative/dimensionless):

    vacuum (eps = 1)  |  coating (eps)  |  substrate (substrate_epsilon)
          z < 0            0 < z < d              z > d

A plane wave travels along +z, i.e. it is incident from the *negative* side of
the slab S-matrix.  The reflected power fraction R(d) is obtained from
``treams_rs`` and its derivative dR/dd from the native Rust pullbacks exposed
through the Advect adapter (``treams_rs.advect`` + ``advect.value_and_grad``).
No finite differences enter the optimization.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np

import treams_rs as t
import treams_rs.advect as tr


def _make_objective(wavelength, epsilon, substrate_epsilon):
    """Return f(d) -> (R, dR/dd) using treams-rs analytic pullbacks."""
    basis = t.PlaneWavePorts.default([0.0, 0.0])  # normal incidence channels
    k0 = 2.0 * np.pi / wavelength

    def reflection(thickness):
        smat = tr.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
            polarization="helicity",
        )
        # incidence along +z == illumination from the negative side;
        # [0, 1] selects the positive-helicity incoming port.
        return smat.power([0, 1], side="negative").reflection

    value_and_grad = ad.value_and_grad(reflection)

    def f(d):
        v, g = value_and_grad(float(d))
        return float(v), float(g)

    return f


def _optimize(f, d0, lo, hi, max_iter=400, tol=1e-14):
    """Projected gradient descent with Barzilai-Borwein steps + Armijo backtracking."""
    d = min(max(float(d0), lo), hi)
    val, grad = f(d)
    history = [val]

    step = 0.1 * (hi - lo) / max(abs(grad), 1e-12)
    prev_d = prev_grad = None

    for _ in range(max_iter):
        if val < 1e-14:
            break
        if prev_d is not None:
            ds, dg = d - prev_d, grad - prev_grad
            if abs(dg) > 0.0:
                bb = abs(ds * ds / (ds * dg)) if ds * dg != 0 else step
                if np.isfinite(bb) and bb > 0:
                    step = bb

        # Armijo backtracking along the projected steepest-descent direction.
        accepted = False
        trial_step = step
        for _ls in range(60):
            cand = min(max(d - trial_step * grad, lo), hi)
            delta = cand - d
            if abs(delta) < 1e-18:
                break
            cval, cgrad = f(cand)
            if cval <= val + 1e-4 * grad * delta:
                accepted = True
                break
            trial_step *= 0.5
        if not accepted:
            break

        prev_d, prev_grad = d, grad
        d, improvement = cand, val - cval
        val, grad = cval, cgrad
        step = trial_step
        history.append(val)
        if improvement <= tol * max(1.0, abs(val)) and val < 1e-12:
            break

    return d, val, grad, history


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    d0 = float(config["initial_thickness"])
    lo, hi = sorted(float(b) for b in config["bounds"])

    f = _make_objective(wavelength, epsilon, substrate_epsilon)

    d_start = min(max(d0, lo), hi)
    initial_reflection, _ = f(d_start)

    d, val, grad, history = _optimize(f, d_start, lo, hi)

    return {
        "thickness": d,
        "reflection": val,
        "initial_reflection": initial_reflection,
        "gradient": grad,
        "loss_history": history,
        "iterations": len(history) - 1,
        "bounds": [lo, hi],
        "wavelength": wavelength,
        "converged": bool(val < 1e-7),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
