"""Analytic-gradient thickness optimization of a single-layer antireflection coating.

Physics: a lossless homogeneous coating of thickness ``t`` (micrometers) sits
directly on a semi-infinite substrate; light arrives at normal incidence from
vacuum travelling along +z.  The reflected power fraction is evaluated with
``treams_rs`` (plane-wave S-matrix of a multilayer slab) and its derivative
``dR/dt`` comes from the native Rust pullbacks exposed through the Advect
adapter ``treams_rs.advect``.  No finite differences enter the optimization.

CLI: reads one JSON config dict on stdin, prints the result dict as JSON.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs as t
import treams_rs.advect as tr

# Port index of the incident channel used for the illumination vector.
_INCIDENT = [0.0, 1.0]


def _make_reflection(k0, epsilon, substrate_epsilon):
    """Return f(t) -> reflected power fraction, differentiable under Advect."""
    basis = t.PlaneWavePorts.default([0, 0])

    def reflection(thickness):
        smat = tr.multilayer_slab(
            basis=basis,
            k0=k0,
            thicknesses=[thickness],
            materials=[epsilon],
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        return smat.power(_INCIDENT, side="negative").reflection

    return reflection


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = complex(config["epsilon"])
    substrate_epsilon = complex(config["substrate_epsilon"])
    t0 = float(config["initial_thickness"])
    lo, hi = (float(b) for b in config["bounds"])
    if lo > hi:
        lo, hi = hi, lo

    tol = float(config.get("reflection_tolerance", 1e-7))
    max_iter = int(config.get("max_iterations", 500))

    # treams takes real permittivities as floats; keep complex only if needed.
    eps = epsilon.real if epsilon.imag == 0.0 else epsilon
    sub = substrate_epsilon.real if substrate_epsilon.imag == 0.0 else substrate_epsilon

    k0 = 2.0 * np.pi / wavelength
    reflection = _make_reflection(k0, eps, sub)
    value_and_grad = ad.value_and_grad(reflection)

    def clip(x):
        return min(max(x, lo), hi)

    x = clip(t0)
    initial_reflection = float(reflection(x))

    loss, grad = value_and_grad(x)
    loss = float(loss)
    grad = float(np.real(grad))
    loss_history = [loss]

    # Scale the first trial step to the phase scale of the layer.
    step = 0.1 * wavelength / max(np.sqrt(abs(eps)), 1.0)
    iterations = 0

    for _ in range(max_iter):
        if loss < tol:
            break
        # Projected gradient step with backtracking line search.
        accepted = False
        for _ls in range(60):
            x_new = clip(x - step * grad)
            if x_new == x:
                break
            loss_new, grad_new = value_and_grad(x_new)
            loss_new = float(loss_new)
            if loss_new < loss:
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break
        x, loss, grad = x_new, loss_new, float(np.real(grad_new))
        loss_history.append(loss)
        iterations += 1
        step *= 2.0  # grow again; the line search shrinks it when needed.

    final_loss, final_grad = value_and_grad(x)

    return {
        "thickness": float(x),
        "reflection": float(final_loss),
        "initial_reflection": initial_reflection,
        "gradient": float(np.real(final_grad)),
        "loss_history": [float(v) for v in loss_history],
        "initial_thickness": float(clip(t0)),
        "bounds": [lo, hi],
        "wavelength": wavelength,
        "iterations": iterations,
        "converged": bool(final_loss < tol),
        "reflection_tolerance": tol,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
