# Single-layer antireflection coating: analytic-gradient thickness optimization

## Problem and model

A lossless homogeneous coating of relative permittivity `epsilon` and thickness
`t` sits directly on a semi-infinite substrate of permittivity
`substrate_epsilon`. There is **no vacuum gap**: the coating's negative-z side
is vacuum, its positive-z side is the substrate. A plane wave is incident at
normal incidence from vacuum, travelling along **+z**.

The objective is the reflected power fraction `R(t)`, minimized over
`t in [bounds[0], bounds[1]]` starting from `initial_thickness`.

## Units and conventions

* Lengths (`wavelength`, `initial_thickness`, `bounds`, returned `thickness`)
  are in **micrometers**. `k0 = 2*pi/wavelength` in rad/um.
* `epsilon`, `substrate_epsilon` are relative and dimensionless; `mu = 1`,
  `kappa = 0` (treams defaults), so `n = sqrt(epsilon)`.
* `reflection` and `initial_reflection` are **power fractions** (0..1), not
  field amplitudes.
* `gradient` is `dR/dt` at the returned thickness, units 1/um.
* Layer ordering follows treams' positive-normal convention: `negative_medium`
  = vacuum (incidence side), `positive_medium` = substrate.

## Method

Forward model: `treams_rs.multilayer_slab` with
`basis = PlaneWavePorts.default([0, 0])` (normal-incidence channels, helicity
polarization); `R` is read from `SMatrix.power([0, 1], side="negative")`, i.e.
illumination from the negative (vacuum) side propagating along +z. At normal
incidence both helicities give the same reflectance.

Derivatives: the same call is made through the Advect adapter
`treams_rs.advect.multilayer_slab`, and `advect.value_and_grad` returns
`(R, dR/dt)` from treams' native Rust pullbacks. **No finite differences are
used to produce the reported gradient or any optimization step.**

Optimizer: projected gradient descent on the single variable `t`. Each
iteration takes `t <- clip(t - step*dR/dt, lo, hi)` with backtracking line
search (halve `step` until the loss decreases, doubling it on success). The
initial step is scaled to the optical phase scale `0.1*wavelength/n`. Iteration
stops when `R < 1e-7`, when the line search can make no further progress (a
local minimum or an active bound), or after `max_iterations` (default 500).
No closed-form quarter-wave thickness is used anywhere.

Optional config overrides: `reflection_tolerance` (default 1e-7) and
`max_iterations` (default 500).

## Returned keys

`thickness`, `reflection`, `initial_reflection`, `gradient`, `loss_history`
(reflected power at the start and after every accepted step), plus context:
`initial_thickness` (clipped to bounds), `bounds`, `wavelength`, `iterations`,
`converged`, `reflection_tolerance`.

## Example result (`results.json`)

Config: `wavelength = 0.7`, `epsilon = 2.25` (n = 1.5),
`substrate_epsilon = 5.0625` (n = 2.25), `initial_thickness = 0.05`,
`bounds = [0.025, 0.21]`.

* `initial_reflection = 9.594027e-02`
* `thickness = 0.1167017 um`, `reflection = 3.87e-08` (< 1e-7 target)
* `gradient = 2.207e-03` 1/um (near-zero, as expected at a flat minimum)
* 9 accepted steps, monotonically decreasing `loss_history`.

## Checks performed

1. **Gradient vs. central finite difference** at the converged thickness
   (h = 1e-7 um): FD `2.2065509219e-03` vs. analytic `2.2065509219e-03`
   — agreement to ~1e-11 relative. FD is used only as a check.
2. **Forward model vs. analytic Fresnel/TMM** for a three-medium stack,
   `R = |(r12 + r23 e^{2i b})/(1 + r12 r23 e^{2i b})|^2`, `b = 2 pi n2 d/lam`:
   agreement to ~1e-15 absolute at d = 0.05, 0.08, 0.1167, 0.2 um.
3. **Monotone descent**: `loss_history` is strictly decreasing by construction
   (line search accepts only decreasing steps).
4. **Robustness on other configs** (not hard-coded): a matched case
   (eps 2.0 on 4.0, lam 1.55) converges to R = 8.2e-08; an unmatchable case
   (n = 2 coating on n = 1.5 substrate) correctly stalls at the half-wave
   value R = 0.04 with `converged = false`; a bound-limited case terminates at
   the active bound with the non-zero gradient reported honestly.

For the example, the index condition `n_coat^2 = n_sub` is satisfied exactly
(1.5^2 = 2.25), so zero reflectance is physically attainable and the optimizer
finds it; the returned thickness is a result of gradient descent, not a
substituted closed form.

## Usage

```
python solution.py < config.json > results.json
```
or `from solution import run; run(config)`.
