# Antireflection coating thickness optimization

## Problem and conventions

A single lossless layer (relative permittivity `epsilon`, `mu = 1`, `kappa = 0`)
sits between a vacuum half space on the negative-z side and a substrate half
space (`substrate_epsilon`) on the positive-z side. There is no vacuum gap:
the stack is exactly `vacuum | coating(d) | substrate`. A plane wave at normal
incidence travels along +z, i.e. it is incident from the negative side.

* Lengths (`wavelength`, `initial_thickness`, `bounds`, `thickness`) are in
  micrometers; `k0 = 2*pi/wavelength` in rad/µm.
* Permittivities are relative and dimensionless; both media here are real
  (lossless), so `transmission + reflection = 1` and absorption is zero.
* `reflection` is a *power* fraction of the incident plane wave (unitless,
  in [0, 1]), not a field amplitude.
* `gradient` is `dR/dthickness` at the returned thickness, in 1/µm.

## Method

Scattering comes entirely from treams-rs:

```
tr.slab(basis=PlaneWavePorts.default([0, 0]), k0=..., thickness=d,
        material=epsilon, negative_medium=1.0, positive_medium=substrate_epsilon)
   .power([0, 1], side="negative").reflection
```

`PlaneWavePorts.default([0, 0])` fixes the transverse wavevector to zero
(normal incidence); channel `[0, 1]` is the positive-helicity input port, and
`side="negative"` declares incidence from the vacuum side. At normal incidence
on isotropic achiral media the two helicities are degenerate, so this single
channel is the full answer.

The objective is evaluated through `treams_rs.advect`, so the derivative
`dR/dd` is the native Rust analytic pullback of the layer-stack routine
exposed via `advect.value_and_grad`. No finite differences enter the
optimization or the reported gradient.

Optimizer: projected gradient descent on `R(d)` with an Armijo backtracking
line search and step growth, clipped to the bounds. Because `R(d)` is periodic
in `d` with period `lambda / (2*sqrt(epsilon))` (the optical half-wave
thickness), a single step is capped at a quarter of that period; without this
cap the growing line-search step could leap over a minimum and stall on a
bound. Iteration stops when `R <= 1e-12`, when the projected gradient vanishes
(including the case of a bound-active stationary point), or after
`max_iterations` (default 400). `tolerance` and `max_iterations` may be
overridden in the config.

## Result for the example config

`wavelength = 0.7`, `epsilon = 2.25`, `substrate_epsilon = 5.0625`,
`initial_thickness = 0.05`, bounds `[0.025, 0.21]` (see `results.json`):

* `initial_reflection = 9.594e-02`
* `thickness = 0.1166668` µm, `reflection = 7.65e-13` (< 1e-7 as required)
* `gradient = 9.8e-06` 1/µm (essentially stationary)
* 24 accepted steps, `loss_history` monotonically decreasing

The optimizer was run from `initial_thickness`; the quarter-wave value was not
substituted. That it lands on `lambda/(4*sqrt(epsilon)) = 0.116667` µm, where
the impedance-matching condition `sqrt(epsilon) = (1 * sqrt(substrate_epsilon))
** 0.5` gives exactly zero reflection, is an independent physical check.

## Checks performed

1. **Derivative validation.** Analytic gradients from Advect agree with central
   finite differences to ~10 significant digits at several thicknesses
   (e.g. at d = 0.05: -1.8625903780 vs -1.8625903778). Finite differences were
   used only for this validation.
2. **Global comparison.** For seven configurations (matched and mismatched
   index, different wavelengths, tight bounds, a start exactly at a local
   maximum) the returned reflection matches the minimum of a 40001-point grid
   scan of `R(d)` over the bounds.
3. **Bound handling.** With bounds `[0.15, 0.21]` (excluding the quarter-wave
   point) the result sits at the active bound 0.15 with a positive gradient,
   matching the grid minimum.
4. **Physical floor.** For a mismatched coating (`epsilon = 2.1025`,
   `substrate_epsilon = 4.41`) the reachable minimum is 3.54e-7, above the 1e-7
   target; the optimizer converges to that floor (gradient ~1e-11). The 1e-7
   target is attainable only when `epsilon**2 ≈ substrate_epsilon`, as in the
   example.
5. **Energy conservation.** `transmission = 1 - reflection` holds to machine
   precision, consistent with a lossless stack.

## Usage

```
echo '{"wavelength":0.7,"epsilon":2.25,"substrate_epsilon":5.0625,
       "initial_thickness":0.05,"bounds":[0.025,0.21]}' | python solution.py
```

`run(config)` returns the same dictionary: `thickness`, `reflection`,
`initial_reflection`, `gradient`, `loss_history`, plus `iterations`, `bounds`,
`converged` and `transmission`.
