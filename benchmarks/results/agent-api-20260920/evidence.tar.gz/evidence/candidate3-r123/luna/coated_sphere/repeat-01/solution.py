"""Rotationally averaged cross sections of a concentric multilayer sphere."""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _material(value: Any) -> complex:
    """Convert either a scalar or a JSON [real, imaginary] pair to epsilon."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ValueError("a material pair must have [real, imag] entries")
        return complex(float(value[0]), float(value[1]))
    return complex(float(value), 0.0)


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return averaged scattering, extinction, and absorption areas in um^2."""
    radii = [float(x) for x in config["radii"]]
    layers = [_material(x) for x in config["epsilon_layers"]]
    wavelengths = [float(x) for x in config["wavelengths"]]
    lmax = int(config["lmax"])

    if len(radii) != len(layers) or not radii:
        raise ValueError("radii and epsilon_layers must be nonempty and have equal length")
    if any(r <= 0 for r in radii) or any(b <= a for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing and positive")
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")
    if lmax < 1:
        raise ValueError("lmax must be positive")

    medium = _material(config.get("epsilon_medium", 1.0))
    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        response = tr.multilayer_sphere_tmatrix(
            k0=2.0 * np.pi / wavelength,
            lmax=lmax,
            radii=radii,
            materials=layers,
            medium=medium,
        )
        # This is treams-rs's rotationally and polarization-averaged result.
        cross = response.average_cross_sections
        sca = float(cross.scattering)
        ext = float(cross.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(float(cross.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    payload = json.load(sys.stdin)
    print(json.dumps(run(payload), allow_nan=False))
