# Coated-sphere spectrum

`solution.py` interprets every length in micrometers, so `k0 = 2π / wavelength`
is in inverse micrometers and the returned cross sections are in square
micrometers. Each `epsilon_layers` entry is converted from `[real, imag]` to a
relative complex permittivity. The layers are passed inside-out at the supplied
increasing outer radii; `epsilon_medium` is passed separately as the infinite
exterior and is not added as a finite layer. Positive imaginary permittivity is
therefore the passive-loss convention.

For each wavelength, treams-rs constructs the native multilayer-sphere
T-matrix and its rotationally and polarization-averaged cross sections are
used. Absorption is treams-rs's extinction minus scattering, with the same area
normalization. The CLI reads one JSON object from standard input and emits one
JSON object on standard output.

Checks include positive wavelengths and radii, strictly increasing radii,
matching nonempty layer/radius lists, and a positive multipole cutoff. The
example was executed with `lmax=4`; its saved output is in `results.json`.
