"""Rotationally averaged spectra of concentric multilayer spheres."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _complex_permittivity(value: Any, name: str) -> complex:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        result = complex(value)
    elif isinstance(value, (list, tuple)) and len(value) == 2:
        result = complex(value[0], value[1])
    else:
        raise ValueError(f"{name} must be a number or [real, imag]")
    if not (math.isfinite(result.real) and math.isfinite(result.imag)):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Calculate sphere cross sections, with one output entry per wavelength."""
    radii = config["radii"]
    layer_values = config["epsilon_layers"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]
    medium = _complex_permittivity(config.get("epsilon_medium", 1.0), "epsilon_medium")

    if not isinstance(radii, (list, tuple)) or not radii:
        raise ValueError("radii must be a nonempty list")
    if len(layer_values) != len(radii):
        raise ValueError("epsilon_layers must have one entry per radius")
    if any(not isinstance(r, (int, float)) or isinstance(r, bool) or not math.isfinite(r) or r <= 0 for r in radii):
        raise ValueError("radii must be finite positive numbers")
    if any(r2 <= r1 for r1, r2 in zip(radii, radii[1:])):
        raise ValueError("radii must increase")
    if not isinstance(lmax, int) or isinstance(lmax, bool) or lmax < 1:
        raise ValueError("lmax must be a positive integer")
    if not isinstance(wavelengths, (list, tuple)):
        raise ValueError("wavelengths must be a list")
    if any(not isinstance(w, (int, float)) or isinstance(w, bool) or not math.isfinite(w) or w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be finite positive numbers")
    materials = [_complex_permittivity(value, f"epsilon_layers[{i}]") for i, value in enumerate(layer_values)]
    if abs(medium.imag) > 1e-14:
        raise ValueError("epsilon_medium must be real for propagating cross sections")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        particle = tr.multilayer_sphere_tmatrix(
            k0=2.0 * math.pi / wavelength,
            lmax=lmax,
            radii=radii,
            materials=materials,
            medium=medium.real,
        )
        average = particle.average_cross_sections
        sca = float(average.scattering)
        ext = float(average.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(ext - sca)
    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
