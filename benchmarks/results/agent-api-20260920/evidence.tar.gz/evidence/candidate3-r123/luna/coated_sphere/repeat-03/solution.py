"""Rotationally averaged cross sections of a concentric coated sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _epsilon(value: Any) -> complex | float:
    """Convert either a scalar or the specified [real, imaginary] pair."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ValueError("permittivity pairs must contain [real, imag]")
        return complex(float(value[0]), float(value[1]))
    return float(value)


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return scattering, extinction and absorption spectra in wavelength order."""
    radii = [float(x) for x in config["radii"]]
    layers = [_epsilon(x) for x in config["epsilon_layers"]]
    wavelengths = [float(x) for x in config["wavelengths"]]
    lmax = int(config["lmax"])

    if len(radii) != len(layers):
        raise ValueError("radii and epsilon_layers must have the same length")
    if not radii or any(r <= 0 for r in radii) or any(a >= b for a, b in zip(radii, radii[1:])):
        raise ValueError("radii must be positive and strictly increasing")
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")
    if lmax < 1:
        raise ValueError("lmax must be positive")

    medium = _epsilon(config.get("epsilon_medium", 1.0))
    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        tmatrix = tr.multilayer_sphere_tmatrix(
            k0=2.0 * math.pi / wavelength,
            lmax=lmax,
            radii=radii,
            materials=layers,
            medium=medium,
        )
        cross = tmatrix.average_cross_sections
        sca = float(cross.scattering)
        ext = float(cross.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(ext - sca)
    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
