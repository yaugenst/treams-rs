# Coated-sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` numerical
scattering routine. The listed radii are the increasing outer boundaries of
the finite layers, ordered inside-out; the exterior permittivity is passed
separately as `medium` and is not added as a layer.

All lengths are in micrometres. For each vacuum wavelength, the calculation
uses `k0 = 2*pi/wavelength` in inverse micrometres, so the returned cross
sections are in square micrometres. A permittivity pair `[real, imag]` is
converted to `real + i*imag`; omitted magnetic and chiral parameters therefore
retain treams-rs defaults (`mu=1`, `kappa=0`).

The reported scattering and extinction values are treams-rs rotationally and
polarization-averaged cross sections. Absorption is checked/formed as
`extinction - scattering`. The CLI was run on the supplied example, and its
JSON output is saved in `results.json`.
