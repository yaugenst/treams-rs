# Coated-sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` routine. The
finite layers are passed inside-out, with the supplied increasing radii; the
exterior medium is passed separately and is not added as a layer.

Lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers and the returned cross sections are in square micrometers.
Permittivities are relative values represented as `real + i*imag`; magnetic
permeability is one and chirality is zero. The package's rotationally and
polarization-averaged scattering/extinction values are used, and absorption is
`extinction - scattering`.

Checks include finite positive wavelengths/radii, strictly increasing radii,
matching layer and radius counts, positive integer `lmax`, and a real,
nonabsorbing exterior required by the cross-section calculation. The example
was executed with `lmax=4`; its JSON output is saved in `results.json`.
