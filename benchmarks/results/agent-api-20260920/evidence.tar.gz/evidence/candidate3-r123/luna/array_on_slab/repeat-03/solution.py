"""Periodic sphere array above a dielectric slab.

The public treams-rs scattering objects are used throughout the calculation.
Lengths are in micrometers, so the vacuum wavenumber is in inverse micrometers.
"""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _real_number(config: dict[str, Any], name: str) -> float:
    value = config[name]
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a real number")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return power fractions for positive-helicity normal incidence.

    The wavelength list is sorted so all returned arrays are explicitly in
    ascending wavelength order.  The plane-wave basis contains both
    zeroth-order helicity channels, while the incident wave selects positive
    helicity.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _real_number(config, "radius")
    sphere_epsilon = _real_number(config, "sphere_epsilon")
    period = _real_number(config, "period")
    gap = _real_number(config, "gap")
    slab_thickness = _real_number(config, "slab_thickness")
    slab_epsilon = _real_number(config, "slab_epsilon")
    lmax_value = config["lmax"]
    if isinstance(lmax_value, bool):
        raise ValueError("lmax must be an integer")
    lmax = int(lmax_value)
    if lmax != lmax_value or lmax < 1:
        raise ValueError("lmax must be a positive integer")

    wavelengths = sorted(_real_number({"value": x}, "value") for x in config["wavelengths"])
    if not wavelengths or any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be a nonempty list of positive values")
    if radius <= 0 or period <= 0 or gap < 0 or slab_thickness < 0:
        raise ValueError("radius and period must be positive; distances cannot be negative")

    # At normal incidence this basis is exactly the two zeroth-order
    # helicities.  The native periodic solver accounts for all multipoles and
    # lattice interactions at the requested fixed lmax.
    ports = tr.PlaneWavePorts.default([0.0, 0.0])
    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        particle = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon
        )
        array = tr.solve_periodic(
            particle, lattice=tr.Lattice.square(period), kpar=[0.0, 0.0]
        ).to_smatrix(ports)
        slab = tr.slab(
            k0=k0,
            basis=ports,
            thickness=slab_thickness,
            material=slab_epsilon,
        )
        vacuum_gap = tr.propagation(
            k0=k0, basis=ports, distance=gap
        )
        network = tr.stack([slab, vacuum_gap, array])
        incident = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity", k0=k0
        )
        power = network.power(incident, side="negative")

        transmission.append(float(power.transmission))
        reflection.append(float(power.reflection))
        # Real epsilon and vacuum media are lossless.  Remove only harmless
        # negative roundoff while retaining any meaningful native result.
        native_absorption = float(power.absorption)
        absorption.append(0.0 if abs(native_absorption) < 1e-12 else native_absorption)

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
