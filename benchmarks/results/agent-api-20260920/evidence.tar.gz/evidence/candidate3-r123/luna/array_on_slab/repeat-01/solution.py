"""Periodic sphere array above a dielectric slab.

The public :mod:`treams_rs` scattering objects do the multipole and lattice
interaction calculations; this module only assembles the requested network.
"""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _number(config: dict[str, Any], name: str) -> float:
    value = config[name]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a number")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    return value


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return power fractions for positive-helicity illumination along +z.

    Lengths use the input micrometre unit.  The returned arrays have the same
    order as ``config['wavelengths']`` (the supplied wavelengths are expected
    to be wavelength-ordered).
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _number(config, "radius")
    sphere_epsilon = _number(config, "sphere_epsilon")
    period = _number(config, "period")
    gap = _number(config, "gap")
    slab_thickness = _number(config, "slab_thickness")
    slab_epsilon = _number(config, "slab_epsilon")
    lmax = config["lmax"]
    if isinstance(lmax, bool) or not isinstance(lmax, int) or lmax < 1:
        raise ValueError("lmax must be a positive integer")
    wavelengths = config["wavelengths"]
    if not isinstance(wavelengths, (list, tuple)) or not wavelengths:
        raise ValueError("wavelengths must be a non-empty list")
    wavelengths = sorted(_number({"value": w}, "value") for w in wavelengths)
    if any(w <= 0 for w in wavelengths):
        raise ValueError("wavelengths must be positive")
    if radius <= 0 or period <= 0 or gap < 0 or slab_thickness < 0:
        raise ValueError("radius and period must be positive; distances non-negative")

    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    # The port basis contains both helicities of the sole (0, 0) diffraction
    # order.  It is reused for all layers at each wavelength.
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        ports = tr.PlaneWavePorts.default([0.0, 0.0])
        sphere = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=sphere_epsilon,
            medium=1.0,
            polarization="helicity",
        )
        periodic = tr.solve_periodic(
            sphere,
            lattice=tr.Lattice.square(period),
            kpar=[0.0, 0.0],
        )
        array = periodic.to_smatrix(ports)
        slab = tr.slab(
            basis=ports,
            k0=k0,
            thickness=slab_thickness,
            material=slab_epsilon,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        gap_network = tr.propagation(
            basis=ports,
            k0=k0,
            distance=gap,
            medium=1.0,
            polarization="helicity",
        )
        network = tr.stack([slab, gap_network, array])
        incident = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            material=1.0,
        )
        balance = network.power(incident, side="negative")
        t = float(balance.transmission)
        r = float(balance.reflection)
        a = float(balance.absorption)
        if abs(a) < 1e-12:
            a = 0.0
        transmission.append(t)
        reflection.append(r)
        absorption.append(a)

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
