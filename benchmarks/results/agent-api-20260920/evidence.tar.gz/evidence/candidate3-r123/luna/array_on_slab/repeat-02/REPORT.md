# Periodic sphere array on a slab

`solution.py` uses the installed `treams_rs` native kernels.  For each
wavelength it constructs the sphere T-matrix at the requested fixed `lmax`,
solves the square-lattice Bloch interaction at `[0, 0]`, converts that response
to the zeroth-order plane-wave ports (both helicities), and cascades the
network in the specified order: slab, vacuum gap, array.

All lengths are in micrometers, with `k0 = 2*pi/wavelength` in inverse
micrometers.  Permittivities are relative and the omitted permeability and
chirality are `mu=1` and `kappa=0`.  The incident wave travels along `+z` from
the negative side and has positive helicity.  Returned wavelengths are sorted
ascending; powers are incident-normalized fractions.

Checks performed for the example: all three wavelengths produced finite
results, and because both materials are real and the exterior is vacuum,
`transmission + reflection + absorption` is unity to numerical precision
(absorption is at the roundoff level).
