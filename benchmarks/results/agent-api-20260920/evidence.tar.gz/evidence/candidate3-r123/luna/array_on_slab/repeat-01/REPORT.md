# Periodic sphere array on a slab

`solution.py` uses micrometres as the length unit, so `k0 = 2π / wavelength`
is in inverse micrometres. Permittivities are relative real values; the
permeability is one, chirality is zero, and all exterior media are vacuum.

The network is cascaded from negative to positive z as slab, vacuum gap, and
periodic sphere array. `PlaneWavePorts.default([0, 0])` retains the zeroth
diffraction order with both helicities. The incident wave has positive
helicity and propagates along +z. The sphere response and full periodic
interaction are computed by the public `treams_rs` API at the requested
`lmax`.

For each wavelength, `network.power(..., side="negative")` supplies the
transmission and reflection fractions; absorption is the native balance
residual `1 - T - R`. The example check gives `T + R = 1` at every wavelength
(within floating-point precision), as expected for real, lossless materials.
