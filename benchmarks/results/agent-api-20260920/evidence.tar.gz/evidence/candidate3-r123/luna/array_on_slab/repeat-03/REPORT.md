# Report

`solution.py` uses micrometers for all lengths and `k0 = 2*pi/wavelength`
in inverse micrometers.  Sphere and slab permittivities are relative,
real-valued epsilon; mu is one, chirality is zero, and the exterior media are
vacuum.

For each wavelength, treams-rs constructs the sphere T-matrix at the requested
`lmax`, solves the full square-lattice periodic interaction at Bloch vector
`[0, 0]`, and cascades the network in the specified order: slab, vacuum gap,
array.  The plane-wave basis contains the zeroth diffraction order in both
helicities, and the incident source is positive helicity propagating along +z.
Returned arrays are sorted by ascending wavelength.

The example was executed and saved in `results.json`.  Its values are:

| wavelength | transmission | reflection | absorption |
|---:|---:|---:|---:|
| 0.65 | 0.8873286362852495 | 0.11267136371475135 | 0.0 |
| 0.74 | 0.9020687269885590 | 0.09793127301144076 | 0.0 |
| 0.83 | 0.9119142686008943 | 0.08808573139910622 | 0.0 |

The native power balance was checked at every wavelength: transmission plus
reflection plus absorption equals one to floating-point precision.  Since all
materials are real and nonmagnetic, absorption is zero; residuals below
`1e-12` are treated as numerical roundoff.
