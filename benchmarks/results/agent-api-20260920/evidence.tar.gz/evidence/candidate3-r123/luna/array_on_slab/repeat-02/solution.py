"""Periodic sphere array above a dielectric slab.

The numerical scattering operations in this module are all supplied by
``treams_rs``.  The network is ordered from negative to positive z.
"""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _positive_finite(config: dict[str, Any], name: str) -> float:
    value = float(config[name])
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")
    return value


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return power fractions for positive-helicity normal incidence.

    Wavelengths are sorted in ascending order in the result.  Every wavelength
    is solved independently, while the multipole cutoff and lattice topology
    remain fixed by the input configuration.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _positive_finite(config, "radius")
    period = _positive_finite(config, "period")
    gap = _positive_finite(config, "gap")
    slab_thickness = _positive_finite(config, "slab_thickness")
    sphere_epsilon = float(config["sphere_epsilon"])
    slab_epsilon = float(config["slab_epsilon"])
    lmax = int(config["lmax"])
    wavelengths = sorted(float(x) for x in config["wavelengths"])
    if not wavelengths or any(not math.isfinite(x) or x <= 0 for x in wavelengths):
        raise ValueError("wavelengths must be a nonempty sequence of positive values")
    if lmax < 1:
        raise ValueError("lmax must be positive")
    if not math.isfinite(sphere_epsilon) or not math.isfinite(slab_epsilon):
        raise ValueError("permittivities must be finite")

    lattice = tr.Lattice.square(period)
    ports = tr.PlaneWavePorts.default([0.0, 0.0])
    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        particle = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=sphere_epsilon,
        )
        periodic = tr.solve_periodic(particle, lattice=lattice, kpar=[0.0, 0.0])
        array = periodic.to_smatrix(ports)
        network = tr.stack(
            [
                tr.slab(
                    basis=ports,
                    k0=k0,
                    thickness=slab_thickness,
                    material=slab_epsilon,
                ),
                tr.propagation(
                    distance=gap,
                    basis=ports,
                    k0=k0,
                ),
                array,
            ]
        )
        incident = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity", k0=k0
        )
        power = network.power(incident, side="negative")
        transmission.append(float(power.transmission))
        reflection.append(float(power.reflection))
        absorption.append(float(power.absorption))

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
