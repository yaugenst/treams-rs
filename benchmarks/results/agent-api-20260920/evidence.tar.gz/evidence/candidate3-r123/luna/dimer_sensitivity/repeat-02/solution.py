"""Multiple-scattering dimer field value and separation sensitivity."""

import json
import math
import sys

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def run(config):
    """Return the total electric-field intensity and its separation derivative."""
    radius = float(config["radius"])
    eps = config["epsilon"]
    epsilon = complex(float(eps[0]), float(eps[1]))
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = anp.asarray([[float(x) for x in config["point"]]])
    k0 = 2.0 * math.pi / wavelength

    def objective(separation):
        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon
        )
        positions = anp.stack(
            (
                anp.stack((-separation / 2.0, 0.0, 0.0)),
                anp.stack((separation / 2.0, 0.0, 0.0)),
            )
        )
        cluster = tr.Cluster([sphere, sphere], positions=positions)
        incident = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity", k0=k0
        )
        total_field = incident.efield(point) + cluster.scatter(incident).efield(point)
        return anp.sum(anp.abs(total_field) ** 2)

    value, gradient = ad.value_and_grad(objective)(float(config["separation"]))
    return {"value": float(value), "gradient": float(gradient)}


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
