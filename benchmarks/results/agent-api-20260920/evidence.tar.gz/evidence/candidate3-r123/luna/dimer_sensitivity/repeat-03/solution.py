"""Two-sphere near-field value and separation sensitivity."""

import json
import sys

import advect as ad
import numpy as np
import treams_rs.advect as tr


def _basis(lmax: int) -> tr.SphericalWaveBasis:
    modes = [
        (particle, ell, m, helicity)
        for particle in range(2)
        for ell in range(1, lmax + 1)
        for m in range(-ell, ell + 1)
        for helicity in range(2)
    ]
    # The origins are replaced by the dynamic origins in the native operators.
    return tr.SphericalWaveBasis(modes, np.zeros((2, 3), dtype=float))


def run(config):
    """Return ``sum(abs(E_total)**2)`` and its analytic d/d(separation)."""
    radius = float(config["radius"])
    eps_pair = config["epsilon"]
    epsilon = complex(float(eps_pair[0]), float(eps_pair[1]))
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = np.asarray(config["point"], dtype=float).reshape(1, 3)
    k0 = 2.0 * np.pi / wavelength
    basis = _basis(lmax)
    direction = np.asarray([[0.0, 0.0, 1.0]], dtype=float)
    # The incident field is positive helicity and has unit electric amplitude.
    incident_kvec = np.asarray([[0.0, 0.0, k0]], dtype=float)
    polarizations = np.asarray([1], dtype=int)
    radii = np.asarray([radius, radius], dtype=float)
    epsilons = np.asarray([epsilon, epsilon], dtype=np.complex128)
    ks = np.asarray([k0, -k0], dtype=float)

    def objective(sep):
        # ad.asarray preserves the separation tracer through the native geometry.
        positions = ad.asarray([[-sep / 2.0, 0.0, 0.0], [sep / 2.0, 0.0, 0.0]])
        coupled = tr.cluster(lmax, k0, radii, epsilons, positions)
        regular = tr.plane_expansion(
            positions,
            direction,
            destination=basis,
            polarizations=polarizations,
            fixed_vectors=True,
        )[:, 0]
        scattered = tr.field(
            coupled @ regular, point, positions, ks, basis=basis
        )
        incident = tr.plane_field(
            None, point, incident_kvec, polarizations=polarizations
        )[:, :, 0]
        total = incident + scattered
        return np.sum(np.abs(total) ** 2)

    value, gradient = ad.value_and_grad(objective)(separation)
    return {"value": float(value), "gradient": float(gradient)}


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
