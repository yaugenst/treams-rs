# Report

`solution.py` uses micrometers for all lengths and inverse micrometers for
the vacuum wavenumber `k0 = 2*pi/wavelength`.  The supplied permittivity is
interpreted as `epsilon[0] + i*epsilon[1]`; the exterior has relative
permittivity and permeability one, with zero chirality.  The incident plane
wave travels in `+z`, has positive helicity, and unit electric-field
amplitude.

The two centers are `(-separation/2, 0, 0)` and
`(+separation/2, 0, 0)`.  `treams_rs.advect.cluster` performs the native
multiple-scattering solve through the requested `lmax`.  The sampled field
is the incident field plus the native scattered field, and the reported
value is the sum of `abs(E)**2` over its three Cartesian components at the
fixed point.  Advect's native analytic reverse pullbacks provide the
separation gradient, including motion of both centers.

Checks for the example:

* CLI execution produced `results.json` with value
  `1.024538650198189` and gradient `-0.017688488173486193`.
* Central-difference checks of the value gave gradients
  `-0.0176884945`, `-0.0176884882`, and `-0.0176884882` for steps
  `1e-3`, `1e-4`, and `1e-5`, respectively.  These checks validate the
  analytic result; finite differences are not used by the solution.
