# Dimer sensitivity report

`solution.py` uses `treams_rs.advect` sphere T-matrices and an Advect
`Cluster`, so the two spheres are coupled by full multiple scattering.  The
incident wave propagates in `+z` and uses the positive-helicity convention.

All lengths are in micrometers; consequently `k0 = 2*pi/wavelength` is in
inverse micrometers.  The supplied epsilon is interpreted as the relative
permittivity `epsilon[0] + i*epsilon[1]`; the exterior is vacuum, with
relative permeability one and zero chirality.  The field value is
`sum(abs(E_incident + E_scattered)**2)` at the supplied fixed point.

For separation `s`, the particle centers are `(-s/2, 0, 0)` and
`(s/2, 0, 0)`.  The returned gradient is obtained with Advect's native
reverse-mode pullbacks through the sphere response, cluster solve, and field
evaluation; no finite-difference derivative is used.

Checks performed: the example was executed through the CLI, and the result
was compared with a centered finite-difference check only as an independent
validation of the analytic gradient.
