# Dimer sensitivity report

`solution.py` uses micrometers for every length.  Thus `k0 = 2π / wavelength`
is in inverse micrometers.  The sphere material is the relative permittivity
`epsilon[0] + i*epsilon[1]`; the exterior is vacuum (`mu=1`, chirality zero).

The incident wave travels in `+z` with treams-rs' positive-helicity
convention.  The two sphere centers are `(-separation/2, 0, 0)` and
`(+separation/2, 0, 0)`.  `Cluster.scatter` supplies the coupled
multiple-scattering field, and the incident field is then added before
computing `sum(abs(E_total)**2)` at the single requested point.

The reported gradient is produced by Advect's native analytic pullback while
the two positions are traced functions of separation.  As checks, the example
was evaluated through both the Python API and the stdin CLI, and a small
central finite difference was used only to validate (not compute) the
gradient.
