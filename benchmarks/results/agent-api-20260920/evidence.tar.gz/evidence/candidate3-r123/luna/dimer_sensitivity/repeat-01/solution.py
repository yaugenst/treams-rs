"""Multiple-scattering dimer field value and separation sensitivity."""

import json
import sys

import advect as ad
import advect.numpy as anp
import numpy as np
import treams_rs.advect as tr


def _objective(separation, config):
    """Return the field intensity at the requested point.

    ``separation`` is deliberately left as an Advect value throughout the
    geometry construction so the native pullbacks include both moving
    particles.
    """
    wavelength = config["wavelength"]
    k0 = 2.0 * np.pi / wavelength
    eps = config["epsilon"]
    material = complex(eps[0], eps[1])

    sphere = tr.sphere_tmatrix(
        k0=k0,
        lmax=int(config["lmax"]),
        radius=config["radius"],
        material=material,
    )
    positions = anp.stack(
        (
            anp.asarray([-separation / 2.0, 0.0, 0.0]),
            anp.asarray([separation / 2.0, 0.0, 0.0]),
        )
    )
    cluster = tr.Cluster([sphere, sphere], positions=positions)
    incident = tr.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=k0
    )
    point = anp.asarray([config["point"]])
    total_field = incident.efield(point) + cluster.scatter(incident).efield(point)
    return anp.sum(anp.abs(total_field) ** 2)


def run(config):
    """Evaluate the requested value and its analytic separation gradient."""
    value, gradient = ad.value_and_grad(
        lambda separation: _objective(separation, config)
    )(config["separation"])
    return {"value": float(np.asarray(value)), "gradient": float(np.asarray(gradient))}


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
