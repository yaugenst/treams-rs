# Sphere sensitivity report

`solution.py` uses `treams_rs.advect.sphere_tmatrix` and the installed Advect
reverse-mode transform. The sphere is homogeneous, the exterior is vacuum
(`epsilon=mu=1`, zero chirality), and incidence is a +z plane wave with
positive helicity. The material is the relative permittivity
`epsilon_real + i epsilon_imag`; positive imaginary part denotes loss.

All lengths are in micrometers, so `k0=2*pi/wavelength` is in inverse
micrometers. The Rust cross-section is an area in square micrometers. The
reported value is `Q=scattering/(pi*radius**2)`, and the reported gradient is
`[dQ/dradius, dQ/depsilon_real]` with wavelength, `epsilon_imag`, and `lmax`
held fixed. The derivative includes the derivative of the area normalization.

Checks performed:

* The example was executed through the CLI and its output was saved in
  `results.json`.
* A separate small central finite-difference check agrees with the analytic
  gradient; finite differences are used only as validation, not to compute it.
