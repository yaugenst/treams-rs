"""Differentiable scattering efficiency of a lossy homogeneous sphere."""

import json
import sys
from math import pi

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _efficiency(x, epsilon_imag, wavelength, lmax):
    radius = x[0]
    epsilon_real = x[1]
    particle = tr.sphere_tmatrix(
        k0=2.0 * pi / wavelength,
        lmax=lmax,
        radius=radius,
        material=epsilon_real + 1j * epsilon_imag,
    )
    incident = tr.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=2.0 * pi / wavelength
    )
    scattering_cross_section = particle.cross_sections(incident).scattering
    return scattering_cross_section / (pi * radius * radius)


def run(config):
    """Return scattering efficiency and its analytic gradient.

    The gradient order is [dQ/dradius, dQ/depsilon_real].
    """
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    if radius <= 0.0 or wavelength <= 0.0 or lmax < 1:
        raise ValueError("radius and wavelength must be positive and lmax >= 1")

    # The objective is traced; treams-rs supplies the native sphere pullback.
    objective = lambda x: _efficiency(x, epsilon_imag, wavelength, lmax)
    value, gradient = ad.value_and_grad(objective)(
        anp.asarray([radius, epsilon_real], dtype=float)
    )
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
