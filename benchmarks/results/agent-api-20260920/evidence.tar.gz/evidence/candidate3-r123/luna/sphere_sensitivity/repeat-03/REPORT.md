# Sphere scattering sensitivity

`solution.py` uses the installed `treams_rs.advect` adapter and its native
first-order pullbacks.  The sphere is illuminated by a unit-amplitude,
positive-helicity plane wave travelling in `+z`.  The vacuum wavenumber is
`k0 = 2*pi/wavelength`; all lengths are in micrometers, so cross sections are
in square micrometers.  The sphere permittivity is
`epsilon_real + i*epsilon_imag`, with relative permeability 1, zero chirality,
and vacuum exterior.

The returned scalar is

`Q = C_sca / (pi * radius**2)`.

The returned gradient is with respect to `(radius, epsilon_real)`, holding the
other inputs fixed.  The quotient and its radius normalization are inside the
Advect objective, so the native pullback differentiates both the scattering
cross section and the normalization.

For the supplied example, `results.json` contains:

```text
Q = 0.46337644643427434
gradient = [18.65367030479629, 0.1997255464561844]
```

Checks: the CLI output was parsed as JSON, the value is finite and positive,
and central finite differences were used only as an independent validation;
they gave `18.6536703474` and `0.1997255465` for the two gradient components.
