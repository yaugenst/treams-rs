# Sphere sensitivity report

`solution.py` uses `treams_rs.advect.sphere_tmatrix` and the native Advect
pullbacks in the installed treams-rs wheel.  It evaluates a homogeneous sphere
in vacuum with relative material permittivity
`epsilon_real + i epsilon_imag`, relative permeability 1, and chirality 0.
The incident wave propagates along +z with positive helicity.  The wavenumber
is `k0 = 2*pi/wavelength`.

All lengths are in micrometers, so the cross section is in square micrometers.
The returned quantity is dimensionless,
`Q = scattering_cross_section / (pi*radius**2)`.  The gradient is ordered as
`[dQ/dradius, dQ/depsilon_real]`, with wavelength, epsilon_imag, and lmax held
fixed.  The normalization is part of the traced objective, so its radius
derivative is included.

For the supplied example, running the CLI produced:

```json
{"value":0.46337644643427434,"gradient":[18.65367030479629,0.1997255464561844]}
```

The gradient comes from `advect.value_and_grad`, not finite differences.  A
separate central finite-difference evaluation of the complete normalized
objective was used only as a check: with step `1e-5`, it gave
`18.6536703474` and `0.1997255465` for the two components.  The CLI was also
exercised through standard input and `results.json` contains its exact JSON
output.
