"""Differentiable scattering efficiency of a lossy homogeneous sphere."""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import advect as ad
import treams_rs.advect as tr


def _objective(x: Any, *, epsilon_imag: float, wavelength: float, lmax: int) -> Any:
    """Return Q for x = [radius, real(relative permittivity)].

    Everything depending on x remains in Advect's namespace while tracing;
    the radius normalization is consequently differentiated too.
    """
    radius = x[0]
    epsilon = x[1] + 1j * epsilon_imag
    k0 = 2.0 * np.pi / wavelength
    sphere = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=epsilon
    )
    incident = tr.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=k0
    )
    scattering = sphere.cross_sections(incident).scattering
    return scattering / (np.pi * radius * radius)


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Compute scattering efficiency and analytic gradient for *config*."""
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    if radius <= 0 or wavelength <= 0 or lmax < 1:
        raise ValueError("radius and wavelength must be positive; lmax must be >= 1")

    # Advect supplies the native reverse-mode pullback from the Rust numerics.
    value, gradient = ad.value_and_grad(
        lambda x: _objective(
            x,
            epsilon_imag=epsilon_imag,
            wavelength=wavelength,
            lmax=lmax,
        )
    )(np.asarray([radius, epsilon_real], dtype=float))
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
