"""Analytic scattering-efficiency sensitivity for a lossy sphere."""

from __future__ import annotations

import json
import sys

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _objective(x, *, epsilon_imag, wavelength, lmax):
    radius = x[0]
    epsilon_real = x[1]
    epsilon = epsilon_real + 1j * epsilon_imag
    k0 = 2.0 * 3.141592653589793 / wavelength
    sphere = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=tr.Material(epsilon=epsilon)
    )
    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    scattering = sphere.cross_sections(incident).scattering
    return scattering / (3.141592653589793 * radius * radius)


def run(config):
    """Return Q and its analytic gradient in the order radius, Re(epsilon)."""
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    x = anp.asarray([radius, epsilon_real])
    value, gradient = ad.value_and_grad(_objective)(
        x,
        epsilon_imag=epsilon_imag,
        wavelength=wavelength,
        lmax=lmax,
    )
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
