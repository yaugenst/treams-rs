# Two-sphere scattering

`solution.py` uses treams-rs sphere T-matrices at the requested fixed `lmax`,
assembles them in a `Cluster`, and solves the coupled cluster response.  Thus
the reported response includes all mutual multiple scattering retained by the
truncated multipole basis.

Lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers and cross sections are in square micrometers.  Each input
permittivity `[real, imag]` is converted to a complex relative epsilon;
relative permeability is one, chirality is zero, and the surrounding medium
is vacuum.  The incident wave travels along +z with treams-rs' positive
helicity and normalization.  The field output is the total electric field,
incident plus scattered, with Cartesian components split into real and
imaginary point-by-3 lists.

Checks performed: the example was executed through the CLI; output was parsed
as JSON; the two sphere origins were placed at x = +/- separation/2; and the
cross-section absorption was checked against scattering minus extinction
(within floating-point roundoff).
