# Dimer scattering report

`solution.py` uses the public `treams_rs` sphere T-matrix and `Cluster` APIs.
The two sphere centers are `(-separation/2, 0, 0)` and
`(+separation/2, 0, 0)`. All lengths are in micrometers, so
`k0 = 2*pi/wavelength` is in inverse micrometers and the cross sections are
in square micrometers. Permittivities are converted from the requested
`[real, imag]` pairs; the exterior is vacuum (`epsilon=1`, `mu=1`) and the
spheres use `mu=1`, zero chirality.

The incident wave propagates along `+z` with treams-rs' positive-helicity
normalization. The reported field is the incident field plus the fully coupled
cluster-scattered field at each point. The fixed input `lmax` is used for both
sphere T-matrices. Scattering, extinction, and absorption are the package's
area cross sections, with absorption checked through
`absorption = extinction - scattering`.

For the supplied example, the implementation was executed through the CLI
and its output was saved in `results.json`. The example gives positive
scattering, extinction, and absorption, and the reported absorption agrees
with extinction minus scattering to floating-point precision.
