"""Two-sphere finite-cluster scattering calculation using treams-rs."""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _complex_epsilon(value: Any) -> complex:
    """Convert the specified [real, imag] representation to a complex number."""
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError("each epsilon must be [real, imag]")
    return complex(float(value[0]), float(value[1]))


def _real_lists(value: np.ndarray) -> list[list[float]]:
    return np.asarray(value, dtype=float).tolist()


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Calculate total electric fields and cross sections for the dimer.

    All geometry and wavelength values are used in the same length unit, here
    micrometers.  treams-rs supplies the incident-wave normalization and the
    multipole translation/coupling used by the finite cluster solve.
    """
    radii = [float(x) for x in config["radii"]]
    epsilons = [_complex_epsilon(x) for x in config["epsilon"]]
    if len(radii) != 2 or len(epsilons) != 2:
        raise ValueError("radii and epsilon must each contain two entries")
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float)
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("points must have shape (n, 3)")
    if wavelength <= 0 or separation <= 0 or lmax < 1:
        raise ValueError("wavelength, separation and lmax must be positive")

    k0 = 2.0 * np.pi / wavelength
    particles = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)
        for radius, epsilon in zip(radii, epsilons, strict=True)
    ]
    cluster = tr.Cluster(
        particles,
        positions=[[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]],
    )
    response = cluster.solve()
    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    scattered = response.scatter(incident)
    total_field = incident.efield(points) + scattered.efield(points)
    cross = response.cross_sections(incident)

    return {
        "total_field_real": _real_lists(np.real(total_field)),
        "total_field_imag": _real_lists(np.imag(total_field)),
        "scattering": float(cross.scattering),
        "extinction": float(cross.extinction),
        "absorption": float(cross.absorption),
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
