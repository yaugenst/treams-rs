# Report

`solution.py` uses micrometers for all lengths, so the reported cross sections
are in square micrometers. Permittivities are interpreted as the requested
`real + i imag` values; the exterior is vacuum (`mu=1`, chirality zero).

The incident wave propagates in `+z` with treams-rs' positive-helicity
normalization. The two sphere centers are `(-separation/2, 0, 0)` and
`(separation/2, 0, 0)`. `Cluster.solve()` includes the complete finite-cluster
multiple-scattering coupling at the supplied `lmax`. The returned fields are
the incident electric field plus the scattered electric field, in the
Cartesian component order `(x, y, z)`.

Checks performed: the example was executed through the CLI; both requested
points produced three-component real and imaginary fields; and absorption was
computed by treams-rs as extinction minus scattering (0.0026176027019321826).
