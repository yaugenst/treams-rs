"""Multiple-scattering solution for a two-sphere dimer."""

import json
import sys

import numpy as np
import treams_rs as tr


def _complex_epsilon(value):
    """Convert the requested [real, imag] representation to a complex value."""
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError("each epsilon must be [real, imag]")
    return complex(float(value[0]), float(value[1]))


def run(config):
    """Solve the dimer and return JSON-compatible fields and cross sections."""
    radii = config["radii"]
    epsilons = config["epsilon"]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float)

    if len(radii) != 2 or len(epsilons) != 2:
        raise ValueError("radii and epsilon must each contain two entries")
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("points must be a list of Cartesian triples")

    k0 = 2.0 * np.pi / wavelength
    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=float(radius),
            material=_complex_epsilon(epsilon),
        )
        for radius, epsilon in zip(radii, epsilons)
    ]
    cluster = tr.Cluster(
        particles,
        positions=[[-separation / 2.0, 0.0, 0.0],
                   [separation / 2.0, 0.0, 0.0]],
    )
    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    response = cluster.solve()
    scattered = response.scatter(incident)
    total_field = incident.efield(points) + scattered.efield(points)
    cross_sections = response.cross_sections(incident)

    return {
        "total_field_real": total_field.real.tolist(),
        "total_field_imag": total_field.imag.tolist(),
        "scattering": float(cross_sections.scattering),
        "extinction": float(cross_sections.extinction),
        "absorption": float(cross_sections.absorption),
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
