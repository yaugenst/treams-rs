"""Finite two-sphere multiple-scattering calculation using treams-rs."""

import json
import sys

import numpy as np
import treams_rs as tr


def _complex_value(pair):
    """Convert the requested [real, imag] representation to a complex scalar."""
    if not isinstance(pair, (list, tuple)) or len(pair) != 2:
        raise ValueError("each epsilon entry must be [real, imag]")
    return complex(float(pair[0]), float(pair[1]))


def run(config):
    """Run the two-sphere calculation and return a JSON-serializable dictionary."""
    radii = config["radii"]
    epsilons = config["epsilon"]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float)

    if len(radii) != 2 or len(epsilons) != 2:
        raise ValueError("radii and epsilon must each contain two entries")
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("points must have shape (n, 3)")

    k0 = 2.0 * np.pi / wavelength
    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=float(radius),
            material=tr.Material(_complex_value(epsilon)),
        )
        for radius, epsilon in zip(radii, epsilons)
    ]
    system = tr.Cluster(
        particles,
        positions=[[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]],
    )
    response = system.solve()
    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)

    total_field = incident.efield(points) + response.scatter(incident).efield(points)
    cross = response.cross_sections(incident)

    # Explicitly split complex values because JSON has no complex number type.
    return {
        "total_field_real": np.asarray(total_field.real, dtype=float).tolist(),
        "total_field_imag": np.asarray(total_field.imag, dtype=float).tolist(),
        "scattering": float(cross.scattering),
        "extinction": float(cross.extinction),
        "absorption": float(cross.absorption),
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
