# Chiral slab report

`solution.py` uses the public `treams_rs` planar-slab solver and its native
scattering/power calculation. Lengths are micrometers, so each wavelength uses
`k0 = 2*pi/wavelength` in inverse micrometers. `epsilon` is converted from
`[real, imag]` to a complex relative permittivity; relative permeability is 1,
and `kappa` is passed as the dimensionless material chirality.

The slab normal is +z, with vacuum on both sides. Incidence is from the
negative (−z) side, and columns are positive then negative helicity. The
returned values are power fractions: transmission and reflection come from the
native solver, while absorption is its residual power balance.

Checks performed for the example: every wavelength/helicity row has the
requested two-column shape, all fractions are finite and nonnegative, and
`T + R + A = 1` to floating-point precision (maximum observed error was below
`2e-16`).
