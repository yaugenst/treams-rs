"""Normal-incidence power balance of a reciprocal chiral slab."""

from __future__ import annotations

import json
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[list[float]]]:
    """Return transmission, reflection, and absorption by wavelength/helicity."""
    thickness = float(config["thickness"])
    epsilon_data = config["epsilon"]
    if not isinstance(epsilon_data, (list, tuple)) or len(epsilon_data) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(float(epsilon_data[0]), float(epsilon_data[1]))
    kappa = complex(float(config.get("kappa", 0.0)))
    wavelengths = [float(value) for value in config["wavelengths"]]

    basis = tr.PlaneWavePorts.default([0.0, 0.0])
    material = tr.Material(epsilon, 1.0, kappa)
    result = {"transmission": [], "reflection": [], "absorption": []}

    # PlaneWave uses the package convention: positive helicity is label 1,
    # negative helicity is label 0.  The two amplitudes are normalized to one.
    for wavelength in wavelengths:
        network = tr.slab(
            basis=basis,
            k0=2.0 * 3.141592653589793 / wavelength,
            thickness=thickness,
            material=material,
        )
        values = []
        for helicity in ("positive_helicity", "negative_helicity"):
            incident = tr.plane_wave(
                [0.0, 0.0, 1.0], helicity, k0=2.0 * 3.141592653589793 / wavelength
            )
            balance = network.power(incident, side="negative")
            values.append((float(balance.transmission), float(balance.reflection), float(balance.absorption)))
        result["transmission"].append([row[0] for row in values])
        result["reflection"].append([row[1] for row in values])
        result["absorption"].append([row[2] for row in values])
    return result


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
