"""Normal-incidence power balance for a reciprocal chiral slab."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _number(value: Any, name: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, list[list[float]]]:
    """Return T, R and A for +z incidence at each requested wavelength.

    The two columns are positive and negative helicity, respectively.
    """
    thickness = _number(config["thickness"], "thickness")
    epsilon = config["epsilon"]
    if not isinstance(epsilon, (list, tuple)) or len(epsilon) != 2:
        raise ValueError("epsilon must be [real, imag]")
    eps = complex(_number(epsilon[0], "epsilon[0]"), _number(epsilon[1], "epsilon[1]"))
    kappa = _number(config.get("kappa", 0.0), "kappa")
    wavelengths = [_number(w, "wavelength") for w in config["wavelengths"]]
    if thickness < 0 or any(w <= 0 for w in wavelengths):
        raise ValueError("thickness must be nonnegative and wavelengths positive")

    ports = tr.PlaneWavePorts.default([0.0, 0.0])
    material = tr.Material(eps, 1.0, kappa)
    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    for wavelength in wavelengths:
        network = tr.slab(
            basis=ports,
            k0=2.0 * math.pi / wavelength,
            thickness=thickness,
            material=material,
            polarization="helicity",
        )
        t_row: list[float] = []
        r_row: list[float] = []
        a_row: list[float] = []
        for incident in ([1.0, 0.0], [0.0, 1.0]):
            balance = network.power(incident, side="negative")
            t_row.append(float(balance.transmission))
            r_row.append(float(balance.reflection))
            a_row.append(float(balance.absorption))
        transmission.append(t_row)
        reflection.append(r_row)
        absorption.append(a_row)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
