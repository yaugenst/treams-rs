"""Normal-incidence scattering from a reciprocal chiral slab."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _finite_real(value: Any, name: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, list[list[float]]]:
    """Return power fractions for positive and negative helicity.

    The two columns in every result row are positive and negative helicity,
    respectively.  Epsilon is supplied as its real and imaginary parts.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    thickness = _finite_real(config["thickness"], "thickness")
    if thickness < 0:
        raise ValueError("thickness must be nonnegative")

    epsilon_parts = config["epsilon"]
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _finite_real(epsilon_parts[0], "epsilon real"),
        _finite_real(epsilon_parts[1], "epsilon imag"),
    )
    kappa = complex(_finite_real(config["kappa"], "kappa"))

    wavelengths = config["wavelengths"]
    if not isinstance(wavelengths, (list, tuple)):
        raise ValueError("wavelengths must be a list")

    # This is the native two-channel normal-incidence basis.  Its modes are
    # labelled [positive helicity, negative helicity] by PlaneWave's names.
    ports = tr.PlaneWavePorts.default([0, 0])
    material = tr.Material(epsilon, 1, kappa)
    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    for index, wavelength_value in enumerate(wavelengths):
        wavelength = _finite_real(wavelength_value, f"wavelengths[{index}]")
        if wavelength <= 0:
            raise ValueError("wavelengths must be positive")
        network = tr.slab(
            basis=ports,
            k0=2 * math.pi / wavelength,
            thickness=thickness,
            material=material,
        )
        row_t: list[float] = []
        row_r: list[float] = []
        row_a: list[float] = []
        for helicity in ("positive_helicity", "negative_helicity"):
            incident = tr.plane_wave(
                [0, 0, 1], helicity, k0=2 * math.pi / wavelength
            )
            balance = network.power(incident, side="negative")
            row_t.append(float(balance.transmission))
            row_r.append(float(balance.reflection))
            row_a.append(float(balance.absorption))
        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    configuration = json.load(sys.stdin)
    print(json.dumps(run(configuration), separators=(",", ":")))
