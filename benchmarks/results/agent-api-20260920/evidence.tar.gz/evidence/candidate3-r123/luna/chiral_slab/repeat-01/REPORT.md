# Chiral slab report

`solution.py` uses the installed `treams_rs` native planar-scattering kernel:
`PlaneWavePorts.default([0, 0])` supplies the two normal-incidence helicity
channels and `slab(...).power(...)` supplies power-normalized transmission and
reflection. Absorption is the native balance `1 - T - R`.

Lengths are in micrometers, so each wavelength uses `k0 = 2*pi/wavelength`
in inverse micrometers. The material is `epsilon = epsilon_real + i*epsilon_imag`,
relative permeability is 1, and `kappa` is passed directly as the dimensionless
package chirality. Incidence is from the negative-z side toward +z. Columns are
positive helicity then negative helicity; rows follow the wavelength list.

Checks performed: the example was executed through the CLI and saved in
`results.json`; each returned fraction is finite, and for every wavelength and
helicity the native result satisfies `T + R + A = 1` to floating-point precision.
