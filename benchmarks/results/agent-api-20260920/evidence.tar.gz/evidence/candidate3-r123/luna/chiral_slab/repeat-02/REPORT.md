# Report

`solution.py` uses `treams_rs.slab` with a `PlaneWavePorts.default([0, 0])`
basis and `Material(epsilon, 1, kappa)`. Lengths are micrometres, so each
vacuum wavenumber is `k0 = 2*pi/wavelength`; epsilon, mu, and kappa are
relative and dimensionless. The input epsilon pair is interpreted as
`epsilon_real + i*epsilon_imag`, with positive imaginary part denoting loss.

The output helicity axis is `[positive, negative]`. Power values come from
treams-rs `PowerBalance` for +z incidence from the negative-z (vacuum) side:
transmission exits at +z, reflection exits at -z, and absorption is the
package balance remainder. No complex amplitude is returned.

Checks performed on the example include the shape `(3, 2)` for every output
array and `T + R + A = 1` for every wavelength and helicity (within numerical
roundoff). The example output is in `results.json`.
