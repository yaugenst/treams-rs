"""Gradient optimization of a single normal-incidence dielectric coating."""

from __future__ import annotations

import json
import sys
from typing import Any

import advect as ad
import treams_rs.advect as tr


def _objective_factory(config: dict[str, Any]):
    wavelength = float(config["wavelength"])
    epsilon = config["epsilon"]
    substrate_epsilon = config["substrate_epsilon"]
    k0 = 2.0 * 3.141592653589793 / wavelength
    ports = tr.PlaneWavePorts.default([0.0, 0.0])

    def reflection(thickness: Any) -> Any:
        # All geometry-dependent work is inside the Advect transform.  The
        # slab routine delegates scattering and its pullback to treams-rs.
        network = tr.slab(
            basis=ports,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        return network.power([1.0, 0.0], side="negative").reflection

    return reflection


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Optimize coating thickness and return JSON-compatible scalar results."""
    lo, hi = (float(x) for x in config["bounds"])
    if not (lo <= hi and lo >= 0.0):
        raise ValueError("bounds must satisfy 0 <= lower <= upper")
    start = float(config["initial_thickness"])
    if not lo <= start <= hi:
        raise ValueError("initial_thickness must lie within bounds")

    objective = _objective_factory(config)
    value_and_gradient = ad.value_and_grad(objective)
    thickness = min(hi, max(lo, start))
    value, gradient = value_and_gradient(thickness)
    initial_reflection = float(value)
    history = [initial_reflection]

    # Armijo backtracking is useful here because the phase-dependent gradient
    # can vary substantially with wavelength and with the supplied bounds.
    for _ in range(400):
        f = float(value)
        g = float(gradient)
        if abs(g) < 1.0e-13 or f < 1.0e-12:
            break
        step = min(0.02, max(1.0e-5, 0.25 * (hi - lo)))
        accepted = False
        while step > 1.0e-12:
            trial = min(hi, max(lo, thickness - step * g))
            if trial == thickness:
                break
            trial_value, trial_gradient = value_and_gradient(trial)
            # Sufficient decrease, with a small tolerance for roundoff.
            if float(trial_value) <= f - 1.0e-4 * step * g * (thickness - trial) + 1e-18:
                thickness, value, gradient = trial, trial_value, trial_gradient
                history.append(float(value))
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    # One fresh pullback makes the reported derivative unambiguously the
    # derivative at the returned thickness.
    value, gradient = value_and_gradient(thickness)
    result = {
        "thickness": float(thickness),
        "reflection": float(value),
        "initial_reflection": initial_reflection,
        "gradient": float(gradient),
        "loss_history": history,
    }
    return result


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
