"""Gradient-based one-layer antireflection optimization."""

import json
import sys

import advect as ad
import treams_rs.advect as tr


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    lower, upper = (float(v) for v in config["bounds"])
    if not (0.0 < wavelength and 0.0 < epsilon and 0.0 < substrate_epsilon):
        raise ValueError("lossless dielectric inputs must be positive")
    if not (0.0 < lower <= upper):
        raise ValueError("bounds must be positive and ordered")

    initial = min(upper, max(lower, initial))
    basis = tr.PlaneWavePorts.default([0.0, 0.0])
    k0 = 2.0 * 3.141592653589793 / wavelength

    def value_and_gradient(thickness):
        def objective(t):
            slab = tr.slab(
                basis=basis, k0=k0, thickness=t, material=epsilon,
                positive_medium=substrate_epsilon,
            )
            return slab.power([0.0, 1.0], side="negative").reflection

        value, gradient = ad.value_and_grad(objective)(thickness)
        return float(value), float(gradient)

    initial_reflection, _ = value_and_gradient(initial)
    thickness = initial
    loss_history = []
    for _ in range(300):
        loss, gradient = value_and_gradient(thickness)
        loss_history.append(loss)
        if loss < 1.0e-7:
            break
        direction = -gradient
        if (thickness <= lower and direction < 0.0) or (
            thickness >= upper and direction > 0.0
        ):
            break
        step = 0.05
        while True:
            candidate = min(upper, max(lower, thickness + step * direction))
            candidate_loss, _ = value_and_gradient(candidate)
            if candidate_loss <= loss + 1.0e-4 * (candidate - thickness) * gradient:
                break
            step *= 0.5
            if step < 1.0e-13:
                candidate = thickness
                break
        if candidate == thickness:
            break
        thickness = candidate

    reflection, gradient = value_and_gradient(thickness)
    return {
        "thickness": thickness,
        "reflection": reflection,
        "initial_reflection": initial_reflection,
        "gradient": gradient,
        "loss_history": loss_history,
    }


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin)), allow_nan=False))
