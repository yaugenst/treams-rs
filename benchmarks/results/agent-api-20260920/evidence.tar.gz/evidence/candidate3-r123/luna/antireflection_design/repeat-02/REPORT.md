# Gradient optimization report

`solution.py` models one homogeneous coating slab in treams-rs. Lengths are
in micrometers, so `k0 = 2*pi/wavelength` is in inverse micrometers.
Permittivities are relative, with vacuum and unit permeability; the incident
wave travels along +z from the negative (vacuum) side into the positive-side
substrate. The reported reflection is the reflected power fraction for one
normal-incidence helicity channel.

Thickness is optimized by projected gradient descent with Armijo
backtracking. Each objective gradient is obtained through the installed
treams-rs Advect adapter and its native slab pullback; no finite differences
or closed-form thickness is used. The bounds are enforced by projection.

Checks performed: the example was executed through the CLI, the returned
reflection is below `1e-7`, the initial reflection is larger, and the final
gradient is returned from a fresh analytic derivative evaluation. The slab is
lossless, so its power balance also satisfies transmission plus reflection
equal to one up to numerical roundoff.
