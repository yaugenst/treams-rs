# Report

`solution.py` models one isotropic coating slab with `treams_rs.advect.slab` at
normal incidence. Lengths are micrometers, so `k0 = 2*pi/wavelength` is in
inverse micrometers. Epsilon, mu, and chirality are relative quantities; this
case uses `mu=1`, `chirality=0`, and vacuum on the negative-`z` incident side.
The wave propagates in `+z` into the substrate on the positive side, with no
gap.

The objective is reflected power for a unit positive-helicity plane wave. Each
optimization gradient is obtained with `advect.value_and_grad` through the
treams-rs native slab/scattering pullback. Optimization is projected gradient
descent with Armijo backtracking, and all trial thicknesses are clipped to the
given bounds.

Checks performed: the example was executed through the CLI; `results.json`
records the output, the final thickness is within bounds, and the reported
reflection is below `1e-7`. The returned final gradient is independently
recomputed by the same analytic pullback after optimization.
