"""Differentiable single-layer antireflection optimization using treams-rs."""

from __future__ import annotations

import json
import sys
from typing import Any

import advect as ad
import treams_rs.advect as tr


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Optimize the coating thickness and return JSON-compatible results."""
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    lower, upper = (float(x) for x in config["bounds"])
    if wavelength <= 0 or epsilon <= 0 or substrate_epsilon <= 0:
        raise ValueError("wavelength and permittivities must be positive")
    if lower > upper:
        raise ValueError("bounds must be increasing")
    initial = min(max(initial, lower), upper)

    # A single normal-incidence helicity channel is sufficient for an isotropic
    # normal-incidence problem.  The basis and incident wave are static; only
    # thickness is traced.
    basis = tr.PlaneWavePorts.default([0.0, 0.0])
    k0 = 2.0 * 3.141592653589793 / wavelength
    incident = tr.plane_wave(
        [0.0, 0.0, 1.0], [1.0, 0.0], k0=k0, medium=1.0
    )

    def reflection(thickness: Any) -> Any:
        system = tr.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        return system.power(incident, side="negative").reflection

    value_and_gradient = ad.value_and_grad(reflection)
    initial_value, _ = value_and_gradient(initial)
    x = initial
    loss_history = [float(initial_value)]

    # Projected gradient descent with an Armijo backtrack.  Every gradient used
    # here comes from treams-rs' native analytic pullback through Advect.
    for _ in range(500):
        value, gradient = value_and_gradient(x)
        value = float(value)
        gradient = float(gradient)
        if value < 1.0e-14 or abs(gradient) < 1.0e-13:
            break
        step = 0.2 * (upper - lower) / max(1.0, abs(gradient))
        accepted = False
        for _ in range(30):
            candidate = min(max(x - step * gradient, lower), upper)
            if candidate == x:
                step *= 0.5
                continue
            candidate_value = float(value_and_gradient(candidate)[0])
            # Armijo condition, with a small allowance for a projected step.
            if candidate_value <= value - 1.0e-4 * abs(gradient) * abs(
                candidate - x
            ):
                x = candidate
                loss_history.append(candidate_value)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    final_value, final_gradient = value_and_gradient(x)
    return {
        "thickness": float(x),
        "reflection": float(final_value),
        "initial_reflection": float(initial_value),
        "gradient": float(final_gradient),
        "loss_history": loss_history,
    }


if __name__ == "__main__":
    configuration = json.load(sys.stdin)
    print(json.dumps(run(configuration), separators=(",", ":")))
