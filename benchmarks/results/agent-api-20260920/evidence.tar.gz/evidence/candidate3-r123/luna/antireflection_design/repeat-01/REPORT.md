# Antireflection coating

`solution.py` models vacuum on the negative (incident, `+z`) side, one
lossless isotropic coating, and the supplied substrate on the positive side.
The wavelength and thickness are in micrometers; epsilon, mu, and chirality
are relative/dimensionless.  Here `mu=1` and chirality is zero.  The normal
incidence ports use treams-rs' helicity convention, and reflection is the
reflected power fraction for incidence from the negative side.

The thickness is optimized by projected gradient descent with Armijo
backtracking.  Both the scattering value and `dR/dthickness` come from
`treams_rs.advect`'s native pullback; no closed-form thickness is used.

Checks performed: the example was executed through the CLI, its result was
written to `results.json`, the returned thickness was within the requested
bounds, and the final reflection was below `1e-7`.  Losslessness also implies
that the treams-rs transmission plus reflection is unity (up to numerical
roundoff).
