"""Inverse design of the radius of a homogeneous dielectric sphere."""

import json
import sys

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _objective(radius, config):
    """Mean relative squared efficiency error (with a native radius VJP)."""
    epsilon = config["epsilon"]
    lmax = int(config["lmax"])
    wavelengths = config["wavelengths"]
    targets = config["target_efficiencies"]
    terms = []
    for wavelength, target in zip(wavelengths, targets):
        k0 = 2.0 * anp.pi / wavelength
        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon
        )
        illumination = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity", k0=k0
        )
        scattering_area = sphere.cross_sections(illumination).scattering
        efficiency = scattering_area / (anp.pi * radius * radius)
        terms.append(((efficiency - target) / target) ** 2)
    return sum(terms) / len(terms)


def _fit(config):
    lower, upper = (float(x) for x in config["bounds"])
    initial = float(config["initial_radius"])
    epsilon = config["epsilon"]
    lmax = int(config["lmax"])
    if lower > upper:
        raise ValueError("bounds must be ordered")
    if not lower <= initial <= upper:
        raise ValueError("initial_radius must lie in bounds")

    value_and_grad = ad.value_and_grad(lambda radius: _objective(radius, config))

    def evaluate(radius):
        value, gradient = value_and_grad(float(radius))
        return float(value), float(gradient)

    radius = initial
    loss, gradient = evaluate(radius)
    initial_loss = loss
    history = [loss]

    # Armijo projected-gradient iterations. Every objective derivative here is
    # the native Advect pullback; the line search only chooses a step length.
    for _ in range(300):
        if abs(gradient) < 1e-12 or loss < 1e-12:
            break
        direction = -gradient
        if radius <= lower and direction < 0:
            break
        if radius >= upper and direction > 0:
            break
        step = (upper - lower) / 4.0
        accepted = False
        while step > (upper - lower) * 1e-14:
            trial = min(upper, max(lower, radius + step * direction))
            if trial == radius:
                step *= 0.5
                continue
            trial_loss, trial_gradient = evaluate(trial)
            # Sufficient decrease using the actual projected displacement.
            if trial_loss <= loss + 1e-4 * gradient * (trial - radius):
                radius, loss, gradient = trial, trial_loss, trial_gradient
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break
        history.append(loss)

    # A final bounded polishing phase handles shallow gradients while keeping
    # all radius updates gradient-driven. The secant slope is only used to
    # propose a scale; acceptance still requires the analytic gradient.
    for _ in range(100):
        if loss < 1e-12 or abs(gradient) < 1e-12:
            break
        step = min(upper - lower, max((upper - lower) / 1000.0, 0.25 * abs(loss / gradient)))
        trial = min(upper, max(lower, radius - step * (1 if gradient > 0 else -1)))
        if trial == radius:
            break
        trial_loss, trial_gradient = evaluate(trial)
        if trial_loss < loss:
            radius, loss, gradient = trial, trial_loss, trial_gradient
            history.append(loss)
        else:
            break

    efficiencies = []
    for wavelength in config["wavelengths"]:
        k0 = 2.0 * anp.pi / wavelength
        sphere = tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)
        illumination = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
        area = sphere.cross_sections(illumination).scattering
        efficiencies.append(float(area / (anp.pi * radius * radius)))

    return {
        "radius": radius,
        "loss": loss,
        "initial_loss": initial_loss,
        "gradient": gradient,
        "fitted_efficiencies": efficiencies,
        "loss_history": history,
    }


def run(config):
    """Fit and return JSON-compatible inverse-design results."""
    return _fit(config)


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
