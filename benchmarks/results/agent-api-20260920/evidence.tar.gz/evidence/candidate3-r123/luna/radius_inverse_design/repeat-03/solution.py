"""Radius inverse design for a homogeneous sphere using treams-rs."""

import json
import sys

import advect
import numpy as np
import treams_rs.advect as tr


def _make_loss(config):
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = tuple(float(x) for x in config["wavelengths"])
    targets = tuple(float(x) for x in config["target_efficiencies"])

    def values(radius):
        result = []
        for wavelength in wavelengths:
            k0 = 2.0 * np.pi / wavelength
            sphere = tr.sphere_tmatrix(
                k0=k0, lmax=lmax, radius=radius, material=epsilon
            )
            incident = tr.plane_wave(
                [0.0, 0.0, 1.0], "positive_helicity", k0=k0
            )
            # treams-rs returns an area cross section.  The efficiency
            # convention is scattering area divided by geometric area.
            result.append(
                sphere.cross_sections(incident).scattering
                / (np.pi * radius * radius)
            )
        return result

    def objective(radius):
        q = values(radius)
        total = 0.0
        for calculated, target in zip(q, targets):
            total = total + ((calculated - target) / target) ** 2
        return total / len(targets)

    return values, objective


def run(config):
    values, objective = _make_loss(config)
    lower, upper = (float(x) for x in config["bounds"])
    radius = min(upper, max(lower, float(config["initial_radius"])))

    value_and_grad = advect.value_and_grad(objective)

    def evaluate(x):
        value, gradient = value_and_grad(np.array(x, dtype=float))
        return float(value), float(gradient)

    initial_loss, _ = evaluate(radius)
    history = [initial_loss]

    # Safeguarded gradient descent.  Every step direction and stopping test
    # uses the native analytic derivative supplied by the Advect adapter.
    for _ in range(300):
        current, gradient = evaluate(radius)
        if current < 1.0e-12 or abs(gradient) < 1.0e-12:
            break
        step = min(0.01, max(1.0e-5, 0.05 * (upper - lower)))
        accepted = False
        for _ in range(30):
            trial = min(upper, max(lower, radius - step * gradient))
            trial_loss, _ = evaluate(trial)
            if trial_loss < current:
                radius = trial
                history.append(trial_loss)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    final_loss, final_gradient = evaluate(radius)
    fitted = [float(x) for x in values(radius)]
    return {
        "radius": float(radius),
        "loss": float(final_loss),
        "initial_loss": float(initial_loss),
        "gradient": float(final_gradient),
        "fitted_efficiencies": fitted,
        "loss_history": [float(x) for x in history],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
