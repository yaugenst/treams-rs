# Radius inverse design

`solution.py` uses the public `treams_rs.advect` adapter and its native
analytic pullback for the sphere T-matrix and scattering cross section. The
optimizer is bounded, safeguarded gradient descent; no finite differences are
used for derivatives or optimization steps.

Lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. Permittivity is relative, the sphere is nonmagnetic, chirality is
zero, and the exterior medium is vacuum. The incident field is a positive
helicity plane wave along +z. For each wavelength,

`Q_sca = C_sca / (pi * radius**2)`.

The reported loss is the mean squared relative efficiency residual. The
example was executed and its JSON output was saved in `results.json`.

Checks: the fitted loss is below `1e-7`, the radius remains within the supplied
bounds, and the final analytic loss gradient is reported in the result.
