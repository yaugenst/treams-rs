# Radius inverse-design report

`solution.py` fits one homogeneous, lossless sphere using `treams_rs`'s
Advect-backed sphere T-matrix and native analytic pullbacks.  The reported
scattering efficiency is the scattering cross section divided by the
geometrical area `π r²`.

All lengths are in micrometers, so wavelengths and radius use μm and `k0` is
in μm⁻¹.  Epsilon is relative permittivity; the sphere has `mu=1` and zero
chirality, and the exterior is vacuum.  The positive-helicity plane wave is
incident along +z.  `lmax` is passed unchanged to the T-matrix.

The optimizer is bounded, projected, backtracked gradient descent.  Its
objective and every trial step use Advect's analytic radius derivative; no
finite-difference derivative is used.  Checks performed: the CLI was run on
the supplied example, the resulting JSON was parsed, the fitted loss was
checked below `1e-7`, and the final analytic gradient was re-evaluated at the
reported radius.
