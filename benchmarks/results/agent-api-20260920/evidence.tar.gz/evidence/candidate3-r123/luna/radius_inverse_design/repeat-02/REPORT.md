# Radius inverse design

`solution.py` uses the public `treams_rs.advect` namespace. For each wavelength
it builds a homogeneous sphere T-matrix at the configured `lmax`, illuminates it
with a positive-helicity plane wave in vacuum, and computes

`Q_sca = C_sca / (pi * radius^2)`.

All lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. Epsilon is relative and the omitted material parameters are
`mu=1`, `kappa=0`; the exterior medium is vacuum. The loss is the mean of the
squared relative efficiency residuals.

The bounded Armijo iterations use `advect.value_and_grad` and treams-rs native
pullbacks for the radius derivative. A final evaluation checks the fitted
efficiencies and the reported derivative.
