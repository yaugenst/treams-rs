"""Analytic inverse design of a homogeneous dielectric sphere."""

from __future__ import annotations

import json
import sys
from typing import Any

import advect as ad
import numpy as np
import treams_rs.advect as tr


def _objective(radius: Any, epsilon: float, lmax: int,
               wavelengths: tuple[float, ...], targets: tuple[float, ...]) -> Any:
    """Mean relative squared efficiency error, retaining traced radius."""
    total = 0.0
    for wavelength, target in zip(wavelengths, targets, strict=True):
        k0 = 2.0 * np.pi / wavelength
        particle = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon
        )
        incident = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity", k0=k0
        )
        scattering_area = particle.cross_sections(incident).scattering
        efficiency = scattering_area / (np.pi * radius * radius)
        total = total + ((efficiency - target) / target) ** 2
    return total / len(wavelengths)


def _fit(epsilon: float, lmax: int, wavelengths: tuple[float, ...],
         targets: tuple[float, ...], initial: float,
         bounds: tuple[float, float]) -> tuple[float, float, float, float, list[float]]:
    def value_gradient(radius: float) -> tuple[float, float]:
        value, gradient = ad.value_and_grad(
            lambda r: _objective(r, epsilon, lmax, wavelengths, targets)
        )(float(radius))
        return float(value), float(np.asarray(gradient))

    lo, hi = bounds
    radius = min(hi, max(lo, initial))
    loss, gradient = value_gradient(radius)
    initial_loss = loss
    history = [loss]

    # Projected, backtracked gradient descent.  Every trial and every update
    # uses the native analytic radius derivative returned by Advect.
    width = hi - lo
    for _ in range(300):
        if loss < 1.0e-12:
            break
        if abs(gradient) < 1.0e-13:
            break
        direction = -1.0 if gradient > 0.0 else 1.0
        step = min(width / 4.0, max(width / 100.0, abs(gradient) * width / 20.0))
        accepted = False
        while step > width * 1.0e-14:
            candidate = min(hi, max(lo, radius + direction * step))
            candidate_loss, candidate_gradient = value_gradient(candidate)
            # Armijo decrease, with a small tolerance for the final floating
            # point-scale steps.
            if candidate_loss <= loss - 1.0e-4 * abs(gradient) * abs(candidate - radius) + 1.0e-15:
                radius, loss, gradient = candidate, candidate_loss, candidate_gradient
                history.append(loss)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    # A final native evaluation makes the reported derivative unambiguously
    # correspond to the reported radius (including a projected-bound result).
    loss, gradient = value_gradient(radius)
    if not history or loss != history[-1]:
        history.append(loss)
    return radius, loss, initial_loss, gradient, history


def _efficiencies(radius: float, epsilon: float, lmax: int,
                  wavelengths: tuple[float, ...]) -> list[float]:
    values = []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        particle = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon
        )
        incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
        values.append(float(particle.cross_sections(incident).scattering /
                           (np.pi * radius * radius)))
    return values


def run(config: dict[str, Any]) -> dict[str, Any]:
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = tuple(float(x) for x in config["wavelengths"])
    targets = tuple(float(x) for x in config["target_efficiencies"])
    initial = float(config["initial_radius"])
    bounds = tuple(float(x) for x in config["bounds"])
    if len(wavelengths) != len(targets) or not wavelengths:
        raise ValueError("wavelengths and target_efficiencies must be nonempty and equal")
    if len(bounds) != 2 or not (0.0 < bounds[0] <= bounds[1]):
        raise ValueError("bounds must be two positive ordered radii")
    radius, loss, initial_loss, gradient, history = _fit(
        epsilon, lmax, wavelengths, targets, initial, bounds
    )
    return {
        "radius": float(radius),
        "loss": float(loss),
        "initial_loss": float(initial_loss),
        "gradient": float(gradient),
        "fitted_efficiencies": _efficiencies(radius, epsilon, lmax, wavelengths),
        "loss_history": [float(x) for x in history],
    }


if __name__ == "__main__":
    print(json.dumps(run(json.load(sys.stdin))))
