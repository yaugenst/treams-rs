# Infinite-cylinder scattering widths

`solution.py` uses the public `treams_rs.cylinder_tmatrix` and
`cross_widths` APIs.  The cylinder axis is z, `kz=0`, and the incident wave
travels along +x with positive helicity.  The supplied relative permittivity
is converted from `[real, imag]`; relative permeability is one and chirality
is zero, with vacuum outside.

All lengths are in micrometers, so `k0=2*pi/wavelength` is in inverse
micrometers.  The returned scattering, extinction, and absorption values are
cylinder cross widths (micrometers), with absorption equal to extinction minus
scattering.  No sphere-area normalization is used.  Results follow the input
wavelength order.

Checks performed: the example was executed through the CLI and saved as
`results.json`; the returned values are finite, absorption obeys the stated
identity, and the passive example has nonnegative absorption.
