"""Cylinder scattering widths using the public treams-rs API."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return scattering, extinction, and absorption widths for each wavelength.

    Lengths are in the same units as ``radius`` and ``wavelengths``.  The
    wavelength entries are paired and returned in ascending wavelength order.
    """
    radius = float(config["radius"])
    epsilon_value = config["epsilon"]
    if not isinstance(epsilon_value, (list, tuple)) or len(epsilon_value) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(float(epsilon_value[0]), float(epsilon_value[1]))
    wavelengths = [float(value) for value in config["wavelengths"]]
    mmax = int(config["mmax"])
    if radius <= 0 or any(wavelength <= 0 for wavelength in wavelengths):
        raise ValueError("radius and wavelengths must be positive")
    if mmax < 0:
        raise ValueError("mmax must be nonnegative")

    values: list[tuple[float, float, float, float]] = []
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        cylinder = tr.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],
            mmax=mmax,
            radius=radius,
            material=epsilon,
        )
        incident = tr.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
        )
        widths = cylinder.cross_widths(incident)
        values.append(
            (
                wavelength,
                float(widths.scattering),
                float(widths.extinction),
                float(widths.absorption),
            )
        )

    values.sort(key=lambda item: item[0])
    return {
        "scattering": [item[1] for item in values],
        "extinction": [item[2] for item in values],
        "absorption": [item[3] for item in values],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
