# Infinite-cylinder scattering

`solution.py` uses the public `treams_rs.cylinder_tmatrix` and
`cross_widths` APIs.  The cylinder is infinite and parallel to `z`, with
`kz=0`; the incident wave propagates along `+x` and uses the positive-helicity
channel.  The supplied `mmax` is used as the azimuthal cutoff, including
orders from `-mmax` through `+mmax`.

All lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers and the returned cross widths are in micrometers.  The material is
`epsilon[0] + i*epsilon[1]`, with relative permeability one, zero chirality,
and vacuum exterior.  No sphere-area normalization is applied.

The absorption list is the native treams-rs result
`extinction - scattering`; the example execution also checks that this
identity holds and that the passive-material values are nonnegative up to
roundoff.
