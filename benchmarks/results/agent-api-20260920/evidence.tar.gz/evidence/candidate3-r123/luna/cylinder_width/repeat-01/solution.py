"""Infinite-cylinder scattering widths using treams-rs."""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return scattering, extinction, and absorption widths for each wavelength.

    The input epsilon is represented as ``[real, imag]``.  All lengths are in
    the same units as radius and wavelength (micrometers for this task).
    """
    radius = float(config["radius"])
    eps_parts = config["epsilon"]
    if len(eps_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(float(eps_parts[0]), float(eps_parts[1]))
    wavelengths = [float(value) for value in config["wavelengths"]]
    mmax = int(config["mmax"])
    if radius <= 0 or any(wavelength <= 0 for wavelength in wavelengths):
        raise ValueError("radius and wavelengths must be positive")
    if mmax < 0:
        raise ValueError("mmax must be nonnegative")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        particle = tr.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=epsilon,
        )
        incident = tr.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
        )
        widths = particle.cross_widths(incident)
        scattering.append(float(widths.scattering))
        extinction.append(float(widths.extinction))
        absorption.append(float(widths.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
