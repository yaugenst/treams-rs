# Cylinder-width calculation

`solution.py` uses the public `treams_rs` cylinder T-matrix and `cross_widths`
workflow.  The cylinder axis is z, `kz=0`, and the incident plane wave travels
along +x with positive helicity.  `mmax` is passed directly as the azimuthal
cutoff; no sphere-area normalization is used.

All lengths are in the input length unit (micrometers here), so the returned
scattering, extinction, and absorption values are widths in that unit.
The complex relative permittivity is formed as `epsilon[0] + i*epsilon[1]`;
the exterior medium is the default vacuum (`epsilon=mu=1`, zero chirality).
The output entries are sorted by wavelength.

Checks performed: the example was executed through the stdin CLI and saved to
`results.json`; the reported absorption is the treams-rs balance
`extinction - scattering` for each wavelength, and all three output arrays
have the same length as the wavelength list.
