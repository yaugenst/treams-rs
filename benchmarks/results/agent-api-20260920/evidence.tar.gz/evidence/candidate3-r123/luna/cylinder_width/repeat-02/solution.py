"""Infinite-cylinder scattering cross widths using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Calculate widths for the wavelengths in *config*, in input order."""
    radius = float(config["radius"])
    eps = config["epsilon"]
    epsilon = complex(float(eps[0]), float(eps[1]))
    wavelengths = [float(value) for value in config["wavelengths"]]
    mmax = int(config["mmax"])

    if radius <= 0 or not wavelengths or any(value <= 0 for value in wavelengths):
        raise ValueError("radius and wavelengths must be positive")
    if len(eps) != 2 or mmax < 0:
        raise ValueError("epsilon must be [real, imag] and mmax nonnegative")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        response = tr.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=epsilon,
        )
        incident = tr.plane_wave(
            [1.0, 0.0, 0.0], "positive_helicity", k0=k0
        )
        widths = response.cross_widths(incident)
        scattering.append(float(widths.scattering))
        extinction.append(float(widths.extinction))
        absorption.append(float(widths.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
