"""Homogeneous dielectric sphere spectrum using treams-rs."""

from __future__ import annotations

import json
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Calculate sphere cross sections for each wavelength in ``config``.

    Lengths are in the input length unit (micrometers here), so the returned
    cross sections are in its squared unit (square micrometers).
    """
    radius = float(config["radius"])
    epsilon = config["epsilon"]
    material = complex(float(epsilon[0]), float(epsilon[1]))
    wavelengths = [float(value) for value in config["wavelengths"]]
    lmax = int(config["lmax"])

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    efficiency: list[float] = []
    geometric_area = 3.141592653589793 * radius * radius

    for wavelength in wavelengths:
        k0 = 2.0 * 3.141592653589793 / wavelength
        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=material
        )
        illumination = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
        )
        cross = sphere.cross_sections(illumination)
        sca = float(cross.scattering)
        ext = float(cross.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(float(cross.absorption))
        efficiency.append(sca / geometric_area)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
