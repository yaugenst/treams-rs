# Sphere spectrum report

`solution.py` uses the installed `treams_rs.sphere_tmatrix` implementation with
the requested fixed `lmax` multipole cutoff.  Each wavelength uses
`k0 = 2*pi/wavelength`, a vacuum exterior (`epsilon=mu=1`), and a plane wave
traveling along +z with `positive_helicity`.  The supplied `epsilon` pair is
interpreted as the complex relative permittivity
`epsilon[0] + i*epsilon[1]`; it is not treated as a refractive index.

The returned scattering, extinction, and absorption values are areas in the
input length squared (micrometer squared for the example).  Absorption is the
treams-rs balance `extinction - scattering`.  Efficiency is scattering divided
by the geometric area `pi*radius**2` and is dimensionless.  Results retain the
input wavelength order.

Checks performed: the CLI was run on the supplied example and its output was
written to `results.json`; the four output arrays have equal length, and the
reported absorption values are computed by the library balance.
