"""Homogeneous dielectric sphere spectrum using treams-rs."""

import json
import math
import sys

import treams_rs


def run(config):
    """Return sphere cross sections for the wavelengths in *config*.

    All lengths are interpreted in micrometers.  Cross sections therefore
    have units of square micrometers.
    """
    radius = float(config["radius"])
    epsilon = config["epsilon"]
    if len(epsilon) != 2:
        raise ValueError("epsilon must be [real, imag]")
    material = complex(float(epsilon[0]), float(epsilon[1]))
    lmax = int(config["lmax"])

    scattering = []
    extinction = []
    absorption = []
    efficiency = []
    for wavelength_value in config["wavelengths"]:
        wavelength = float(wavelength_value)
        k0 = 2.0 * math.pi / wavelength
        response = treams_rs.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=material,
            polarization="helicity",
        )
        incident = treams_rs.plane_wave(
            direction=(0.0, 0.0, 1.0),
            polarization="positive_helicity",
            k0=k0,
        )
        cross_sections = response.cross_sections(incident)
        sca = float(cross_sections.scattering)
        ext = float(cross_sections.extinction)
        abs_cs = float(cross_sections.absorption)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(abs_cs)
        efficiency.append(sca / (math.pi * radius * radius))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")
