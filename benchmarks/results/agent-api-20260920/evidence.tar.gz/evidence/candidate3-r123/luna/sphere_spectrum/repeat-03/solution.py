"""Homogeneous dielectric-sphere spectrum using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return sphere cross sections and scattering efficiency for *config*.

    Lengths are in the same units as the input (micrometers here), so the
    returned cross sections are in squared input length units.
    """
    radius = float(config["radius"])
    epsilon = config["epsilon"]
    if len(epsilon) != 2:
        raise ValueError("epsilon must be [real, imaginary]")
    eps = complex(float(epsilon[0]), float(epsilon[1]))
    wavelengths = [float(value) for value in config["wavelengths"]]
    lmax = int(config["lmax"])
    if radius <= 0 or lmax < 1 or any(value <= 0 for value in wavelengths):
        raise ValueError("radius, wavelengths, and lmax must be positive")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    efficiency: list[float] = []
    geometric_area = math.pi * radius * radius

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        response = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=eps,
            medium=1,
            polarization="helicity",
        )
        incident = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        cross = response.cross_sections(incident)
        sca = float(cross.scattering)
        ext = float(cross.extinction)
        scattering.append(sca)
        extinction.append(ext)
        absorption.append(float(cross.absorption))
        efficiency.append(sca / geometric_area)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
