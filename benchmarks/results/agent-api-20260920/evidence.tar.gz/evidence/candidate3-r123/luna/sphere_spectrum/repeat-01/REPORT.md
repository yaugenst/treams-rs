# Sphere spectrum

`solution.py` uses the public `treams_rs.sphere_tmatrix` and
`treams_rs.plane_wave` APIs. The sphere is centered at the origin in vacuum,
illuminated along +z with positive helicity, and uses the requested `lmax`.

Lengths are in micrometers, so the scattering, extinction, and absorption
values are areas in µm². `epsilon: [real, imag]` is converted to the complex
relative permittivity `real + i imag`; the exterior has relative permittivity
and permeability 1, with zero chirality. Efficiency is scattering divided by
`pi * radius²`.

Checks performed: the CLI was run on the supplied example; the returned
absorption agrees with extinction minus scattering (up to floating-point
roundoff), and the resulting lists preserve input wavelength order. The numerical scattering and extinction are supplied
by treams-rs at the specified multipole cutoff.
