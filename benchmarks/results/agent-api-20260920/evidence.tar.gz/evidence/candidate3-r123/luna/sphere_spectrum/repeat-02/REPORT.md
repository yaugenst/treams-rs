# Sphere spectrum report

`solution.py` uses the public `treams_rs.sphere_tmatrix` and
`treams_rs.plane_wave`/`cross_sections` APIs.  The sphere is centered at the
origin, the exterior is vacuum, and illumination propagates in `+z` with
positive helicity.  The requested `lmax` is passed unchanged to the native
T-matrix calculation.

All lengths are micrometers, so cross sections are square micrometers.
`epsilon=[real, imag]` is converted to the relative complex permittivity
`real + i*imag`; positive imaginary part is passive loss.  The returned
efficiency is scattering divided by `pi*radius**2`.

Checks performed: the CLI was run on the supplied example and its output was
saved in `results.json`; absorption is the library's extinction-minus-
scattering value, and every wavelength is evaluated independently in the
input order.
