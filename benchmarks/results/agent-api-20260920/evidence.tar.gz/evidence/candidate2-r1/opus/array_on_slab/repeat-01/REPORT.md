# Sphere array above a dielectric slab — T / R / A power fractions

## What is computed

For each vacuum wavelength the stack is assembled along +z as

```
vacuum | slab (slab_thickness, slab_epsilon) | vacuum gap (gap) | sphere array | vacuum
```

and illuminated from the negative-z side by a positive-helicity plane wave
propagating along +z. Returned are the outgoing power fractions
`transmission` (into +z), `reflection` (back into -z) and `absorption`,
in the same order as the input `wavelengths`.

## Units and conventions

- All lengths (`radius`, `period`, `gap`, `slab_thickness`, `wavelengths`) are
  in micrometers. `k0 = 2*pi/wavelength` is the vacuum angular wavenumber, so
  `1/k0` carries the same length unit as the geometry.
- `sphere_epsilon` and `slab_epsilon` are real relative permittivities; `mu=1`
  and `kappa=0` throughout. All exterior media are vacuum.
- Square lattice of side `period` in the xy-plane, Bloch vector `kpar=[0, 0]`
  (normal incidence). Because every wavelength exceeds the period, only the
  zeroth order propagates; the port basis is
  `PlaneWavePorts.default([0, 0])`, i.e. the zeroth order with both
  helicities. Evanescent orders are not carried as open channels — their
  effect is fully contained in the periodic lattice sums.
- `gap` is measured from the slab's top face to the **sphere-center plane**,
  which is exactly where `treams_rs.propagation` terminates for an array
  S-matrix. The spheres therefore protrude `radius` above that plane; with the
  example numbers (`gap=0.12 > radius=0.06`) the spheres do not touch the slab.
- Powers are normalized by the incident flux, so `T + R + A = 1`.

## Method (treams-rs)

1. `sphere_tmatrix(k0, lmax, radius, material)` — Mie T-matrix of one sphere
   at the fixed multipole cutoff `lmax`.
2. `solve_periodic(sphere, lattice=Lattice.square(period), kpar=[0, 0])` —
   solves the full periodic multiple-scattering interaction of the array
   (Ewald lattice sums, all orders of interaction), then `.to_smatrix(ports)`
   projects it onto the retained plane-wave channels.
3. `slab(...)` for the dielectric layer and `propagation(..., distance=gap)`
   for the vacuum gap, both in the same port basis.
4. `stack([slab, gap, array])` cascades them from negative to positive z, and
   `network.power(plane_wave([0, 0, 1], "positive_helicity", k0), side="negative")`
   returns the `PowerBalance`.

No scattering physics is reimplemented; all of it comes from treams-rs.

## Checks performed

- **Energy conservation:** `T + R + A = 1` to ~1e-16 at every wavelength
  (reported as `sum_check` in `results.json`).
- **Losslessness:** with real permittivities the absorption comes out at the
  1e-16 level (occasionally a tiny negative value, pure round-off). It is
  reported raw rather than clamped.
- **Bare slab vs. analytic Fresnel:** the `slab` block alone reproduces the
  closed-form normal-incidence reflectance of a lossless layer,
  `R = |r(1-e^{2ink0d})/(1-r^2 e^{2ink0d})|^2` with `r=(1-n)/(1+n)`, to
  <1e-16 at all three wavelengths.
- **Multipole convergence:** transmission at `lmax = 1, 2, 3, 4, 6` for the
  example config changes by <1e-5 beyond `lmax=2`; the requested `lmax` is
  used as given.
- **Achiral duality:** negative-helicity illumination gives identical T and R
  (agreement to ~1e-15), as required for a mirror-symmetric, achiral stack at
  normal incidence.
- **Absorption channel:** adding an imaginary part to `sphere_epsilon`
  (diagnostic only, not part of the task) yields positive absorption with
  `T + R + A = 1`.

## Files

- `solution.py` — `run(config)` plus a CLI that reads one JSON config on
  stdin and prints the result dictionary as JSON on stdout.
- `example_config.json`, `results.json` — the example config and its output.

## Result for the example config

| wavelength (um) | T | R | A |
|---|---|---|---|
| 0.65 | 0.887329 | 0.112671 | ~0 |
| 0.74 | 0.902069 | 0.097931 | ~0 |
| 0.83 | 0.911914 | 0.088086 | ~0 |
