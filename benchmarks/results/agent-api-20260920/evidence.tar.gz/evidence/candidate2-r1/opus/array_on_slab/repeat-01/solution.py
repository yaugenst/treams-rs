"""Periodic sphere array above a dielectric slab: T/R/A power fractions.

Network ordering along +z: slab, vacuum gap, sphere array. Illumination
travels along +z from the negative-z side with positive helicity. Only the
zeroth diffraction order (both helicities) is retained, Bloch vector [0, 0].
All lengths in micrometers; permittivities are relative and dimensionless.
"""

import json
import sys

import treams_rs as tr


def run(config):
    radius = float(config["radius"])
    sphere_epsilon = float(config["sphere_epsilon"])
    period = float(config["period"])
    gap = float(config["gap"])
    slab_thickness = float(config["slab_thickness"])
    slab_epsilon = float(config["slab_epsilon"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config["lmax"])

    lattice = tr.Lattice.square(period)
    ports = tr.PlaneWavePorts.default([0, 0])  # zeroth order, both helicities

    transmission = []
    reflection = []
    absorption = []

    for wavelength in wavelengths:
        k0 = 2.0 * 3.141592653589793 / wavelength

        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon
        )
        array = tr.solve_periodic(sphere, lattice=lattice, kpar=[0, 0]).to_smatrix(
            ports
        )
        layer = tr.slab(
            k0=k0, basis=ports, thickness=slab_thickness, material=slab_epsilon
        )
        vacuum_gap = tr.propagation(k0=k0, basis=ports, distance=gap)

        network = tr.stack([layer, vacuum_gap, array])  # negative -> positive z
        wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
        power = network.power(wave, side="negative")

        transmission.append(float(power.transmission))
        reflection.append(float(power.reflection))
        absorption.append(float(power.absorption))

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
        "sum_check": [
            t + r + a for t, r, a in zip(transmission, reflection, absorption)
        ],
    }


def main():
    print(json.dumps(run(json.load(sys.stdin))))


if __name__ == "__main__":
    main()
