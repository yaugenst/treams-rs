# Homogeneous dielectric sphere spectrum

## What is computed

For each vacuum wavelength the exact Mie T-matrix of the sphere is built with
`treams_rs.sphere_tmatrix(k0=2*pi/wavelength, lmax=..., radius=..., material=...,
medium=1, polarization="helicity")`, illuminated by a plane wave travelling along
`+z` with positive helicity (`treams_rs.plane_wave(direction=[0,0,1],
polarization="positive_helicity", k0=..., material=1)`), and the cross sections are
taken from `tmatrix.cross_sections(illumination)`. No scattering physics is
reimplemented.

## Units and conventions

- Lengths (`radius`, `wavelengths`) are in micrometers; `k0 = 2*pi/wavelength` is the
  vacuum angular wavenumber in 1/um.
- `epsilon = [real, imag]` is the **relative permittivity** (not a refractive index),
  entered as `Material(complex(re, im))`. `mu = 1`, `kappa = 0`, exterior = vacuum.
- treams uses the `exp(-i omega t)` convention, so a positive imaginary part of
  epsilon is loss; this is confirmed below by the positive absorption.
- `scattering`, `extinction`, `absorption` are areas in um^2 (squared length units of
  the input). `absorption = extinction - scattering`.
- `efficiency = scattering / (pi * radius**2)`, dimensionless (scattering efficiency
  Qsca; extinction is not normalized, per the requested keys).
- All four lists are in the order of the input `wavelengths` (no sorting applied).
- `lmax` is used exactly as given as the fixed multipole cutoff.

## Example result (radius 0.1 um, epsilon 12+0.05i, lmax 4)

| lambda (um) | sigma_sca (um^2) | sigma_ext (um^2) | sigma_abs (um^2) | Qsca |
|---|---|---|---|---|
| 0.45 | 0.0271457634 | 0.0291621529 | 0.0020163896 | 0.8640765 |
| 0.55 | 0.1624754734 | 0.1651156717 | 0.0026401983 | 5.1717549 |
| 0.65 | 0.1398053723 | 0.1418898545 | 0.0020844822 | 4.4501432 |
| 0.75 | 0.1793368534 | 0.1866766776 | 0.0073398242 | 5.7084693 |

Stored in `results.json`.

## Checks

- **Independent Mie series.** The standard `a_n`/`b_n` Mie coefficients (Riccati-Bessel
  form, `m = sqrt(epsilon)`, truncated at the same `lmax`) reproduce the returned
  scattering and extinction areas to ~10 significant digits at all four wavelengths.
- **Optical theorem / energy balance.** `absorption = extinction - scattering > 0` at
  every wavelength, i.e. the lossy sphere absorbs, confirming the sign convention.
- **Helicity symmetry.** An achiral sphere gives identical cross sections for positive
  and negative helicity (agreement to ~1e-16 relative), as it must for `kappa = 0`.
- **Multipole convergence.** At 0.45 um the cross sections change by <5e-9 relative
  between `lmax = 4` and `lmax = 10`, so the requested cutoff is converged for the
  example; the code nevertheless always uses the `lmax` supplied in the config.

## Usage

```
python solution.py < config.json        # JSON config on stdin, JSON result on stdout
```
or `from solution import run; run(config)`.
