"""Spectrum of a homogeneous dielectric sphere illuminated along +z.

Cross sections are computed from the exact Mie T-matrix provided by
``treams_rs.sphere_tmatrix`` for a plane wave of positive helicity.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as t


def _material(epsilon):
    """Relative permittivity given as [real, imag] (or a scalar) -> Material."""
    if isinstance(epsilon, (list, tuple)):
        re, im = (list(epsilon) + [0.0])[:2]
        eps = complex(float(re), float(im))
    else:
        eps = complex(epsilon)
    return t.Material(eps)


def run(config):
    radius = float(config["radius"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    material = _material(config["epsilon"])
    medium = t.Material(1)  # vacuum exterior

    scattering, extinction, absorption, efficiency = [], [], [], []
    area = np.pi * radius**2
    for wl in wavelengths:
        k0 = 2 * np.pi / wl  # vacuum angular wavenumber, 1/um
        tm = t.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )
        illu = t.plane_wave(
            direction=[0, 0, 1],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
        )
        cs = tm.cross_sections(illu)
        scattering.append(float(cs.scattering))
        extinction.append(float(cs.extinction))
        absorption.append(float(cs.absorption))
        efficiency.append(float(cs.scattering / area))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
