"""Two-sphere (dimer) multiple-scattering fields and cross sections via treams-rs.

Geometry: spheres at x = -separation/2 and x = +separation/2 (y = z = 0),
radii/epsilon given in that order. Illumination: plane wave along +z with
positive helicity. All lengths in micrometers; epsilon is [real, imag],
mu = 1, kappa = 0, exterior vacuum.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def _complex_eps(entry):
    """[real, imag] (or a plain number) -> complex relative permittivity."""
    if isinstance(entry, (list, tuple)):
        re, im = (list(entry) + [0.0])[:2]
        return complex(float(re), float(im))
    return complex(entry)


def run(config):
    radii = [float(r) for r in config["radii"]]
    eps = [_complex_eps(e) for e in config["epsilon"]]
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    points = np.asarray(config["points"], dtype=float).reshape(-1, 3)

    k0 = 2.0 * np.pi / wavelength  # vacuum angular wavenumber, 1/um
    positions = [[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]]

    particles = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=tr.Material(e))
        for r, e in zip(radii, eps)
    ]
    cluster = tr.Cluster(particles, positions=positions)
    solved = cluster.solve()  # full multiple scattering at fixed lmax

    incident = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    cross = solved.cross_sections(incident)

    scattered = solved.scatter(incident)
    total = np.asarray(incident.efield(points)) + np.asarray(scattered.efield(points))
    total = np.atleast_2d(total)

    return {
        "total_field_real": total.real.tolist(),
        "total_field_imag": total.imag.tolist(),
        "scattering_cross_section": float(cross.scattering),
        "extinction_cross_section": float(cross.extinction),
        "absorption_cross_section": float(cross.absorption),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
