# Dimer total field and cross sections (treams-rs)

## What is computed
Two homogeneous spheres at `x = -separation/2` and `x = +separation/2` (`y = z = 0`),
with `radii[i]`/`epsilon[i]` assigned in that order. The pair is illuminated by a plane
wave travelling along `+z` with positive helicity. The coupled cluster is solved with
**all multiple scattering** at the fixed multipole cutoff `lmax`
(`treams_rs.Cluster(...).solve()`), and at each requested point the **total** field
`E_inc + E_sca` is evaluated.

## Units and conventions
- Lengths (radii, separation, wavelength, point coordinates) in micrometers.
  Vacuum angular wavenumber `k0 = 2*pi/wavelength` [1/um].
- `epsilon` entries are `[real, imag]` relative permittivities; `mu = 1`, `kappa = 0`,
  exterior is vacuum — passed as `treams_rs.Material(eps)`.
- Fields use the package incident normalization: `plane_wave([0,0,1],
  "positive_helicity", k0)` has unit amplitude, `E(0) = -(x̂ + i ŷ)/sqrt(2)`, so
  `|E_inc| = 1` everywhere. The time convention and helicity convention are those of
  treams-rs; the returned field is the raw complex vector, split into
  `total_field_real` / `total_field_imag` (each `n_points x 3`, Cartesian x,y,z).
- Cross sections come from `solved.cross_sections(incident)` and are areas in um^2
  (scattering, extinction, absorption) for this fixed incident plane wave — not
  orientation- or polarization-averaged.

## Output keys
`total_field_real`, `total_field_imag` (lists of 3-vectors, one per input point),
`scattering_cross_section`, `extinction_cross_section`, `absorption_cross_section`.

## Example result (`results.json`)
Config: radii `[0.08, 0.11]`, eps `[4+0.02i, 6+0.08i]`, separation `0.32`,
wavelength `0.72`, `lmax = 3`.

- sigma_sca = 5.648477e-02 um^2, sigma_ext = 5.910237e-02 um^2,
  sigma_abs = 2.617603e-03 um^2
- E(0, 0, 0.3)      = (0.80919 - 0.26914i, 0.23513 + 0.82034i, 0.03110 + 0.07267i)
- E(0.35, 0.2, 0.1) = (-0.22645 - 0.60503i, 0.52804 - 0.43737i, -0.02124 - 0.12125i)

## Checks performed
1. **Energy balance / passivity**: `sigma_abs = sigma_ext - sigma_sca > 0` for the lossy
   example; with `Im(eps) = 0` the absorption is 1.4e-17 um^2 (machine zero) and
   `sigma_sca = sigma_ext`.
2. **Multipole convergence**: going from `lmax = 3` to `lmax = 6` changes the cross
   sections by ~1.4e-5 relative and the field components by ~1e-6 absolute, so
   `lmax = 3` is well converged for these small spheres (the requested `lmax` is used
   as specified, this is only a diagnostic).
3. **Isolated-particle limit**: at `separation = 200 um` the dimer extinction
   (5.78380e-02 um^2) matches the sum of the two single-sphere Mie extinctions
   (5.78460e-02 um^2) to 1.4e-4 relative, confirming correct coupling and the fact
   that coupling is genuinely included at the nominal separation (where the total
   differs from the incoherent sum by ~2%).
4. **Far-point field**: at `(0, 0, 1e4)` the total field reduces to the unit-amplitude
   incident wave (`|Ex| = |Ey| = 0.70711`, `|Ez| ~ 1e-10`), verifying the incident
   normalization and the incident+scattered sum.
5. **C2z symmetry**: rotating the problem by 180 deg about z (swap the two spheres and
   map a point `(x, y, z) -> (-x, -y, z)`) reproduces the field up to the expected
   global sign of a positive-helicity wave, to 1.4e-16, and leaves the cross sections
   unchanged.

No derivatives or optimization are requested by this task, so no sensitivity machinery
is used; the scattering itself is done entirely by treams-rs (no reimplementation).

## Usage
```
python solution.py < config.json > results.json
```
or `from solution import run; run(config_dict)`.
