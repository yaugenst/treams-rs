# Chiral slab: normal-incidence power fractions

## Problem and method

A homogeneous, isotropic, reciprocal chiral layer of thickness `d` lies normal to
z with vacuum on both sides.  A plane wave of definite helicity is incident from
the negative side and propagates along +z.  The scattering problem is solved with
`treams_rs.slab`, which builds the S-matrix of one layer between named exterior
media in a plane-wave basis; the power fractions come from
`SMatrices.power(illumination, side="negative")`.  No Fresnel/Fabry–Perot algebra
is reimplemented in the solution — the analytic formulas below are used only as
an independent check.

## Units and conventions

- Lengths (`thickness`, `wavelengths`) are in micrometers; `k0 = 2*pi/lambda` is
  the vacuum angular wavenumber in 1/µm.  Only the ratio `d/lambda` matters, so
  any consistent length unit works.
- `epsilon` is given as `[real, imag]` and is the relative permittivity.  `mu`
  (optional, default 1) and `kappa` (default 0) are dimensionless; `kappa` is
  treams' material chirality, entering through
  `Material(epsilon, mu, kappa)` with helicity refractive indices
  `n_pm = sqrt(epsilon*mu) ± kappa` and a common wave impedance
  `Z = sqrt(mu/epsilon)`.  A positive `Im(epsilon)` is absorbing (exp(-i*omega*t)
  time convention); a positive `Im(kappa)` makes the **positive** helicity the
  more strongly absorbed one.
- Both `epsilon` and `kappa` accept a scalar or a `[real, imag]` pair.
- Basis: `PlaneWavePorts.default([0, 0])` — normal incidence, transverse
  wavevector `(kx, ky) = (0, 0)`, two helicity channels.  The default mode order
  is `(0,0,pol=1)` then `(0,0,pol=0)`, i.e. **positive helicity first, negative
  second**, matching the requested output ordering.  Illumination vectors
  `[1,0]` and `[0,1]` therefore select positive and negative helicity.
- Outputs are **power fractions** normalized to the incident flux, not amplitude
  coefficients: `transmission = |t|^2`-type flux ratios, and
  `absorption = 1 - transmission - reflection` (treams' `PowerBalance.absorption`).
  Each of `transmission`, `reflection`, `absorption` has shape
  `(n_wavelengths, 2)`.

## Output

`run(config)` returns `wavelengths`, `helicity_order` (`["positive","negative"]`),
and the three `(n_wavelengths, 2)` lists.  The CLI reads one JSON config from
stdin and prints this dictionary as JSON.

## Example result (`results.json`)

`thickness = 0.16 µm`, `epsilon = 2.25 + 0.06i`, `kappa = 0.08`,
`lambda = 0.55, 0.65, 0.8 µm`:

| lambda (µm) | T (+/-) | R (+/-) | A (+/-) |
|---|---|---|---|
| 0.55 | 0.905416 | 0.024049 | 0.070536 |
| 0.65 | 0.864572 | 0.080756 | 0.054673 |
| 0.80 | 0.826736 | 0.130154 | 0.043110 |

The two helicities coincide to ~1e-15 here.  This is physical, not a bug: for a
**real** `kappa` the two circular eigenwaves share the same impedance and the
same `Im(n)`, so `kappa` produces optical rotation (a phase difference) but no
circular dichroism at normal incidence.  Helicity-resolved power differences
require `Im(kappa) != 0` (or anisotropy/oblique incidence).

## Checks performed

1. **Power balance**: `T + R + A = 1` by construction of `PowerBalance`.
2. **Lossless limit**: `Im(epsilon)=0`, real `kappa=0.15`, `d=0.3 µm` gives
   `A <= 4e-16` and `T + R = 1` for both helicities.
3. **Achiral reduction**: with `kappa = 0` the results reproduce the textbook
   Fabry–Perot slab formula
   `t = t01 t10 e^{i n k0 d} / (1 - r10^2 e^{2 i n k0 d})` to ~1e-15
   (T = 0.9054155085149018 vs 0.9054155085149027 at 0.55 µm).
4. **Chiral analytic cross-check**: for real `kappa`, the same Fabry–Perot sum
   with helicity-flipping internal reflections (forward `n_+`, backward `n_-`)
   reproduces treams to ~1e-15 for the example parameters.
5. **Vanishing thickness**: `d = 1e-9 µm` gives `T -> 1`, `R -> 5e-17`.
6. **Thick-slab Beer–Lambert**: with `kappa = 0.08 + 0.03i`, the transmission
   ratio between `d = 2 µm` and `d = 4 µm` for positive helicity is 9.63,
   against `exp(2 k0 Im(n_+) * 2 µm) = 9.82` from the bulk decay alone (the
   residual difference is the interface/Fabry–Perot contribution).
7. **Dichroism sign**: `kappa = 0.08 + 0.03i` at 0.55 µm yields
   `T = (0.8219, 0.9513)` and `A = (0.1743, 0.0449)`, i.e. the positive helicity
   — the one with the larger `Im(n_+) = Im(n) + Im(kappa)` — is absorbed more,
   confirming the helicity ordering of the output columns.

No finite differences or derivatives are involved in this task.
