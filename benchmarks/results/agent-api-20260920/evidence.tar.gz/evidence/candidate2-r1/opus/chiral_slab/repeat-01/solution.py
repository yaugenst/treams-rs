"""Normal-incidence power balance of a homogeneous reciprocal chiral slab.

The slab is normal to z, bounded by vacuum on both sides, and illuminated from
the negative side (propagation along +z).  For each vacuum wavelength the
transmitted, reflected and absorbed power fractions are returned for positive
and negative helicity illumination, using treams-rs for the electromagnetic
solution.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _complex(value: Any) -> complex:
    """Accept a scalar or a [real, imag] pair and return a complex number."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"expected a scalar or [real, imag] pair, got {value!r}")
    return complex(value)


def run(config: dict) -> dict:
    thickness = float(config["thickness"])
    epsilon = _complex(config["epsilon"])
    mu = _complex(config.get("mu", 1.0))
    kappa = _complex(config.get("kappa", 0.0))
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]

    material = tr.Material(epsilon, mu, kappa)
    # Normal incidence: a single transverse wavevector (kx, ky) = (0, 0).
    # The default basis holds both helicity channels, ordered (pol=1, pol=0),
    # i.e. positive helicity first, negative helicity second.
    basis = tr.PlaneWavePorts.default([0.0, 0.0])
    illuminations = [[1.0, 0.0], [0.0, 1.0]]  # positive, then negative helicity

    transmission, reflection, absorption = [], [], []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        smat = tr.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1,  # vacuum below the slab
            positive_medium=1,  # vacuum above the slab
            polarization="helicity",
        )
        # side="negative": the wave is incident from z < 0 and travels toward +z.
        balance = [smat.power(illu, side="negative") for illu in illuminations]
        transmission.append([float(b.transmission) for b in balance])
        reflection.append([float(b.reflection) for b in balance])
        absorption.append([float(b.absorption) for b in balance])

    return {
        "wavelengths": wavelengths,
        "helicity_order": ["positive", "negative"],
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
