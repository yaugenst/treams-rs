# Dimer near-field intensity and its separation sensitivity

## Problem

Two identical spheres are centred at `x = -separation/2` and `x = +separation/2`
(y = z = 0) in vacuum, illuminated by a positive-helicity plane wave travelling
along `+z`. At a fixed observation point,

    value = sum_i |E_total,i|^2 ,   E_total = E_incident + E_scattered ,

with the scattered field obtained from the fully coupled two-sphere problem
(multiple scattering included). The reported gradient is `d(value)/d(separation)`;
both sphere centres move with the separation, while point, wavelength, radii,
material and `lmax` are fixed.

## Units and conventions

* Lengths (`radius`, `separation`, `wavelength`, `point`) are in micrometres.
  The vacuum angular wavenumber is `k0 = 2*pi/wavelength` in 1/µm
  (example: `k0 = 8.72664626 µm^-1`).
* `epsilon = [real, imag]` is the relative permittivity of the spheres;
  a positive imaginary part is passive loss (treams-rs convention). `mu = 1`,
  `kappa = 0`, exterior is vacuum (`epsilon = 1`).
* The incident plane wave has unit amplitude, so `sum|E_inc|^2 = 1` exactly at
  any point (verified below); `value` is therefore dimensionless intensity
  normalised to the incident field, and `gradient` has units of 1/µm.
* `sum(abs(E)**2)` runs over the three Cartesian components of the complex
  field at the single observation point.
* Multipole truncation is `lmax` per sphere (helicity basis).

## Method

`treams_rs.advect` (the installed Advect adapter over the Rust core) is used
throughout:

1. `tr.sphere_tmatrix(k0, lmax, radius, material=tr.Material(epsilon))` — Mie
   T-matrix of one sphere.
2. `tr.Cluster([sphere, sphere], positions=...)` with the positions built from
   the traced `separation` via `advect.numpy.stack`, then `.scatter(incident)`,
   which solves the coupled system (multiple scattering) and returns the
   outgoing multipole wave.
3. `incident.efield(points) + scattered.efield(points)` gives the total field;
   the objective is its squared modulus summed over components.
4. `advect.value_and_grad(objective)(separation)` returns value and the analytic
   reverse-mode derivative through the native pullbacks (geometry/translation,
   cluster solve and field evaluation). No finite differences enter the returned
   gradient.

## Results (example config)

| quantity | value |
|---|---|
| value | 1.1855506354526988 |
| gradient d(value)/d(separation) | -0.40372542061712435 µm^-1 |

Saved in `results.json`.

## Checks

* **Finite-difference validation only** (not used for the answer): central
  differences of `value` in `separation` give −0.4037265 (h=1e-3),
  −0.40372543 (h=1e-4), −0.403725421 (h=1e-5) against the analytic
  −0.403725421 — agreement improving as O(h^2) to ~1e-10.
* A second, unrelated config (radius 0.15, epsilon 9+0.5j, separation 0.55,
  wavelength 1.1, lmax 3, point (−0.2, 0.3, −0.4)) reproduces its analytic
  gradient −0.0332604568 vs. FD −0.0332604569.
* **Incident normalisation**: `sum|E_inc|^2 = 1.0000000000000004`.
* **Multiple scattering is active**: switching the coupling off (summing two
  isolated single-sphere scattered fields) changes the value from 1.18555 to
  1.19410, so the coupled solve is genuinely used.
* **Truncation**: value/gradient at lmax = 2, 3, 4, 5 are
  (1.1855506, −0.403725), (1.1855316, −0.403250), (1.1855313, −0.403268),
  (1.1855313, −0.403269) — converged to ~1e-5 already at lmax = 2; the reported
  numbers use the requested `lmax` from the config.
* The plain NumPy `treams_rs` namespace reproduces the traced value exactly
  (1.1855506354526988), confirming tracing does not alter the physics.

## Usage

```
python solution.py < config.json > results.json
```

`run(config)` returns the dictionary with `value`, `gradient` and an echo of the
resolved inputs (`k0`, `sphere_positions`, …) for traceability.
