"""Sensitivity of the total near-field intensity of a sphere dimer to its separation.

Two identical spheres sit at x = -separation/2 and x = +separation/2, illuminated
by a positive-helicity plane wave travelling along +z. The scattered field is
computed with full multiple scattering (treams-rs ``Cluster``), and

    value = sum(|E_total|^2)  at the fixed observation point,

with E_total = E_incident + E_scattered. The gradient d(value)/d(separation) is
obtained by reverse-mode analytic differentiation (Advect + native treams-rs
pullbacks); the sphere positions depend on the traced separation.
"""

from __future__ import annotations

import json
import sys

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _objective(separation, *, k0, lmax, radius, epsilon, point):
    """Total |E|^2 at ``point`` as a differentiable function of ``separation``."""
    half = separation / 2.0
    zero = 0.0 * half  # keep the traced dtype/structure for the fixed components
    positions = anp.stack(
        [
            anp.stack([-half, zero, zero]),
            anp.stack([half, zero, zero]),
        ]
    )

    material = tr.Material(epsilon=epsilon)
    sphere = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=material
    )
    incident = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)

    cluster = tr.Cluster([sphere, sphere], positions=positions)
    scattered = cluster.scatter(incident)

    points = anp.asarray([point])
    total = incident.efield(points) + scattered.efield(points)
    return anp.sum(anp.real(total) ** 2 + anp.imag(total) ** 2)


def run(config):
    radius = float(config["radius"])
    eps_re, eps_im = (float(v) for v in config["epsilon"])
    epsilon = complex(eps_re, eps_im)
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = [float(v) for v in config["point"]]

    k0 = 2.0 * anp.pi / wavelength

    def objective(sep):
        return _objective(
            sep, k0=k0, lmax=lmax, radius=radius, epsilon=epsilon, point=point
        )

    value, gradient = ad.value_and_grad(objective)(separation)

    return {
        "value": float(value),
        "gradient": float(gradient),
        "separation": separation,
        "wavelength": wavelength,
        "k0": float(k0),
        "radius": radius,
        "epsilon": [eps_re, eps_im],
        "lmax": lmax,
        "point": point,
        "sphere_positions": [
            [-separation / 2.0, 0.0, 0.0],
            [separation / 2.0, 0.0, 0.0],
        ],
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
