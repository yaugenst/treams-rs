"""Infer a lossless sphere radius from target scattering efficiencies.

The forward model is the Mie (T-matrix) response of a homogeneous sphere in
vacuum, evaluated with treams-rs.  Radius gradients of the relative-error loss
come from treams-rs' native pullbacks through the Advect adapter.
"""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import numpy as np

import advect as ad
import treams_rs.advect as tr

MAX_ITERATIONS = 200
LOSS_TOLERANCE = 1e-12  # stop the local descent once the fit is essentially exact
TARGET_LOSS = 1e-9      # below this no global safeguard scan is needed
STEP_TOLERANCE = 1e-14
MAX_SCAN_POINTS = 1200


def _efficiencies(radius, wavelengths, epsilon, lmax):
    """Scattering efficiencies Q_sca = C_sca / (pi r^2), one per wavelength.

    Works both untraced (plain floats) and inside an Advect trace.
    """
    out = []
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon, medium=1.0
        )
        wave = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
        c_sca = sphere.cross_sections(wave).scattering
        out.append(c_sca / (math.pi * radius * radius))
    return out


def _make_loss(wavelengths, epsilon, lmax, targets):
    def loss(radius):
        total = 0.0
        for q, target in zip(_efficiencies(radius, wavelengths, epsilon, lmax), targets):
            total = total + ((q - target) / target) ** 2
        return total / len(targets)

    return loss


def _descend(value_and_grad, radius, lo, hi):
    """Projected gradient descent with Armijo backtracking and BB steps."""
    value, grad = (float(x) for x in value_and_grad(radius))
    history = [value]
    step = None

    for _ in range(MAX_ITERATIONS):
        if value < LOSS_TOLERANCE or grad == 0.0:
            break
        if step is None:
            # First step: scale so the linear model would remove the loss.
            step = value / (grad * grad)
        accepted = False
        for _ in range(60):
            trial_r = min(max(radius - step * grad, lo), hi)
            actual = trial_r - radius
            if abs(actual) < STEP_TOLERANCE:
                break
            trial_v, trial_g = (float(x) for x in value_and_grad(trial_r))
            if trial_v <= value + 1e-4 * grad * actual:
                dg = trial_g - grad
                step = abs(actual / dg) if dg != 0.0 else step  # Barzilai-Borwein
                radius, value, grad = trial_r, trial_v, trial_g
                history.append(value)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    return radius, value, grad, history


def _scan_starts(loss_fn, lo, hi, wavelengths, epsilon):
    """Coarse sweep of the bounds, returning candidate restart radii.

    The sampling resolves the Mie oscillations: the size parameter inside the
    sphere, x = 2*pi*r*sqrt(epsilon)/lambda, advances by at most ~0.1 per point.
    """
    span = 2.0 * math.pi * (hi - lo) * math.sqrt(abs(epsilon)) / min(wavelengths)
    n = int(min(MAX_SCAN_POINTS, max(64, 10.0 * span)))
    grid = [lo + (hi - lo) * i / (n - 1) for i in range(n)]
    values = [float(loss_fn(r)) for r in grid]
    # Keep interior local minima of the sampled curve, plus the endpoints.
    candidates = [0, n - 1]
    candidates += [i for i in range(1, n - 1)
                   if values[i] <= values[i - 1] and values[i] <= values[i + 1]]
    candidates.sort(key=lambda i: values[i])
    return [grid[i] for i in candidates]


def run(config: dict[str, Any]) -> dict[str, Any]:
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    targets = [float(t) for t in config["target_efficiencies"]]
    lo, hi = (float(b) for b in config["bounds"])
    start = min(max(float(config["initial_radius"]), lo), hi)

    loss_fn = _make_loss(wavelengths, epsilon, lmax, targets)
    value_and_grad = ad.value_and_grad(loss_fn)

    # Local descent from the requested starting radius.
    radius, value, grad, history = _descend(value_and_grad, start, lo, hi)
    initial_loss = history[0]

    # Safeguard: the relative-error loss is strongly non-convex in the radius,
    # so if the local run did not reach the target, restart from the best
    # minima of a coarse sweep of the bounds.
    if value >= TARGET_LOSS:
        for restart in _scan_starts(loss_fn, lo, hi, wavelengths, epsilon):
            r2, v2, g2, h2 = _descend(value_and_grad, restart, lo, hi)
            if v2 < value:
                radius, value, grad = r2, v2, g2
                history += [h for h in h2 if h < history[-1]]
            if value < TARGET_LOSS:
                break

    fitted = [float(q) for q in _efficiencies(radius, wavelengths, epsilon, lmax)]

    return {
        "radius": radius,
        "loss": value,
        "initial_loss": initial_loss,
        "gradient": grad,
        "fitted_efficiencies": fitted,
        "loss_history": history,
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
