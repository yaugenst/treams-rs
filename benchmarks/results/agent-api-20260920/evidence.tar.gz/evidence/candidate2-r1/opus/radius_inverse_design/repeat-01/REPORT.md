# Sphere radius inverse design from scattering efficiencies

## Problem

Given target scattering efficiencies `Q_target(λ_i)` measured at several vacuum
wavelengths, recover the radius of a homogeneous, lossless sphere of fixed
relative permittivity `epsilon` (μ = 1, κ = 0) in vacuum, at fixed multipole
cutoff `lmax`, by minimizing

    L(r) = mean_i ( (Q_i(r) - Q_target,i) / Q_target,i )^2

over `r` restricted to `bounds`.

## Units and conventions

* All lengths are in micrometers: `wavelengths`, `initial_radius`, `bounds` and
  the returned `radius`. `epsilon`, `mu`, `kappa` are relative/dimensionless.
* `k0 = 2π / λ_vac` (µm⁻¹), matching treams-rs' convention that `radius` and
  `1/k0` share a length unit.
* Cross sections from treams-rs are areas in µm². The scattering **efficiency**
  is the standard geometric-cross-section normalization
  `Q_sca = C_sca / (π r²)` — dimensionless.
* The sphere is illuminated by a unit plane wave along +z of positive helicity.
  For an isotropic sphere `C_sca` is independent of incidence direction and
  polarization, so this equals the orientation/polarization average
  (`xs_sca_avg`); this was checked numerically.
* The exterior is vacuum (`medium=1`). Since `epsilon` is real and positive the
  particle is lossless, so extinction equals scattering (verified: the two agree
  to ~1e-16 relative).
* `gradient` is `dL/dr` in µm⁻¹, evaluated at the returned radius.

## Method

* **Forward model**: `treams_rs.advect.sphere_tmatrix` (Mie T-matrix, helicity
  basis) and `.cross_sections(plane_wave(...)).scattering`. No scattering
  physics is reimplemented.
* **Derivatives**: analytic, via treams-rs' native Rust pullbacks exposed
  through the Advect adapter — `advect.value_and_grad(loss)(radius)` returns the
  loss and `dL/dr` in one reverse pass. Finite differences appear nowhere in the
  optimizer; they were used only as an external check (see below).
* **Optimizer**: projected gradient descent starting at `initial_radius`, with
  Armijo backtracking and Barzilai–Borwein step sizes, iterates clipped to
  `bounds`. The first trial step is scaled so the linear model would remove the
  current loss.
* **Global safeguard**: `L(r)` is strongly non-convex (Mie resonances), so if the
  descent from `initial_radius` stalls above `1e-9` the code sweeps the bounds on
  a grid fine enough to resolve the internal size parameter
  (`Δ(2πr√ε/λ_min) ≲ 0.1`), and restarts the same gradient-based descent from the
  sampled local minima, best first. Grid values are forward evaluations only;
  every optimization step still uses analytic gradients. For the example config
  this safeguard is never triggered.
* `loss_history` is the sequence of accepted (monotonically decreasing) loss
  values, beginning with the loss at `initial_radius` (= `initial_loss`).

## Result for the example config

| quantity | value |
|---|---|
| radius | 0.1100000029 µm |
| initial_loss | 6.2153e-01 |
| final loss | 1.14e-14 (requirement: < 1e-7) |
| gradient dL/dr | 7.82e-06 µm⁻¹ |
| fitted Q | 1.5627983, 0.8019216, 0.4253872 |

Relative deviation from each target is ≈1.1e-7; the radius lies strictly inside
`[0.06, 0.14]`. Full output is in `results.json`.

## Checks performed

* **Gradient**: analytic gradient vs. central finite differences, at the start
  point −18.552369192760 (analytic) vs −18.552369193126 (FD, h=1e-7), and again
  at the solution (7.8233e-06 vs 7.8237e-06). Agreement to the FD noise floor.
* **Stationarity / bounds**: final gradient ≈ 0 and the solution is interior, so
  it is a genuine minimum rather than a clipped bound.
* **Round trips**: targets synthesized from known radii were recovered to
  ≲1e-6 µm with loss ≲1e-12 for `epsilon` ∈ {2.25, 3, 4, 6, 9, 12}, `lmax` ∈
  {2…6}, 2–4 wavelengths, wide bounds and deliberately adversarial starting
  radii (at a bound, and on the far side of resonances).
* **Inconsistent targets**: with perturbed targets that no single radius can
  match, the optimizer converges to a stationary point (|dL/dr| ~ 1e-13) with a
  residual loss ~7e-4; the bounds sweep confirms it is the global minimum. Nothing
  about the example answer is hard-coded.

## Usage

```
python solution.py < config.json > results.json
```

`run(config)` returns a JSON-serializable dict with `radius`, `loss`,
`initial_loss`, `gradient`, `fitted_efficiencies` and `loss_history`.
