# Scattering cross widths of an infinite cylinder (treams-rs)

## Problem

A homogeneous, infinitely long circular cylinder whose axis is the z axis is
illuminated by a plane wave travelling along **+x** (normal incidence, axial
wavenumber `kz = 0`) with **positive helicity**. For each wavelength the
scattering, extinction and absorption **cross widths** are returned.

## Files

- `solution.py` — `run(config) -> dict`; CLI reads one JSON config on stdin and
  prints the result dict as JSON on stdout.
- `results.json` — output for the example config.
- `checks.py` — validation script (not part of the API).

Run: `echo '{...}' | python solution.py`

## Units and conventions

- **Lengths** (`radius`, `wavelengths`) are in micrometers. The vacuum angular
  wavenumber is `k0 = 2*pi/wavelength` [1/um].
- **Cross widths** are cross sections per unit cylinder length, so they have
  units of **length (um)**. No sphere-area (`pi r^2`) or any other
  normalization is applied — the raw widths from
  `CylindricalTMatrix.cross_widths` are reported.
- `epsilon` is given as `[real, imag]` and is relative/dimensionless. treams
  uses the `exp(-i omega t)` convention, so a **positive imaginary part means
  loss** (verified: `Im(eps) > 0` gives absorption > 0, `Im(eps) < 0` gives
  absorption < 0).
- Defaults: `mu = 1`, `chirality = 0`, exterior = vacuum. These can be
  overridden with optional keys `mu`, `chirality`, `epsilon_host`, `mu_host`,
  `chirality_host`; they are not required.
- `mmax` is the azimuthal cutoff: cylindrical multipole orders
  `m = -mmax ... mmax` (both helicity channels, single `kz = 0` slice).
- Cross widths are independent of the incident amplitude normalization
  (they are ratios to the incident flux), and for `kz = 0` they are also
  independent of the in-plane propagation direction.

## Method

`treams_rs.cylinder_tmatrix(k0=..., kz=[0.0], mmax=..., radius=...,
material=Material(eps, mu, kappa), medium=..., polarization="helicity")`
builds the cylindrical T-matrix of the homogeneous cylinder.
`treams_rs.plane_wave(direction=[1,0,0], polarization="positive_helicity",
k0=k0, material=medium)` defines the illumination, and
`tmat.cross_widths(illumination)` returns the named
scattering / extinction / absorption widths. All numerics come from
treams-rs; nothing is reimplemented.

## Results for the example config

radius = 0.08 um, epsilon = 5 + 0.1i, mmax = 4:

| lambda (um) | sigma_sca (um) | sigma_ext (um) | sigma_abs (um) |
|---|---|---|---|
| 0.50 | 0.5330353956 | 0.5611064991 | 0.0280711035 |
| 0.65 | 0.2585917234 | 0.2695397227 | 0.0109479993 |
| 0.80 | 0.2407417379 | 0.2488644544 | 0.0081227166 |

## Checks (`checks.py`)

1. **Energy balance**: `ext - sca - abs = 0` exactly (0.0 residual).
2. **Lossless limit**: `Im(eps) = 0` gives absorption `1e-16` (numerical zero).
3. **Empty scatterer**: `eps = 1` gives scattering and extinction `~1e-17`.
4. **Cutoff convergence**: sigma_sca at 0.5 um is 0.5330353947 (mmax=3),
   0.5330353956 (mmax=4), and identical to 13 digits for mmax = 6 and 10, so
   the requested `mmax = 4` is converged to ~1e-9 relative here.
5. **Independent power integration**: the time-averaged Poynting flux of the
   scattered field, integrated over a circle of radius 3 um using
   `scatter(...).efield/hfield`, gives sigma_sca = 0.5330353956 and (from the
   scattered-incident interference term) sigma_ext = 0.5611064991 — agreeing
   with the library values to ~1e-15. This is an independent confirmation of
   both the magnitude and the length units of the reported widths.
6. **Direction invariance**: illuminating along +y reproduces the same widths.

Finite differences were not needed; no derivatives are requested by this task.
