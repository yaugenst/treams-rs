"""Scattering by a homogeneous infinite circular cylinder parallel to z.

Normal incidence (kz = 0), positive-helicity plane wave travelling along +x.
Cross widths (length units, micrometers) are computed with treams-rs.
"""

from __future__ import annotations

import json
import sys
from typing import Any, Dict

import numpy as np
import treams_rs as tr


def _complex(value: Any) -> complex:
    """Accept a scalar, a [real, imag] pair or a complex-looking string."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return complex(value[0])
        if len(value) == 2:
            return complex(float(value[0]), float(value[1]))
        raise ValueError(f"expected scalar or [real, imag], got {value!r}")
    if isinstance(value, dict):
        return complex(float(value.get("real", 0.0)), float(value.get("imag", 0.0)))
    return complex(value)


def _pair(value: complex) -> list:
    return [value.real, value.imag]


def run(config: Dict[str, Any]) -> Dict[str, Any]:
    radius = float(config["radius"])
    mmax = int(config["mmax"])
    wavelengths = [float(w) for w in np.atleast_1d(config["wavelengths"])]

    # Cylinder material: relative, dimensionless. Loss is a positive imaginary
    # part of epsilon in the exp(-i omega t) convention used by treams.
    mat_eps = _complex(config.get("epsilon", 1.0))
    mat_mu = _complex(config.get("mu", 1.0))
    mat_kappa = _complex(config.get("chirality", 0.0))
    material = tr.Material(mat_eps, mat_mu, mat_kappa)
    # Exterior: vacuum unless overridden.
    med_eps = _complex(config.get("epsilon_host", config.get("medium_epsilon", 1.0)))
    med_mu = _complex(config.get("mu_host", config.get("medium_mu", 1.0)))
    med_kappa = _complex(
        config.get("chirality_host", config.get("medium_chirality", 0.0))
    )
    medium = tr.Material(med_eps, med_mu, med_kappa)

    scattering, extinction, absorption = [], [], []
    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl  # vacuum angular wavenumber, 1/um
        tmat = tr.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],  # normal incidence
            mmax=mmax,
            radius=radius,
            material=material,
            medium=medium,
            polarization="helicity",
        )
        illumination = tr.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
            material=medium,
        )
        xw = tmat.cross_widths(illumination)
        scattering.append(float(xw.scattering))
        extinction.append(float(xw.extinction))
        absorption.append(float(xw.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering_cross_width": scattering,
        "extinction_cross_width": extinction,
        "absorption_cross_width": absorption,
        "units": {
            "wavelengths": "um",
            "cross_widths": "um (cross section per unit cylinder length)",
        },
        "setup": {
            "geometry": "homogeneous infinite circular cylinder along z",
            "radius_um": radius,
            "kz": 0.0,
            "incidence": "+x, normal to the cylinder axis",
            "polarization": "positive helicity",
            "mmax": mmax,
            "epsilon": _pair(mat_eps),
            "mu": _pair(mat_mu),
            "chirality": _pair(mat_kappa),
            "medium_epsilon": _pair(med_eps),
            "normalization": "no sphere-area normalization applied",
        },
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
