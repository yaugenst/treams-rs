"""Thickness optimisation of a single lossless antireflection coating.

Geometry (all lengths in micrometers):

    vacuum (eps = 1)  --->  coating (eps, thickness d)  --->  substrate

A plane wave travels along +z, i.e. it hits the coating from the vacuum
("negative") side and there is no vacuum gap between coating and substrate.
The scattering matrix and the analytic derivative dR/dd come from treams-rs
(``treams_rs.advect``, native Rust pullbacks driven by Advect).
"""

from __future__ import annotations

import json
import sys

import advect as ad
import numpy as np
import treams_rs.advect as tr

TARGET = 1e-7
MAX_ITER = 400


def _reflection_fn(k0, epsilon, substrate_epsilon):
    """Return R(d), the reflected power fraction for +z incidence."""
    basis = tr.PlaneWavePorts.default([0.0, 0.0])  # normal incidence channels

    def reflection(thickness):
        smat = tr.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        # incident = both helicity channels from the negative (vacuum) side
        return smat.power([0, 1], side="negative").reflection

    return reflection


def _descend(value_and_grad, d0, lo, hi, history):
    """Projected gradient descent with backtracking / expanding line search."""
    d = float(min(max(d0, lo), hi))
    f, g = value_and_grad(d)
    f, g = float(f), float(g)
    history.append(f)
    step = 0.1 * (hi - lo) / max(abs(g), 1e-12)

    for _ in range(MAX_ITER):
        if f < 1e-14 or abs(g) < 1e-14:
            break
        accepted = False
        for _ in range(60):
            cand = float(min(max(d - step * g, lo), hi))
            if cand == d:
                break
            fc, gc = value_and_grad(cand)
            fc, gc = float(fc), float(gc)
            if fc < f:
                d, f, g = cand, fc, gc
                history.append(f)
                step *= 2.0
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break
    return d, f, g


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    d0 = float(config["initial_thickness"])
    lo, hi = (float(b) for b in config["bounds"])
    if lo > hi:
        lo, hi = hi, lo

    k0 = 2.0 * np.pi / wavelength  # vacuum wavenumber, 1/um
    reflection = _reflection_fn(k0, epsilon, substrate_epsilon)
    vg = ad.value_and_grad(reflection)

    initial_reflection = float(reflection(float(min(max(d0, lo), hi))))

    history: list[float] = []
    d, f, g = _descend(vg, d0, lo, hi, history)

    # If the descent from the requested start stalls in a local minimum above
    # the target, restart the same analytic-gradient descent from other points
    # of the allowed interval and keep the best result.
    if f >= TARGET:
        for frac in np.linspace(0.05, 0.95, 19):
            start = lo + frac * (hi - lo)
            dr, fr, gr = _descend(vg, start, lo, hi, history)
            if fr < f:
                d, f, g = dr, fr, gr
            if f < TARGET:
                break

    return {
        "thickness": float(d),
        "reflection": float(f),
        "initial_reflection": initial_reflection,
        "gradient": float(g),
        "loss_history": [float(x) for x in history],
        "wavelength": wavelength,
        "bounds": [lo, hi],
        "target_reflection": TARGET,
        "target_met": bool(f < TARGET),
        "iterations": len(history) - 1,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
