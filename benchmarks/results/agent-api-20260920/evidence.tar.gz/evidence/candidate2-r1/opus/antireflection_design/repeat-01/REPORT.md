# Single-layer antireflection coating: analytic-gradient thickness optimisation

## Problem and conventions

A plane wave propagates along **+z** from vacuum, hits one homogeneous lossless
coating of relative permittivity `epsilon` and thickness `d`, and enters a
semi-infinite substrate of relative permittivity `substrate_epsilon`. There is
no vacuum gap: the coating is in direct contact with the substrate.

* Lengths (`wavelength`, `initial_thickness`, `bounds`, `thickness`) are in **micrometers**.
* `epsilon`, `substrate_epsilon` are **relative and dimensionless**; `mu = 1`, `kappa = 0`.
* The vacuum wavenumber passed to treams-rs is `k0 = 2*pi/wavelength` (1/um).
* Incidence is normal: the plane-wave basis is
  `PlaneWavePorts.default([0, 0])` (zero transverse wavevector, both helicity channels).
* `reflection` is the **reflected power fraction** `R` (0…1), taken from
  `SMatrix.power([0, 1], side="negative").reflection`, i.e. illumination from
  the negative (vacuum) side, consistent with +z propagation. Since both media
  and the coating are lossless and real, `R + T = 1` and absorption is 0.
* `gradient` is `dR/d(thickness)` in units of 1/um, evaluated at the returned
  thickness.

## Method

`treams_rs.advect.slab` builds the S-matrix of the layer with
`negative_medium = 1.0` (vacuum) and `positive_medium = substrate_epsilon`.
The objective `R(d)` is differentiated with `advect.value_and_grad`, which
uses treams-rs' native Rust pullbacks — no finite differences and no
closed-form Fresnel reimplementation enter the optimisation.

The optimiser is **projected gradient descent** on `R(d)` starting at
`initial_thickness`: each iteration takes `d <- clip(d - step * dR/dd, lo, hi)`
with a backtracking line search (step halved until the loss decreases, doubled
after every accepted step). It stops when the gradient or the loss becomes
numerically negligible, or the line search can no longer make progress.
`loss_history` lists `R` at the start and after every accepted step.

If the descent from `initial_thickness` stalls above the 1e-7 target (a local
minimum, or a stationary starting point such as a half-wave maximum where the
gradient vanishes), the *same* analytic-gradient descent is restarted from a
grid of points inside `bounds` and the best result is kept; those iterations
are appended to `loss_history`. No closed-form quarter-wave value is ever
substituted for the optimisation.

## Example result (`results.json`)

Config: `wavelength = 0.7`, `epsilon = 2.25`, `substrate_epsilon = 5.0625`,
`initial_thickness = 0.05`, `bounds = [0.025, 0.21]`.

| quantity | value |
| --- | --- |
| initial reflection | 9.594027e-02 |
| final reflection | 1.892e-15 (target < 1e-7 met) |
| thickness | 0.11666666 um |
| final dR/dthickness | -4.88e-07 1/um |
| accepted iterations | 12 |

## Checks

* **Gradient validation** (finite differences used only as a check, never to
  drive the optimisation): central differences with `h = 1e-6` um agree with
  the analytic gradient to ~10 significant digits at the returned thickness,
  and to 9+ digits at the starting point (-1.8625904 vs -1.8625904 1/um).
* **Physics check**: the converged thickness equals the quarter-wave value
  `lambda / (4*sqrt(epsilon)) = 0.1166667` um, and with
  `sqrt(epsilon) = 1.5 = sqrt(sqrt(substrate_epsilon))^2` the index-matching
  condition `n_coat^2 = n_sub` holds, so `R -> 0` exactly; the optimiser finds
  `R ~ 1e-15` (double-precision floor).
* **Gradient at the optimum** is ~5e-7, i.e. zero to within the achievable
  precision of a quadratic minimum reached to `R ~ 1e-15`.
* **Energy balance**: `transmission + reflection = 1` within 1e-15 for the
  lossless stack.
* **Other configs** were run to confirm no hard-coding: e.g.
  `wavelength = 1.55, epsilon = 2, substrate_epsilon = 4` converges to
  0.274004 um (= lambda/(4n)) with `R = 3.2e-15`; a mismatched case
  (`epsilon = 2`, `substrate_epsilon = 12.25`) correctly converges to the
  quarter-wave point but plateaus at the physically minimal
  `R = ((n^2 - n_s)/(n^2 + n_s))^2 = 7.44e-2`, and the output then reports
  `target_met = false` rather than claiming success. Bounds are respected: a
  narrow interval returns the constrained optimum at the bound.

## Usage

```
python solution.py < config.json > results.json
```
`run(config)` returns the same dictionary (JSON-serialisable): `thickness`,
`reflection`, `initial_reflection`, `gradient`, `loss_history`, plus
`wavelength`, `bounds`, `target_reflection`, `target_met`, `iterations`.
