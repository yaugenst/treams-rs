# Scattering efficiency of a lossy sphere and its analytic sensitivities

## Problem

A homogeneous sphere of radius `radius` and relative permittivity
`epsilon = epsilon_real + 1j*epsilon_imag` (mu = 1, kappa = 0) sits in vacuum and is
illuminated by a positive-helicity plane wave propagating along +z. We report

    Q = sigma_sca / (pi * radius**2)

and `gradient = [dQ/dradius, dQ/depsilon_real]`, with `epsilon_imag`, `wavelength`
and `lmax` held fixed.

## Units and conventions

- Lengths in micrometers; `wavelength` is the vacuum wavelength, so the vacuum angular
  wavenumber is `k0 = 2*pi/wavelength` (rad/um) and cross sections come out in um^2.
- Permittivity is relative and dimensionless. Loss is a positive imaginary part
  (`exp(-i omega t)` convention, as in treams); `absorption = extinction - scattering > 0`
  confirms the sign is consistent with a passive material.
- Exterior medium is vacuum (`medium=1.0`), `mu=1`, `kappa=0`.
- Helicity basis with `"positive_helicity"` polarization; incidence direction `[0, 0, 1]`.
- Cross sections use treams-rs' default incident flux `0.5`, which corresponds to a unit
  amplitude plane wave — the normalization for which `sigma` is the usual cross section.
- `lmax` is the fixed multipole cutoff (static, not differentiated).
- Q is dimensionless; `dQ/dradius` has units 1/um, `dQ/depsilon_real` is dimensionless.

## Method

`treams_rs.advect.sphere_tmatrix` builds the Mie T-matrix with traced radius and
permittivity, `treams_rs.advect.plane_wave` builds the illumination, and
`.cross_sections(wave).scattering` gives sigma_sca. The geometric normalization
`1/(pi*radius**2)` is written inside the traced objective, so `radius` enters both the
scattering physics and the normalization and `ad.value_and_grad` differentiates both
contributions in one reverse pass through treams-rs' native pullbacks. No finite
differences and no hand-written Mie code are used to produce the returned numbers.

The complex permittivity is assembled inside the trace as
`epsilon_real + 1j*epsilon_imag`, so only the real part carries a derivative.

## Results for the example config

Config: `radius=0.1`, `epsilon_real=4.0`, `epsilon_imag=0.06`, `wavelength=0.72`, `lmax=3`
(size parameter `k0*radius = 0.8727`).

| quantity | value |
|---|---|
| Q (scattering efficiency) | 0.4633764464342743 |
| dQ/dradius | 18.65367030479629 um^-1 |
| dQ/depsilon_real | 0.1997255464561844 |
| sigma_sca | 0.0145574004 um^2 |
| sigma_ext | 0.0156358052 um^2 |
| sigma_abs | 0.0010784048 um^2 |

Full output is in `results.json`.

## Checks

- **Gradient vs. central finite differences** (`check_gradient.py`, validation only):
  relative error ~1e-11 for dQ/dradius and ~1e-10 for dQ/depsilon_real, both at the
  example config and at a second config (`radius=0.25`, `epsilon_real=2.25`,
  `epsilon_imag=0.3`, `wavelength=0.5`, `lmax=5`).
- **Energy balance**: `extinction - scattering - absorption = 0` exactly, and absorption
  is positive as required for a lossy sphere.
- **Multipole convergence**: Q at the example parameters is 0.46233 (lmax=1), 0.463376
  (lmax=2), 0.4633764464 (lmax=3), 0.4633764465 (lmax>=5), i.e. the requested `lmax=3`
  is converged to ~1e-10 relative. `lmax` is treated as a user input, not overridden.

## Usage

```
python solution.py < config.json          # CLI: JSON dict in, JSON dict out
from solution import run; run(config)     # library use
```
