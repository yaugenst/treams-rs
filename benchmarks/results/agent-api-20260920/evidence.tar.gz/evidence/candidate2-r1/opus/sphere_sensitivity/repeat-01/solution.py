"""Scattering efficiency of a lossy sphere and its analytic sensitivities.

Q = sigma_sca / (pi * radius**2) for a homogeneous sphere with complex
permittivity eps = epsilon_real + 1j*epsilon_imag, illuminated by a
positive-helicity plane wave travelling along +z.  The gradient
[dQ/dradius, dQ/depsilon_real] is obtained from treams-rs' native reverse-mode
pullbacks through the Advect adapter, so the 1/(pi r**2) normalization is
differentiated together with the cross section.
"""

from __future__ import annotations

import json
import math
import sys

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _efficiency(radius, epsilon_real, *, epsilon_imag, k0, lmax):
    """Traceable objective: scattering efficiency of the sphere."""
    epsilon = epsilon_real + 1j * epsilon_imag
    sphere = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=tr.Material(epsilon=epsilon),
        medium=1.0,  # vacuum exterior
    )
    wave = tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0)
    sigma_sca = sphere.cross_sections(wave).scattering
    return sigma_sca / (math.pi * radius * radius)


def run(config):
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    k0 = 2.0 * math.pi / wavelength

    def objective(params):
        return _efficiency(
            params[0], params[1], epsilon_imag=epsilon_imag, k0=k0, lmax=lmax
        )

    params = anp.asarray([radius, epsilon_real])
    value, gradient = ad.value_and_grad(objective)(params)

    # Cross sections and the absorption balance, for context (undifferentiated).
    sphere = tr.sphere_tmatrix(
        k0=k0,
        lmax=lmax,
        radius=radius,
        material=tr.Material(epsilon=epsilon_real + 1j * epsilon_imag),
        medium=1.0,
    )
    xs = sphere.cross_sections(tr.plane_wave([0.0, 0.0, 1.0], "positive_helicity", k0=k0))

    return {
        "value": float(value),
        "gradient": [float(g) for g in gradient],
        "scattering_efficiency": float(value),
        "dQ_dradius": float(gradient[0]),
        "dQ_depsilon_real": float(gradient[1]),
        "scattering_cross_section": float(xs.scattering),
        "extinction_cross_section": float(xs.extinction),
        "absorption_cross_section": float(xs.absorption),
        "extinction_efficiency": float(xs.extinction / (math.pi * radius**2)),
        "absorption_efficiency": float(xs.absorption / (math.pi * radius**2)),
        "k0": k0,
        "size_parameter": k0 * radius,
        "lmax": lmax,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
