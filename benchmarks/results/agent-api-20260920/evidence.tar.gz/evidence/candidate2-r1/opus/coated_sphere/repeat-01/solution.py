"""Core-shell (multilayer) sphere cross-section spectrum via treams-rs.

All lengths are in micrometers; permittivities are relative and dimensionless.
"""

from __future__ import annotations

import json
import sys

import numpy as np
import treams_rs as tr


def _complex(value):
    """Accept [re, im], a real number, or a complex number."""
    if isinstance(value, (list, tuple)):
        re = float(value[0])
        im = float(value[1]) if len(value) > 1 else 0.0
        return complex(re, im)
    if isinstance(value, complex):
        return value
    return complex(float(value), 0.0)


def _material(epsilon, mu=1, kappa=0):
    return tr.Material(_complex(epsilon), _complex(mu), _complex(kappa))


def run(config):
    radii = [float(r) for r in config["radii"]]
    eps_layers = list(config["epsilon_layers"])
    wavelengths = [float(w) for w in config["wavelengths"]]
    lmax = int(config.get("lmax", 4))

    if len(radii) != len(eps_layers):
        raise ValueError("radii and epsilon_layers must have the same length")
    if any(b <= a for a, b in zip(radii, radii[1:])) or radii[0] <= 0:
        raise ValueError("radii must be positive and strictly increasing")

    mu_layers = config.get("mu_layers", [1] * len(radii))
    kappa_layers = config.get("kappa_layers", [0] * len(radii))
    materials = [
        _material(e, m, k) for e, m, k in zip(eps_layers, mu_layers, kappa_layers)
    ]
    medium = _material(
        config.get("epsilon_medium", 1),
        config.get("mu_medium", 1),
        config.get("kappa_medium", 0),
    )

    sca, ext, abs_ = [], [], []
    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl  # vacuum angular wavenumber, 1/um
        tm = tr.multilayer_sphere_tmatrix(
            k0=k0, lmax=lmax, radii=radii, materials=materials, medium=medium
        )
        xs = tm.average_cross_sections  # rotation- and polarization-averaged
        sca.append(float(xs.scattering))
        ext.append(float(xs.extinction))
        abs_.append(float(xs.absorption))

    return {
        "wavelengths": wavelengths,
        "scattering_cross_section": sca,
        "extinction_cross_section": ext,
        "absorption_cross_section": abs_,
        "units": {"length": "um", "cross_section": "um^2"},
        "lmax": lmax,
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
