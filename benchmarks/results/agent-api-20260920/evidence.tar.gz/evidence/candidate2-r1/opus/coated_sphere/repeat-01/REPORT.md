# Core-shell sphere spectrum (treams-rs)

## What is computed
For each wavelength the multilayer (concentric) sphere T-matrix is built with
`treams_rs.multilayer_sphere_tmatrix` and the rotationally and polarization
averaged scattering / extinction / absorption cross sections are read off from
`TMatrix.average_cross_sections`. No Mie code is reimplemented.

## Units and conventions
- Lengths (`radii`, `wavelengths`) in micrometers; cross sections in um^2.
- Vacuum angular wavenumber `k0 = 2*pi/wavelength` (1/um). The wavelength is the
  *vacuum* wavelength; the exterior index enters through `medium`.
- Permittivity/permeability/chirality are relative and dimensionless.
  `epsilon_layers` entries are `[real, imag]`, i.e. `eps = re + 1j*im`, with the
  `exp(-i w t)` convention so a positive imaginary part means loss.
- `radii` are increasing *outer* boundaries of each layer, ordered inside-out;
  `epsilon_layers[i]` is the material of the layer ending at `radii[i]`.
  The exterior (`epsilon_medium`) is passed as `medium` only and is **not**
  appended as a finite layer.
- Defaults: mu = 1, kappa = 0 in every layer and in the exterior; exterior
  vacuum if `epsilon_medium` is absent. Optional `mu_layers`, `kappa_layers`,
  `mu_medium`, `kappa_medium` are honoured if supplied.
- Multipole truncation `lmax` (default 4). Helicity basis internally; the
  averaged cross sections are basis independent.

## Output keys
`wavelengths`, `scattering_cross_section`, `extinction_cross_section`,
`absorption_cross_section` (lists in the input wavelength order, um^2), plus
`units` and `lmax`. Absorption is extinction minus scattering.

## CLI
`python solution.py < config.json > results.json` — reads one config dict from
stdin, writes the result dict as JSON to stdout.

## Checks performed
1. **lmax convergence**: cross sections change by <1e-9 relative between
   lmax = 6 and 8 for the example (size parameter x = 2*pi*n_med*R/lambda ~ 1.7),
   and lmax = 4 is already converged to ~1e-8 absolute in the scattering cross
   section.
2. **Homogeneous limit**: setting both layers to the same permittivity reproduces
   `sphere_tmatrix` for a single 0.12 um sphere to machine precision
   (0.029808583525099040 vs 0.029808583525099033 um^2 at 0.7 um).
3. **Energy consistency**: extinction >= scattering at every wavelength, and with
   purely real permittivities the absorption is zero to ~2e-17 um^2, confirming
   the exterior is treated as lossless and the layer ordering is consistent.

## Example result (config as given)
| lambda (um) | C_sca (um^2) | C_ext (um^2) | C_abs (um^2) |
|---|---|---|---|
| 0.58 | 3.431592e-02 | 3.752383e-02 | 3.207911e-03 |
| 0.70 | 1.891246e-02 | 2.117016e-02 | 2.257697e-03 |
| 0.82 | 1.213568e-02 | 1.390107e-02 | 1.765386e-03 |

Saved in `results.json`.
