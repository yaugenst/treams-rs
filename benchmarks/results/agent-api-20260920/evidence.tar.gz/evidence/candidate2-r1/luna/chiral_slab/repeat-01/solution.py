"""Normal-incidence chiral-slab power calculation using treams-rs."""

from __future__ import annotations

import json
import sys
from numbers import Real

import treams_rs as tr


def _real(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a real number")
    return float(value)


def run(config: dict) -> dict:
    """Return transmission, reflection, and absorption by wavelength/helicity."""
    if not isinstance(config, dict):
        raise ValueError("config must be a dictionary")
    thickness = _real(config["thickness"], "thickness")
    epsilon = config["epsilon"]
    if not isinstance(epsilon, (list, tuple)) or len(epsilon) != 2:
        raise ValueError("epsilon must be [real, imag]")
    eps = complex(_real(epsilon[0], "epsilon[0]"), _real(epsilon[1], "epsilon[1]"))
    kappa = _real(config.get("kappa", 0.0), "kappa")
    wavelengths = config["wavelengths"]
    if not isinstance(wavelengths, (list, tuple)):
        raise ValueError("wavelengths must be a list")

    basis = tr.PlaneWavePorts.default([0.0, 0.0])
    material = tr.Material(epsilon=eps, kappa=kappa)
    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    # Named sources make the requested (+, -) helicity ordering explicit.
    for wavelength_value in wavelengths:
        wavelength = _real(wavelength_value, "wavelength")
        k0 = 2.0 * 3.141592653589793 / wavelength
        network = tr.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            polarization="helicity",
        )
        row_t: list[float] = []
        row_r: list[float] = []
        row_a: list[float] = []
        for helicity in ("positive_helicity", "negative_helicity"):
            incident = tr.plane_wave([0.0, 0.0, 1.0], helicity, k0=k0)
            powers = network.power(incident, side="negative")
            row_t.append(float(powers.transmission))
            row_r.append(float(powers.reflection))
            row_a.append(float(powers.absorption))
        transmission.append(row_t)
        reflection.append(row_r)
        absorption.append(row_a)

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
