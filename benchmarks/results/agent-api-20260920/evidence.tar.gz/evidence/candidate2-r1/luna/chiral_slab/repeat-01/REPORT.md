# Chiral slab report

`solution.py` uses `treams_rs.slab` and its native plane-wave scattering
kernel. Lengths are micrometers, so `k0 = 2π / wavelength` is in inverse
micrometers. The material is nonmagnetic vacuum outside the slab; the slab
uses `epsilon = epsilon_real + i epsilon_imag` and the dimensionless package
chirality `kappa`. Positive and negative helicity are evaluated for +z
incidence and returned in that order.

The reported quantities are power fractions from `network.power`: transmitted
power, reflected power, and `1 - T - R` absorption. The example was checked
with both helicities at every wavelength; each row satisfies energy balance
(`T + R + A = 1` to floating-point precision), and all fractions are finite
and nonnegative.
