# Report

`solution.py` uses `treams_rs.multilayer_sphere_tmatrix` with the supplied
increasing radii and finite-layer permittivities in inside-out order. The
exterior permittivity is passed through `medium`, so it is not added as a
finite layer. Each wavelength uses `k0 = 2*pi/wavelength`.

All lengths are in micrometers, so returned cross sections are square
micrometers. Permittivities are relative and `[real, imag]` means
`real + i*imag`; the installed convention uses positive imaginary part for
passive loss. The reported values are treams-rs rotationally and
polarization-averaged scattering, extinction, and absorption, with absorption
computed by the library as extinction minus scattering.

Checks performed: radii are required to be positive and strictly increasing;
the layer/radius counts must agree; wavelengths and `lmax` are validated; the
CLI output is JSON with finite numeric lists. For the supplied lossy example,
the saved results were checked to have nonnegative scattering and absorption
within numerical precision, and extinction equal to scattering plus
absorption.
