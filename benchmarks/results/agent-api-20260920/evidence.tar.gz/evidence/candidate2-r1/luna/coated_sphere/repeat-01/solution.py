"""Rotationally averaged spectra for concentric multilayer spheres."""

from __future__ import annotations

import json
import sys
from numbers import Real

import treams_rs as tr


def _epsilon(value):
    """Convert a scalar or [real, imag] JSON value to a complex epsilon."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2 or not all(isinstance(x, Real) for x in value):
            raise ValueError("permittivity pairs must be [real, imag]")
        return complex(value[0], value[1])
    if isinstance(value, Real):
        return complex(value)
    raise ValueError("permittivity must be a scalar or [real, imag]")


def run(config):
    """Return rotationally averaged scattering, extinction, and absorption areas."""
    radii = config["radii"]
    layers = config["epsilon_layers"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]
    medium = _epsilon(config["epsilon_medium"])

    if len(radii) != len(layers) or not radii:
        raise ValueError("radii and epsilon_layers must be nonempty and have equal length")
    if radii[0] <= 0 or any(
        radii[i] <= radii[i - 1] for i in range(1, len(radii))
    ):
        raise ValueError("radii must be strictly increasing and positive")
    if not isinstance(lmax, int) or lmax < 1:
        raise ValueError("lmax must be a positive integer")

    scattering = []
    extinction = []
    absorption = []
    for wavelength in wavelengths:
        if not isinstance(wavelength, Real) or wavelength <= 0:
            raise ValueError("wavelengths must be positive numbers")
        sphere = tr.multilayer_sphere_tmatrix(
            k0=2.0 * 3.141592653589793 / wavelength,
            lmax=lmax,
            radii=radii,
            materials=[_epsilon(value) for value in layers],
            medium=medium,
        )
        cross = sphere.average_cross_sections
        scattering.append(float(cross.scattering))
        extinction.append(float(cross.extinction))
        absorption.append(float(cross.absorption))

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
