# Report

`solution.py` uses treams-rs' native `sphere_tmatrix`, `solve_periodic`,
plane-wave ports, slab/propagation layers, and `stack` network.  For each
wavelength it solves the square lattice at Bloch vector `[0, 0]`, retaining
the two helicity channels of the zeroth diffraction order.  The stack is
ordered along +z as slab, vacuum gap, and sphere array, and is illuminated by
positive helicity travelling along +z from the negative-z side.

All lengths use the input unit (micrometres here), with
`k0 = 2*pi/wavelength`; epsilon and the default mu=1 are relative quantities.
Transmission and reflection are the native power fractions normalized to
incident flux.  Absorption is `1 - transmission - reflection`.

The example was executed and its output was saved in `results.json`.
As a check, each wavelength satisfies power conservation to numerical
precision: transmission + reflection + absorption equals one.
