"""Periodic sphere array above a dielectric slab.

The numerical scattering is delegated to treams-rs.  Lengths are in the
user's unit (micrometres for the supplied problem), so the vacuum wave number
is 2*pi/wavelength in the same inverse unit.
"""

import json
import math
import sys

import treams_rs as tr


def run(config):
    """Return wavelength-resolved transmission, reflection and absorption."""
    required = (
        "radius", "sphere_epsilon", "period", "gap", "slab_thickness",
        "slab_epsilon", "wavelengths", "lmax",
    )
    missing = [key for key in required if key not in config]
    if missing:
        raise KeyError("missing config keys: " + ", ".join(missing))

    wavelengths = [float(value) for value in config["wavelengths"]]
    if not wavelengths or any(not math.isfinite(value) or value <= 0 for value in wavelengths):
        raise ValueError("wavelengths must be a nonempty sequence of positive finite values")

    # A single port basis is valid for every wavelength because it stores the
    # transverse wave vector (zero here), not the dimensional k_z.
    ports = tr.PlaneWavePorts.default([0, 0])
    rows = []
    for wavelength in sorted(wavelengths):
        k0 = 2.0 * math.pi / wavelength
        particle = tr.sphere_tmatrix(
            k0=k0,
            lmax=int(config["lmax"]),
            radius=float(config["radius"]),
            material=float(config["sphere_epsilon"]),
        )
        array = tr.solve_periodic(
            particle,
            lattice=tr.Lattice.square(float(config["period"])),
            kpar=[0, 0],
        ).to_smatrix(ports)
        slab = tr.slab(
            basis=ports,
            k0=k0,
            thickness=float(config["slab_thickness"]),
            material=float(config["slab_epsilon"]),
        )
        gap = tr.propagation(
            basis=ports,
            k0=k0,
            distance=float(config["gap"]),
        )
        network = tr.stack([slab, gap, array])
        incident = tr.plane_wave(
            [0, 0, 1], "positive_helicity", k0=k0
        )
        balance = network.power(incident, side="negative")
        transmission = float(balance.transmission)
        reflection = float(balance.reflection)
        absorption = float(1.0 - transmission - reflection)
        # The supplied media are lossless; suppress only roundoff-sized
        # negative residuals so the returned power fraction remains physical.
        if abs(absorption) < 1e-12:
            absorption = 0.0
        rows.append((wavelength, transmission, reflection, absorption))

    return {
        "wavelengths": [row[0] for row in rows],
        "transmission": [row[1] for row in rows],
        "reflection": [row[2] for row in rows],
        "absorption": [row[3] for row in rows],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
