"""Dimer field intensity and analytic separation sensitivity."""

from __future__ import annotations

import json
import sys

import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def run(config: dict) -> dict:
    """Return the total electric-field intensity and d(value)/d(separation)."""
    radius = float(config["radius"])
    epsilon_data = config["epsilon"]
    epsilon = complex(float(epsilon_data[0]), float(epsilon_data[1]))
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = anp.asarray([config["point"]])
    k0 = 2.0 * 3.141592653589793 / wavelength

    def objective(sep):
        particle = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon
        )
        positions = anp.stack(
            (
                anp.asarray([-sep / 2.0, 0.0, 0.0]),
                anp.asarray([sep / 2.0, 0.0, 0.0]),
            )
        )
        cluster = tr.Cluster([particle, particle], positions=positions)
        incident = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity", k0=k0
        )
        total = incident.efield(point) + cluster.scatter(incident).efield(point)
        return anp.sum(anp.real(anp.conj(total) * total))

    value, gradient = ad.value_and_grad(objective)(separation)
    return {"value": float(value), "gradient": float(gradient)}


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
