# Dimer sensitivity report

`run(config)` uses treams-rs' differentiable sphere T-matrix and finite
two-particle `Cluster`, so the scattered field includes all multiple
scattering. The incident plane wave propagates in `+z` and has positive
helicity. The reported field is the total field (incident plus scattered) at
the requested point, with

`value = sum over Cartesian components of |E_total|^2`.

All lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. Epsilon is converted from `[real, imag]`; the exterior has
relative epsilon and permeability one, with zero chirality. The two centers
are `(-separation/2, 0, 0)` and `(separation/2, 0, 0)`.

The gradient is obtained with Advect's native reverse-mode pullback through
the treams-rs cluster interaction and field evaluation. Thus both moving
spheres contribute to `d(value)/d(separation)`; no finite difference is used
to produce it.

For the supplied example, the CLI was executed and its JSON output was saved
in `results.json`. The implementation also checks the analytic result against
a finite-difference estimate during development; that check is validation
only.
