"""Gradient-based antireflection coating optimization using treams-rs."""

import json
import sys

import numpy as np
import advect as ad
import treams_rs.advect as tr


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial = float(config["initial_thickness"])
    lower, upper = (float(v) for v in config["bounds"])
    if wavelength <= 0 or lower < 0 or upper < lower:
        raise ValueError("invalid wavelength or thickness bounds")
    if not lower <= initial <= upper:
        raise ValueError("initial_thickness must lie within bounds")

    k0 = 2.0 * np.pi / wavelength
    ports = tr.PlaneWavePorts.default([0.0, 0.0])

    def reflected_power(thickness):
        system = tr.slab(
            basis=ports,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate_epsilon,
        )
        incident = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0
        )
        return system.power(incident, side="negative").reflection

    value_and_gradient = ad.value_and_grad(reflected_power)
    initial_reflection = float(np.asarray(reflected_power(initial)))
    thickness = initial
    value, gradient = value_and_gradient(thickness)
    value = float(np.asarray(value))
    gradient = float(np.asarray(gradient))
    loss_history = [value]

    # Projected gradient descent with Armijo backtracking.  Every gradient
    # used here is from Advect's native treams-rs pullback.
    for _ in range(200):
        if value < 1.0e-14 and abs(gradient) < 1.0e-9:
            break
        step = min(0.02, 0.25 * (upper - lower))
        accepted = False
        while step > 1.0e-15:
            candidate = min(upper, max(lower, thickness - step * gradient))
            if candidate == thickness:
                break
            candidate_value, candidate_gradient = value_and_gradient(candidate)
            candidate_value = float(np.asarray(candidate_value))
            candidate_gradient = float(np.asarray(candidate_gradient))
            if candidate_value < value - 1.0e-4 * abs(candidate - thickness) * gradient:
                thickness = candidate
                value = candidate_value
                gradient = candidate_gradient
                loss_history.append(value)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    # Refresh the reported derivative at the exact returned thickness.
    value, gradient = value_and_gradient(thickness)
    value = float(np.asarray(value))
    gradient = float(np.asarray(gradient))
    return {
        "thickness": thickness,
        "reflection": value,
        "initial_reflection": initial_reflection,
        "gradient": gradient,
        "loss_history": loss_history,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))
