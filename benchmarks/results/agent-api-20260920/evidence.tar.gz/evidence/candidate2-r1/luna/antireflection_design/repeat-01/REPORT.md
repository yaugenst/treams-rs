# Antireflection coating

`solution.py` models one finite, homogeneous coating with `treams_rs.advect.slab`.
All lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers.  Permittivities are relative and dimensionless; the incident
medium is vacuum (`epsilon=mu=1`), the coating and positive-side substrate use
the supplied permittivities, and `mu=1`, chirality `kappa=0` are implicit.

The normal-incidence basis is the two-helicity plane-wave basis at zero
transverse wavevector.  Incidence is from the negative side along `+z`, and
`reflection` is the incident-normalized reflected power.  The reported
thickness gradient is obtained with Advect's analytic treams-rs pullback, not
finite differences.  Optimization uses projected gradient descent with
Armijo backtracking and the supplied bounds.

Checks performed for the example:

- initial reflected power: approximately `9.5940272752e-2`;
- final thickness: approximately `0.1166666667` micrometers;
- final reflected power: below `1e-14`;
- loss history decreases monotonically from the initial value;
- the returned thickness remains within `[0.025, 0.21]` micrometers.
