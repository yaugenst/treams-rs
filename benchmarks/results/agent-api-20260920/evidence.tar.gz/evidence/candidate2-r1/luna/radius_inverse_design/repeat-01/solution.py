"""Inverse radius design for a homogeneous dielectric sphere."""

import json
import sys
from typing import Any

import advect as ad
import numpy as np
import treams_rs as tr
import treams_rs.advect as atr
import advect.numpy as anp


def _loss_function(epsilon: float, lmax: int, wavelengths: list[float],
                   targets: list[float]):
    """Return an Advect-compatible scalar objective of radius."""
    def objective(radius: Any) -> Any:
        terms = []
        for wavelength, target in zip(wavelengths, targets, strict=True):
            sphere = atr.sphere_tmatrix(
                k0=2.0 * np.pi / wavelength,
                lmax=lmax,
                radius=radius,
                material=epsilon,
            )
            wave = atr.plane_wave(
                [0.0, 0.0, 1.0], "positive_helicity",
                k0=2.0 * np.pi / wavelength,
            )
            # CrossSections.scattering is an area; pi*r^2 is the
            # geometrical cross-sectional area of the sphere.
            efficiency = sphere.cross_sections(wave).scattering / (
                np.pi * radius * radius
            )
            terms.append(((efficiency - target) / target) ** 2)
        return anp.sum(anp.asarray(terms)) / len(terms)
    return objective


def _efficiencies(radius: float, epsilon: float, lmax: int,
                  wavelengths: list[float]) -> list[float]:
    values = []
    for wavelength in wavelengths:
        sphere = tr.sphere_tmatrix(
            k0=2.0 * np.pi / wavelength, lmax=lmax,
            radius=radius, material=epsilon,
        )
        wave = tr.plane_wave(
            [0.0, 0.0, 1.0], "positive_helicity",
            k0=2.0 * np.pi / wavelength,
        )
        values.append(float(sphere.cross_sections(wave).scattering /
                           (np.pi * radius * radius)))
    return values


def run(config: dict[str, Any]) -> dict[str, Any]:
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = [float(x) for x in config["wavelengths"]]
    targets = [float(x) for x in config["target_efficiencies"]]
    initial = float(config["initial_radius"])
    lower, upper = (float(x) for x in config["bounds"])
    if not (0.0 < lower <= initial <= upper):
        raise ValueError("initial_radius must lie inside bounds")
    if len(wavelengths) != len(targets) or not wavelengths:
        raise ValueError("wavelengths and target_efficiencies must be nonempty and equal")
    if any(x <= 0.0 for x in targets):
        raise ValueError("target efficiencies must be positive")

    objective = _loss_function(epsilon, lmax, wavelengths, targets)
    value_grad = ad.value_and_grad(objective)

    def evaluate(radius: float) -> tuple[float, float]:
        value, gradient = value_grad(float(radius))
        return float(np.asarray(value)), float(np.asarray(gradient))

    radius = initial
    loss, gradient = evaluate(radius)
    initial_loss = loss
    history = [loss]

    # Projected, backtracking steepest descent. Every derivative used for
    # the steps below is supplied by Advect's native treams-rs pullbacks.
    for _ in range(1000):
        if loss < 1.0e-12 or abs(gradient) < 1.0e-12:
            break
        direction = -gradient
        step = min(0.25 * (upper - lower), 0.01)
        accepted = False
        while step > 1.0e-14:
            candidate = min(upper, max(lower, radius + step * direction))
            if candidate == radius:
                step *= 0.5
                continue
            candidate_loss, candidate_gradient = evaluate(candidate)
            # Armijo condition, with a projected step if a bound is active.
            displacement = candidate - radius
            if candidate_loss <= loss + 1.0e-4 * gradient * displacement:
                radius, loss, gradient = candidate, candidate_loss, candidate_gradient
                history.append(loss)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            break

    fitted = _efficiencies(radius, epsilon, lmax, wavelengths)
    return {
        "radius": float(radius),
        "loss": float(loss),
        "initial_loss": float(initial_loss),
        "gradient": float(gradient),
        "fitted_efficiencies": fitted,
        "loss_history": [float(x) for x in history],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
