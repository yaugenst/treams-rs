# Radius inverse design

`solution.py` models a homogeneous, nonmagnetic, nonchiral sphere in vacuum
using `treams_rs.sphere_tmatrix` at the requested fixed `lmax`. The input
lengths are in micrometers, so `k0 = 2*pi/wavelength` is in inverse
micrometers. Permittivity is relative and dimensionless.

For each wavelength, the fitted observable is the scattering efficiency
`Q = C_sca / (pi*r^2)`, where `C_sca` is the treams-rs scattering cross
section. The objective is the mean squared relative efficiency residual.

The bounded optimizer uses analytic radius gradients from Advect's native
treams-rs pullbacks with backtracking and projection onto the supplied radius
bounds. The example was executed through the CLI and its output was saved in
`results.json`. Checks include JSON serialization, bound compliance, and
re-evaluation of all fitted efficiencies with the non-differentiated
treams-rs API.
