"""Homogeneous dielectric sphere spectrum using treams-rs."""

from __future__ import annotations

import json
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return cross sections for the requested wavelengths, in input order."""
    radius = float(config["radius"])
    epsilon_parts = config["epsilon"]
    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    wavelengths = [float(value) for value in config["wavelengths"]]
    lmax = int(config["lmax"])

    if radius <= 0 or lmax < 1 or not wavelengths or any(value <= 0 for value in wavelengths):
        raise ValueError("radius and wavelengths must be positive and lmax must be >= 1")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []
    for wavelength in wavelengths:
        k0 = 2.0 * np.pi / wavelength
        sphere = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon, medium=1
        )
        incident = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
            medium=1,
        )
        cross = sphere.cross_sections(incident)
        scattering.append(float(cross.scattering))
        extinction.append(float(cross.extinction))
        absorption.append(float(cross.absorption))

    geometric_area = float(np.pi * radius * radius)
    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": [value / geometric_area for value in scattering],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
