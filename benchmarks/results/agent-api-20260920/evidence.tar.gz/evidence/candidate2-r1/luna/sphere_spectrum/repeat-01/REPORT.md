# Sphere spectrum report

`solution.py` constructs a native `treams_rs.sphere_tmatrix` at each wavelength,
with the requested `lmax`, and illuminates it by a +z plane wave of positive
helicity. The supplied `epsilon` pair is interpreted as relative permittivity
`epsilon' + i epsilon''`; relative permeability is 1, chirality is zero, and
the exterior medium is vacuum. All lengths are in micrometers, so the returned
cross sections are in square micrometers.

The returned lists retain input wavelength order. Scattering, extinction, and
absorption are the native area-valued quantities, with absorption checked by
the package identity `absorption = extinction - scattering`. Efficiency is
`scattering / (pi * radius**2)`. The example run was executed locally and its
JSON output is stored in `results.json`.
