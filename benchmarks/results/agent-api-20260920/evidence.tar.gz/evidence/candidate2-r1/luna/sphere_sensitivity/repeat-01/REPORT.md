# Sphere sensitivity report

`solution.py` uses the public `treams_rs.advect` API.  It constructs a
homogeneous sphere in vacuum, illuminates it with unit-amplitude
positive-helicity propagation along `+z`, and obtains the scattering cross
section from `cross_sections`.  The returned value is

\[
Q = C_{\rm sca}/(\pi r^2).
\]

Lengths are in micrometers, so `k0 = 2 pi / wavelength` is in inverse
micrometers.  Permittivity is relative and complex, with the specified
positive-loss convention `epsilon = epsilon_real + i epsilon_imag`.
Permeability is one, chirality is zero, and the exterior medium is vacuum.
`lmax` is the fixed spherical multipole cutoff.

The gradient is computed by Advect reverse mode and treams-rs native
pullbacks.  The radius dependence of the `pi*r**2` normalization is included
inside the differentiated objective.  As checks, the example was executed
through both `run` and the stdin CLI, and the analytic gradient was compared
with centered finite differences (validation only).
