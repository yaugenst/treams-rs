"""Scattering efficiency and its analytic parameter gradient."""

import json
import sys

import numpy as np
import advect as ad
import advect.numpy as anp
import treams_rs.advect as tr


def _objective(parameters, epsilon_imag, wavelength, lmax):
    radius = parameters[0]
    epsilon_real = parameters[1]
    material = tr.Material(epsilon=epsilon_real + 1j * epsilon_imag)
    particle = tr.sphere_tmatrix(
        k0=2.0 * np.pi / wavelength,
        lmax=lmax,
        radius=radius,
        material=material,
    )
    incident = tr.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=2.0 * np.pi / wavelength
    )
    scattering_cross_section = particle.cross_sections(incident).scattering
    return scattering_cross_section / (np.pi * radius * radius)


def run(config):
    """Return Q and dQ/d(radius, epsilon_real) using native pullbacks."""
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    def objective(parameters):
        return _objective(parameters, epsilon_imag, wavelength, lmax)

    parameters = anp.asarray([radius, epsilon_real])
    value, gradient = ad.value_and_grad(objective)(parameters)
    return {
        "value": float(np.asarray(value)),
        "gradient": [float(x) for x in np.asarray(gradient).reshape(-1)],
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
