"""Infinite-cylinder scattering widths using treams-rs."""

import json
import sys

import treams_rs as tr


def run(config):
    """Return scattering, extinction, and absorption widths for each wavelength."""
    radius = float(config["radius"])
    epsilon = config["epsilon"]
    material = complex(float(epsilon[0]), float(epsilon[1]))
    wavelengths = config["wavelengths"]
    mmax = int(config["mmax"])

    scattering = []
    extinction = []
    absorption = []
    for wavelength in wavelengths:
        k0 = 2.0 * 3.141592653589793 / float(wavelength)
        cylinder = tr.cylinder_tmatrix(
            k0=k0,
            kz=0.0,
            mmax=mmax,
            radius=radius,
            material=material,
        )
        incident = tr.plane_wave(
            direction=[1.0, 0.0, 0.0],
            polarization="positive_helicity",
            k0=k0,
        )
        widths = cylinder.cross_widths(incident)
        s = float(widths.scattering)
        e = float(widths.extinction)
        scattering.append(s)
        extinction.append(e)
        absorption.append(e - s)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    print(json.dumps(run(config), separators=(",", ":")))
