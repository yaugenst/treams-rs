# Infinite-cylinder scattering widths

`solution.py` uses the public `treams_rs.cylinder_tmatrix` and
`cross_widths` APIs.  The cylinder axis is z, `kz=0`, and the incident wave
travels in +x with positive helicity.  The exterior medium is the default
vacuum (`epsilon=mu=1`); the supplied complex epsilon is relative and its
positive imaginary part is treated as passive loss.

All lengths are in micrometers, so wavelengths and radius produce widths in
micrometers.  The returned lists preserve the input wavelength order.  The
absorption width is computed from the energy balance
`absorption = extinction - scattering`; no sphere-area normalization is used.

Checks performed: the example was run through the CLI, and every result is
finite with nonnegative absorption (within numerical precision).  The chosen
cutoff is the requested azimuthal range `-mmax,...,+mmax` supplied to
treams-rs.
