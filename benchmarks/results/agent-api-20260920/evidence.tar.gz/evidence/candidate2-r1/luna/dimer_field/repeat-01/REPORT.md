# Dimer scattering report

`solution.py` uses the public `treams_rs` sphere T-matrix and `Cluster.solve()`;
the latter includes all sphere-to-sphere multiple scattering at the requested
`lmax`.  The incident wave is a +z plane wave with positive helicity and the
package's default incident amplitude normalization.  The reported field is
`incident.efield(points) + scattered.efield(points)`.

All input lengths are interpreted in micrometers, so the vacuum wavenumber is
`k0 = 2*pi/wavelength` in inverse micrometers.  Each complex permittivity is
formed as `real + i*imag`; the spheres and exterior use relative material
parameters, with `mu=1`, zero chirality, and vacuum exterior.

The reported cross sections are the treams-rs scattering, extinction, and
absorption areas.  Checks performed: the CLI was run on the supplied example,
the output was parsed as JSON, and the field arrays had one 3-vector per input
point.  The implementation constructs all geometry and material values from
the input config rather than hard-coding example results.
