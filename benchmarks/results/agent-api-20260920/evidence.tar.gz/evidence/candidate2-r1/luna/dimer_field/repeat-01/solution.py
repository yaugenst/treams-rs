"""Multiple-scattering solution for a two-sphere dimer using treams-rs."""

import json
import sys

import numpy as np
import treams_rs as tr


def run(config):
    """Evaluate the dimer fields and cross sections for one configuration."""
    radii = config["radii"]
    epsilons = config["epsilon"]
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    separation = float(config["separation"])

    k0 = 2.0 * np.pi / wavelength
    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=float(radius),
            material=tr.Material(complex(float(eps[0]), float(eps[1]))),
        )
        for radius, eps in zip(radii, epsilons)
    ]
    system = tr.Cluster(
        particles,
        positions=[[-separation / 2.0, 0.0, 0.0], [separation / 2.0, 0.0, 0.0]],
    )
    response = system.solve()
    incident = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
    )

    points = np.asarray(config["points"], dtype=float)
    total = incident.efield(points) + response.scatter(incident).efield(points)
    cross = response.cross_sections(incident)

    return {
        "total_field_real": total.real.tolist(),
        "total_field_imag": total.imag.tolist(),
        "scattering": float(cross.scattering),
        "extinction": float(cross.extinction),
        "absorption": float(cross.absorption),
    }


def main():
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
