# Cylinder scattering: cross widths

## Physical setup
- Infinite homogeneous circular cylinder, axis along z, embedded in vacuum.
- Illumination: plane wave with wavevector along +x (kz = 0, propagation
  perpendicular to the cylinder axis), positive-helicity polarization.
- Material: relative permittivity `epsilon = eps_re + i*eps_im` (config
  `epsilon: [real, imag]`), relative permeability mu = 1, chirality kappa = 0
  (defaults), embedded in vacuum (epsilon = mu = 1).
- `mmax` is the azimuthal (cylindrical multipole) truncation order; modes
  m = -mmax..mmax are included for each polarization.

## Units and conventions
- All lengths (radius, wavelength) are in micrometers.
- Vacuum wavenumber `k0 = 2*pi/wavelength` (1/micrometer), consistent with the
  length unit of the radius, so results are self-consistent regardless of the
  absolute unit choice.
- Returned scattering, extinction and absorption quantities are *widths*
  (length units, micrometers), not areas — this is the natural normalization
  for a 2D (translationally invariant along z) scattering problem, as opposed
  to the cross-*section* (area) normalization used for finite 3D scatterers
  such as spheres. `treams_rs.CylindricalTMatrix.cross_widths` returns exactly
  this length-unit convention (its docstring: "Cross widths have length
  units."), so no extra normalization to a sphere's projected area is applied
  or needed.
- The default `flux=0.5` normalization of `cross_widths` corresponds to the
  standard unit-amplitude incident plane-wave irradiance convention used
  throughout treams; it was used unchanged.

## Method
For each wavelength:
1. Build a single concentric-cylinder T-matrix with
   `treams_rs.CylindricalTMatrix.cylinder(kzs=0.0, mmax, k0, radius,
   materials=[epsilon_material, vacuum])` — the axis wavenumber `kz` is fixed
   to 0 as required (illumination perpendicular to the axis).
2. Build the incident field with `treams_rs.plane_wave(direction=[1,0,0],
   polarization="positive_helicity", k0=k0, material=1)`.
3. Call `tm.cross_widths(pw)` to obtain named `scattering`, `extinction`, and
   `absorption` (`extinction - scattering`) widths directly from treams-rs's
   analytic T-matrix solution — no reimplementation of Mie-type cylinder
   theory was performed.

Results are collected per wavelength, preserving the input wavelength order.

## Checks performed
- **Power balance**: for every wavelength, `extinction - scattering -
  absorption == 0` to floating-point precision (verified numerically above),
  confirming energy conservation as computed by the library.
- **mmax convergence**: re-running the example config with `mmax = 8` instead
  of `4` reproduces the `mmax = 4` scattering/extinction/absorption widths to
  ~9 significant figures, confirming `mmax = 4` is already converged for this
  small radius (0.08 micrometers) relative to the wavelengths used.
- **No hard-coding**: `run(config)` reads `radius`, `epsilon`, `wavelengths`,
  and `mmax` from the input dictionary and recomputes everything through
  treams-rs; no example-specific values appear in the code.

## Example config output
Input:
```json
{"radius": 0.08, "epsilon": [5, 0.1], "wavelengths": [0.5, 0.65, 0.8], "mmax": 4}
```
Output (see `results.json`):
```json
{
  "scattering_width": [0.5330353956472306, 0.2585917233709188, 0.24074173787002],
  "extinction_width": [0.5611064991202264, 0.26953972269712123, 0.24886445442336308],
  "absorption_width": [0.028071103472995795, 0.01094799932620244, 0.008122716553343068]
}
```
