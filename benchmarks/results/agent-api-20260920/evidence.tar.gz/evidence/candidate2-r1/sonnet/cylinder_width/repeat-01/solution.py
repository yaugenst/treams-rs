import json
import sys

import numpy as np
import treams_rs as trs


def run(config):
    radius = float(config["radius"])
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    wavelengths = config["wavelengths"]
    mmax = int(config["mmax"])

    scattering = []
    extinction = []
    absorption = []

    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl
        tm = trs.CylindricalTMatrix.cylinder(
            0.0, mmax, k0, radius, [epsilon, 1]
        )
        pw = trs.plane_wave(
            direction=[1, 0, 0],
            polarization="positive_helicity",
            k0=k0,
            material=1,
        )
        cs = tm.cross_widths(pw)
        scattering.append(cs.scattering)
        extinction.append(cs.extinction)
        absorption.append(cs.absorption)

    return {
        "scattering_width": scattering,
        "extinction_width": extinction,
        "absorption_width": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
