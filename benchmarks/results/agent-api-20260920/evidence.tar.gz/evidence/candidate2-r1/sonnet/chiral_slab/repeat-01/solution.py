import json
import sys

import numpy as np
import treams_rs as t


def run(config):
    thickness = float(config["thickness"])
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    kappa = complex(config.get("kappa", 0.0))
    wavelengths = config["wavelengths"]

    material = t.Material(epsilon, 1.0, kappa)
    basis = t.PlaneWavePorts.default([0.0, 0.0])

    transmission = []
    reflection = []
    absorption = []
    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl
        sm = t.slab(basis=basis, k0=k0, thickness=thickness, material=material)
        pb_pos = sm.power([0, 1], side="negative")
        pb_neg = sm.power([1, 0], side="negative")
        transmission.append([float(pb_pos.transmission), float(pb_neg.transmission)])
        reflection.append([float(pb_pos.reflection), float(pb_neg.reflection)])
        absorption.append([float(pb_pos.absorption), float(pb_neg.absorption)])

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
