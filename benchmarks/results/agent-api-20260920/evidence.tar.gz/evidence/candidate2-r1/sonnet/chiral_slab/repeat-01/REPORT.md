# Chiral slab scattering — REPORT

## Problem
A uniform, reciprocal, chiral, non-magnetic slab of finite thickness lies in
vacuum, normal to `z`. Light is normally incident from `z = -infinity`
(`+z` propagation). For each wavelength we compute the transmitted,
reflected and absorbed power fraction separately for positive- and
negative-helicity (circularly polarized) incidence.

## Units and conventions
- Lengths (`thickness`, `wavelengths`) are in micrometers; both must use the
  same length unit, since only the ratio enters the physics through
  `k0 = 2*pi/wavelength`.
- `epsilon = [Re(eps), Im(eps)]` is the slab's relative permittivity
  (dimensionless, complex). `Im(eps) >= 0` for a passive absorbing medium.
- `mu = 1` (not exposed in the config; the problem statement fixes it).
- `kappa` is the package's (real) reciprocal chirality parameter, entering
  the material as `treams_rs.Material(epsilon, mu=1, kappa)`. Its two
  circular-polarization refractive indices are
  `n_pm = sqrt(eps*mu) +/- kappa` (positive helicity uses `+kappa`,
  negative helicity uses `-kappa`), matching `Material.nmp`.
- The exterior on both sides of the slab is vacuum (`Material(1)`), matching
  the "bounded by vacuum on both sides" specification.
- `transmission`, `reflection`, `absorption` are **power fractions**
  (`0..1`), not complex field-amplitude coefficients, with shape
  `(len(wavelengths), 2)`, column 0 = positive helicity, column 1 =
  negative helicity, following `treams_rs`'s own documented convention:
  `SMatrices.power([0, 1], side="negative")` returns the
  positive-helicity `(transmission, reflection)` fractions for a wave
  incident from the negative (`-z`) side, i.e. propagating in `+z`, and
  `power([1, 0], side="negative")` gives the negative-helicity fractions.
  `PowerBalance.absorption` is `1 - transmission - reflection`.

## Numerical method (treams-rs)
For each wavelength:
1. Build the normal-incidence plane-wave port basis:
   `basis = treams_rs.PlaneWavePorts.default([0, 0])` (both circular
   polarizations at zero transverse wavevector).
2. Build the slab material: `treams_rs.Material(epsilon, 1, kappa)`.
3. Compute the slab's S-matrix network with
   `treams_rs.slab(basis=basis, k0=2*pi/wavelength, thickness=thickness,
   material=material)` — this is the package's exact (non-perturbative)
   multiple-reflection solution for a homogeneous layer between two
   half-spaces, not an approximation.
4. Read off `sm.power([0, 1], side="negative")` and
   `sm.power([1, 0], side="negative")` for the positive- and
   negative-helicity power balances, respectively.

No custom scattering physics is implemented; all electromagnetic
computation (wavevectors, Fresnel-type interface matrices, propagation
phases, multiple-reflection cascading, and power projection) is delegated
to `treams-rs`.

## Checks performed
- **Energy conservation**: for every wavelength and helicity,
  `transmission + reflection + absorption == 1` to floating-point
  precision (verified numerically for the example config, residual
  `~1e-16`).
- **Passivity**: `Im(epsilon) >= 0` gives `absorption >= 0`.
- **Physical symmetry (verified, not assumed)**: because `kappa` in this
  API is a *real* scalar (no imaginary chirality is exposed), the two
  circular eigenmodes `n_pm = sqrt(eps*mu) +/- kappa` always share the same
  imaginary part `Im(sqrt(eps*mu))` (their difference is a purely real
  shift), and the slab's front/back Fresnel reflection amplitude depends
  only on the wave impedance `sqrt(mu/eps)`, which is independent of
  `kappa`. Consequently, for a reciprocal, real-kappa chiral slab, the
  positive- and negative-helicity power fractions are provably identical
  (`T+ = T-`, `R+ = R-`, `A+ = A-`); only the *phase* (optical rotation)
  differs between helicities, not the power split. This was confirmed
  both analytically and numerically (matching to ~1e-13 across a wide
  range of `kappa`, `epsilon`, and slab thickness). It is real chiral-optics
  physics — non-absorptive circular dichroism requires an imaginary part of
  `kappa`, which this API's `Material` does not model as an independent
  input here — not an artifact of the implementation.
- Cross-checked achiral limits (`kappa = 0`) against the closed-form
  Fresnel/Airy multi-reflection formula for a lossy dielectric slab; the
  `treams-rs` `power()` output matches the analytic formula to floating
  point precision.

## Files
- `solution.py`: exposes `run(config)` and a CLI (`python3 solution.py`
  reads a JSON config from stdin, writes the JSON result to stdout).
- `results.json`: output of `run(config)` for the example config in the
  prompt.
