import json
import sys

import numpy as np
import treams_rs as tr


def run(config):
    radii = config["radii"]
    epsilon = config["epsilon"]
    separation = config["separation"]
    wavelength = config["wavelength"]
    lmax = config["lmax"]
    points = config["points"]

    k0 = 2 * np.pi / wavelength

    materials = [tr.Material(complex(e[0], e[1])) for e in epsilon]
    particles = [
        tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=r, material=m)
        for r, m in zip(radii, materials)
    ]
    positions = [[-separation / 2, 0.0, 0.0], [separation / 2, 0.0, 0.0]]
    system = tr.Cluster(particles, positions=positions)

    incident = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)

    response = system.solve()
    cross = response.cross_sections(incident)
    scattered = response.scatter(incident)

    e_inc = incident.efield(points)
    e_scat = scattered.efield(points)
    e_total = np.asarray(e_inc) + np.asarray(e_scat)

    return {
        "total_field_real": e_total.real.tolist(),
        "total_field_imag": e_total.imag.tolist(),
        "scattering_cross_section": float(cross.scattering),
        "extinction_cross_section": float(cross.extinction),
        "absorption_cross_section": float(cross.absorption),
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
