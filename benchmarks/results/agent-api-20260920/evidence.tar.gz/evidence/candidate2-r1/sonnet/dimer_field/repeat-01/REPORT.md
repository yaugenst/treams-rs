# Dimer Total Field via treams-rs

## Method
Two homogeneous, isotropic spheres are built with `treams_rs.sphere_tmatrix`
at the fixed multipole cutoff `lmax`, each embedded in vacuum with the given
complex permittivity (`epsilon = [real, imag]`, `mu=1`, `kappa=0`). They are
placed at `x = -separation/2` and `x = +separation/2` (`y=z=0`) using
`treams_rs.Cluster(particles, positions=...)`. `Cluster.solve()` performs the
full multipole translation/interaction solve and returns the coupled T-matrix
of the two-sphere system, i.e. all orders of multiple scattering between the
spheres are included at the chosen `lmax` (no Born/single-scattering
truncation).

Illumination is a `+z`-propagating plane wave with positive helicity,
`treams_rs.plane_wave([0,0,1], "positive_helicity", k0=k0)`, using the
package's native incident-field amplitude normalization (unit-amplitude
positive-helicity plane wave).

The scattered field is obtained from `response.scatter(incident).efield(points)`
and added to the incident field `incident.efield(points)` to give the total
field returned to the user (`total_field_real` + i*`total_field_imag`,
shape `(n_points, 3)`, one row per requested point, Cartesian E-field
components).

Cross sections (`scattering`, `extinction`, `absorption`) come directly from
`response.cross_sections(incident)`, in area units consistent with the length
unit of the geometry (see below), using the package's default flux
normalization (`flux=0.5`, i.e. the standard unit-amplitude plane-wave
convention appearing in the treams reference, Beutel et al., Comput. Phys.
Commun. 297, 109076 (2024)).

## Units and conventions
- All lengths (`radii`, `separation`, `wavelength`, `points`) are in
  micrometers.
- `k0 = 2*pi/wavelength` is the vacuum angular wavenumber (inverse
  micrometers), matching the length unit used for radii/positions.
- `epsilon`/`mu` are dimensionless relative material parameters; chirality
  (`kappa`) is 0 unless otherwise specified; the exterior medium is vacuum.
- Cross sections are areas in micrometers^2 (length unit squared).
- Field components are complex (returned as separate real/imag lists) in the
  package's internal field-amplitude units (unit-amplitude incident plane
  wave).

## Checks performed
- For a lossless configuration (real epsilon, `imag=0` for both spheres),
  `extinction_cross_section` equals `scattering_cross_section` and
  `absorption_cross_section` is numerically zero (~1e-18), verifying energy
  conservation for the coupled dimer solve.
- For the example config (absorbing spheres), `absorption = extinction -
  scattering > 0`, as required physically.
- Total field values were cross-checked by recomputing `incident.efield` and
  `scattered.efield` independently and summing, matching the values returned
  by `run()`.
- `run()` was exercised on the example config and on an independent
  configuration (equal lossless spheres, different separation/wavelength/lmax)
  to confirm the code path is not hard-coded to the example.

## Files
- `solution.py`: exposes `run(config)` and a CLI (`stdin` JSON -> `stdout`
  JSON).
- `results.json`: output for the example config.
