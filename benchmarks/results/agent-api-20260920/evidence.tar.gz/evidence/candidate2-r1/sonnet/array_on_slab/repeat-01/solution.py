"""Periodic sphere array above a dielectric slab, separated by a vacuum gap.

Network ordered from negative to positive z: slab, vacuum gap, sphere array.
Illumination is from the negative-z side (vacuum), propagating along +z with
positive helicity. Only the zeroth diffraction order (Bloch vector [0, 0],
both helicities) is retained, valid when wavelength > period.
"""

import json
import sys

import numpy as np
import treams_rs as tr


def run(config):
    radius = config["radius"]
    sphere_epsilon = config["sphere_epsilon"]
    period = config["period"]
    gap = config["gap"]
    slab_thickness = config["slab_thickness"]
    slab_epsilon = config["slab_epsilon"]
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    lattice = tr.Lattice.square(period)
    kpar = [0.0, 0.0]
    ports = tr.PlaneWavePorts.default(kpar)

    transmission = []
    reflection = []
    absorption = []

    for wl in wavelengths:
        k0 = 2 * np.pi / wl

        particle = tr.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=sphere_epsilon
        )
        periodic = tr.solve_periodic(particle, lattice=lattice, kpar=kpar)
        array_layer = periodic.to_smatrix(ports)

        slab_layer = tr.slab(
            k0=k0, basis=ports, thickness=slab_thickness, material=slab_epsilon
        )
        gap_layer = tr.propagation(k0=k0, basis=ports, distance=gap)

        network = tr.stack([slab_layer, gap_layer, array_layer])

        wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
        power = network.power(wave, side="negative")

        transmission.append(float(power.transmission))
        reflection.append(float(power.reflection))
        absorption.append(float(power.absorption))

    return {
        "wavelengths": list(wavelengths),
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
