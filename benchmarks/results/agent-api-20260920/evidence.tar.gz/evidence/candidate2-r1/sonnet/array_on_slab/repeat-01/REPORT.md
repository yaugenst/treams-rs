# Sphere array on a dielectric slab — power balance

## Physical setup

A square periodic array of identical dielectric spheres sits above a
homogeneous dielectric slab, separated by a vacuum gap. All exterior media
(above the sphere plane and below the slab) are vacuum. Along +z the network
is ordered:

```
slab  →  vacuum gap  →  sphere array (Bloch vector [0, 0])
```

Illumination is a plane wave incident from the negative-z side, propagating
along +z, with positive helicity (a definite-helicity, i.e. circularly
polarized, wave). Because the array period exceeds all requested wavelengths,
only the zeroth diffraction order is open; the periodic problem is truncated
to the two zeroth-order helicity channels (`PlaneWavePorts.default([0, 0])`).
The full periodic multiple-scattering problem for the sphere lattice is
solved at the fixed spherical-multipole cutoff `lmax` (`treams_rs.solve_periodic`),
then converted into an S-matrix in that plane-wave port basis and cascaded
with the slab and gap layers (`treams_rs.slab`, `treams_rs.propagation`,
`treams_rs.stack`).

## Units and conventions

- Lengths (`radius`, `period`, `gap`, `slab_thickness`, wavelengths) are in
  micrometers; all length quantities share this unit, so no unit conversion
  is required.
- `sphere_epsilon` and `slab_epsilon` are real, relative permittivities
  (`mu = 1`, chirality `kappa = 0` throughout, matching the problem
  statement's defaults).
- The vacuum angular wavenumber is `k0 = 2*pi / wavelength`.
- Polarization/mode convention is "helicity" (the package default), matching
  the "positive helicity" illumination specified in the problem.
- `PowerBalance.transmission`/`.reflection` are outgoing power fractions of
  the incident flux through the two-port zeroth-order S-matrix;
  `.absorption` is `1 - transmission - reflection`.

## Numerical solution steps (per wavelength)

1. Build the isolated-sphere T-matrix (`sphere_tmatrix`) at the given `k0`,
   `lmax`, `radius`, and `sphere_epsilon` (vacuum exterior).
2. Solve the periodic lattice-coupling problem for the square array
   (`solve_periodic`, `Lattice.square(period)`, `kpar = [0, 0]`).
3. Convert the solved periodic response to an S-matrix in the zeroth-order,
   both-helicity port basis (`PeriodicResponse.to_smatrix`).
4. Build the homogeneous slab S-matrix (`slab`, thickness `slab_thickness`,
   `slab_epsilon`) and the vacuum-gap propagation S-matrix (`propagation`,
   distance `gap`), both in the same port basis.
5. Cascade `[slab, gap, array]` from negative to positive z
   (`stack`) to obtain the full network S-matrix.
6. Illuminate with a `k0`-dependent plane wave along `+z` with
   `positive_helicity` polarization, incident from the `negative` side, and
   read off `power.transmission`, `power.reflection`, `power.absorption`.

## Checks

- All materials are lossless (real permittivities, `mu = 1`, no chirality),
  so energy conservation requires `transmission + reflection ≈ 1` and
  `absorption ≈ 0`. For the example config and additional test configs, the
  computed absorption is at floating-point round-off (~1e-15), confirming
  the power balance is respected.
- Varying wavelength, radius, period, gap, slab thickness and permittivities
  in ad hoc test configurations produces smoothly varying, physically
  reasonable transmission/reflection spectra (no negative or >1 fractions),
  consistent with the expected Fabry–Pérot-like interference between the
  slab and the resonant sphere array.

## Example run

Input (`example_config.json`): the config given in the task description.
Output (`results.json`), wavelength-ordered:

| wavelength (µm) | transmission | reflection | absorption |
|---|---|---|---|
| 0.65 | 0.8873 | 0.1127 | ~0 |
| 0.74 | 0.9021 | 0.0979 | ~0 |
| 0.83 | 0.9119 | 0.0881 | ~0 |

## Notes on `run(config)`

`solution.py` exposes `run(config)`, which is fully driven by the input
dictionary (radius, permittivities, period, gap, slab thickness, wavelength
list, lmax) with no hard-coded values. The CLI entry point reads one JSON
config object from stdin and prints the dictionary returned by `run` as JSON
to stdout.
