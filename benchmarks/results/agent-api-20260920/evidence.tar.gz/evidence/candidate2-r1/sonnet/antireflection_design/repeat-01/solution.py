"""Minimize reflected power of one lossless coating via analytic gradient descent."""
import json
import sys
import math

import advect as ad
import treams_rs as t
import treams_rs.advect as tr


def _reflection_fn(basis, k0, eps_coat, eps_sub):
    material = tr.Material(epsilon=eps_coat)
    sub = tr.Material(epsilon=eps_sub)
    wave = tr.PlaneWave([0.0, 0.0, 1.0], "positive_helicity", k0=k0, medium=1.0)

    def reflection(thickness):
        smat = tr.slab(
            basis=basis,
            k0=k0,
            thickness=thickness,
            material=material,
            negative_medium=1.0,
            positive_medium=sub,
            polarization="helicity",
        )
        return smat.power(wave).reflection

    return reflection


def run(config):
    wavelength = float(config["wavelength"])
    epsilon = float(config["epsilon"])
    substrate_epsilon = float(config["substrate_epsilon"])
    initial_thickness = float(config["initial_thickness"])
    lo, hi = (float(config["bounds"][0]), float(config["bounds"][1]))

    k0 = 2.0 * math.pi / wavelength
    basis_dir = t.PlaneWaveBasis.default([0.0, 0.0, 1.0])
    basis = basis_dir.bycomp(k0=k0, material=1.0)

    reflection = _reflection_fn(basis, k0, epsilon, substrate_epsilon)
    value_and_grad = ad.value_and_grad(reflection)

    thickness = min(max(initial_thickness, lo), hi)
    initial_reflection = float(reflection(thickness))

    tol = 1e-7
    max_iters = 200
    step = 0.05 * wavelength
    min_step = 1e-14

    loss_history = []
    grad = 0.0
    for _ in range(max_iters):
        r, g = value_and_grad(thickness)
        r = float(r)
        g = float(g)
        loss_history.append(r)
        grad = g
        if r < tol:
            break
        if g == 0.0:
            break

        trial_step = step
        while True:
            candidate = min(max(thickness - trial_step * g, lo), hi)
            r_candidate = float(reflection(candidate))
            if r_candidate < r or trial_step < min_step:
                break
            trial_step *= 0.5

        if trial_step < min_step and r_candidate >= r:
            break

        thickness = candidate
        step = trial_step * 1.5

    final_reflection, grad = value_and_grad(thickness)
    final_reflection = float(final_reflection)
    grad = float(grad)
    if not loss_history or loss_history[-1] != final_reflection:
        loss_history.append(final_reflection)

    return {
        "thickness": thickness,
        "reflection": final_reflection,
        "initial_reflection": initial_reflection,
        "gradient": grad,
        "loss_history": loss_history,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
