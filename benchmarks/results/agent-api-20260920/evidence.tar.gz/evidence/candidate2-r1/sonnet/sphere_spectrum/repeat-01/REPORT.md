# Homogeneous Sphere Mie Spectrum

## Method

`solution.py` computes the T-matrix of a homogeneous dielectric sphere with
`treams_rs.sphere_tmatrix` in the helicity polarization basis, illuminates it
with a plane wave propagating along `+z` with positive helicity
(`treams_rs.plane_wave(direction=[0,0,1], polarization="positive_helicity", poltype="helicity")`),
and reads off scattering/extinction/absorption cross sections from
`TMatrix.cross_sections(...)`. No reimplementation of Mie theory is used;
all numerics come from treams-rs.

## Units and conventions

- Lengths (`radius`, `wavelengths`) are in micrometers; the vacuum angular
  wavenumber used internally is `k0 = 2*pi/wavelength` in inverse micrometers,
  consistent with `radius` sharing the same length unit.
- `epsilon = [real, imag]` is the sphere's relative permittivity (not a
  refractive index), passed directly as `complex(real, imag)` to
  `sphere_tmatrix(material=...)`. The exterior medium is vacuum
  (`medium=1`, the default), `mu=1`, and chirality `kappa=0` for the sphere,
  as specified.
- Illumination is a plane wave along `+z` with **positive helicity**
  polarization, in the helicity basis (`poltype="helicity"`), matching the
  sphere T-matrix's `polarization="helicity"` setting.
- Returned cross sections (`scattering`, `extinction`, `absorption`) are areas
  in squared length units (micrometers^2), one value per wavelength in the
  order given in `wavelengths`.
- `efficiency` is the scattering efficiency `Q_sca = scattering / (pi * radius**2)`,
  dimensionless, per wavelength.

## Checks

- Energy conservation: for every wavelength, `extinction == scattering + absorption`
  exactly (matches `CrossSections.absorption`, which is defined as
  extinction minus scattering internally).
- Example config (`radius=0.1`, `epsilon=[12, 0.05]`,
  `wavelengths=[0.45, 0.55, 0.65, 0.75]`, `lmax=4`) produces cross sections
  that rise from a small value at 0.45 um toward a resonance-like peak in the
  0.55-0.75 um range, consistent with a Mie resonance for a subwavelength
  high-index sphere; results are saved in `results.json`.
- The function does not hard-code these example values; it recomputes
  `sphere_tmatrix` and `cross_sections` for whatever `radius`, `epsilon`,
  `wavelengths`, and `lmax` are supplied in `config`.

## CLI usage

```
python3 solution.py < config.json > results.json
```

reads a single JSON config dictionary from stdin and prints the resulting
dictionary as JSON to stdout.
