import sys
import json
import math

import treams_rs as trs


def run(config):
    radius = config["radius"]
    eps_re, eps_im = config["epsilon"]
    epsilon = complex(eps_re, eps_im)
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    scattering = []
    extinction = []
    absorption = []
    efficiency = []

    area = math.pi * radius**2

    for wavelength in wavelengths:
        k0 = 2 * math.pi / wavelength
        tmat = trs.sphere_tmatrix(
            k0=k0, lmax=lmax, radius=radius, material=epsilon, polarization="helicity"
        )
        pw = trs.plane_wave(
            direction=[0, 0, 1],
            polarization="positive_helicity",
            k0=k0,
            material=1,
            poltype="helicity",
        )
        cs = tmat.cross_sections(pw)

        scattering.append(cs.scattering)
        extinction.append(cs.extinction)
        absorption.append(cs.absorption)
        efficiency.append(cs.scattering / area)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
