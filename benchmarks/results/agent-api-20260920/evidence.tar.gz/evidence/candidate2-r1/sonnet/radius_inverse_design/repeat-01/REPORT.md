# Radius inverse design

## Problem
Given target scattering efficiencies `Q_target(lambda_i)` for a homogeneous,
lossless sphere (fixed relative permittivity `epsilon`, `mu=1`, `kappa=0`) in
vacuum, find the sphere radius `r` minimizing

    loss(r) = mean_i( ((Q(r, lambda_i) - Q_target_i) / Q_target_i)^2 )

starting from `initial_radius` and staying within `bounds`.

## Units and conventions
- All lengths (radius, wavelength, bounds) are in micrometers.
- `epsilon` is the relative (dimensionless) permittivity of the sphere;
  the exterior medium is vacuum (`epsilon=1`).
- Vacuum wavenumber `k0 = 2*pi / wavelength` (rad/um), matching
  `treams_rs.sphere_tmatrix(k0=..., radius=...)`, where `radius` and `1/k0`
  share the same length unit (micrometers here).
- Scattering efficiency is the standard dimensionless
  `Q_sca = C_sca / (pi * r^2)`, with `C_sca` the scattering cross section
  (area, um^2) from `TMatrix.cross_sections(plane_wave).scattering` under a
  unit-amplitude plane-wave illumination (default flux normalization).
- `lmax` (multipole cutoff) is fixed, as specified in the config.

## Numerics
- The T-matrix and scattering cross section are computed with treams-rs
  (`treams_rs.advect.sphere_tmatrix`, `.cross_sections`), not reimplemented.
- The `treams_rs.advect` namespace (the installed `Advect` adapter) is used
  so that the radius-to-loss map is traced and its **analytic** derivative
  (native reverse-mode pullback through the T-matrix and cross-section
  computation) is available via `advect.value_and_grad`.
- Optimization: no `scipy` is available in this environment, so a small
  bounded gradient-descent with backtracking (Armijo-style) line search is
  implemented directly using the analytic gradient. Each step halves the
  trial step size until the loss decreases (or the step underflows), then
  the accepted step size is grown slightly for the next iteration. The
  radius is clipped to `bounds` after every step. Iteration stops once the
  loss drops below `1e-9` or after a fixed iteration budget.
- On the example config this converges to `loss ~ 2e-11` in 10 iterations,
  comfortably below the required `1e-7` threshold.

## Checks performed
- **Gradient validation**: the analytic gradient from `advect.value_and_grad`
  was compared against a central finite-difference estimate of `loss'(r)`
  away from the optimum; they agree to ~8 significant figures
  (e.g. analytic `-21.920920387` vs finite-difference `-21.920920357`).
  Finite differences are used here only to *validate* the analytic gradient,
  never to supply it to the optimizer.
- **Recovery test**: targets were synthesized from a known radius (not the
  example's) using `treams-rs` forward scattering efficiencies, and `run()`
  recovered that radius to within `~5e-6` um, with final loss `~4e-10`.
- The function does not hard-code the example's radius, epsilon, wavelengths
  or targets; all optimization state (loss, gradient, fitted efficiencies)
  is recomputed from the supplied `config` on every call.

## Output of `run(config)`
- `radius`: fitted sphere radius (um), within `bounds`.
- `loss`: final value of `mean(((Q-target)/target)**2)`.
- `initial_loss`: loss evaluated at the (bounds-clipped) `initial_radius`.
- `gradient`: analytic `d(loss)/d(radius)` at the final radius.
- `fitted_efficiencies`: `Q(r, lambda_i)` at the fitted radius, one per
  wavelength.
- `loss_history`: loss value after each accepted optimization step
  (including the initial evaluation).

## Example run
Input: `epsilon=4.0`, `lmax=3`, `wavelengths=[0.58, 0.69, 0.81]` um,
`initial_radius=0.075` um, `bounds=[0.06, 0.14]` um.

Result (saved in `results.json`): fitted `radius ≈ 0.110000` um,
`loss ≈ 2.0e-11`, `initial_loss ≈ 0.622`, matching the target efficiencies
to ~5 significant figures.
