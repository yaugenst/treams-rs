"""Infer a homogeneous sphere radius from target scattering efficiencies at
several wavelengths, using treams-rs analytic (Advect) radius gradients.

All lengths are in micrometers; epsilon/mu/kappa are dimensionless relative
quantities. The exterior is vacuum, mu=1 and chirality=0 unless given.
k0 = 2*pi/wavelength (rad/um). Scattering efficiency Q = C_sca / (pi * r**2).
"""

import json
import sys

import numpy as np
import advect as ad
import treams_rs.advect as tr


def _make_loss(k0s, targets, lmax, epsilon):
    def loss_fn(radius):
        terms = []
        for k0, target in zip(k0s, targets):
            sphere = tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)
            wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
            cs = sphere.cross_sections(wave)
            q = cs.scattering / (np.pi * radius**2)
            terms.append(((q - target) / target) ** 2)
        return sum(terms) / len(terms)

    return loss_fn


def _efficiencies(radius, k0s, lmax, epsilon):
    out = []
    for k0 in k0s:
        sphere = tr.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=epsilon)
        wave = tr.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
        cs = sphere.cross_sections(wave)
        out.append(float(cs.scattering) / (np.pi * radius**2))
    return out


def run(config):
    epsilon = config["epsilon"]
    lmax = config["lmax"]
    wavelengths = config["wavelengths"]
    initial_radius = config["initial_radius"]
    lo, hi = config["bounds"]
    targets = config["target_efficiencies"]

    k0s = [2 * np.pi / w for w in wavelengths]
    loss_fn = _make_loss(k0s, targets, lmax, epsilon)

    r = float(min(max(initial_radius, lo), hi))
    initial_loss, initial_grad = ad.value_and_grad(loss_fn)(r)
    initial_loss = float(initial_loss)

    loss_history = [initial_loss]
    val, grad = initial_loss, float(initial_grad)
    step = 1e-3
    max_iters = 500
    tol = 1e-9

    for _ in range(max_iters):
        if val < tol:
            break
        t = step
        for _ in range(60):
            r_new = min(max(r - t * grad, lo), hi)
            val_new, grad_new = ad.value_and_grad(loss_fn)(r_new)
            val_new = float(val_new)
            if val_new < val or t < 1e-14:
                break
            t *= 0.5
        r, val, grad = r_new, val_new, float(grad_new)
        loss_history.append(val)
        step = t * 1.5

    final_loss, final_grad = ad.value_and_grad(loss_fn)(r)
    final_loss = float(final_loss)
    final_grad = float(final_grad)
    loss_history[-1] = final_loss

    fitted_efficiencies = _efficiencies(r, k0s, lmax, epsilon)

    return {
        "radius": r,
        "loss": final_loss,
        "initial_loss": initial_loss,
        "gradient": final_grad,
        "fitted_efficiencies": fitted_efficiencies,
        "loss_history": loss_history,
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
