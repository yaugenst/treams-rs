import json
import sys

import numpy as np
import treams_rs as trs


def run(config):
    radii = config["radii"]
    epsilon_layers = config["epsilon_layers"]
    epsilon_medium = config.get("epsilon_medium", 1.0)
    wavelengths = config["wavelengths"]
    lmax = config["lmax"]

    if isinstance(epsilon_medium, (list, tuple)):
        eps_medium = complex(epsilon_medium[0], epsilon_medium[1])
    else:
        eps_medium = complex(epsilon_medium)

    layer_materials = [trs.Material(complex(e[0], e[1])) for e in epsilon_layers]

    scattering = []
    extinction = []
    absorption = []

    for wl in wavelengths:
        k0 = 2.0 * np.pi / wl
        materials = layer_materials + [trs.Material(eps_medium)]
        tm = trs.TMatrix.sphere(lmax, k0, radii, materials)
        avg = tm.average_cross_sections
        scattering.append(avg.scattering)
        extinction.append(avg.extinction)
        absorption.append(avg.absorption)

    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
    }


if __name__ == "__main__":
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
