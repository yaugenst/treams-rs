# Core-shell sphere spectrum (treams-rs)

## Method
For each wavelength `wl` in `config["wavelengths"]`, a concentric multilayer
sphere T-matrix is built with `treams_rs.TMatrix.sphere(lmax, k0, radii, materials)`,
where:

- `k0 = 2*pi / wl` is the **vacuum** angular wavenumber (µm⁻¹), since all
  lengths (radii, wavelengths) are given in micrometers.
- `radii` are the increasing outer boundaries of each layer (µm), passed
  through unchanged — the outermost radius is a real finite layer boundary,
  not the exterior.
- `materials` is the list of layer materials (inside-out, one per entry of
  `epsilon_layers`, each `[real, imag]` -> `complex(re, im)`) **followed by**
  the exterior medium material built from `epsilon_medium` (real or
  `[real, imag]`). This matches the documented convention "one entry per
  layer plus the exterior medium, ordered from the center outward" — the
  exterior is supplied as the last material, not as an extra radius.
- `mu = 1` and `kappa = 0` (achiral, non-magnetic) are used for every layer
  and the exterior, since the config does not specify them (per the task's
  stated defaults).

The rotationally- and polarization-averaged cross sections are then read
from the `average_cross_sections` property of the resulting `TMatrix`,
which returns a `CrossSections(scattering, extinction)` namedtuple with an
`.absorption` property (`extinction - scattering`). These are exactly the
plane-wave-illumination, orientation-averaged cross sections requested.

## Units and conventions
- Lengths (radii, wavelengths) in micrometers.
- `epsilon_layers`/`epsilon_medium` are dimensionless relative permittivities
  (complex, with the imaginary part representing absorption, `Im(eps) >= 0`).
- Returned cross sections (`scattering`, `extinction`, `absorption`) are in
  µm² (area units), matching the length unit convention, one value per
  wavelength in the same order as `config["wavelengths"]`.
- No reimplementation of Mie/T-matrix physics: all scattering computation
  is delegated to `treams_rs.TMatrix.sphere` and its `average_cross_sections`
  property.

## Checks performed
- **lmax convergence**: for the example config, increasing `lmax` from 4 to
  8 changes the averaged cross sections only in the 6th significant digit,
  confirming `lmax=4` is already converged for these small size parameters
  (radii ~0.07-0.12 µm at wavelengths 0.58-0.82 µm).
- **Lossless sanity check**: a single real-epsilon (no imaginary part)
  homogeneous sphere in vacuum gives `scattering == extinction` to machine
  precision (zero absorption), as required by energy conservation for a
  non-absorbing scatterer.
- **Physical ordering**: for the example config, extinction >= scattering
  >= 0 and absorption >= 0 at every wavelength, and all three cross
  sections decrease monotonically with increasing wavelength, consistent
  with the shrinking size parameter.

## Example result (`results.json`)
For `radii=[0.07,0.12]`, `epsilon_layers=[[2.25,0.03],[4,0.06]]`,
`epsilon_medium=1.7689`, `wavelengths=[0.58,0.7,0.82]`, `lmax=4`:

```json
{
  "scattering":  [0.03431592329021956, 0.018912460310459123, 0.012135679701039646],
  "extinction":  [0.03752383432335123, 0.02117015737980841,  0.013901066200918064],
  "absorption":  [0.003207911033131665, 0.002257697069349286, 0.0017653864998784172]
}
```

## CLI usage
```
python3 solution.py < config.json > results.json
```
reads one JSON config dict from stdin and prints the result dict as JSON to
stdout.
