"""Dimer sensitivity: sum(|E_total|^2) at a fixed point vs. sphere separation.

Two identical spheres are placed on the x-axis at (+-separation/2, 0, 0) and
illuminated along +z with positive helicity. Multiple scattering between the
spheres is solved for exactly (treams_rs.Cluster.solve). The field value and
its derivative with respect to separation are computed analytically using
treams_rs's Advect-differentiable API (treams_rs.advect), which propagates
derivatives through the full multiple-scattering solve, not just a single
scattering step.

Units: all lengths (radius, separation, wavelength, point coordinates) are in
micrometers. epsilon = [real, imag] is the relative (dimensionless) sphere
permittivity; mu = 1 and chirality = 0 (default, unspecified). The exterior
medium is vacuum. k0 = 2*pi/wavelength (rad/um).
"""

import sys
import json

import numpy as np
import advect
import advect.numpy as anp
import treams_rs.advect as adv


def _objective(radius, material, k0, lmax, point):
    point = np.asarray(point, dtype=float)

    def objective(separation):
        sphere_a = adv.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
        sphere_b = adv.sphere_tmatrix(k0=k0, lmax=lmax, radius=radius, material=material)
        zero = anp.asarray(0.0)
        positions = anp.stack(
            [
                anp.stack([-separation / 2, zero, zero]),
                anp.stack([separation / 2, zero, zero]),
            ]
        )
        cluster = adv.Cluster([sphere_a, sphere_b], positions=positions)
        incident = adv.plane_wave([0, 0, 1], "positive_helicity", k0=k0)
        response = cluster.solve()
        scattered = response.scatter(incident)

        pts = point[None, :]
        e_total = incident.efield(pts) + scattered.efield(pts)
        return anp.sum(anp.abs(e_total) ** 2)

    return objective


def run(config):
    radius = float(config["radius"])
    eps_re, eps_im = config["epsilon"]
    material = complex(float(eps_re), float(eps_im))
    separation = float(config["separation"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])
    point = config["point"]

    k0 = 2.0 * np.pi / wavelength

    objective = _objective(radius, material, k0, lmax, point)
    value, gradient = advect.value_and_grad(objective)(separation)

    return {
        "value": float(value),
        "gradient": float(gradient),
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
