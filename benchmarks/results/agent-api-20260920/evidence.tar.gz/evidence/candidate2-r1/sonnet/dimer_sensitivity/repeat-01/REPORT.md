# Dimer sensitivity: sensitivity of the total field intensity to sphere separation

## Physical setup

Two identical, homogeneous, isotropic dielectric spheres are placed on the
x-axis, symmetrically around the origin, at Cartesian positions
`(-separation/2, 0, 0)` and `(+separation/2, 0, 0)`. They are illuminated by
a plane wave propagating along `+z` with positive helicity (a definite
circular-polarization state, the natural basis for `treams`'s T-matrix/vector
spherical wave formalism). Multiple scattering between the two spheres is
solved exactly (not perturbatively) with `treams_rs.Cluster.solve()`, which
builds and inverts the full coupled-particle interaction system.

At a fixed observation point `point = (x, y, z)`, the reported `value` is

    value = sum(|E_incident(point) + E_scattered(point)|**2)

i.e. the sum over the three Cartesian field components of the squared
modulus of the *total* electric field (incident + multiply-scattered field
from both spheres). `gradient` is the analytic derivative
`d(value)/d(separation)`, obtained with the sphere positions moving
symmetrically as `separation` changes while `point`, `wavelength`, `radius`,
`material`, and `lmax` are held fixed.

## Units and conventions

- All lengths (`radius`, `separation`, `wavelength`, and `point` coordinates)
  are in micrometers.
- `epsilon = [real, imag]` is the sphere's relative (dimensionless) electric
  permittivity; `mu = 1` and `chirality = 0` (both unspecified, so treams's
  defaults are used); the surrounding medium is vacuum.
- The vacuum wavenumber is `k0 = 2*pi/wavelength` (rad/um), passed directly
  to `treams_rs.sphere_tmatrix`/`plane_wave`.
- Fields are complex-valued (SI-like Gaussian convention used internally by
  `treams`); `value` is a real, non-negative scalar (a field-intensity-like
  quantity, units of |E|^2, with `E` in whatever unit the plane-wave
  amplitude of 1 defines).
- Polarization/expansion convention: `helicity` (default for
  `sphere_tmatrix`) is used throughout, consistent for the T-matrices,
  cluster assembly, and plane-wave illumination.

## Numerical method

- `treams_rs.advect.sphere_tmatrix` builds each sphere's T-matrix with
  differentiable geometry/material handles.
- `treams_rs.advect.Cluster` assembles the two-particle system at Cartesian
  positions built as a function of the (traced) `separation` variable using
  `advect.numpy` array operations, so the whole pipeline — T-matrix
  construction, inter-particle coupling/translation, the coupled linear
  solve (`Cluster.solve()`), and the field evaluation
  (`response.scatter(incident).efield(point)`) — is inside one autodiff
  trace.
- `advect.value_and_grad` computes `value` and its exact reverse-mode
  derivative with respect to `separation` in a single pass through this
  trace. This is an analytic derivative through the full multiple-scattering
  solve (via reverse-mode/pullback autodiff), not a finite-difference
  approximation and not a single-scattering/Born approximation.

## Checks performed

- Cross-checked `value` from the (non-differentiable) plain
  `treams_rs.Cluster` path against the `treams_rs.advect.Cluster` path for
  the example config: both give `1.1855506354526986` / `...93` (agree to
  machine precision).
- Central finite-difference check of `d(value)/d(separation)` with
  `h = 1e-6` on the example config and on two independently chosen
  configurations (different radius, epsilon, wavelength, lmax, point,
  separation). Analytic and finite-difference gradients agreed to
  ~1e-9 relative accuracy in all cases, e.g.:
  - example config: analytic `-0.4037254206171242`, FD `-0.40372542053912497`
  - alternate config (`radius=0.1, epsilon=[3,0.1], separation=0.45,
    wavelength=0.6, lmax=3, point=(0,0,0.5)`): analytic
    `-0.7309982468383783`, FD `-0.7309982468228782`.

## Example result

For the given example config
(`radius=0.08, epsilon=[4.0,0.04], separation=0.3, wavelength=0.72, lmax=2,
point=(0.05,0.02,0.28)`):

```json
{
  "value": 1.1855506354526986,
  "gradient": -0.4037254206171242
}
```

saved in `results.json`.

## Files

- `solution.py`: exposes `run(config) -> dict` and a CLI (`stdin` JSON config
  -> `stdout` JSON `{"value": ..., "gradient": ...}`).
- `results.json`: output for the example config above.
