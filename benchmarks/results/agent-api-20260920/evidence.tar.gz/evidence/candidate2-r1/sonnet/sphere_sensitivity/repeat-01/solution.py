"""Scattering efficiency and its gradient for a lossy sphere under +z, positive-helicity incidence.

Uses treams_rs for the analytic Mie-type T-matrix scattering calculation and its
`advect` adapter for reverse-mode automatic differentiation of the scattering
cross section and the pi*radius**2 normalization jointly, w.r.t. radius and
epsilon_real, holding epsilon_imag, wavelength and lmax fixed.
"""
import json
import math
import sys

import advect
import treams_rs.advect as adv


def _Q(radius, epsilon_real, epsilon_imag, k0, lmax):
    epsilon = advect.numpy.array(epsilon_real) + 1j * epsilon_imag
    tmat = adv.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=epsilon, polarization="helicity"
    )
    wave = adv.plane_wave([0, 0, 1], "positive_helicity", k0=k0, medium=1.0)
    cross_sections = tmat.cross_sections(wave)
    return cross_sections.scattering / (math.pi * radius ** 2)


def run(config):
    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax = int(config["lmax"])

    k0 = 2.0 * math.pi / wavelength

    def objective(radius, epsilon_real):
        return _Q(radius, epsilon_real, epsilon_imag, k0, lmax)

    Q, (dQ_dr, dQ_deps) = advect.value_and_grad(objective, argnums=(0, 1))(
        radius, epsilon_real
    )

    return {
        "Q": float(Q),
        "gradient": [float(dQ_dr), float(dQ_deps)],
    }


def main():
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
