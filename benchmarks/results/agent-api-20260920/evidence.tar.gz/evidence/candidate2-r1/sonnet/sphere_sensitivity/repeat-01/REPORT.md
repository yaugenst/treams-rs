# Scattering efficiency and gradient of a lossy sphere

## Problem
For a homogeneous, lossy dielectric sphere illuminated by a positive-helicity
plane wave propagating along +z in vacuum, compute the scattering efficiency

    Q = C_sca / (pi * radius**2)

and its gradient `[dQ/dradius, dQ/depsilon_real]`, holding `epsilon_imag`,
`wavelength` and `lmax` fixed.

## Units and conventions
- Lengths (`radius`, `wavelength`) are in micrometers. `1/radius` and
  `k0 = 2*pi/wavelength` share the same length unit, so `k0` is in
  rad/micrometer.
- `epsilon_real`/`epsilon_imag` form the relative (dimensionless) sphere
  permittivity `epsilon = epsilon_real + i*epsilon_imag`; `mu = 1`,
  `kappa = 0` (no chirality), and the exterior medium is vacuum
  (`epsilon = mu = 1`), per the problem statement.
- The T-matrix is built in the **helicity** basis (`polarization="helicity"`)
  so that "positive-helicity" illumination corresponds directly to the
  `positive_helicity` plane-wave polarization channel offered by treams-rs.
- Incidence direction is `[0, 0, 1]` (+z), as required.
- `C_sca` is the scattering cross section returned by
  `TMatrix.cross_sections(plane_wave)`, in micrometer^2 (area), consistent
  with the length unit above. `Q` is therefore dimensionless.

## Method
`treams_rs.advect.sphere_tmatrix` and `treams_rs.advect.plane_wave` are the
differentiable ("advect") counterparts of the plain `treams_rs` physics
functions; they trace the same native Mie/T-matrix scattering solver but
support forward/reverse-mode automatic differentiation through
`advect.value_and_grad`. `solution.py`:

1. Builds `k0 = 2*pi/wavelength`.
2. Defines `epsilon = epsilon_real + 1j*epsilon_imag` as an `advect`-traced
   array wrapping the (real, differentiable) `epsilon_real` argument, with
   `epsilon_imag` folded in as a fixed constant offset.
3. Computes `tmatrix.cross_sections(plane_wave).scattering`, divides by the
   *also-differentiated* normalization `pi*radius**2` (the geometric cross
   section), and returns this ratio `Q` as a scalar.
4. Calls `advect.value_and_grad(objective, argnums=(0, 1))(radius,
   epsilon_real)` to get `Q` and `[dQ/dradius, dQ/depsilon_real]` together in
   one reverse-mode pass, using treams-rs's analytic pullbacks (no finite
   differences are used to produce the returned numbers).

Both the numerator (`C_sca`) and the denominator (`pi*radius**2`) are
differentiated with respect to `radius`, as required by "differentiate the
normalization as well as the cross section."

## Verification
The analytic gradient was cross-checked against central finite differences
(`h = 1e-6`) of the same `Q(radius, epsilon_real)` function evaluated with the
plain (non-differentiable) `treams_rs` API, for both the example config and an
independent second config (`radius=0.15`, `epsilon_real=6.0`,
`epsilon_imag=0.3`, `wavelength=0.9`, `lmax=4`). Agreement was to ~6-7 significant
figures in both cases, confirming the analytic derivatives from `advect` are
correct. Finite differences are used here only for validation, not to supply
the returned gradient.

## Example result
For the example config
(`radius=0.1, epsilon_real=4.0, epsilon_imag=0.06, wavelength=0.72, lmax=3`):

```json
{"Q": 0.46337644643427434, "gradient": [18.65367030479629, 0.1997255464561844]}
```

saved in `results.json`.

## Usage
```
python3 solution.py < config.json
```
reads a JSON config dict from stdin and prints `{"Q": ..., "gradient": [...]}`
to stdout. `run(config)` is importable directly for programmatic use.
