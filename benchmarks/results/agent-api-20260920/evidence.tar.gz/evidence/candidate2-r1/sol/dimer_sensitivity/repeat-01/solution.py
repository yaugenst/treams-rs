"""Near-field intensity and analytic separation sensitivity for a sphere dimer."""

from __future__ import annotations

import json
import sys
from collections.abc import Mapping
from typing import Any

import advect as ad
import advect.numpy as anp
import numpy as np
import treams_rs.advect as tr


def run(config: Mapping[str, Any]) -> dict[str, float]:
    """Return total electric-field intensity and its separation derivative.

    Length inputs use micrometers.  The derivative therefore has units of
    inverse micrometers when the incident electric-field amplitude is one.
    """
    required = {"radius", "epsilon", "separation", "wavelength", "lmax", "point"}
    missing = required.difference(config)
    if missing:
        raise ValueError(f"missing configuration keys: {', '.join(sorted(missing))}")

    radius = float(config["radius"])
    wavelength = float(config["wavelength"])
    separation = float(config["separation"])
    lmax = int(config["lmax"])
    epsilon_parts = tuple(config["epsilon"])
    point_values = tuple(config["point"])

    if radius <= 0 or wavelength <= 0:
        raise ValueError("radius and wavelength must be positive")
    if lmax < 1 or lmax != config["lmax"]:
        raise ValueError("lmax must be a positive integer")
    if len(epsilon_parts) != 2:
        raise ValueError("epsilon must contain [real, imag]")
    if len(point_values) != 3:
        raise ValueError("point must contain three Cartesian coordinates")

    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    k0 = 2.0 * np.pi / wavelength
    point = anp.asarray([[float(x) for x in point_values]])

    # These two local T-matrices are identical and independent of separation.
    particle = tr.sphere_tmatrix(
        k0=k0, lmax=lmax, radius=radius, material=epsilon
    )
    incident = tr.plane_wave(
        [0.0, 0.0, 1.0], "positive_helicity", k0=k0
    )

    def objective(current_separation: Any) -> Any:
        zero = anp.asarray(0.0)
        positions = anp.stack(
            (
                anp.stack((-0.5 * current_separation, zero, zero)),
                anp.stack((0.5 * current_separation, zero, zero)),
            )
        )
        dimer = tr.Cluster([particle, particle], positions=positions)
        scattered_e = dimer.scatter(incident).efield(point)
        total_e = incident.efield(point) + scattered_e
        return anp.sum(anp.abs(total_e) ** 2)

    value, gradient = ad.value_and_grad(objective)(separation)
    return {"value": float(value), "gradient": float(gradient)}


def _main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
