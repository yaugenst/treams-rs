# Dimer near-field sensitivity

`solution.py` uses the public `treams_rs.advect` interface and Advect reverse
mode. Each sphere is represented by a helicity-basis spherical T-matrix, and
`Cluster.scatter` solves the coupled two-particle problem, including all
multiple scattering retained by the fixed `lmax`. The reported field is the
scattered field plus the incident plane wave.

All lengths are in micrometers. Thus `k0 = 2*pi/wavelength` is in inverse
micrometers. `epsilon = [real, imag]` is the relative complex permittivity;
vacuum exterior, relative permeability 1, and chirality 0 are used. The
incident wave travels in +z with positive helicity and unit electric-field
amplitude in the package convention. The scalar `value` is
`sum(abs(E_total)**2)` over the three Cartesian electric-field components at
the requested point. With that unit incident amplitude it is dimensionless,
and `gradient` is its derivative with respect to separation in um, hence has
units um^-1.

The centers are `(-separation/2, 0, 0)` and `(separation/2, 0, 0)`. Both center
motions are therefore included in the derivative while the observation point
and all other inputs remain fixed. The production derivative is an analytic
reverse-mode derivative through treams-rs native pullbacks; finite differences
are used only as an independent check.

For the supplied example, the analytic result is recorded in `results.json`.
A centered finite-difference check with steps 1e-4, 1e-5, and 1e-6 um converged
to the analytic gradient, and direct evaluation agreed with the value returned
alongside the gradient.
