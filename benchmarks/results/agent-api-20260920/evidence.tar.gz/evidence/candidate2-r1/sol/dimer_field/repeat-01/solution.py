"""Electromagnetic response of a two-sphere dimer using treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import numpy as np
import treams_rs as tr


def _positive_finite(value: Any, name: str) -> float:
    result = float(value)
    if not math.isfinite(result) or result <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return result


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Calculate total E fields and cross sections for a two-sphere dimer.

    Length inputs are in micrometers, so field sample coordinates are in
    micrometers and the returned cross sections are in square micrometers.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radii_raw = config["radii"]
    epsilon_raw = config["epsilon"]
    points = np.asarray(config["points"], dtype=float)
    if len(radii_raw) != 2 or len(epsilon_raw) != 2:
        raise ValueError("radii and epsilon must each contain two entries")
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("points must have shape (n, 3)")
    if not np.all(np.isfinite(points)):
        raise ValueError("points must be finite")

    radii = [_positive_finite(value, f"radii[{i}]") for i, value in enumerate(radii_raw)]
    separation = _positive_finite(config["separation"], "separation")
    wavelength = _positive_finite(config["wavelength"], "wavelength")
    lmax = config["lmax"]
    if isinstance(lmax, bool) or int(lmax) != lmax or not 1 <= int(lmax) <= 128:
        raise ValueError("lmax must be an integer from 1 through 128")
    lmax = int(lmax)
    if separation <= sum(radii):
        raise ValueError("the spheres must not overlap or touch")

    epsilon: list[complex] = []
    for i, pair in enumerate(epsilon_raw):
        if len(pair) != 2:
            raise ValueError(f"epsilon[{i}] must be [real, imag]")
        eps = complex(float(pair[0]), float(pair[1]))
        if not (math.isfinite(eps.real) and math.isfinite(eps.imag)):
            raise ValueError(f"epsilon[{i}] must be finite")
        epsilon.append(eps)

    k0 = 2.0 * math.pi / wavelength
    particles = [
        tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=eps,
        )
        for radius, eps in zip(radii, epsilon, strict=True)
    ]
    positions = [[-0.5 * separation, 0.0, 0.0], [0.5 * separation, 0.0, 0.0]]
    cluster = tr.Cluster(particles, positions=positions).solve()
    incident = tr.plane_wave(
        direction=[0.0, 0.0, 1.0],
        polarization="positive_helicity",
        k0=k0,
    )

    cross = cluster.cross_sections(incident)
    total_field = incident.efield(points) + cluster.scatter(incident).efield(points)

    return {
        "total_field_real": np.asarray(total_field.real, dtype=float).tolist(),
        "total_field_imag": np.asarray(total_field.imag, dtype=float).tolist(),
        "scattering": float(cross.scattering),
        "extinction": float(cross.extinction),
        "absorption": float(cross.absorption),
    }


def main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
