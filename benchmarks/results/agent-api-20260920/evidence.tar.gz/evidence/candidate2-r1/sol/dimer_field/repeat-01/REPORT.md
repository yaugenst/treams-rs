# Dimer field calculation

`solution.py` uses the public `treams_rs` API. Each sphere is represented by a
spherical T-matrix truncated at the requested `lmax`; `Cluster.solve()` then
includes all inter-sphere multiple-scattering orders within that fixed basis.
The reported electric field is the package-normalized positive-helicity plane
wave propagating along +z plus the solved cluster's outgoing field.

## Units and conventions

- All input lengths and point coordinates are in micrometers. The vacuum
  wavenumber is `k0 = 2*pi/wavelength` in inverse micrometers.
- Scattering, extinction, and absorption cross sections are in square
  micrometers. The package's default incident flux normalization (`0.5`) is
  used consistently by `cross_sections`.
- Permittivity is relative and is formed as `real + 1j*imag`. The exterior is
  vacuum; relative permeability is 1 and chirality is 0 by their API defaults.
- Sphere 0 is centered at `(-separation/2, 0, 0)` and sphere 1 at
  `(+separation/2, 0, 0)`, preserving the input radii/material order.
- Complex fields follow the package convention. The JSON stores Cartesian
  `(Ex, Ey, Ez)` components in separate real and imaginary arrays.

## Checks on the example

The CLI was run on the supplied example to produce `results.json`. Both field
arrays have shape 2-by-3 and all returned values are finite. The passive-loss
checks give positive scattering, extinction, and absorption. Energy balance is
satisfied to displayed precision:

`extinction - scattering = 0.002617602701932185`,

compared with the reported absorption `0.0026176027019321826` (absolute
difference about `2.6e-18`). Importing `run` and JSON serialization are also
checked directly.
