# Sphere scattering sensitivity

For the supplied example, the scattering efficiency is
`Q_sca = 0.46337644643427434`. Its gradient in the requested order is
`[18.65367030479629, 0.1997255464561844]`.

Lengths are in micrometers. Thus `k0 = 2 pi / wavelength` is in inverse
micrometers, the scattering cross section is in square micrometers, and
`Q_sca = C_sca / (pi radius^2)` is dimensionless. The radius derivative has
units of inverse micrometers; the derivative with respect to relative
permittivity is dimensionless because relative permittivity is dimensionless.

The sphere has relative permittivity
`epsilon_real + i epsilon_imag`, relative permeability 1, and chirality 0,
and is embedded in vacuum. Illumination propagates along +z and uses the
treams-rs `positive_helicity` convention. The reported finite `lmax` is held
fixed during differentiation, as are wavelength and `epsilon_imag`.

The value and both derivatives are computed with `advect.value_and_grad`
through the native analytic pullbacks of `treams_rs.advect.sphere_tmatrix`.
The area normalization remains inside the differentiated expression, so its
radius dependence is included. As a check only, centered finite differences
gave relative discrepancies of approximately `9.2e-12` for the radius
derivative (step `1e-6` micrometers) and `1.8e-10` for the permittivity
derivative (step `1e-5`). The unnormalized example scattering cross section
was `0.014557400399644607` square micrometers; dividing by `pi * 0.1^2`
reproduces the reported efficiency.
