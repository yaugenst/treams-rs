"""Scattering efficiency and analytic sensitivity of a lossy sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect
from treams_rs import advect as treams


_KEYS = ("radius", "epsilon_real", "epsilon_imag", "wavelength", "lmax")


def _validated(config: dict[str, Any]) -> tuple[float, float, float, float, int]:
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")
    missing = [key for key in _KEYS if key not in config]
    if missing:
        raise KeyError(f"missing config key(s): {', '.join(missing)}")

    radius = float(config["radius"])
    epsilon_real = float(config["epsilon_real"])
    epsilon_imag = float(config["epsilon_imag"])
    wavelength = float(config["wavelength"])
    lmax_value = config["lmax"]
    lmax = int(lmax_value)

    values = (radius, epsilon_real, epsilon_imag, wavelength)
    if not all(math.isfinite(value) for value in values):
        raise ValueError("all continuous inputs must be finite")
    if radius <= 0 or wavelength <= 0:
        raise ValueError("radius and wavelength must be positive")
    if isinstance(lmax_value, bool) or lmax != lmax_value or lmax < 1:
        raise ValueError("lmax must be a positive integer")
    return radius, epsilon_real, epsilon_imag, wavelength, lmax


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Return Q_sca and [dQ/dradius, dQ/dRe(epsilon)].

    The two derivatives are evaluated by Advect reverse-mode AD through
    treams-rs's native analytic pullbacks.  All other inputs are fixed.
    """
    radius, epsilon_real, epsilon_imag, wavelength, lmax = _validated(config)
    k0 = 2.0 * math.pi / wavelength

    def efficiency(r: Any, eps_real: Any) -> Any:
        response = treams.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=r,
            material=eps_real + 1j * epsilon_imag,
        )
        incident = treams.plane_wave(
            [0.0, 0.0, 1.0],
            "positive_helicity",
            k0=k0,
        )
        scattering = response.cross_sections(incident).scattering
        # Keeping the denominator inside the differentiated function includes
        # its -2 * C_sca / (pi * r**3) contribution to dQ/dr.
        return scattering / (math.pi * r * r)

    value, gradient = advect.value_and_grad(efficiency, argnums=(0, 1))(
        radius, epsilon_real
    )
    return {
        "value": float(value),
        "gradient": [float(gradient[0]), float(gradient[1])],
    }


def _main() -> None:
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    _main()
