# Core-shell sphere spectrum

`solution.py` uses the public `treams_rs.multilayer_sphere_tmatrix` interface.
Each vacuum wavelength is converted to `k0 = 2*pi / wavelength`, and the
library's rotationally and polarization-averaged cross sections are returned
in the original wavelength order.

## Units and conventions

- Radii and vacuum wavelengths are in micrometers; scattering, extinction,
  and absorption cross sections are therefore in square micrometers.
- `radii[i]` is the increasing outer boundary of `epsilon_layers[i]`. The
  exterior permittivity is passed separately as the embedding medium and is
  not added as a finite layer.
- Permittivity pairs mean `real + i*imag`. Relative permeability is 1 and
  chirality is 0 for every region. With the treams-rs convention, the positive
  imaginary parts in the example represent passive loss.
- Results use the requested fixed multipole cutoff `lmax`. Because a sphere is
  rotationally symmetric, the library average also removes dependence on
  incident orientation and polarization.

## Checks on the example

- All scattering, extinction, and absorption values are positive.
- For every wavelength, `extinction - scattering - absorption` is zero at the
  returned floating-point precision.
- Repeating with `lmax = 5` changes extinction relative to that result by
  `2.57e-6`, `8.58e-7`, and `3.19e-7` at wavelengths 0.58, 0.70, and 0.82 um,
  respectively. This is a convergence check only; `results.json` uses the
  requested `lmax = 4`.
