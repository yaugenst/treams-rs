"""Rotationally averaged cross sections of a concentric multilayer sphere."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping, Sequence
from numbers import Real
from typing import Any

import treams_rs


def _permittivity(value: Any, name: str) -> complex:
    """Convert a JSON real or ``[real, imag]`` pair to a finite complex value."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number or a [real, imag] pair")
    if isinstance(value, Real):
        result = complex(float(value))
    elif (
        isinstance(value, Sequence)
        and not isinstance(value, (str, bytes))
        and len(value) == 2
        and all(isinstance(part, Real) and not isinstance(part, bool) for part in value)
    ):
        result = complex(float(value[0]), float(value[1]))
    else:
        raise ValueError(f"{name} must be a number or a [real, imag] pair")
    if not (math.isfinite(result.real) and math.isfinite(result.imag)):
        raise ValueError(f"{name} must be finite")
    return result


def _positive_floats(values: Any, name: str) -> list[float]:
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
        raise ValueError(f"{name} must be a list")
    result: list[float] = []
    for i, value in enumerate(values):
        if isinstance(value, bool) or not isinstance(value, Real):
            raise ValueError(f"{name}[{i}] must be a number")
        number = float(value)
        if not math.isfinite(number) or number <= 0:
            raise ValueError(f"{name}[{i}] must be finite and positive")
        result.append(number)
    if not result:
        raise ValueError(f"{name} must not be empty")
    return result


def run(config: Mapping[str, Any]) -> dict[str, list[float]]:
    """Calculate averaged scattering, extinction, and absorption cross sections.

    Length inputs are in micrometers, so all returned cross sections are in
    square micrometers. The supplied wavelengths are vacuum wavelengths.
    """
    if not isinstance(config, Mapping):
        raise ValueError("config must be a dictionary")

    radii = _positive_floats(config.get("radii"), "radii")
    if any(inner >= outer for inner, outer in zip(radii, radii[1:])):
        raise ValueError("radii must be strictly increasing outer boundaries")

    raw_layers = config.get("epsilon_layers")
    if not isinstance(raw_layers, Sequence) or isinstance(raw_layers, (str, bytes)):
        raise ValueError("epsilon_layers must be a list")
    if len(raw_layers) != len(radii):
        raise ValueError("epsilon_layers must contain one permittivity per radius")
    materials = [
        _permittivity(value, f"epsilon_layers[{i}]")
        for i, value in enumerate(raw_layers)
    ]

    medium = _permittivity(config.get("epsilon_medium"), "epsilon_medium")
    wavelengths = _positive_floats(config.get("wavelengths"), "wavelengths")

    lmax = config.get("lmax")
    if isinstance(lmax, bool) or not isinstance(lmax, int) or lmax < 1 or lmax > 128:
        raise ValueError("lmax must be an integer from 1 through 128")

    result = {"scattering": [], "extinction": [], "absorption": []}
    for wavelength in wavelengths:
        response = treams_rs.multilayer_sphere_tmatrix(
            k0=2 * math.pi / wavelength,
            lmax=lmax,
            radii=radii,
            materials=materials,
            medium=medium,
        )
        cross_sections = response.average_cross_sections
        result["scattering"].append(float(cross_sections.scattering))
        result["extinction"].append(float(cross_sections.extinction))
        result["absorption"].append(float(cross_sections.absorption))
    return result


def _main() -> None:
    config = json.load(sys.stdin)
    print(json.dumps(run(config), allow_nan=False))


if __name__ == "__main__":
    _main()
