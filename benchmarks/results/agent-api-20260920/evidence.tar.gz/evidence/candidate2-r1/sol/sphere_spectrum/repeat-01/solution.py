"""Spectrum of a homogeneous dielectric sphere computed with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import treams_rs as tr


def run(config: Mapping[str, Any]) -> dict[str, list[float]]:
    """Return sphere cross sections and scattering efficiency.

    Length inputs are interpreted in micrometers, so the three cross sections
    are returned in square micrometers. Results follow the supplied wavelength
    order.
    """
    radius = float(config["radius"])
    epsilon_parts = config["epsilon"]
    wavelengths = [float(value) for value in config["wavelengths"]]
    lmax = int(config["lmax"])

    if radius <= 0 or not math.isfinite(radius):
        raise ValueError("radius must be a finite positive number")
    if len(epsilon_parts) != 2:
        raise ValueError("epsilon must contain [real, imag]")
    epsilon = complex(float(epsilon_parts[0]), float(epsilon_parts[1]))
    if not (math.isfinite(epsilon.real) and math.isfinite(epsilon.imag)):
        raise ValueError("epsilon components must be finite")
    if lmax < 1 or lmax != config["lmax"]:
        raise ValueError("lmax must be a positive integer")
    if any(wavelength <= 0 or not math.isfinite(wavelength) for wavelength in wavelengths):
        raise ValueError("wavelengths must be finite positive numbers")

    scattering: list[float] = []
    extinction: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        sphere = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=radius,
            material=epsilon,
        )
        incident = tr.plane_wave(
            direction=[0.0, 0.0, 1.0],
            polarization="positive_helicity",
            k0=k0,
        )
        cross = sphere.cross_sections(incident)
        scattering.append(float(cross.scattering))
        extinction.append(float(cross.extinction))
        absorption.append(float(cross.absorption))

    geometric_area = math.pi * radius * radius
    efficiency = [value / geometric_area for value in scattering]
    return {
        "scattering": scattering,
        "extinction": extinction,
        "absorption": absorption,
        "efficiency": efficiency,
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
