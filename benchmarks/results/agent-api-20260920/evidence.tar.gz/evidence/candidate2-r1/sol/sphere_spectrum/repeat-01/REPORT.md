# Homogeneous sphere spectrum

`solution.py` constructs a `treams_rs.sphere_tmatrix` independently at each
input wavelength, using the requested `lmax`. The illumination is a plane wave
travelling along +z with `positive_helicity` polarization. The sphere is
nonmagnetic and achiral, and the surrounding medium is vacuum (the defaults of
the public treams-rs sphere API).

## Units and conventions

- Radius and vacuum wavelength are in micrometers; `k0 = 2*pi/wavelength` is
  therefore in inverse micrometers.
- `epsilon = [real, imag]` is converted directly to the complex relative
  permittivity `real + i*imag`. It is not treated as a refractive index.
- Scattering, extinction, and absorption are cross-sectional areas in square
  micrometers.
- Efficiency is dimensionless and is defined here as the scattering cross
  section divided by `pi*radius**2`.
- Every returned list retains the input wavelength order.

## Checks

For the supplied example, the CLI output was captured in `results.json`.
Absorption is positive at every wavelength, as expected for the specified
passive material. The optical power identity
`extinction = scattering + absorption` holds for every entry (the largest
floating-point residual is below `3e-17` square micrometers). All output values
are finite JSON numbers.
