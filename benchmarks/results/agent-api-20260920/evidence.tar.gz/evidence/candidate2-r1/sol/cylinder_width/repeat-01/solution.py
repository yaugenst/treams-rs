"""Cross widths of a homogeneous infinite cylinder computed with treams-rs."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _finite_real(value: Any, name: str) -> float:
    """Convert a JSON number to a finite float, rejecting booleans."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite real number")
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must be a finite real number") from error
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite real number")
    return result


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return cylinder scattering, extinction, and absorption cross widths.

    The returned lists retain the order of ``config["wavelengths"]``. All
    lengths (radius, wavelengths, and resulting widths) are in micrometers.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    radius = _finite_real(config.get("radius"), "radius")
    if radius <= 0:
        raise ValueError("radius must be positive")

    epsilon_parts = config.get("epsilon")
    if not isinstance(epsilon_parts, (list, tuple)) or len(epsilon_parts) != 2:
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _finite_real(epsilon_parts[0], "epsilon[0]"),
        _finite_real(epsilon_parts[1], "epsilon[1]"),
    )

    mmax_value = config.get("mmax")
    if isinstance(mmax_value, bool) or not isinstance(mmax_value, int):
        raise ValueError("mmax must be a nonnegative integer")
    if mmax_value < 0:
        raise ValueError("mmax must be a nonnegative integer")

    wavelength_values = config.get("wavelengths")
    if not isinstance(wavelength_values, (list, tuple)) or not wavelength_values:
        raise ValueError("wavelengths must be a nonempty list")
    wavelengths = [
        _finite_real(value, f"wavelengths[{index}]")
        for index, value in enumerate(wavelength_values)
    ]
    if any(value <= 0 for value in wavelengths):
        raise ValueError("all wavelengths must be positive")

    result: dict[str, list[float]] = {
        "scattering": [],
        "extinction": [],
        "absorption": [],
    }
    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength
        cylinder = tr.cylinder_tmatrix(
            k0=k0,
            kz=[0.0],
            mmax=mmax_value,
            radius=radius,
            material=epsilon,
            medium=1.0,
            polarization="helicity",
        )
        incident = tr.plane_wave(
            [1.0, 0.0, 0.0],
            "positive_helicity",
            k0=k0,
            medium=1.0,
        )
        widths = cylinder.cross_widths(incident)
        result["scattering"].append(float(widths.scattering))
        result["extinction"].append(float(widths.extinction))
        result["absorption"].append(float(widths.absorption))

    return result


def main() -> None:
    """Read one JSON configuration from stdin and emit one JSON result."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
