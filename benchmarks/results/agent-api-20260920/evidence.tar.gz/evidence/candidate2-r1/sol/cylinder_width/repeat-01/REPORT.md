# Cylinder cross-width calculation

`solution.py` uses the public `treams_rs` API to construct the homogeneous
infinite-cylinder T-matrix independently at each requested wavelength. The
vacuum angular wavenumber is `k0 = 2 pi / wavelength`; the cylindrical axial
wavenumber is fixed to `kz = 0`, and azimuthal orders from `-mmax` through
`+mmax` are retained. The incident plane wave propagates along `+x` and uses
the package's `positive_helicity` convention.

Radius and vacuum wavelength are in micrometers. Relative permittivity is
formed as `epsilon[0] + i epsilon[1]`; relative permeability is one, chirality
is zero, and the exterior medium is vacuum. The returned scattering,
extinction, and absorption values are cross widths in micrometers (power per
unit cylinder length divided by incident intensity), not cross sections and
not normalized by any sphere area. Output lists correspond element-for-element
to the input wavelength list and retain its order.

Checks on the example confirmed that all values are finite and positive,
absorption equals extinction minus scattering, and passive loss gives
nonnegative absorption. Repeating the calculation with `mmax = 5` changed the
reported widths by at most `2.21e-9` micrometers (the largest change was in
extinction). The executed `mmax = 4` example output is saved in `results.json`.
