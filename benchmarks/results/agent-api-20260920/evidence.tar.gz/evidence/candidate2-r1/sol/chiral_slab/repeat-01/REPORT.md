# Chiral slab calculation

`solution.py` uses the public `treams_rs.slab` scattering-matrix API and its
native power normalization. Lengths (thickness and vacuum wavelength) are in
micrometers, so `k0 = 2*pi/wavelength` is in inverse micrometers. Epsilon,
mu, and kappa are relative, dimensionless material parameters. The slab uses
`mu = 1`; both exterior half-spaces are vacuum.

The normal is +z and illumination enters from the negative-z side, propagating
along +z. Results are power fractions, not squared unnormalized amplitudes.
Every output row follows the input wavelength order, and its columns are
positive helicity followed by negative helicity. The complex-permittivity
convention has positive imaginary epsilon for passive loss. Kappa is passed
directly as the package's reciprocal-material chirality parameter.

Checks performed:

- For every example wavelength and helicity, `T + R + A` is 1 to floating-point
  precision; all reported fractions are between 0 and 1.
- A vacuum slab (`epsilon = [1, 0]`, `kappa = 0`) gives unit transmission and
  zero reflection/absorption to numerical precision.
- A lossless dielectric test gives zero absorption to numerical precision.
- Positive and negative helicity powers in the example agree to roundoff. This
  is expected for real kappa in this uniform, normally illuminated slab:
  chirality changes phase, while both helicities have the same impedance and
  material attenuation.
