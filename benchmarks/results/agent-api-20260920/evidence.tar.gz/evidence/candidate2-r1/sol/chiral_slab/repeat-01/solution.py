"""Power fractions for normal incidence on a reciprocal chiral slab."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import treams_rs as tr


def _finite_number(value: Any, name: str) -> float:
    """Convert a JSON number to a finite float, rejecting booleans."""
    if isinstance(value, bool):
        raise TypeError(f"{name} must be a number")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must be a number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def run(config: dict[str, Any]) -> dict[str, list[list[float]]]:
    """Compute slab transmission, reflection, and absorption power fractions.

    Rows correspond to ``config["wavelengths"]``.  Each row is ordered as
    ``[positive helicity, negative helicity]``.
    """
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")

    thickness = _finite_number(config["thickness"], "thickness")
    if thickness < 0:
        raise ValueError("thickness must be nonnegative")

    epsilon_parts = config["epsilon"]
    if (
        not isinstance(epsilon_parts, (list, tuple))
        or len(epsilon_parts) != 2
    ):
        raise ValueError("epsilon must be [real, imag]")
    epsilon = complex(
        _finite_number(epsilon_parts[0], "epsilon[0]"),
        _finite_number(epsilon_parts[1], "epsilon[1]"),
    )
    kappa = _finite_number(config["kappa"], "kappa")

    wavelengths_raw = config["wavelengths"]
    if not isinstance(wavelengths_raw, (list, tuple)):
        raise TypeError("wavelengths must be a list")
    wavelengths = [
        _finite_number(value, f"wavelengths[{index}]")
        for index, value in enumerate(wavelengths_raw)
    ]
    if any(value <= 0 for value in wavelengths):
        raise ValueError("wavelengths must be positive")

    # PlaneWavePorts.default orders its channels by mode labels (1, 0), while
    # incident coefficient vectors select positive helicity with [0, 1].  This
    # convention is specified by the public slab API.
    ports = tr.PlaneWavePorts.default([0.0, 0.0])
    material = tr.Material(epsilon, 1.0, kappa)
    incidents = ([0.0, 1.0], [1.0, 0.0])  # positive, then negative helicity

    transmission: list[list[float]] = []
    reflection: list[list[float]] = []
    absorption: list[list[float]] = []

    for wavelength in wavelengths:
        network = tr.slab(
            basis=ports,
            k0=math.tau / wavelength,
            thickness=thickness,
            material=material,
            negative_medium=1.0,
            positive_medium=1.0,
            polarization="helicity",
        )
        balances = [
            network.power(incident, side="negative") for incident in incidents
        ]
        transmission.append([float(value.transmission) for value in balances])
        reflection.append([float(value.reflection) for value in balances])
        absorption.append([float(value.absorption) for value in balances])

    return {
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main() -> None:
    """Read one JSON config from stdin and write one JSON result to stdout."""
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout, allow_nan=False, separators=(",", ":"))
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
