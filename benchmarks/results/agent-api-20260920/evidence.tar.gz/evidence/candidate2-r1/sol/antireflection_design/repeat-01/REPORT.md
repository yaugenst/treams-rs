# Antireflection optimization report

`solution.py` models one homogeneous coating with `treams_rs.advect.slab` and
uses `advect.value_and_grad` to obtain the native analytic derivative of
reflected power. The bounded optimizer is projected steepest descent with an
Armijo line search and a one-dimensional Barzilai--Borwein step estimate. It
starts at `initial_thickness`; a deterministic multistart fallback handles the
exceptional case of an initial stationary maximum. No closed-form coating
thickness is used.

## Units and conventions

- Wavelength, coating thickness, and bounds are in micrometers. Consequently,
  `k0 = 2*pi/wavelength` is in inverse micrometers.
- `epsilon` and `substrate_epsilon` are relative permittivities, not refractive
  indices. All media are lossless, with relative permeability 1 and chirality
  0. The negative-side exterior is vacuum and the supplied substrate is the
  positive-side exterior; there is no vacuum gap.
- The slab normal is +z. Illumination is the normal-incidence positive-helicity
  port incident from the negative side and propagating toward +z. At normal
  incidence the other helicity gives the same reflected power for these
  isotropic materials.
- `reflection` and `initial_reflection` are dimensionless incident-normalized
  power fractions. `gradient` is `d(reflection)/d(thickness)` in inverse
  micrometers. `loss_history` contains reflected powers at accepted iterates,
  beginning with the supplied initial thickness.

## Checks

For the example, the reflected power fell from `0.09594027275235116` to
`4.857221902264943e-33` at a thickness of `0.11666666666666667` micrometers.
The final analytic gradient is `-2.8626051989907565e-16` per micrometer.

As a diagnostic only, centered finite differences with a `1e-6` micrometer
step were compared with the analytic gradients. At thickness `0.05`, the
analytic and finite-difference values were `-1.862590377991575` and
`-1.862590377758877`; at thickness `0.116`, they were
`-0.041959176093962464` and `-0.04195917608603559`. Finite differences are not
used by the optimizer or in the returned derivative.
