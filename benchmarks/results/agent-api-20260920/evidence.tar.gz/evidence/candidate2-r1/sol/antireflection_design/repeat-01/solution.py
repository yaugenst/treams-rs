"""Optimize a single antireflection layer with treams-rs analytic gradients."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import advect as ad
import treams_rs.advect as tr


def _inputs(config: Mapping[str, Any]) -> tuple[float, float, float, float, float, float]:
    """Validate and normalize the scalar, lossless problem description."""
    required = (
        "wavelength",
        "epsilon",
        "substrate_epsilon",
        "initial_thickness",
        "bounds",
    )
    missing = [key for key in required if key not in config]
    if missing:
        raise ValueError(f"missing configuration keys: {', '.join(missing)}")

    try:
        wavelength = float(config["wavelength"])
        epsilon = float(config["epsilon"])
        substrate = float(config["substrate_epsilon"])
        initial = float(config["initial_thickness"])
        bounds = config["bounds"]
        if len(bounds) != 2:
            raise ValueError
        lower, upper = (float(bounds[0]), float(bounds[1]))
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("inputs must be finite real scalars and bounds must have length two") from exc

    values = (wavelength, epsilon, substrate, initial, lower, upper)
    if not all(math.isfinite(value) for value in values):
        raise ValueError("all inputs must be finite")
    if wavelength <= 0 or epsilon <= 0 or substrate <= 0:
        raise ValueError("wavelength and lossless permittivities must be positive")
    if not (0 <= lower < upper):
        raise ValueError("bounds must satisfy 0 <= lower < upper")
    if not lower <= initial <= upper:
        raise ValueError("initial_thickness must lie within bounds")
    return values


def run(config: Mapping[str, Any]) -> dict[str, Any]:
    """Return a bounded, analytic-gradient optimization of reflected power."""
    wavelength, epsilon, substrate, initial, lower, upper = _inputs(config)
    k0 = 2.0 * math.pi / wavelength
    ports = tr.PlaneWavePorts.default([0.0, 0.0])

    def reflected_power(thickness: Any) -> Any:
        network = tr.slab(
            basis=ports,
            k0=k0,
            thickness=thickness,
            material=epsilon,
            negative_medium=1.0,
            positive_medium=substrate,
        )
        # [0, 1] is the positive-helicity normal-incidence port.  Incidence
        # from the negative side propagates along +z.
        return network.power([0.0, 1.0], side="negative").reflection

    value_and_gradient = ad.value_and_grad(reflected_power)

    def evaluate(x: float) -> tuple[float, float]:
        value, gradient = value_and_gradient(float(x))
        return float(value), float(gradient)

    width = upper - lower
    gradient_tolerance = 1e-11 / max(width, 1e-12)

    def descend(seed: float) -> tuple[float, float, float, list[float]]:
        """Run one projected analytic-gradient descent from ``seed``."""
        x = seed
        loss, gradient = evaluate(x)
        local_history = [loss]
        # A Barzilai--Borwein inverse-curvature estimate accelerates the
        # one-dimensional convergence after the first accepted step.
        step_scale = 0.25 * width / max(abs(gradient), 1.0)
        for _ in range(200):
            if abs(gradient) <= gradient_tolerance:
                break

            old_x, old_loss, old_gradient = x, loss, gradient
            trial_scale = step_scale
            accepted = False
            for _ in range(60):
                trial_x = min(upper, max(lower, old_x - trial_scale * old_gradient))
                displacement = trial_x - old_x
                if displacement == 0.0:
                    break
                trial_loss, trial_gradient = evaluate(trial_x)
                # Projected Armijo condition using the actual displacement.
                if trial_loss <= old_loss + 1e-4 * old_gradient * displacement:
                    x, loss, gradient = trial_x, trial_loss, trial_gradient
                    local_history.append(loss)
                    accepted = True
                    break
                trial_scale *= 0.5

            if not accepted:
                break

            s = x - old_x
            y = gradient - old_gradient
            if s * y > 0.0:
                step_scale = min(10.0 * width, max(1e-14, s / y))
            else:
                step_scale = min(
                    2.0 * trial_scale, width / max(abs(gradient), 1.0)
                )
        return x, loss, gradient, local_history

    # The requested initial point is always the first optimizer evaluation.
    x, loss, gradient, history = descend(initial)
    initial_loss = history[0]

    # Exact interference maxima have zero first derivative.  If the requested
    # start lands on one (or a local bound solution is inadequate), use a small
    # deterministic multistart set, then continue with analytic-gradient steps.
    if loss >= 1e-7:
        candidates = [lower + width * i / 32.0 for i in range(33)]
        seed, seed_loss = min(
            ((candidate, evaluate(candidate)[0]) for candidate in candidates),
            key=lambda item: item[1],
        )
        trial_x, trial_loss, trial_gradient, trial_history = descend(seed)
        if trial_loss < loss:
            x, loss, gradient = trial_x, trial_loss, trial_gradient
            if seed_loss < history[-1]:
                history.extend(trial_history)
            else:
                history.extend(trial_history[1:])

    # At an active bound only the feasible, projected derivative must vanish.
    projected_gradient = gradient
    if (x <= lower and gradient > 0.0) or (x >= upper and gradient < 0.0):
        projected_gradient = 0.0
    if loss >= 1e-7:
        raise RuntimeError(
            "bounded gradient optimization could not reach reflected power below 1e-7; "
            f"best value was {loss:.6g} at thickness {x:.6g}"
        )
    if abs(projected_gradient) > 1e-7:
        raise RuntimeError("optimizer stopped before satisfying first-order stationarity")

    return {
        "thickness": x,
        "reflection": loss,
        "initial_reflection": initial_loss,
        "gradient": gradient,
        "loss_history": history,
    }


def main() -> None:
    """Read one JSON configuration from stdin and emit one JSON result."""
    config = json.load(sys.stdin)
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
