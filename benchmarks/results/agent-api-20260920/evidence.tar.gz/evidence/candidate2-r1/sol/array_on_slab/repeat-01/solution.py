"""Scattering of a square sphere array above a dielectric slab."""

from __future__ import annotations

import json
import math
import sys
from collections.abc import Mapping
from typing import Any

import treams_rs as tr


_SCALAR_KEYS = (
    "radius",
    "sphere_epsilon",
    "period",
    "gap",
    "slab_thickness",
    "slab_epsilon",
)


def _real_scalar(config: Mapping[str, Any], key: str) -> float:
    """Return a finite real scalar from the configuration."""
    if key not in config:
        raise ValueError(f"missing configuration key: {key}")
    value = config[key]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{key} must be a real number")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{key} must be finite")
    return result


def _validate(config: Mapping[str, Any]) -> tuple[dict[str, float], list[float], int]:
    if not isinstance(config, Mapping):
        raise TypeError("config must be a dictionary")

    values = {key: _real_scalar(config, key) for key in _SCALAR_KEYS}
    if values["radius"] <= 0:
        raise ValueError("radius must be positive")
    if values["period"] <= 0:
        raise ValueError("period must be positive")
    if values["gap"] < 0 or values["slab_thickness"] < 0:
        raise ValueError("gap and slab_thickness must be nonnegative")

    if "lmax" not in config:
        raise ValueError("missing configuration key: lmax")
    lmax_value = config["lmax"]
    if isinstance(lmax_value, bool) or not isinstance(lmax_value, int):
        raise TypeError("lmax must be an integer")
    lmax = int(lmax_value)
    if lmax < 1:
        raise ValueError("lmax must be at least 1")

    if "wavelengths" not in config:
        raise ValueError("missing configuration key: wavelengths")
    raw_wavelengths = config["wavelengths"]
    if not isinstance(raw_wavelengths, (list, tuple)) or not raw_wavelengths:
        raise TypeError("wavelengths must be a nonempty list")
    wavelengths: list[float] = []
    for index, value in enumerate(raw_wavelengths):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"wavelengths[{index}] must be a real number")
        wavelength = float(value)
        if not math.isfinite(wavelength) or wavelength <= 0:
            raise ValueError(f"wavelengths[{index}] must be finite and positive")
        if wavelength <= values["period"]:
            raise ValueError(
                "every wavelength must exceed the period when only the zeroth "
                "diffraction order is retained"
            )
        wavelengths.append(wavelength)

    return values, wavelengths, lmax


def run(config: dict[str, Any]) -> dict[str, list[float]]:
    """Return wavelength-ordered power fractions for positive-helicity incidence."""
    values, wavelengths, lmax = _validate(config)

    # One transverse Bloch vector and two helicities: the zeroth-order ports.
    ports = tr.PlaneWavePorts.default([0.0, 0.0])
    lattice = tr.Lattice.square(values["period"])
    incident = [0.0, 1.0]  # Positive helicity in the documented default port basis.

    transmission: list[float] = []
    reflection: list[float] = []
    absorption: list[float] = []

    for wavelength in wavelengths:
        k0 = 2.0 * math.pi / wavelength

        sphere = tr.sphere_tmatrix(
            k0=k0,
            lmax=lmax,
            radius=values["radius"],
            material=values["sphere_epsilon"],
        )
        array = tr.solve_periodic(
            sphere,
            lattice=lattice,
            kpar=[0.0, 0.0],
        ).to_smatrix(ports)

        slab = tr.slab(
            k0=k0,
            basis=ports,
            thickness=values["slab_thickness"],
            material=values["slab_epsilon"],
        )
        gap = tr.propagation(
            k0=k0,
            basis=ports,
            distance=values["gap"],
        )
        network = tr.stack([slab, gap, array])
        power = network.power(incident, side="negative")

        transmission.append(float(power.transmission))
        reflection.append(float(power.reflection))
        absorption.append(float(power.absorption))

    return {
        "wavelengths": wavelengths,
        "transmission": transmission,
        "reflection": reflection,
        "absorption": absorption,
    }


def main() -> None:
    config = json.load(sys.stdin)
    result = run(config)
    json.dump(result, sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
