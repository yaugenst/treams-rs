# Array-over-slab scattering

`solution.py` uses `treams_rs` for the sphere T-matrix, the full periodic
multiple-scattering solve, planar scattering matrices, and their cascade. For
each input wavelength it constructs the network in increasing-z order as

`dielectric slab -> vacuum propagation gap -> periodic sphere array`.

## Units and conventions

- All input lengths and wavelengths are in micrometers. Accordingly,
  `k0 = 2*pi/wavelength` is in inverse micrometers.
- `sphere_epsilon` and `slab_epsilon` are relative permittivities, not
  refractive indices. Relative permeability is one and chirality is zero.
- The slab's two exterior media, the propagation gap, the sphere background,
  and both network exterior half-spaces are vacuum.
- The square lattice lies in the xy plane, has the supplied period, and uses
  Bloch vector `(0, 0)`. `PlaneWavePorts.default([0, 0])` retains only the
  zeroth diffraction order and both helicities.
- Illumination enters on the negative-z side, propagates along +z, and has
  positive helicity. The gap distance runs from the slab top to the
  sphere-center plane, as required by the periodic-array S-matrix convention.
- Transmission and reflection are outgoing powers normalized by incident
  flux. Absorption is `1 - transmission - reflection`.

## Checks

The example was run through the JSON CLI. All wavelengths exceed the period,
so no nonzero diffraction order propagates. Both supplied permittivities are
real; the computed example satisfies `T + R = 1` to about `1e-15`, and the
reported absorption is correspondingly at floating-point roundoff. The code
also validates finite scalar inputs, positive geometric scales and wavelengths,
a fixed positive integer `lmax`, and the stated subwavelength condition.
