# Radius inverse-design report

`solution.py` models a homogeneous, isotropic, nonmagnetic sphere with relative
permittivity `epsilon`, relative permeability 1, chirality 0, and a vacuum
exterior. Lengths (radius and wavelength) are in micrometers, so the vacuum
angular wavenumber supplied to treams-rs is

\[
k_0 = 2\pi/\lambda \quad [\mathrm{micrometer}^{-1}].
\]

The treams-rs sphere T-matrix is truncated at the configured `lmax`. A unit
positive-helicity plane wave propagating along +z is used; for an isotropic
sphere the scattering result is independent of this orientation and helicity.
The scattering efficiency follows the usual dimensionless convention

\[
Q_\mathrm{sca}=C_\mathrm{sca}/(\pi r^2),
\]

where `cross_sections(...).scattering` supplies the area-valued scattering
cross section. The optimized objective is the requested mean squared relative
residual over wavelengths.

All objective derivatives are computed with `advect.value_and_grad` around
the public `treams_rs.advect` API. That path uses the package's native
pullbacks for the sphere scattering calculation. Optimization is performed in
a dimensionless bounded-radius coordinate using an inverse-BFGS/secant step
and an analytic-gradient Armijo line search. Trial points are clipped to the
configured bounds.

For the supplied example, execution produced radius
`0.10999999999990015` micrometers and loss `1.3297798489611956e-23`. The final
efficiencies agree with the targets to about 6e-12 absolute or better. As a
derivative diagnostic only, at radius 0.1 micrometers the analytic loss
gradient was `-17.129731746670046` per micrometer, while a centered finite
difference with step `1e-7` micrometers gave `-17.129731747292375`. Synthetic
recovery checks at radii 0.065, 0.09, 0.12, and 0.135 micrometers all recovered
the generating radius to better than 5e-14 micrometers with losses below
3e-24. Finite differences are not used by the optimizer or returned gradient.
