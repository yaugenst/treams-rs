"""Radius inversion for scattering efficiencies of a dielectric sphere."""

from __future__ import annotations

import json
import math
import sys
from typing import Any

import advect as ad
import advect.numpy as anp
import numpy as np
import treams_rs.advect as tr


def _validated(config: dict[str, Any]) -> tuple[float, int, np.ndarray, float, float, float, np.ndarray]:
    """Validate and normalize the small, fixed input schema."""
    epsilon = float(config["epsilon"])
    lmax = int(config["lmax"])
    wavelengths = np.asarray(config["wavelengths"], dtype=float)
    initial = float(config["initial_radius"])
    bounds = np.asarray(config["bounds"], dtype=float)
    targets = np.asarray(config["target_efficiencies"], dtype=float)

    if not math.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("epsilon must be finite and positive")
    if lmax < 1 or lmax != config["lmax"]:
        raise ValueError("lmax must be a positive integer")
    if wavelengths.ndim != 1 or len(wavelengths) == 0:
        raise ValueError("wavelengths must be a nonempty one-dimensional sequence")
    if targets.shape != wavelengths.shape:
        raise ValueError("target_efficiencies must match wavelengths")
    if bounds.shape != (2,):
        raise ValueError("bounds must contain exactly two values")
    lower, upper = map(float, bounds)
    if (
        not np.all(np.isfinite(wavelengths))
        or np.any(wavelengths <= 0)
        or not np.all(np.isfinite(targets))
        or np.any(targets <= 0)
        or not math.isfinite(lower)
        or not math.isfinite(upper)
        or lower <= 0
        or lower >= upper
        or not lower <= initial <= upper
    ):
        raise ValueError("require positive wavelengths/targets and valid positive radius bounds")
    return epsilon, lmax, wavelengths, initial, lower, upper, targets


def run(config: dict[str, Any]) -> dict[str, Any]:
    """Fit the sphere radius and return JSON-compatible optimization results."""
    epsilon, lmax, wavelengths, initial, lower, upper, targets = _validated(config)
    k0s = 2.0 * np.pi / wavelengths

    def efficiencies(radius: Any) -> Any:
        values = []
        for k0 in k0s:
            sphere = tr.sphere_tmatrix(
                k0=float(k0),
                lmax=lmax,
                radius=radius,
                material=epsilon,
                medium=1.0,
            )
            incident = tr.plane_wave(
                [0.0, 0.0, 1.0],
                "positive_helicity",
                k0=float(k0),
                medium=1.0,
            )
            cross_section = sphere.cross_sections(incident).scattering
            values.append(cross_section / (np.pi * radius * radius))
        return anp.stack(values)

    def objective(radius: Any) -> Any:
        relative_residual = (efficiencies(radius) - targets) / targets
        return anp.mean(relative_residual * relative_residual)

    value_and_gradient = ad.value_and_grad(objective)
    span = upper - lower

    def evaluate(x: float) -> tuple[float, float]:
        radius = lower + span * x
        value, gradient_radius = value_and_gradient(radius)
        return float(value), float(gradient_radius) * span

    # Optimize in a dimensionless coordinate. In one dimension, the inverse-BFGS
    # update is the positive secant slope; Armijo backtracking keeps every trial
    # and accepted iterate inside the supplied bounds.
    x = (initial - lower) / span
    loss, gradient_x = evaluate(x)
    initial_loss = loss
    history = [loss]
    inverse_hessian = 1.0

    for _ in range(100):
        if loss <= 1e-15 or abs(gradient_x) <= 1e-12:
            break

        direction = -inverse_hessian * gradient_x
        if not math.isfinite(direction) or direction * gradient_x >= 0:
            direction = -gradient_x

        accepted = False
        step = 1.0
        old_x, old_loss, old_gradient = x, loss, gradient_x
        for _ in range(60):
            trial_x = min(1.0, max(0.0, old_x + step * direction))
            displacement = trial_x - old_x
            if displacement == 0.0:
                step *= 0.5
                continue
            trial_loss, trial_gradient = evaluate(trial_x)
            if (
                math.isfinite(trial_loss)
                and math.isfinite(trial_gradient)
                and trial_loss <= old_loss + 1e-4 * old_gradient * displacement
            ):
                x, loss, gradient_x = trial_x, trial_loss, trial_gradient
                accepted = True
                break
            step *= 0.5

        if not accepted:
            break
        history.append(loss)

        s = x - old_x
        y = gradient_x - old_gradient
        if s * y > 1e-20:
            inverse_hessian = min(1e6, max(1e-10, s / y))
        else:
            inverse_hessian = 1.0 / max(1.0, abs(gradient_x))

        if abs(s) <= 2e-14 * max(1.0, abs(x)):
            break

    radius = lower + span * x
    final_loss, final_gradient = value_and_gradient(radius)
    fitted = efficiencies(radius)

    return {
        "radius": float(radius),
        "loss": float(final_loss),
        "initial_loss": float(initial_loss),
        "gradient": float(final_gradient),
        "fitted_efficiencies": [float(v) for v in np.asarray(fitted)],
        "loss_history": [float(v) for v in history],
    }


def main() -> None:
    config = json.load(sys.stdin)
    if not isinstance(config, dict):
        raise TypeError("standard input must contain one JSON object")
    json.dump(run(config), sys.stdout, allow_nan=False)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
