# /// script
# requires-python = ">=3.12"
# dependencies = []
# ///
"""Replay frozen final submissions on a reviewed wheel without new agent calls.

Run with the repository's development environment; tool processes see only the
environment specified by --env. Existing submissions and scores are read only.
"""

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--env", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
os.environ["TREAMS_EVAL_VENV"] = str(args.env)
sys.path.insert(0, str(args.repo / "scripts/agent_eval"))
from grade import grade_run

root = args.repo / "benchmarks/results/agent-api-20260920"
tasks = {}
for name in ("reference.json", "candidate4-reference.json"):
    reference = args.repo / "benchmarks/agent-api" / name
    tasks.update({t["id"]: t for t in json.loads(reference.read_text())})
    shutil.copy2(reference, args.output / name)
previous = {}
jobs = []
for cohort in ("candidate4-r123", "candidate4-transfer"):
    for score in json.loads((root / cohort / "scores.json").read_text()):
        previous[score["trial"]] = score["outcome"]
    for run in sorted((root / cohort).glob("*/*/repeat-*/run.json")):
        log = args.output / run.parent.relative_to(root)
        log.mkdir(parents=True)
        record = json.loads(run.read_text())
        trial = args.output / "trials" / run.parent.relative_to(root)
        shutil.copytree(record["trial"], trial, symlinks=True)
        record["original_trial"] = record["trial"]
        record["trial"] = str(trial)
        record["venv"] = str(args.env)
        (log / "run.json").write_text(json.dumps(record, indent=2) + "\n")
        jobs.append(log)

def replay(log):
    score = grade_run(log, tasks)
    (log / "grade.json").write_text(json.dumps(score, indent=2) + "\n")
    source = Path(score["trial"]) / "solution.py"
    return {
        "attempt": str(log.relative_to(args.output)),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "previous_outcome": previous[score["original_trial"]],
        "outcome": score["outcome"],
        "checks": score["checks"],
    }

with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(replay, jobs))
summary = {
    "kind": "Saved-solution compatibility replay; no fresh agents or agent timing",
    "attempts": len(results),
    "outcomes": dict(Counter(r["outcome"] for r in results)),
    "changed_outcomes": [r["attempt"] for r in results if r["outcome"] != r["previous_outcome"]],
    "grader_sha256": hashlib.sha256((args.repo / "scripts/agent_eval/grade.py").read_bytes()).hexdigest(),
    "results": results,
}
(args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
shutil.copy2(__file__, args.output / "replay.py")
print(json.dumps({k: v for k, v in summary.items() if k != "results"}, indent=2))
assert len(results) == 160
assert not summary["changed_outcomes"]
