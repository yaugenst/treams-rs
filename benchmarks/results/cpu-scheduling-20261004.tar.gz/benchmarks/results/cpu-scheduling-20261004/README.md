# CPU scheduling qualification, 2026-10-04

No measurement was rerun for publication. The tracked qualification is
benchmarks/cpu-scheduling-20261004.json; docs/performance/cpu-speedups.md explains
its relationship to the separate preceding CPU evidence archive.

Selected candidate: work-cap-inline, native SHA-256
41748dd504e744b58c14842390c6aa5015591328c3bfe7f3de5e5f4998a3c6dd.
Final results: final-inline-vs-v010-32threads.json (12 cases, seven rounds),
final-inline-vs-v010-4threads.json (two controls, seven rounds), and
final-inline-main-targets-4threads.json (two dominant targets, three rounds).
final-inline-bits.json checks six final-build workflows across native budgets
1/4/16/32 with BLAS fixed at one. This does not establish bitwise equality to
0.1.0, which has its own numerical comparison gate.

All exploratory screens, null controls, rechecks and rejected variants are kept.
Files starting final-vs- (without inline) measure the REJECTED <=4-budget branch.
The selected final build is 29.8% slower than stage6 for N16 at four threads;
the rejected branch is 32.9% slower. Final-versus-original-0.1.0 controls pass.
The first work-cap variant has the same worker cap without the early serial
shortcut; its 1/16-thread screens and shape sweep are not final-build timing.

Source provenance is reconstructed, not recorded contemporaneously at build:
selected-source.json derives from the immediately subsequent rejected-variant
snapshot by restoring threads.rs. reconstruction.json describes verification.
selected-reconstructed.patch applies to 8bbcb87aaeaccd9293fc8c09eecb8727c37c4970;
all 180 native/Python/manifest source hashes match selected-source.json. It also
includes two supporting build inputs recorded at publication. This is not a
snapshot of all as-run documentation/tests. Restore compare_builds-as-run.py to
scripts/compare_builds.py and _harness.py to scripts/_harness.py for timing replay.
The repository harness was simplified AFTER timing; the archived hash is as-run.
Rebuild baseline and candidate packages separately; binaries are not archived.

The final build contains preceding CPU work and sw/plan allocation pruning as
well as the scheduling cap. Final-versus-0.1.0 results measure that combination;
they do not isolate all changes. No scheduling memory measurements were made.
See the preceding CPU record for the retained periodic memory-growth failures.

manifest.json gives original sha256 and distributed sanitized_sha256 values.
Original result/source fingerprints remain unchanged. Only incidental repository
paths and the private host label are redacted; JSON numerical values, timing
samples, outcomes and all other strings are unchanged. Archive owners and times
are neutral. Scripts retain their original local directory assumptions.
