# /// script
# requires-python = ">=3.12"
# dependencies = ["numpy>=2.1,<3"]
# ///
"""Untimed cross-budget checks of selected complete workflows on the final build."""

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--tree", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[4]
os.environ.update(TREAMS_RS_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
sys.path[:0] = [str(args.tree.resolve()), str(root / "scripts")]
import compare_builds as compare
import numpy as np
import treams_rs as tr

def digest(value):
    result = hashlib.sha256()
    def add(item):
        if isinstance(item, (tuple,list)):
            for child in item:
                add(child)
        else:
            array = np.asarray(item,dtype=np.complex128)
            assert np.isfinite(array).all()
            result.update(str(array.shape).encode())
            result.update(array.tobytes())
    add(value)
    return result.hexdigest()

results = {}
for name in ("cluster-solve-n16", "stack-power-h64", "stack-power-h256", "periodic-array-n4-l6-size1-gradient", "slab-internal-h1024-gradient", "iterative-n512-l1-p8-gradient"):
    tr.set_num_threads(1)
    run = compare.CALLS[name](tr)
    bits = {}
    for budget in (1,4,16,32):
        tr.set_num_threads(budget)
        bits[budget] = digest(run())
    results[name] = {"output_sha256": bits,"same_bits":len(set(bits.values()))==1}
    print(name,results[name]["same_bits"],flush=True)
result = {"native":compare.provenance(args.tree), "script_sha256":compare.file_sha256(__file__), "cpu_affinity":compare.cpu_affinity(), "blas_threads":1,"cases":results}
with args.output.open("x") as stream:
    json.dump(result,stream,indent=2)
    stream.write("\n")
assert all(case["same_bits"] for case in results.values())
