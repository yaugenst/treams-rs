# /// script
# requires-python = ">=3.12"
# dependencies = ["numpy>=2.1,<3"]
# ///
"""Native-budget sweep of actual stack and rectangular illumination workflows."""

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--tree", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--reverse", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parents[4]
os.environ.update(TREAMS_RS_NUM_THREADS="32", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", BLIS_NUM_THREADS="1")
sys.path[:0] = [str(args.tree.resolve()), str(root / "scripts")]
import compare_builds as compare
import numpy as np
import treams_rs as tr

def digest(value):
    flat = np.asarray(compare.values(value), dtype=np.complex128)
    assert np.isfinite(flat).all()
    return hashlib.sha256(flat.tobytes()).hexdigest()

def stack(modes, gradient=False):
    ports = compare._ports(tr, modes)
    lower = tr.slab(k0=1.3, basis=ports, thickness=0.3, material=2.3+0.1j)
    upper = tr.slab(k0=1.3, basis=ports, thickness=0.2, material=1.7+0.05j)
    if gradient:
        def run():
            value, context = tr.diff.smatrix_add(lower.array, upper.array)
            return (abs(value)**2).sum(), context.pullback(2*value)
        return run
    amplitudes = compare._amplitudes(modes)
    return lambda: tuple(tr.stack([lower, upper]).power(amplitudes))

def illumination(modes, columns, gradient=False):
    ports = compare._ports(tr, modes)
    lower = tr.slab(k0=1.3, basis=ports, thickness=0.3, material=2.3+0.1j)
    upper = tr.slab(k0=1.3, basis=ports, thickness=0.2, material=1.7+0.05j)
    rng = np.random.default_rng(29)
    up = rng.normal(size=(modes, columns)) + 1j*rng.normal(size=(modes, columns))
    down = .1*(rng.normal(size=(modes, columns)) + 1j*rng.normal(size=(modes, columns)))
    def run():
        value, context = tr.diff.smatrix_illuminate(lower.array, upper.array, up, down)
        return ((abs(value)**2).sum(), context.pullback(2*value)) if gradient else value
    return run

calls = {f"stack-h{n}": lambda n=n: stack(n) for n in (32,64,96,128,192,256,512)}
calls.update({f"illumination-h{n}-p{p}": lambda n=n,p=p: illumination(n,p) for n,p in ((64,4),(256,4),(768,4),(128,32),(512,32))})
calls["stack-h128-gradient"] = lambda: stack(128,True)
calls["illumination-h256-p4-gradient"] = lambda: illumination(256,4,True)
budgets = [1,4,16,32]
if args.reverse:
    budgets.reverse()
results = {}
for name, setup in calls.items():
    tr.set_num_threads(1)
    run = setup()
    expected = digest(run())
    records = {}
    for budget in budgets:
        tr.set_num_threads(budget)
        actual = digest(run())
        records[budget] = {"seconds": compare.time_call(run,min_sample=.08,samples=3), "same_bits_as_one_thread": actual==expected, "output_sha256": actual}
    results[name] = records
    print(name, {budget:round(record["seconds"]*1000,3) for budget,record in records.items()}, flush=True)
result = {"scope":"Prepared physical slabs; native budget varies; BLAS fixed at one; setup and thread-budget changes outside timing; stack forward times one Redheffer composition plus power; gradient includes composition forward and pullback.", "native":compare.provenance(args.tree), "script_sha256":compare.file_sha256(__file__), "cpu_affinity":compare.cpu_affinity(), "blas_threads":1, "results":results}
with args.output.open("x") as stream:
    json.dump(result,stream,indent=2)
    stream.write("\n")
