# /// script
# requires-python = ">=3.12"
# dependencies = []
# ///
"""Package frozen scheduling evidence; perform no measurements or builds."""

import difflib
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
import tempfile
from pathlib import Path

root = Path.cwd()
source = root / "benchmarks/results/local/cpu-scheduling-20261004"
summary = json.loads((source / "summary.json").read_text())
identity = json.loads((source / "selected-source.json").read_text())
prefix = "benchmarks/results/cpu-scheduling-20261004"
public_path = root / f"{prefix}.tar.gz"
private_path = source / "publication-original.tar.gz"


def sha(data):
    return hashlib.sha256(data).hexdigest()


preserved_paths = [root / "benchmarks/cpu-speedups-20261004.json", root / "benchmarks/results/cpu-speedups-20261004.tar.gz"]
preserved = {path: sha(path.read_bytes()) for path in preserved_paths}
selected = {}
for path, expected in identity["source_sha256"].items():
    snapshot = {
        "crates/treams-core/src/threads.rs": "selected-threads.rs",
        "crates/treams-core/src/smatrix/solve.rs": "selected-solve.rs",
        "crates/treams-core/src/special/bessel.rs": "selected-bessel.rs",
    }.get(path)
    data = (source / snapshot if snapshot else root / path).read_bytes()
    assert sha(data) == expected, path
    selected[path] = data
# These build inputs supplement the native/Python hash inventory. Their hashes
# are publication-time reconstruction facts, not original build-time fingerprints.
extra = ["pyproject.toml", "crates/treams-core/references/spherical_hankel.txt"]
for path in extra:
    selected[path] = (root / path).read_bytes()

base_files = {}
patches = []
for path, data in sorted(selected.items()):
    result = subprocess.run(["git", "show", f"{identity['base_commit']}:{path}"], cwd=root, capture_output=True)
    before = result.stdout if result.returncode == 0 else b""
    base_files[path] = before if result.returncode == 0 else None
    if before != data:
        patches.append("".join(difflib.unified_diff(
            before.decode().splitlines(keepends=True), data.decode().splitlines(keepends=True),
            fromfile=f"a/{path}" if result.returncode == 0 else "/dev/null", tofile=f"b/{path}",
        )))
patch = "".join(patches).encode()
(source / "selected-reconstructed.patch").write_bytes(patch)
with tempfile.TemporaryDirectory(prefix="treams-scheduling-replay-") as temporary:
    tree = Path(temporary)
    for path, data in base_files.items():
        if data is not None:
            target = tree / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    subprocess.run(["git", "apply", "--unsafe-paths", f"--directory={tree}", str(source / "selected-reconstructed.patch")], check=True, cwd=root)
    for path, data in selected.items():
        assert (tree / path).read_bytes() == data, path
reconstruction = {
    "kind": "Publication-time source reconstruction, not a contemporaneous build snapshot",
    "base_commit": identity["base_commit"],
    "patch": "selected-reconstructed.patch",
    "patch_sha256": sha(patch),
    "basis": identity["snapshot_provenance"],
    "scope": "Native and Python source inventory plus two supporting build inputs; not the whole as-run documentation/test tree.",
    "verified_source_files": len(identity["source_sha256"]),
    "all_selected_source_hashes_match": True,
    "patch_replayed_from_base_and_all_payloads_verified": True,
    "additional_build_inputs_sha256": {path: sha(selected[path]) for path in extra},
    "additional_input_provenance": "Current supporting manifest and reference table captured for replay after timing; not present in the original source hash inventory.",
    "measured_harness": summary["harness_snapshot"],
    "measured_harness_sha256": summary["harness_sha256"],
}
(source / "reconstruction.json").write_text(json.dumps(reconstruction, indent=2) + "\n")
names = set(summary["artifacts"]) | {"summary.json", "selected-reconstructed.patch", "reconstruction.json", "package_evidence.py"}
original = {name: (source / name).read_bytes() for name in sorted(names)}
for name, expected in summary["artifacts"].items():
    assert sha(original[name]) == expected, name
assert sha(original[summary["harness_snapshot"]]) == summary["harness_sha256"]
for name in summary["final_qualification"]:
    record = json.loads(original[name])
    assert record["candidate"] == summary["selected_native"]
    assert record["benchmark_sha256"] == summary["harness_sha256"]

private_hosts = {
    document["host"]
    for name, data in original.items()
    if name.endswith(".json")
    and isinstance(document := json.loads(data), dict)
    and isinstance(document.get("host"), str)
}


def sanitize(text):
    text = text.replace(str(root), "<repository>")
    for host in private_hosts:
        text = text.replace(host, "<benchmark-host>")
    return text


distributed = {name: sanitize(data.decode()).encode() for name, data in original.items()}
numeric_count = 0


def check_json(before, after):
    global numeric_count
    assert type(before) is type(after)
    if isinstance(before, dict):
        assert before.keys() == after.keys()
        for key in before:
            check_json(before[key], after[key])
    elif isinstance(before, list):
        assert len(before) == len(after)
        for first, second in zip(before, after, strict=True):
            check_json(first, second)
    elif isinstance(before, str):
        assert sanitize(before) == after
    elif isinstance(before, float):
        assert before.hex() == after.hex()
        numeric_count += 1
    else:
        assert before == after
        numeric_count += 1


for name, data in original.items():
    if name.endswith(".json"):
        check_json(json.loads(data), json.loads(distributed[name]))
    assert str(root).encode() not in distributed[name]
    assert all(host.encode() not in distributed[name] for host in private_hosts)

readme = """# CPU scheduling qualification, 2026-10-04

No measurement was rerun for publication. The tracked qualification is
benchmarks/cpu-scheduling-20261004.json; docs/performance/cpu-speedups.md explains
its relationship to the separate preceding CPU evidence archive.

Selected candidate: work-cap-inline, native SHA-256
41748dd504e744b58c14842390c6aa5015591328c3bfe7f3de5e5f4998a3c6dd.
Final results: final-inline-vs-v010-32threads.json (12 cases, seven rounds),
final-inline-vs-v010-4threads.json (two controls, seven rounds), and
final-inline-main-targets-4threads.json (two dominant targets, three rounds).
final-inline-bits.json checks six final-build workflows across native budgets
1/4/16/32 with BLAS fixed at one. This does not establish bitwise equality to
0.1.0, which has its own numerical comparison gate.

All exploratory screens, null controls, rechecks and rejected variants are kept.
Files starting final-vs- (without inline) measure the REJECTED <=4-budget branch.
The selected final build is 29.8% slower than stage6 for N16 at four threads;
the rejected branch is 32.9% slower. Final-versus-original-0.1.0 controls pass.
The first work-cap variant has the same worker cap without the early serial
shortcut; its 1/16-thread screens and shape sweep are not final-build timing.

Source provenance is reconstructed, not recorded contemporaneously at build:
selected-source.json derives from the immediately subsequent rejected-variant
snapshot by restoring threads.rs. reconstruction.json describes verification.
selected-reconstructed.patch applies to 8bbcb87aaeaccd9293fc8c09eecb8727c37c4970;
all 180 native/Python/manifest source hashes match selected-source.json. It also
includes two supporting build inputs recorded at publication. This is not a
snapshot of all as-run documentation/tests. Restore compare_builds-as-run.py to
scripts/compare_builds.py and _harness.py to scripts/_harness.py for timing replay.
The repository harness was simplified AFTER timing; the archived hash is as-run.
Rebuild baseline and candidate packages separately; binaries are not archived.

The final build contains preceding CPU work and sw/plan allocation pruning as
well as the scheduling cap. Final-versus-0.1.0 results measure that combination;
they do not isolate all changes. No scheduling memory measurements were made.
See the preceding CPU record for the retained periodic memory-growth failures.

manifest.json gives original sha256 and distributed sanitized_sha256 values.
Original result/source fingerprints remain unchanged. Only incidental repository
paths and the private host label are redacted; JSON numerical values, timing
samples, outcomes and all other strings are unchanged. Archive owners and times
are neutral. Scripts retain their original local directory assumptions.
""".encode()
manifest = {
    "schema_version": 1,
    "scope": "Final scheduling qualification and retained intermediate failures; privacy-only distribution copies",
    "measurements_rerun": False,
    "base_commit": identity["base_commit"],
    "reconstructed_patch_sha256": sha(patch),
    "as_run_native_sha256": summary["selected_native"]["native_sha256"],
    "json_non_string_primitives_verified": numeric_count,
    "files": {name: {"sha256": sha(original[name]), "sanitized_sha256": sha(distributed[name]), "bytes": len(distributed[name])} for name in sorted(original)},
}
for payload in (original, distributed):
    payload["README.md"] = readme
    payload["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()


def archive(payload):
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as tar:
            for name, data in sorted(payload.items()):
                info = tarfile.TarInfo(f"{prefix}/{name}")
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
    return stream.getvalue()


private_bytes, public_bytes = archive(original), archive(distributed)
private_path.write_bytes(private_bytes)
public_path.write_bytes(public_bytes)
with tarfile.open(fileobj=io.BytesIO(public_bytes), mode="r:gz") as tar:
    assert len(tar.getmembers()) == len(distributed)
    for member in tar:
        name = member.name.removeprefix(prefix + "/")
        assert member.uid == member.gid == member.mtime == 0
        assert member.uname == member.gname == ""
        assert tar.extractfile(member).read() == distributed[name]

qualification = {
    "schema_version": 1,
    "kind": "CPU scheduling qualification with separate original-release and intermediate comparators",
    "recorded_at": summary["recorded_at"],
    "source": {
        "baseline_tag": "v0.1.0",
        "baseline_commit": identity["base_commit"],
        "candidate": "Selected work-cap-inline build, including preceding CPU work and sw/plan allocation pruning",
        "native": summary["selected_native"],
        "benchmark_sha256": summary["harness_sha256"],
        "source_identity": f"{prefix}/selected-source.json",
        "source_snapshot_provenance": identity["snapshot_provenance"],
        "reconstruction": reconstruction,
    },
    "policy": summary["policy"],
    "environment": {"cpu": "AMD Ryzen 9 9950X, 16 physical cores / 32 logical CPUs", "platform": "Linux", "precision": "complex128/f64", "profile": identity["profile"]},
    "measurement": {
        "processes": "Fresh sequential per-case workers, alternating tree order; input preparation excluded",
        "32_threads": {"cpu_affinity": list(range(32)), "rounds": 7, "samples": 3, "minimum_sample_seconds": 0.08},
        "4_thread_controls": {"cpu_affinity": [8, 9, 10, 11], "rounds": 7, "samples": 3, "minimum_sample_seconds": 0.12},
        "ratio": "Median paired candidate/baseline time; smaller is faster",
    },
    "final_qualification": summary["final_qualification"],
    "bitwise_qualification": summary["bitwise_qualification"],
    "exploratory_shapes": summary["exploratory_shapes"],
    "retained_failed_gates": summary["retained_failed_gates"],
    "interpretation": summary["interpretation"],
    "limitations": summary["limitations"] + ["No scheduling memory run; preceding memory exceptions remain applicable evidence limits.", "Selected source snapshot is reconstructed from the immediately following rejected variant, not recorded at selected-build time.", "The full 1300-case benchmark grid was not replayed."],
    "preceding_qualification": "benchmarks/cpu-speedups-20261004.json",
    "evidence_archive": {
        "path": str(public_path.relative_to(root)), "sha256": sha(public_bytes), "bytes": len(public_bytes), "files": len(distributed),
        "manifest": f"{prefix}/manifest.json", "extract_from_repository_root": f"tar -xzf {public_path.relative_to(root)}",
        "privacy_provenance": "benchmarks/privacy-provenance.json",
    },
}
(root / "benchmarks/cpu-scheduling-20261004.json").write_text(json.dumps(qualification, indent=2) + "\n")
privacy_path = root / "benchmarks/privacy-provenance.json"
privacy = json.loads(privacy_path.read_text())
artifact_path = str(public_path.relative_to(root))
assert all(item["path"] != artifact_path for item in privacy["artifacts"])
privacy["artifacts"].append({
    "path": artifact_path, "original_archive": str(private_path.relative_to(root)),
    "original_sha256": sha(private_bytes), "sanitized_sha256": sha(public_bytes),
    "operation": "Publish final CPU scheduling evidence and all intermediate results; original distribution revision above does not apply to this new archive.",
    "source_base_commit": identity["base_commit"], "reconstructed_source_patch_sha256": sha(patch),
    "source_snapshot_provenance": identity["snapshot_provenance"], "measurements_rerun": False,
    "verification": {
        "json_non_string_primitives_checked": numeric_count, "payload_files": len(manifest["files"]), "archive_members": len(distributed),
        "all_other_strings_unchanged": True, "as_run_fingerprints_preserved": True,
        "archive_members_read_back_byte_identical": True, "neutral_archive_metadata": True,
        "removed": ["Incidental repository absolute path", "Private benchmark host label"],
    },
})
privacy_path.write_text(json.dumps(privacy, indent=2) + "\n")
for path, expected in preserved.items():
    assert sha(path.read_bytes()) == expected, path
print(json.dumps(qualification["evidence_archive"], indent=2))
print(f"Verified {numeric_count} non-string JSON primitives; all preceding artifacts unchanged.")
print(f"Replayed {len(selected)} source/build inputs, {len(identity['source_sha256'])} match original selected-source inventory.")
